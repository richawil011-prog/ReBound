// Falling debris and spray, for the towers, the span and the end of every cycle.
import * as THREE from '../../vendor/three.module.min.js';

const ND = 260, NS = 900;
const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v = new THREE.Vector3(), s = new THREE.Vector3();

export class FX {
  constructor(scene) {
    const mat = new THREE.MeshStandardMaterial({ color: 0x6a655f, roughness: 0.95 });
    this.debris = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), mat, ND);
    this.debris.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.debris.castShadow = true;
    this.debris.frustumCulled = false;
    this.d = [];
    for (let i = 0; i < ND; i++) this.d.push({ live: 0, p: new THREE.Vector3(), vel: new THREE.Vector3(), r: new THREE.Vector3(), w: new THREE.Vector3(), s: 1 });
    this.di = 0;
    for (let i = 0; i < ND; i++) { m4.makeScale(0, 0, 0); this.debris.setMatrixAt(i, m4); }
    scene.add(this.debris);

    const g = new THREE.BufferGeometry();
    this.sp = new Float32Array(NS * 3); this.sa = new Float32Array(NS);
    this.sv = new Float32Array(NS * 3); this.sl = new Float32Array(NS);
    g.setAttribute('position', new THREE.BufferAttribute(this.sp, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('alpha', new THREE.BufferAttribute(this.sa, 1).setUsage(THREE.DynamicDrawUsage));
    const pm = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: 'attribute float alpha; varying float vA; void main(){ vA = alpha; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_Position = projectionMatrix * mv; gl_PointSize = 260.0 * (0.4 + alpha) / max(1.0, -mv.z); }',
      fragmentShader: 'varying float vA; void main(){ float d = length(gl_PointCoord - 0.5); float a = smoothstep(0.5, 0.1, d) * vA; gl_FragColor = vec4(vec3(0.75, 0.85, 0.9) * a * 0.55, 1.0); }'
    });
    this.spray = new THREE.Points(g, pm);
    this.spray.frustumCulled = false;
    scene.add(this.spray);
    this.si = 0;
  }
  burst(x, y, z, n = 8, spread = 3, speed = 3) {
    for (let k = 0; k < n; k++) {
      const d = this.d[this.di]; this.di = (this.di + 1) % ND;
      d.live = 1; d.s = 0.25 + Math.random() * 0.9;
      d.p.set(x + (Math.random() - 0.5) * spread, y + Math.random() * 1.5, z + (Math.random() - 0.5) * spread);
      d.vel.set((Math.random() - 0.5) * speed, Math.random() * speed * 0.6, (Math.random() - 0.5) * speed);
      d.r.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
      d.w.set((Math.random() - 0.5) * 6, (Math.random() - 0.5) * 6, (Math.random() - 0.5) * 6);
    }
  }
  splash(x, y, z, size = 1) {
    const n = Math.floor(24 * size);
    for (let k = 0; k < n; k++) {
      const i = this.si; this.si = (this.si + 1) % NS;
      const a = Math.random() * Math.PI * 2, r = Math.random() * size;
      this.sp[i * 3] = x + Math.cos(a) * r; this.sp[i * 3 + 1] = y; this.sp[i * 3 + 2] = z + Math.sin(a) * r;
      this.sv[i * 3] = Math.cos(a) * (1 + Math.random() * 2) * size; this.sv[i * 3 + 1] = (3 + Math.random() * 6) * Math.sqrt(size); this.sv[i * 3 + 2] = Math.sin(a) * (1 + Math.random() * 2) * size;
      this.sl[i] = 1;
    }
  }
  clear() {
    for (const d of this.d) d.live = 0;
    this.sl.fill(0); this.sa.fill(0);
    for (let i = 0; i < ND; i++) { m4.makeScale(0, 0, 0); this.debris.setMatrixAt(i, m4); }
    this.debris.instanceMatrix.needsUpdate = true;
    this.spray.geometry.attributes.alpha.needsUpdate = true;
  }
  update(dt, sea) {
    let any = false;
    for (let i = 0; i < ND; i++) {
      const d = this.d[i];
      if (!d.live) continue;
      any = true;
      d.vel.y -= 14 * dt;
      d.p.addScaledVector(d.vel, dt);
      d.r.addScaledVector(d.w, dt);
      if (d.p.y < sea && d.vel.y < -4) { if (Math.random() < 0.5) this.splash(d.p.x, sea, d.p.z, 0.5 * d.s); d.vel.multiplyScalar(0.15); }
      if (d.p.y < sea - 6) { d.live = 0; m4.makeScale(0, 0, 0); this.debris.setMatrixAt(i, m4); continue; }
      q.setFromEuler(e.set(d.r.x, d.r.y, d.r.z));
      m4.compose(d.p, q, s.setScalar(d.s));
      this.debris.setMatrixAt(i, m4);
    }
    if (any) this.debris.instanceMatrix.needsUpdate = true;
    let spray = false;
    for (let i = 0; i < NS; i++) {
      if (this.sl[i] <= 0) continue;
      spray = true;
      this.sl[i] -= dt * 0.7;
      this.sv[i * 3 + 1] -= 12 * dt;
      this.sp[i * 3] += this.sv[i * 3] * dt; this.sp[i * 3 + 1] += this.sv[i * 3 + 1] * dt; this.sp[i * 3 + 2] += this.sv[i * 3 + 2] * dt;
      this.sa[i] = Math.max(0, this.sl[i]);
      if (this.sp[i * 3 + 1] < sea - 0.5) this.sl[i] = 0, this.sa[i] = 0;
    }
    if (spray || this._spray) { this.spray.geometry.attributes.position.needsUpdate = true; this.spray.geometry.attributes.alpha.needsUpdate = true; }
    this._spray = spray;
  }
}
