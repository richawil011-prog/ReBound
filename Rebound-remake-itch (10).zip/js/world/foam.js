// Foam where the sea meets the world: every steep face that crosses the waterline gets a strip of
// broken white water along it, pushed outward from the face. Built once from the merged chunk
// geometry, drawn as a single mesh. A chunk's foam is hidden as soon as that chunk starts to
// move (towers falling, platforms sinking), and all of it fades while the sea rises at the end.
import * as THREE from '../../vendor/three.module.min.js';

const MAX_CHUNKS = 64;

export function buildFoam(W) {
  const pos = [], attr = [], ids = [];
  const owners = [];
  const near = [];
  const inside = (x, z) => {
    W.phys.near(x, z, 0.6, near);
    for (const c of near) {
      if (c.chunk && c.chunk.dynamic) continue;
      if (c.type === 'cyl') { if (c.y0 < 0.25 && c.y1 > 0.25 && Math.hypot(x - c.x, z - c.z) < c.r) return true; continue; }
      if (c.type !== 'box') continue;
      if (c.y - c.hy > 0.25 || c.y + c.hy < 0.25) continue;
      const dx = x - c.x, dz = z - c.z, lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
      if (Math.abs(lx) < c.hx && Math.abs(lz) < c.hz) return true;
    }
    return false;
  };
  const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3(), e1 = new THREE.Vector3(), e2 = new THREE.Vector3(), n = new THREE.Vector3();
  const cut = [];
  const segs = [];
  const cross = (p, q) => { const t = p.y / (p.y - q.y); cut.push([p.x + (q.x - p.x) * t, p.z + (q.z - p.z) * t]); };

  for (const ch of W.chunks) {
    if (ch.name === 'people') continue;
    let idx = -1;
    for (const m of ch.group.children) {
      if (!m.isMesh || m.isInstancedMesh) continue;
      const mat = m.material;
      if (mat.transparent || mat.isShaderMaterial || mat.isMeshBasicMaterial) continue;
      const P = m.geometry.attributes.position;
      if (!P || m.geometry.index) continue;
      const bb = m.geometry.boundingBox;
      if (bb && (bb.min.y > 0 || bb.max.y < 0)) continue;
      for (let i = 0; i < P.count; i += 3) {
        const y0 = P.getY(i), y1 = P.getY(i + 1), y2 = P.getY(i + 2);
        if (Math.min(y0, y1, y2) >= 0 || Math.max(y0, y1, y2) <= 0) continue;
        a.fromBufferAttribute(P, i); b.fromBufferAttribute(P, i + 1); c.fromBufferAttribute(P, i + 2);
        n.crossVectors(e1.subVectors(b, a), e2.subVectors(c, a));
        const L = n.length(); if (L < 1e-6) continue;
        n.divideScalar(L);
        if (Math.abs(n.y) > 0.75) continue;
        cut.length = 0;
        if ((a.y < 0) !== (b.y < 0)) cross(a, b);
        if ((b.y < 0) !== (c.y < 0)) cross(b, c);
        if ((c.y < 0) !== (a.y < 0)) cross(c, a);
        if (cut.length < 2) continue;
        const [p, q] = cut;
        const len = Math.hypot(q[0] - p[0], q[1] - p[1]);
        if (len < 0.05) continue;
        const h = Math.hypot(n.x, n.z), nx = n.x / h, nz = n.z / h;
        const mx = (p[0] + q[0]) / 2, mz = (p[1] + q[1]) / 2;
        const reg = W.regionAt(mx, 0, mz);
        if (reg === 'deep' || reg === 'core' || reg === 'station') continue;
        // faces that open into something solid (inner faces of walls, piles inside decks) get no foam
        if (inside(mx + nx * 0.45, mz + nz * 0.45)) continue;
        if (idx < 0) { if (owners.length >= MAX_CHUNKS) break; idx = owners.length; owners.push(ch); }
        segs.push({ p, q, nx, nz, idx });
      }
    }
  }
  // outer edges follow the averaged normal at each shared end, so strips join into rings.
  // Ends within 2 cm of each other are treated as the same point.
  const grid = new Map(), pts = [];
  const pointId = (x, z) => {
    const gx = Math.round(x / 0.03), gz = Math.round(z / 0.03);
    for (let i = -1; i <= 1; i++) for (let k = -1; k <= 1; k++) {
      const l = grid.get((gx + i) + ',' + (gz + k));
      if (l) for (const id of l) { const q = pts[id]; if (Math.abs(q.x - x) < 0.02 && Math.abs(q.z - z) < 0.02) return id; }
    }
    const id = pts.length; pts.push({ x, z, nx: 0, nz: 0 });
    const kk = gx + ',' + gz; (grid.get(kk) || grid.set(kk, []).get(kk)).push(id);
    return id;
  };
  for (const s of segs) {
    s.a = pointId(s.p[0], s.p[1]); s.b = pointId(s.q[0], s.q[1]);
    for (const id of [s.a, s.b]) { pts[id].nx += s.nx; pts[id].nz += s.nz; }
  }
  for (const q of pts) { const l = Math.hypot(q.nx, q.nz) || 1; q.nx /= l; q.nz /= l; }
  // strips joined into one loop share a width: a thin pile gets a narrow collar of foam rather than
  // a wide ring that reads as a starburst, long walls get the full width
  const root = pts.map((_, i) => i);
  const find = (i) => { while (root[i] !== i) i = root[i] = root[root[i]]; return i; };
  for (const s of segs) root[find(s.a)] = find(s.b);
  const perim = new Map();
  for (const s of segs) { const r = find(s.a); perim.set(r, (perim.get(r) || 0) + Math.hypot(s.q[0] - s.p[0], s.q[1] - s.p[1])); }
  for (const s of segs) s.w = Math.min(0.75, Math.max(0.16, perim.get(find(s.a)) * 0.3));
  for (const s of segs) {
    const W0 = s.w;
    const end = (id) => {
      const q = pts[id];
      const d = Math.max(0.45, q.nx * s.nx + q.nz * s.nz);
      return [[q.x - q.nx * 0.04, q.z - q.nz * 0.04], [q.x + q.nx * W0 / d, q.z + q.nz * W0 / d]];
    };
    const [Pi, Po] = end(s.a), [Qi, Qo] = end(s.b);
    const quad = [[Pi[0], Pi[1], 0], [Qi[0], Qi[1], 0], [Qo[0], Qo[1], 1], [Pi[0], Pi[1], 0], [Qo[0], Qo[1], 1], [Po[0], Po[1], 1]];
    for (const [x, z, e] of quad) { pos.push(x, 0, z); attr.push(e); ids.push(s.idx); }
  }
  if (!pos.length) return null;
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('edge', new THREE.Float32BufferAttribute(attr, 1));
  g.setAttribute('owner', new THREE.Float32BufferAttribute(ids, 1));
  g.computeBoundingSphere();
  const u = {
    time: { value: 0 },
    tint: { value: new THREE.Color(0.6, 0.62, 0.72) },
    fade: { value: 1 },
    hidden: { value: new Array(MAX_CHUNKS).fill(0) }
  };
  const mat = new THREE.ShaderMaterial({
    uniforms: u, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    vertexShader: `
      attribute float edge; attribute float owner;
      uniform float hidden[${MAX_CHUNKS}];
      varying float vE; varying vec3 vW;
      void main(){
        vE = edge;
        float h = hidden[int(owner + 0.5)];
        vec4 w = modelMatrix * vec4(position, 1.0);
        vW = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
        if (h > 0.5) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
      }`,
    fragmentShader: `
      uniform float time; uniform vec3 tint; uniform float fade;
      varying float vE; varying vec3 vW;
      float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
      void main(){
        vec2 p = vW.xz;
        float n = noise(p * 2.3 + vec2(time * 0.21, -time * 0.17)) * 0.6 + noise(p * 6.1 - vec2(time * 0.4, time * 0.33)) * 0.4;
        // a line of foam that breathes in and out from the wall
        float swell = 0.5 + 0.5 * sin(time * 0.9 + dot(p, vec2(0.37, 0.29)));
        float band = smoothstep(0.0, 0.08, vE) * (1.0 - smoothstep(0.25 + swell * 0.55, 1.0, vE));
        float lace = noise(p * 11.0 + vec2(time * 0.6, 0.0)) * noise(p * 17.0 - vec2(0.0, time * 0.5));
        float a = band * smoothstep(0.3, 0.7, n * 0.8 + (1.0 - vE) * 0.55 - vE * 0.25) * (0.55 + lace * 0.9);
        a *= exp(-length(vW - cameraPosition) * 0.008) * fade;
        if (a < 0.01) discard;
        gl_FragColor = vec4(tint * (0.8 + n * 0.5), min(0.75, a * 0.8));
      }`
  });
  const mesh = new THREE.Mesh(g, mat);
  mesh.renderOrder = 2;
  mesh.frustumCulled = false;
  W.scene.add(mesh);
  return {
    mesh, u,
    update(t, sea, fog) {
      u.time.value = t;
      mesh.position.y = sea + 0.02;
      u.fade.value = Math.max(0, 1 - Math.abs(sea) / 0.6);
      mesh.visible = u.fade.value > 0.01;
      for (let i = 0; i < owners.length; i++) {
        const gr = owners[i].group;
        u.hidden.value[i] = Math.abs(gr.position.y) > 0.05 || Math.abs(gr.rotation.x) + Math.abs(gr.rotation.z) > 0.002 || !gr.visible ? 1 : 0;
      }
      if (fog) u.tint.value.copy(fog).multiplyScalar(2.4).addScalar(0.3);
    },
    stats: () => ({ tris: pos.length / 9, chunks: owners.map(o => o.name) })
  };
}
