// Small life around the basin, none of which knows about the loop either:
//   fish that leap out of the water somewhere near you, with a ripple where they go in
//   butterflies in the glasshouse on Verdant Rise
//   fireflies over Lantern Isle once the evening comes on
//   dust turning slowly in the light of the Civic Archive's reading room
//   gulls on the Market Pier bollards that take off if you walk up to them
// Everything is instanced or a single Points cloud, so the lot costs a handful of draw calls.
import * as THREE from '../../vendor/three.module.min.js';

const tmp = new THREE.Object3D();
let seed = 31;
const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };

// a soft round dot for the glowing things
function dotTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.65)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// open water where a fish might jump: near the piers, the isles and the drowned quarter
const WATERS = [[-80, -132, 9], [-60, -138, 10], [-128, -76, 10], [-112, -186, 10], [-140, -170, 14], [68, -120, 10], [60, -92, 8], [-30, -140, 9]];
const GLASS = { x: -122, z: -203, y: 3.6 };
const ISLE = { x: -141, z: -60, y: 3.0 };
const ARCHIVE = { x0: 12.2, x1: 19.4, y0: 6.6, y1: 10.2, z0: -112.5, z1: -99.5 };

export class Life {
  constructor(W) {
    this.W = W;
    const scene = W.scene, dot = dotTexture();

    // ---- fish: a silver body with a darker back, leaping in an arc
    const fg = new THREE.SphereGeometry(1, 10, 6); fg.scale(0.06, 0.07, 0.22);
    const tail = new THREE.ConeGeometry(0.07, 0.12, 4); tail.rotateX(-Math.PI / 2); tail.translate(0, 0, -0.26);
    this.fish = new THREE.InstancedMesh(mergeTwo(fg, tail), new THREE.MeshStandardMaterial({ color: 0x9fb4bc, roughness: 0.35, metalness: 0.4 }), 3);
    this.fish.instanceMatrix.setUsage(THREE.DynamicDrawUsage); this.fish.frustumCulled = false; scene.add(this.fish);
    this.jumps = [{ t: -1 }, { t: -1 }, { t: -1 }];
    this.nextJump = 3;
    // ripples where they leave and land
    const rg = new THREE.RingGeometry(0.85, 1, 32); rg.rotateX(-Math.PI / 2);
    this.rippleMat = new THREE.MeshBasicMaterial({ color: 0xdfeef0, transparent: true, opacity: 0.5, depthWrite: false });
    this.ripples = [];
    for (let i = 0; i < 6; i++) { const m = new THREE.Mesh(rg, this.rippleMat.clone()); m.visible = false; scene.add(m); this.ripples.push({ m, t: 9 }); }

    // ---- butterflies: two wings hinged on a tiny body, warm orange and pale cyan
    const N = 7;
    const wing = new THREE.PlaneGeometry(0.15, 0.12); wing.translate(0.075, 0, 0); wing.rotateX(-Math.PI / 2);
    const wm = new THREE.MeshStandardMaterial({ side: THREE.DoubleSide, roughness: 0.8 });
    this.bl = new THREE.InstancedMesh(wing, wm, N); this.br = new THREE.InstancedMesh(wing, wm, N);
    const cols = [0xf2a65a, 0xe8d27a, 0x9fe0dc, 0xf2a65a, 0xffffff, 0xe88a5a, 0x9fe0dc];
    for (let i = 0; i < N; i++) { const c = new THREE.Color(cols[i % cols.length]); this.bl.setColorAt(i, c); this.br.setColorAt(i, c); }
    for (const m of [this.bl, this.br]) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; scene.add(m); }
    this.flies = Array.from({ length: N }, (_, i) => ({ ph: rnd() * 100, sp: 0.6 + rnd() * 0.5, ox: (rnd() - 0.5) * 7, oz: (rnd() - 0.5) * 10 }));

    // ---- fireflies over the isle
    const FN = 46, fp = new Float32Array(FN * 3);
    this.fireflies = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(fp, 3)),
      new THREE.PointsMaterial({ map: dot, color: new THREE.Color(0xd8ff8a).multiplyScalar(3), size: 0.16, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    this.fireflies.frustumCulled = false; scene.add(this.fireflies);
    this.ff = Array.from({ length: FN }, () => ({ a: rnd() * 6.28, r: 1 + rnd() * 8, y: rnd() * 2.2, sp: 0.15 + rnd() * 0.25, ph: rnd() * 10 }));

    // ---- dust in the archive's light
    const DN = 140, dp = new Float32Array(DN * 3);
    for (let i = 0; i < DN; i++) { dp[i * 3] = lerp(ARCHIVE.x0, ARCHIVE.x1, rnd()); dp[i * 3 + 1] = lerp(ARCHIVE.y0, ARCHIVE.y1, rnd()); dp[i * 3 + 2] = lerp(ARCHIVE.z0, ARCHIVE.z1, rnd()); }
    this.dust = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(dp, 3)),
      new THREE.PointsMaterial({ map: dot, color: 0xffe2b8, size: 0.035, transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending }));
    this.dust.frustumCulled = false; scene.add(this.dust);
    this.dustV = Array.from({ length: DN }, () => [(rnd() - 0.5) * 0.05, (rnd() - 0.5) * 0.03, (rnd() - 0.5) * 0.05]);

    // ---- gulls, perched round the fisherman, hoping
    this.gulls = GULL_PERCHES.map(([x, y, z, yaw], i) => {
      const m = gullModel(); m.g.position.set(x, y, z); m.g.rotation.y = yaw; scene.add(m.g);
      return { ...m, x, y, z, yaw, state: 'perch', t: 0, look: 0, lookT: rnd() * 2, ph: rnd() * 10, i };
    });
  }

  update(dt, t, st, cam, sea) {
    const W = this.W, near = (x, z, r) => Math.hypot(cam.x - x, cam.z - z) < r;
    // ---- fish
    this.nextJump -= dt;
    if (this.nextJump < 0) {
      this.nextJump = 4 + rnd() * 7;
      const spots = WATERS.filter(([x, z]) => near(x, z, 55));
      const j = this.jumps.find(j => j.t < 0 || j.t > 1.3);
      if (spots.length && j) {
        const [x, z, r] = spots[Math.floor(rnd() * spots.length)], a = rnd() * 6.28;
        j.x = x + Math.cos(a) * r * rnd(); j.z = z + Math.sin(a) * r * rnd(); j.h = rnd() * 6.28; j.t = 0; j.len = 1.4 + rnd() * 1.2; j.hi = 0.6 + rnd() * 0.6;
        this.ripple(j.x, j.z, sea);
        j.landed = false;
      }
    }
    this.jumps.forEach((j, i) => {
      if (j.t < 0 || j.t > 1) { tmp.position.set(0, -100, 0); tmp.updateMatrix(); this.fish.setMatrixAt(i, tmp.matrix); if (j.t >= 0) j.t += dt; return; }
      j.t += dt / 0.85;
      const k = Math.min(1, j.t), dx = Math.sin(j.h), dz = Math.cos(j.h);
      const y = sea + Math.sin(k * Math.PI) * j.hi - 0.1;
      tmp.position.set(j.x + dx * j.len * k, y, j.z + dz * j.len * k);
      tmp.rotation.set(-Math.cos(k * Math.PI) * 0.9, j.h, 0, 'YXZ');
      tmp.updateMatrix(); this.fish.setMatrixAt(i, tmp.matrix);
      if (k >= 1 && !j.landed) { j.landed = true; this.ripple(j.x + dx * j.len, j.z + dz * j.len, sea); if (W.sound && near(j.x, j.z, 25)) W.sound.plip && W.sound.plip(); }
    });
    this.fish.instanceMatrix.needsUpdate = true;
    for (const r of this.ripples) {
      r.t += dt;
      r.m.visible = r.t < 1.6;
      if (r.m.visible) { const s = 0.15 + r.t * 0.7; r.m.scale.set(s, 1, s); r.m.position.y = sea + 0.03; r.m.material.opacity = 0.45 * (1 - r.t / 1.6); }
    }

    // ---- now and then, a gull calls (outside, by the water, while there's still a world to call over)
    this.gullT = (this.gullT ?? 12) - dt;
    if (this.gullT < 0) {
      this.gullT = 18 + rnd() * 30;
      const outside = !['station', 'deep', 'core'].includes(W.regionKey);
      if (outside && W.sound && W.sound.gull && st.elapsed < 1250) W.sound.gull();
    }

    // ---- butterflies (only when you're near enough to see them)
    const glassNear = near(GLASS.x, GLASS.z, 40);
    this.bl.visible = this.br.visible = glassNear;
    if (glassNear) {
      this.flies.forEach((f, i) => {
        const tt = t * f.sp + f.ph;
        const x = GLASS.x + f.ox * 0.5 + Math.sin(tt * 0.7) * 2.2 + Math.sin(tt * 1.9) * 0.4;
        const z = GLASS.z + f.oz * 0.5 + Math.cos(tt * 0.5) * 3.0 + Math.cos(tt * 2.3) * 0.4;
        const y = GLASS.y + Math.sin(tt * 1.3) * 0.7 + Math.sin(tt * 4.1) * 0.12;
        const head = Math.atan2(Math.cos(tt * 0.7) * 0.7 * 2.2, -Math.sin(tt * 0.5) * 0.5 * 3.0);
        const flap = Math.sin(t * 22 + f.ph * 3) * 1.1;
        for (const [m, side] of [[this.br, 1], [this.bl, -1]]) {
          tmp.position.set(x, y, z); tmp.rotation.set(0, head + (side < 0 ? Math.PI : 0), side * flap, 'YXZ');
          tmp.updateMatrix(); m.setMatrixAt(i, tmp.matrix);
        }
      });
      this.bl.instanceMatrix.needsUpdate = this.br.instanceMatrix.needsUpdate = true;
    }

    // ---- fireflies: out from the early evening until the end comes, never in the morning after
    const dusk = st.ended ? 0 : smooth(950, 1080, st.elapsed) * (1 - smooth(1270, 1300, st.elapsed));
    const isleNear = near(ISLE.x, ISLE.z, 70);
    this.fireflies.visible = dusk > 0.01 && isleNear;
    if (this.fireflies.visible) {
      const P = this.fireflies.geometry.attributes.position;
      this.ff.forEach((f, i) => {
        f.a += dt * f.sp * 0.4;
        const r = f.r + Math.sin(t * 0.3 + f.ph) * 0.8;
        P.setXYZ(i, ISLE.x + Math.cos(f.a) * r, ISLE.y + 0.4 + f.y + Math.sin(t * 0.9 + f.ph) * 0.35, ISLE.z + Math.sin(f.a) * r);
      });
      P.needsUpdate = true;
      // they pulse, not all at once
      this.fireflies.material.opacity = dusk * (0.65 + 0.35 * Math.sin(t * 2.1));
    }

    // ---- gulls
    if (this.gullLoop !== st.loop || st.elapsed + 2 < (this.gullEl ?? 0)) { this.gullLoop = st.loop; for (const g of this.gulls) this.perch(g); }
    this.gullEl = st.elapsed;
    const leaving = (st.elapsed > 1235 && !st.ended) || !!W.cutscene;   // the end coming, or the pier filling with people
    for (const g of this.gulls) {
      const d = Math.hypot(cam.x - g.x, cam.z - g.z), dy = Math.abs(cam.y - g.y);
      if (g.state === 'perch') {
        g.g.visible = d < 60;
        if (!g.g.visible) continue;
        // little jerks of the head, now and then a shuffle of the wings
        g.lookT -= dt; if (g.lookT < 0) { g.lookT = 0.6 + rnd() * 2.4; g.look = (rnd() - 0.5) * 2.2; }
        g.head.rotation.y += (g.look - g.head.rotation.y) * Math.min(1, dt * 14);
        const shuffle = Math.max(0, Math.sin(t * 0.37 + g.ph) - 0.96) * 12;
        for (const [w, k] of [[g.wl, 1], [g.wr, -1]]) { w.rotation.set(0, k * 1.38, k * (0.1 + shuffle * 0.5)); }
        g.body.position.y = Math.sin(t * 2 + g.ph) * 0.002;
        if ((d < 3.4 && dy < 3) || leaving) {
          // off it goes: away from you, out over the water, climbing
          g.state = 'fly'; g.t = 0;
          const away = Math.atan2(g.x - cam.x, g.z - cam.z) + (rnd() - 0.5) * 0.8;
          g.dir = leaving ? g.yaw + (rnd() - 0.5) : away;
          if (W.sound && d < 30) { W.sound.flutter && W.sound.flutter(); if (rnd() < 0.6 && W.sound.gull) W.sound.gull(); }
        }
      } else if (g.state === 'fly') {
        g.t += dt;
        const sp = Math.min(6, 2 + g.t * 3), climb = g.t < 1 ? 2.2 : 0.9;
        g.g.position.x += Math.sin(g.dir) * sp * dt; g.g.position.z += Math.cos(g.dir) * sp * dt; g.g.position.y += climb * dt;
        g.dir += Math.sin(g.t * 0.7 + g.ph) * 0.25 * dt;
        g.g.rotation.set(-0.15, g.dir, Math.sin(g.t * 0.7 + g.ph) * 0.2, 'YXZ');
        const flap = g.t < 1.4 ? Math.sin(g.t * 26) * 0.9 : Math.sin(g.t * 9) * (Math.sin(g.t * 0.8) > 0 ? 0.5 : 0.08);
        g.wl.rotation.set(0, 0, flap); g.wr.rotation.set(0, 0, -flap);
        g.head.rotation.y *= 0.9;
        if (g.t > 9) { g.state = 'gone'; g.g.visible = false; g.t = 0; }
      } else if (g.state === 'gone') {
        g.t += dt;
        // back on its post once nobody's looking
        if (g.t > 25 && d > 22 && !leaving && !st.ended) this.perch(g);
      }
    }

    // ---- dust
    const archNear = cam.x > ARCHIVE.x0 - 8 && cam.x < ARCHIVE.x1 + 8 && cam.z > ARCHIVE.z0 - 8 && cam.z < ARCHIVE.z1 + 8;
    this.dust.visible = archNear;
    if (archNear) {
      const P = this.dust.geometry.attributes.position;
      for (let i = 0; i < this.dustV.length; i++) {
        const v = this.dustV[i];
        let x = P.getX(i) + (v[0] + Math.sin(t * 0.2 + i) * 0.01) * dt, y = P.getY(i) + (v[1] - 0.004) * dt, z = P.getZ(i) + (v[2] + Math.cos(t * 0.17 + i) * 0.01) * dt;
        if (y < ARCHIVE.y0) y = ARCHIVE.y1;
        if (x < ARCHIVE.x0) x = ARCHIVE.x1; if (x > ARCHIVE.x1) x = ARCHIVE.x0;
        if (z < ARCHIVE.z0) z = ARCHIVE.z1; if (z > ARCHIVE.z1) z = ARCHIVE.z0;
        P.setXYZ(i, x, y, z);
      }
      P.needsUpdate = true;
    }
  }

  perch(g) {
    g.state = 'perch'; g.t = 0; g.g.visible = true;
    g.g.position.set(g.x, g.y, g.z); g.g.rotation.set(0, g.yaw, 0);
  }

  ripple(x, z, sea) {
    const r = this.ripples.find(r => r.t > 1.6) || this.ripples[0];
    r.t = 0; r.m.position.set(x, sea + 0.03, z);
  }
}

// bollards and barrel tops on the Market Pier (WF 2)
const GULL_PERCHES = [[-56, 2.6, -121.6, 2.4], [-70.6, 2.6, -121.6, 0.4], [-47.6, 2.95, -128, 1.2], [-46.9, 2.95, -127.3, -0.8],
  [-114, 5.1, -208, 2.0], [-130, 3.45, -196, -1.0]];   // and two out on Verdant Rise: the water tank, a barrel

// a herring gull, about forty centimetres of it: white body and head, grey wings with black tips,
// a yellow beak, pink-orange legs. Wings hinge at the shoulder; folded along the back when perched
// built as four vertex-coloured meshes per bird (body, head, two wings) so a flock costs little
let gullMat = null;
function bake(parts) {
  const pos = [], nor = [], col = [], c = new THREE.Color();
  for (const [geo, color, m] of parts) {
    const g = geo.index ? geo.toNonIndexed() : geo; g.applyMatrix4(m);
    const P = g.attributes.position, N = g.attributes.normal; c.set(color);
    for (let i = 0; i < P.count; i++) { pos.push(P.getX(i), P.getY(i), P.getZ(i)); nor.push(N.getX(i), N.getY(i), N.getZ(i)); col.push(c.r, c.g, c.b); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  return g;
}
const at = (x, y, z, sx = 1, sy = 1, sz = 1, rx = 0, ry = 0, rz = 0) => new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(sx, sy, sz));
let gullGeo = null;
function gullModel() {
  gullMat ||= new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.82 });
  if (!gullGeo) {
    const W = 0xeeebe4, G = 0x8e959e, B = 0x1e2024, Y = 0xe4b23a, L = 0xd8946a, E = 0x111111;
    const body = [
      [new THREE.SphereGeometry(1, 14, 10), W, at(0, 0.15, -0.01, 0.085, 0.08, 0.19, 0.18)],
      [new THREE.BoxGeometry(0.11, 0.018, 0.12), W, at(0, 0.17, -0.2, 1, 1, 1, 0.25)],
      [new THREE.SphereGeometry(1, 10, 8), W, at(0, 0.19, 0.11, 0.048, 0.06, 0.06)]
    ];
    for (const k of [-1, 1]) { body.push([new THREE.CylinderGeometry(0.007, 0.007, 0.1, 5), L, at(k * 0.03, 0.05, 0)]); body.push([new THREE.BoxGeometry(0.03, 0.006, 0.05), L, at(k * 0.03, 0.003, 0.02)]); }
    const head = [[new THREE.SphereGeometry(0.052, 12, 10), W, at(0, 0.02, 0.02)], [new THREE.ConeGeometry(0.014, 0.07, 6), Y, at(0, 0.012, 0.095, 1, 1, 1, Math.PI / 2)]];
    for (const k of [-1, 1]) head.push([new THREE.SphereGeometry(0.008, 6, 5), E, at(k * 0.038, 0.035, 0.045)]);
    const wing = (k) => bake([[new THREE.BoxGeometry(0.3, 0.012, 0.13), G, at(k * 0.15, 0, 0)], [new THREE.BoxGeometry(0.1, 0.01, 0.09), B, at(k * 0.33, 0, -0.015)]]);
    gullGeo = { body: bake(body), head: bake(head), wl: wing(1), wr: wing(-1) };
  }
  const g = new THREE.Group(), body = new THREE.Group(); g.add(body);
  const mesh = (geo, parent) => { const m = new THREE.Mesh(geo, gullMat); m.castShadow = true; parent.add(m); return m; };
  mesh(gullGeo.body, body);
  const head = new THREE.Group(); head.position.set(0, 0.205, 0.13); body.add(head); mesh(gullGeo.head, head);
  const wing = (k) => { const pv = new THREE.Group(); pv.position.set(k * 0.07, 0.19, 0.02); body.add(pv); mesh(k > 0 ? gullGeo.wl : gullGeo.wr, pv); return pv; };
  return { g, body, head, wl: wing(1), wr: wing(-1) };
}

function lerp(a, b, t) { return a + (b - a) * t; }
function smooth(a, b, x) { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); }
function mergeTwo(a, b) {
  const A = a.toNonIndexed(), B = b.toNonIndexed(), g = new THREE.BufferGeometry();
  for (const k of ['position', 'normal']) {
    const arr = new Float32Array(A.attributes[k].array.length + B.attributes[k].array.length);
    arr.set(A.attributes[k].array); arr.set(B.attributes[k].array, A.attributes[k].array.length);
    g.setAttribute(k, new THREE.BufferAttribute(arr, 3));
  }
  return g;
}
