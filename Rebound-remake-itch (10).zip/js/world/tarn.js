// The Tarn Rooftops: what is left above the water of the district the Engine could not save.
// Planks laid from roof to roof by someone who came back many times, a hut, and the old bell tower
// leaning out of the water with its clock stopped at 21:58.
import * as THREE from '../../vendor/three.module.min.js';
import { writeOn, chalkify } from './lettering.js';
import { room, wallLine } from './arch.js';
import { railing, crate, barrel, sign, cable, sconce, ceilingLight, lampPost, cot } from './props.js';
import { textTexture } from './materials.js';

export const TARN = { x: 90, z: -110 };

export function buildTarn(W) {
  const M = W.M;
  const ch = W.chunk('tarnRoofs');
  // drowned buildings: solid blocks from the sea bed, roofs just above the water
  const roof = (x0, z0, x1, z1, top, o = {}) => {
    ch.box((x0 + x1) / 2, -14, (z0 + z1) / 2, x1 - x0, 14 + top, z1 - z0, o.mat || M.concreteDark, { tint: o.tint || 0x8a8480, ao: 0 });
    ch.box((x0 + x1) / 2, top - 0.02, (z0 + z1) / 2, x1 - x0 - 0.3, 0.04, z1 - z0 - 0.3, M.tile, { collide: false, ao: 0, tint: 0x8a857c });
    // low parapet with gaps where the planks land
    const gaps = o.gaps || [];
    const edge = (ax, az, bx, bz) => {
      const len = Math.hypot(bx - ax, bz - az), yaw = Math.atan2(bx - ax, bz - az);
      // split around gaps that lie on this edge
      let segs = [[0, len]];
      for (const [gx, gz, gw] of gaps) {
        const t = ((gx - ax) * (bx - ax) + (gz - az) * (bz - az)) / (len * len) * len;
        const dist = Math.abs((gx - ax) * (bz - az) - (gz - az) * (bx - ax)) / len;
        if (dist > 0.6 || t < 0 || t > len) continue;
        segs = segs.flatMap(([s0, s1]) => t - gw / 2 > s1 || t + gw / 2 < s0 ? [[s0, s1]] : [[s0, t - gw / 2], [t + gw / 2, s1]].filter(([a, b]) => b - a > 0.05));
      }
      for (const [s0, s1] of segs) {
        const m = (s0 + s1) / 2;
        const px = ax + (bx - ax) * m / len, pz = az + (bz - az) * m / len;
        ch.box(px, top, pz, 0.3, 0.55, s1 - s0, M.concrete, { yaw, tint: 0x9a948a, ao: 0 });
        // the parapet is low; an invisible rail keeps you on the roof
        ch.collider({ type: 'box', x: px, y: top + 0.9, z: pz, hx: 0.15, hy: 1.0, hz: (s1 - s0) / 2, yaw, rail: true });
      }
    };
    edge(x0, z0, x1, z0); edge(x1, z0, x1, z1); edge(x1, z1, x0, z1); edge(x0, z1, x0, z0);
  };
  const plank = (x0, z0, x1, z1, y0, y1) => {
    const len = Math.hypot(x1 - x0, z1 - z0), yaw = Math.atan2(x1 - x0, z1 - z0);
    // the boards run a little past each end, so they rest on the roofs either side
    const lap = 0.35, slope = (y1 - y0) / len;
    ch.ramp((x0 + x1) / 2, (z0 + z1) / 2, 1.3, len + lap * 2, y0 - slope * lap, y1 + slope * lap, 0.12, M.wood, { yaw });
    // rope rails on posts
    for (const k of [-1, 1]) {
      const ox = Math.cos(yaw) * 0.62 * k, oz = -Math.sin(yaw) * 0.62 * k;
      cable(ch, M, [x0 + ox, y0 + 0.9, z0 + oz], [x1 + ox, y1 + 0.9, z1 + oz], 0.15, 0.02);
      for (const [px, py, pz] of [[x0 + ox, y0, z0 + oz], [x1 + ox, y1, z1 + oz]]) ch.cyl(px, py - 0.05, pz, 0.045, 1.0, M.wood, { seg: 6, collide: false });
      for (let i = 0; i < 10; i++) {
        const t = (i + 0.5) / 10, px = x0 + (x1 - x0) * t + ox, pz = z0 + (z1 - z0) * t + oz, py = y0 + (y1 - y0) * t;
        ch.collider({ type: 'box', x: px, y: py + 0.5, z: pz, hx: 0.08, hy: 1.1, hz: len / 20 + 0.02, yaw, rail: true });
      }
    }
  };
  // Roof A: the landing
  roof(80, -108, 92, -100, 1.6, { gaps: [[92, -104, 1.6], [88, -108, 1.6], [80, -104, 2.0]] });
  // Roof B: east, higher
  roof(95, -107, 104, -98, 2.4, { gaps: [[95, -104, 1.6]] });
  // Roof C: south, Wren's hut
  roof(84, -122, 96, -111, 2.0, { gaps: [[88, -111, 1.6]] });
  plank(92.1, -104, 94.9, -104, 1.6, 2.4);
  plank(88, -108.1, 88, -110.9, 1.6, 2.0);
  // the landing step for the skiff on the west side
  ch.box(78.6, 0.6, -104, 2.8, 1.0, 2.4, M.woodDark, { ao: 0 });
  for (const dz of [-1, 1]) ch.cyl(77.4, -4, -104 + dz, 0.15, 5.6, M.woodDark, { seg: 8, collide: false });

  // lanterns someone keeps lit along the way
  lampPost(W, ch, 84, 1.6, -101.2, { yaw: Math.PI, h: 2.6, intensity: 5, dist: 10 });
  lampPost(W, ch, 103, 2.4, -99, { yaw: Math.PI, h: 2.6, intensity: 4, dist: 9, flicker: 0.4 });
  lampPost(W, ch, 85.4, 2.0, -112.4, { yaw: Math.PI / 2, h: 2.6, intensity: 5, dist: 10 });
  // Roof B: a water tank on its side, debris, a rusted sign
  ch.cyl(100, 2.4, -101.5, 1.1, 2.2, M.copper, { seg: 16, tint: 0x5f7a6e, collide: true, roll: 0 });
  crate(ch, M, 97, 2.4, -105.2, 0.8, { yaw: 0.4 });
  barrel(ch, M, 102.6, 2.4, -105.4, {});
  sign(W, ch, textTexture(['TARN QUARTER', { text: 'No. 4 · Wharf Row', size: 34 }], { w: 512, h: 160, size: 48, color: '#2a2620', bg: '#c8b890', style: 'enamel' }), 103.82, 3.6, -101.5, 1.4, 0.45, Math.PI / 2, { backMat: M.steel });
  // on two posts from the wall top
  for (const dz of [-0.6, 0.6]) ch.box(103.76, 2.94, -101.5 + dz, 0.06, 0.95, 0.06, M.steel, { collide: false, ao: 0 });

  // Roof C: Wren's hut. A lean-to of scavenged boards, lived in, many times over.
  const hx = 90, hz = -117;
  room(ch, M, hx - 2.2, hz - 2.0, hx + 2.2, hz + 2.0, 2.0, 2.5, { wall: M.woodDark, floorMat: M.wood, floorThick: 0.1, sides: { n: [{ t: 2.2, w: 1.1, h: 2.1 }] } });
  ch.box(hx, 4.55, hz, 5.0, 0.12, 4.6, M.copper, { collide: false, ao: 0, tint: 0x6a6460, pitch: 0.08 });
  // inside: a cot, a stool, a tag on a nail, chalk on the back wall, a cylinder player
  cot(ch, M, hx - 1.3, 2.0, hz - 0.6, 0, 0x7a5a8a);
  ch.box(hx + 1.2, 2.0, hz + 0.9, 0.9, 0.75, 0.6, M.woodDark, {});
  ch.box(hx + 1.1, 2.75, hz + 0.9, 0.34, 0.14, 0.26, M.steel, { collide: false, ao: 0 });
  ch.cyl(hx + 1.1, 2.83, hz + 0.9, 0.06, 0.24, M.brass, { seg: 10, roll: Math.PI / 2, collide: false });
  W.addInteract({ id: 'lastHand', x: hx + 1.1, y: 3.0, z: hz + 1.0, r: 1.8, label: 'Play the cylinder' });
  // the tag
  ch.box(hx + 1.86, 3.5, hz - 0.8, 0.12, 0.04, 0.04, M.steel, { collide: false, ao: 0 });
  ch.box(hx + 1.88, 3.25, hz - 0.8, 0.02, 0.24, 0.16, M.paint, { collide: false, ao: 0, tint: 0xe4d6b0 });
  ch.box(hx + 1.87, 3.43, hz - 0.8, 0.02, 0.05, 0.16, M.fabricRed, { collide: false, ao: 0 });
  W.addInteract({ id: 'wrenTag', x: hx + 1.75, y: 3.3, z: hz - 0.8, r: 1.8, label: 'Look at the tag' });
  // chalk drawing on the back wall
  {
    const c = document.createElement('canvas'); c.width = 768; c.height = 384; const g = c.getContext('2d');
    g.strokeStyle = 'rgba(240,236,224,0.85)'; g.fillStyle = 'rgba(240,236,224,0.85)'; g.lineWidth = 6; g.lineCap = 'round'; g.lineJoin = 'round';
    // lighthouse
    g.beginPath(); g.moveTo(90, 300); g.lineTo(110, 120); g.lineTo(150, 120); g.lineTo(170, 300); g.closePath(); g.stroke();
    g.beginPath(); g.moveTo(100, 120); g.lineTo(130, 90); g.lineTo(160, 120); g.stroke();
    for (const a of [-0.5, -0.25, 0.25, 0.5]) { g.beginPath(); g.moveTo(130, 105); g.lineTo(130 + Math.cos(a) * (a < 0 ? -90 : 90), 105 + Math.sin(Math.abs(a)) * -40); g.stroke(); }
    // a tall figure with a lamp, a small one holding her hand
    g.beginPath(); g.arc(420, 120, 22, 0, 7); g.stroke(); g.beginPath(); g.moveTo(420, 142); g.lineTo(420, 250); g.moveTo(420, 250); g.lineTo(395, 320); g.moveTo(420, 250); g.lineTo(445, 320); g.moveTo(420, 175); g.lineTo(470, 200); g.moveTo(420, 175); g.lineTo(380, 215); g.stroke();
    g.beginPath(); g.arc(480, 210, 12, 0, 7); g.fill();
    g.beginPath(); g.arc(355, 205, 15, 0, 7); g.stroke(); g.beginPath(); g.moveTo(355, 220); g.lineTo(355, 280); g.moveTo(355, 280); g.lineTo(340, 320); g.moveTo(355, 280); g.lineTo(370, 320); g.moveTo(355, 235); g.lineTo(380, 215); g.stroke();
    // waves
    g.beginPath(); for (let x = 30; x < 740; x += 40) { g.moveTo(x, 345); g.quadraticCurveTo(x + 10, 330, x + 20, 345); g.quadraticCurveTo(x + 30, 360, x + 40, 345); } g.stroke();
    // a child's capitals, pressed hard
    const kid = { color: 'rgba(240,236,224,0.9)', pen: 0.15, wobble: 1.8, slant: -0.04 };
    const lines = [['IONA SAYS', 70, 30], ['STAY ON', 112, 30], ['THE ROOF.', 154, 30], ['IONA COMES', 214, 30], ['BACK', 260, 36]];
    lines.forEach(([t, y, cap], i) => writeOn(g, t, 522 + (i % 2) * 8, y, cap, { ...kid, seed: 3 + i * 4, maxW: 228 }));
    chalkify(g, 768, 384, 11);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.6), new THREE.MeshBasicMaterial({ map: t, transparent: true, color: 0x9a968e }));
    m.position.set(hx, 3.25, hz - 1.68); ch.mesh(m);
    W.addInteract({ id: 'wrenNote', x: hx, y: 3.2, z: hz - 1.55, r: 2.6, label: 'Look at the drawing' });
  }
  ceilingLight(W, ch, hx, 4.5, hz, 0, { len: 0.6, intensity: 2.2, dist: 5, color: 0xffc48a, flicker: 0.3 });
  // the lamp on the hut roof that lights after the release
  ch.box(hx + 1.6, 4.6, hz + 1.6, 0.12, 1.4, 0.12, M.steel, { ao: 0 });
  const tl = new THREE.Mesh(new THREE.SphereGeometry(0.3, 10, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xfff2d8).multiplyScalar(5), toneMapped: false }));
  tl.position.set(hx + 1.6, 6.15, hz + 1.6); tl.visible = false; W.scene.add(tl); W.tarnLamp = tl;

  // the old Tarn bell tower, leaning out of the water to the east of roof C; its clock stopped at 21:58
  {
    const tx = 101, tz = -118;
    const tower = new THREE.Group();
    const stone = new THREE.Mesh(new THREE.BoxGeometry(4, 16, 4), M.stone); stone.position.y = 2; tower.add(stone);
    const cap = new THREE.Mesh(new THREE.ConeGeometry(3.1, 5, 4), M.copper); cap.position.y = 12.5; cap.rotation.y = Math.PI / 4; tower.add(cap);
    const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
    g.fillStyle = '#cfc4a6'; g.beginPath(); g.arc(128, 128, 120, 0, 7); g.fill(); g.strokeStyle = '#2e2a24'; g.lineWidth = 6; g.stroke();
    for (let i = 0; i < 22; i++) { const a = i / 22 * Math.PI * 2; g.lineWidth = i % 2 ? 2 : 5; g.beginPath(); g.moveTo(128 + Math.sin(a) * 104, 128 - Math.cos(a) * 104); g.lineTo(128 + Math.sin(a) * 90, 128 - Math.cos(a) * 90); g.stroke(); }
    const ah = (21 + 58 / 60) / 22 * Math.PI * 2;
    g.lineWidth = 7; g.beginPath(); g.moveTo(128, 128); g.lineTo(128 + Math.sin(ah) * 70, 128 - Math.cos(ah) * 70); g.stroke();
    g.lineWidth = 4; g.beginPath(); g.moveTo(128, 128); g.lineTo(128 + Math.sin(58 / 60 * Math.PI * 2) * 95, 128 - Math.cos(58 / 60 * Math.PI * 2) * 95); g.stroke();
    const ft = new THREE.CanvasTexture(c); ft.colorSpace = THREE.SRGBColorSpace;
    const face = new THREE.Mesh(new THREE.CircleGeometry(1.4, 32), new THREE.MeshStandardMaterial({ map: ft, roughness: 0.8, emissive: 0xffffff, emissiveMap: ft, emissiveIntensity: 0.22 }));
    face.position.set(0, 7, -2.02); face.rotation.y = Math.PI; tower.add(face);
    const face2 = face.clone(); face2.position.set(-2.02, 7, 0); face2.rotation.y = -Math.PI / 2; tower.add(face2);
    tower.position.set(tx, -1.5, tz); tower.rotation.set(0.05, 0, 0.22);
    tower.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    ch.mesh(tower);
    W.addInteract({ id: 'tarnClock', x: 96.2, y: 4.2, z: -117.2, r: 3.4, label: 'Look at the drowned clock' });
  }
}
