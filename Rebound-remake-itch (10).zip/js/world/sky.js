// Sky dome, the Sister (the crescent moon), the Fracture (the scar the Engine leaves across
// the sky, brighter as the loop runs out), and the sea. The sea reflects the same sky function.
import * as THREE from '../../vendor/three.module.min.js';
import { shared } from './materials.js';

export const skyU = {
  sunDir: { value: new THREE.Vector3(-0.8, 0.2, -0.3).normalize() },
  moonDir: { value: new THREE.Vector3(0.55, 0.32, 0.62).normalize() },
  fracture: { value: 0.25 },     // 0..1 over the loop, >1 during the collapse
  dusk: { value: 0 },            // 0 early evening, 1 night
  dawn: { value: 0 },            // the ending: a real sunrise
  uTime: shared.uTime,
  zen: { value: new THREE.Color(0x0a0f26) },
  mid: { value: new THREE.Color(0x3a2b57) },
  hor: { value: new THREE.Color(0x8a5e72) },
  sunCol: { value: new THREE.Color(0xff9a5a) },
  fogCol: { value: new THREE.Color(0x3a3550) },
  under: { value: 0 }            // camera under water
};

export const skyGLSL = `
uniform vec3 sunDir, moonDir, zen, mid, hor, sunCol, fogCol;
uniform float fracture, dusk, dawn, uTime;
float h21(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(h21(i), h21(i+vec2(1,0)), f.x), mix(h21(i+vec2(0,1)), h21(i+vec2(1,1)), f.x), f.y); }
float fbm2(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 4; i++){ s += vn(p) * a; p = p * 2.03 + 7.1; a *= 0.5; } return s; }
vec3 skyColor(vec3 d, bool withBodies){
  float h = d.y;
  float sunAmt = max(dot(d, sunDir), 0.0);
  vec3 c = mix(hor, mid, smoothstep(-0.02, 0.28, h));
  c = mix(c, zen, smoothstep(0.22, 0.85, h));
  // warm band around the sun's side of the horizon
  float side = pow(max(dot(normalize(vec3(d.x, 0.0, d.z)), normalize(vec3(sunDir.x, 0.0, sunDir.z))), 0.0), 3.0);
  c += sunCol * side * (1.0 - smoothstep(0.0, 0.45, h)) * 0.55 * (1.0 - dusk * 0.7);
  c += sunCol * pow(sunAmt, 18.0) * 0.6 * (1.0 - dusk * 0.6);
  // below the horizon fades into the fog colour
  c = mix(c, fogCol, 1.0 - smoothstep(-0.12, 0.04, h));
  if (withBodies) {
    // sun disc (low, swollen)
    c += sunCol * 6.0 * smoothstep(0.9993, 0.9997, sunAmt) * (1.0 - dusk * 0.8);
    // stars
    vec2 sp = vec2(atan(d.z, d.x) * 60.0, h * 120.0);
    float st = h21(floor(sp));
    float tw = 0.6 + 0.4 * sin(uTime * 2.0 + st * 60.0);
    c += vec3(0.8, 0.85, 1.0) * step(0.9965, st) * smoothstep(0.05, 0.4, h) * (0.35 + dusk) * tw * smoothstep(0.35, 0.0, length(fract(sp) - 0.5));
    // high thin cloud bands, lit from below by the sun
    vec2 cp = d.xz / max(h + 0.12, 0.05);
    float cl = fbm2(cp * 0.9 + vec2(uTime * 0.004, 0.0));
    cl = smoothstep(0.52, 0.85, cl) * smoothstep(0.02, 0.18, h) * (1.0 - smoothstep(0.35, 0.7, h));
    vec3 clc = mix(mid * 1.3, sunCol * 0.9, side * 0.8 + 0.1);
    c = mix(c, clc, cl * 0.55);
    // the Sister
    float md = dot(d, moonDir);
    if (md > 0.9984) {
      vec3 mx = normalize(cross(moonDir, vec3(0.0, 1.0, 0.0)));
      vec3 my = cross(mx, moonDir);
      vec2 q = vec2(dot(d, mx), dot(d, my)) / 0.0566;
      float r = length(q);
      if (r < 1.0) {
        vec3 nrm = normalize(q.x * mx + q.y * my - sqrt(1.0 - r * r) * moonDir);
        float lit = clamp(dot(nrm, normalize(sunDir - moonDir * 1.6)), 0.0, 1.0);
        float crater = fbm2(q * 4.0 + 3.0);
        vec3 mc = vec3(0.78, 0.74, 0.82) * (0.55 + 0.45 * crater) * smoothstep(0.0, 0.35, lit) + vec3(0.06, 0.05, 0.09);
        c = mix(c, mc * 0.95, smoothstep(1.0, 0.985, r));
      }
    }
    c += vec3(0.6, 0.55, 0.8) * 0.05 * smoothstep(0.975, 0.998, md);
    // the Fracture: a jagged seam along a great circle
    vec3 fn = normalize(vec3(0.28, 0.86, 0.42));
    float pd = dot(d, fn);
    float along = atan(dot(d, normalize(cross(fn, vec3(0,1,0)))), d.y);
    float jag = (fbm2(vec2(along * 5.0, 1.0)) - 0.5) * 0.018 + (vn(vec2(along * 30.0, uTime * 0.3)) - 0.5) * 0.003;
    float w = 0.0018 + 0.0035 * fracture;
    float seam = exp(-pow((pd - jag) / w, 2.0));
    float halo = exp(-abs(pd - jag) / (0.015 + 0.04 * fracture));
    // break the seam into uneven stretches so it reads as a crack, not a line
    float gaps = smoothstep(0.35, 0.6, fbm2(vec2(along * 14.0, 3.0)) + fracture * 0.25);
    float vis = smoothstep(0.02, 0.3, h) * fracture;
    float flick = 0.8 + 0.2 * sin(uTime * 2.3 + along * 17.0);
    c += (vec3(0.6, 1.0, 0.95) * seam * 1.6 * flick * gaps + vec3(0.45, 0.32, 0.95) * halo * 0.3 * (0.4 + 0.6 * gaps)) * vis;
  }
  // dawn (ending)
  c = mix(c, mix(vec3(0.95, 0.62, 0.42), vec3(0.35, 0.5, 0.75), smoothstep(0.0, 0.5, h)), dawn * 0.85);
  return c;
}`;

export function makeSky(scene) {
  const g = new THREE.SphereGeometry(4000, 48, 24);
  const m = new THREE.ShaderMaterial({
    uniforms: skyU, side: THREE.BackSide, depthWrite: false, fog: false,
    vertexShader: `varying vec3 vD; void main(){ vD = normalize(position); vec4 p = modelViewMatrix * vec4(position, 1.0); gl_Position = projectionMatrix * p; gl_Position.z = gl_Position.w * 0.9999; }`,
    fragmentShader: skyGLSL + `varying vec3 vD; uniform float under; void main(){ vec3 c = skyColor(normalize(vD), true); gl_FragColor = vec4(c, 1.0); }`
  });
  const sky = new THREE.Mesh(g, m);
  sky.frustumCulled = false;
  sky.renderOrder = -10;
  scene.add(sky);
  return sky;
}

export function makeSea(scene) {
  const g = new THREE.PlaneGeometry(6000, 6000, 1, 1);
  g.rotateX(-Math.PI / 2);
  const u = {
    ...skyU,
    camPos: { value: new THREE.Vector3() },
    fogDen: { value: 0.012 },
    deep: { value: new THREE.Color(0x07121c) },
    shallow: { value: new THREE.Color(0x1d3b4a) },
    glowCol: { value: new THREE.Color(0x3fe0d0) },
    corePos: { value: new THREE.Vector2(0, -258) },
    coreAmt: { value: 0.4 }
  };
  const m = new THREE.ShaderMaterial({
    uniforms: u, transparent: false,
    vertexShader: `varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
    fragmentShader: skyGLSL + `
      varying vec3 vW; uniform vec3 camPos, deep, shallow, glowCol; uniform float fogDen, coreAmt; uniform vec2 corePos;
      vec2 wave(vec2 p, float t){
        vec2 g = vec2(0.0);
        g += vec2(cos(p.x * 0.21 + t * 0.9), 0.0) * 0.21 * 0.12;
        g += vec2(0.0, cos(p.y * 0.17 - t * 0.7)) * 0.17 * 0.14;
        g += vec2(cos(dot(p, vec2(0.6, 0.8)) * 0.53 + t * 1.3)) * vec2(0.6, 0.8) * 0.53 * 0.05;
        g += vec2(cos(dot(p, vec2(-0.7, 0.5)) * 1.1 - t * 1.7)) * vec2(-0.7, 0.5) * 1.1 * 0.025;
        g += (vec2(vn(p * 0.9 + t * 0.3), vn(p * 0.9 - t * 0.3 + 9.0)) - 0.5) * 0.18;
        return g;
      }
      void main(){
        vec3 V = camPos - vW; float dist = length(V); V /= dist;
        float t = uTime;
        vec2 gr = wave(vW.xz, t) * (1.0 - smoothstep(60.0, 600.0, dist) * 0.8);
        vec3 N = normalize(vec3(-gr.x, 1.0, -gr.y));
        vec3 R = reflect(-V, N); R.y = abs(R.y);
        float fres = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
        vec3 refl = skyColor(normalize(R), true);
        vec3 body = mix(deep, shallow, 0.25 + 0.25 * N.x);
        // the Core column lights the water around it
        float cd = length(vW.xz - corePos);
        body += glowCol * coreAmt * exp(-cd * 0.03) * 0.6;
        vec3 c = mix(body, refl, clamp(fres, 0.0, 1.0));
        // sun glitter
        float spec = pow(max(dot(R, sunDir), 0.0), 220.0);
        c += sunCol * spec * 3.0 * (1.0 - dusk * 0.7);
        float f = 1.0 - exp(-pow(dist * fogDen, 1.6));
        vec3 fogC = mix(fogCol, skyColor(normalize(vec3(-V.x, 0.02, -V.z)), false), 0.5);
        c = mix(c, fogC, clamp(f, 0.0, 1.0));
        gl_FragColor = vec4(c, 1.0);
      }`
  });
  const sea = new THREE.Mesh(g, m);
  sea.frustumCulled = false;
  sea.receiveShadow = false;
  scene.add(sea);
  return { mesh: sea, u };
}

// interior water: still, dark, catches cyan light
export function makePool(w, d, o = {}) {
  const g = new THREE.PlaneGeometry(w, d, 1, 1); g.rotateX(-Math.PI / 2);
  const m = new THREE.MeshStandardMaterial({ color: o.color || 0x0b1c22, roughness: 0.08, metalness: 0.6, transparent: true, opacity: o.opacity ?? 0.92 });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = shared.uTime;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP2;').replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWP2 = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP2; uniform float uTime;')
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        vec2 q = vWP2.xz;
        vec3 bump = vec3(sin(q.x * 1.7 + uTime * 1.1) * 0.05 + sin(q.y * 2.3 - uTime * 0.8) * 0.04, 0.0, cos(q.y * 1.9 + uTime) * 0.05 + cos(q.x * 2.9 - uTime * 1.4) * 0.03);
        normal = normalize(normal + (viewMatrix * vec4(bump, 0.0)).xyz);`);
  };
  m.customProgramCacheKey = () => 'pool';
  const mesh = new THREE.Mesh(g, m);
  mesh.receiveShadow = true;
  return mesh;
}

// the rim of the basin: low mountains far out, drawn as a silhouette that takes its colour from the sky
export function makeRim(scene) {
  const segs = 256, R = 1500;
  const pos = [], idx = [];
  const h = (a) => {
    let v = 0;
    for (const [f, amp, ph] of [[3, 0.35, 0.3], [7, 0.22, 1.7], [13, 0.14, 2.2], [29, 0.07, 0.9], [61, 0.03, 4.1]]) v += Math.sin(a * f + ph) * amp;
    // a wide notch to the west-south-west where the sun sets
    const d = Math.atan2(Math.sin(a - 4.28), Math.cos(a - 4.28));
    return Math.max(0.05, (0.55 + v) * (1 - Math.exp(-d * d * 8) * 0.8));
  };
  for (let i = 0; i <= segs; i++) {
    const a = i / segs * Math.PI * 2, x = Math.sin(a) * R, z = Math.cos(a) * R, y = 20 + h(a) * 150;
    pos.push(x, -30, z, x * 1.02, y, z * 1.02);
    if (i < segs) { const k = i * 2; idx.push(k, k + 2, k + 1, k + 1, k + 2, k + 3); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setIndex(idx);
  const m = new THREE.ShaderMaterial({
    uniforms: skyU, side: THREE.DoubleSide, fog: false,
    vertexShader: `varying vec3 vD; varying float vY; void main(){ vD = normalize(position); vY = position.y; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: skyGLSL + `varying vec3 vD; varying float vY; void main(){
      vec3 d = normalize(vec3(vD.x, 0.01, vD.z));
      vec3 sky = skyColor(d, false);
      float hgt = smoothstep(-30.0, 170.0, vY);
      vec3 c = mix(fogCol * 1.05, sky * 0.62, 0.55) * (0.85 + 0.15 * hgt);
      c = mix(c, sky, 0.25 * (1.0 - hgt));
      gl_FragColor = vec4(c, 1.0); }`
  });
  const mesh = new THREE.Mesh(g, m);
  mesh.frustumCulled = false; mesh.renderOrder = -5;
  scene.add(mesh);
  return mesh;
}
