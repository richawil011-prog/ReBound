// A few gulls riding the wind over the water. They don't know about the loop either.
// Drawn as three instanced meshes (bodies, left wings, right wings): three draw calls for the flock.
import * as THREE from '../../vendor/three.module.min.js';

const tmpM = new THREE.Matrix4(), wingM = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), p = new THREE.Vector3(), s = new THREE.Vector3(1.4, 1.4, 1.4);

export class Birds {
  constructor(scene) {
    const flocks = [[-40, -110, 22], [0, -70, 30], [-130, -60, 20], [-120, -200, 18], [30, -150, 26]];
    this.list = [];
    flocks.forEach(([cx, cz, cy], fi) => {
      for (let i = 0; i < 3; i++) this.list.push({ cx, cz, cy: cy + i * 2.5, r: 14 + i * 7 + fi * 2, sp: (0.12 + i * 0.03) * (i % 2 ? 1 : -1), ph: i * 2.1 + fi });
    });
    const n = this.list.length;
    const mat = new THREE.MeshStandardMaterial({ color: 0xd8d4cc, roughness: 0.9, side: THREE.DoubleSide, vertexColors: true });
    const body = new THREE.BoxGeometry(0.16, 0.12, 0.55);
    body.setAttribute('color', new THREE.Float32BufferAttribute(new Array(body.attributes.position.count * 3).fill(1), 3));
    // a wing: a pale inner panel and a dark tip, hinged at x = 0
    const wing = new THREE.BufferGeometry();
    const P = [0, 0, -0.12, 0.75, 0, -0.12, 0.75, 0, 0.12, 0, 0, -0.12, 0.75, 0, 0.12, 0, 0, 0.12,
      0.75, 0, -0.1, 0.97, 0, -0.08, 0.97, 0, 0.06, 0.75, 0, -0.1, 0.97, 0, 0.06, 0.75, 0, 0.1];
    const C = []; for (let i = 0; i < 12; i++) { const k = i < 6 ? 1 : 0.25; C.push(k, k, k * 1.05); }
    wing.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
    wing.setAttribute('color', new THREE.Float32BufferAttribute(C, 3));
    wing.computeVertexNormals();
    this.body = new THREE.InstancedMesh(body, mat, n);
    this.left = new THREE.InstancedMesh(wing, mat, n);
    this.right = new THREE.InstancedMesh(wing, mat, n);
    for (const m of [this.body, this.left, this.right]) { m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.frustumCulled = false; scene.add(m); }
  }
  update(dt, t, sea) {
    this.list.forEach((b, i) => {
      const a = t * b.sp + b.ph;
      p.set(b.cx + Math.cos(a) * b.r, Math.max(sea + 4, b.cy + Math.sin(t * 0.3 + b.ph) * 3), b.cz + Math.sin(a) * b.r);
      const dx = -Math.sin(a) * Math.sign(b.sp), dz = Math.cos(a) * Math.sign(b.sp);
      q.setFromEuler(e.set(0, Math.atan2(dx, dz), -Math.sign(b.sp) * 0.25));
      tmpM.compose(p, q, s);
      this.body.setMatrixAt(i, tmpM);
      // glide most of the time, flap in bursts
      const burst = Math.sin(t * 0.7 + b.ph * 3) > 0.55;
      const f = burst ? Math.sin(t * 11 + b.ph) * 0.6 : 0.12 + Math.sin(t * 1.5 + b.ph) * 0.05;
      this.left.setMatrixAt(i, wingM.copy(tmpM).multiply(new THREE.Matrix4().makeRotationZ(f)));
      this.right.setMatrixAt(i, wingM.copy(tmpM).multiply(new THREE.Matrix4().makeScale(-1, 1, 1)).multiply(new THREE.Matrix4().makeRotationZ(f)));
    });
    this.body.instanceMatrix.needsUpdate = true; this.left.instanceMatrix.needsUpdate = true; this.right.instanceMatrix.needsUpdate = true;
  }
}
