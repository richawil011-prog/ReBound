// Materials and procedural textures. Everything is lit PBR with vertex colours (tint + contact
// shadow) and a world-space triplanar pattern, so surfaces keep a real-world scale however a
// piece was stretched. A shared tide uniform darkens and glosses anything below the waterline.
import * as THREE from '../../vendor/three.module.min.js';
import { signTexture } from './lettering.js';

export const shared = {
  uTide: { value: 0.0 },     // sea surface height: wet band just above it
  uDeepTide: { value: -100 },// interior water (the Deep)
  uTime: { value: 0 },
  uPulse: { value: 0 }       // end-of-loop instability, makes emissives throb
};

// ---------- tileable noise ----------
function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
function valueNoise(size, cells, seed) {
  const r = rng(seed), g = [];
  for (let i = 0; i < cells * cells; i++) g.push(r());
  const out = new Float32Array(size * size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const fx = x / size * cells, fy = y / size * cells;
    const x0 = Math.floor(fx), y0 = Math.floor(fy), tx = fx - x0, ty = fy - y0;
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    const a = g[(y0 % cells) * cells + (x0 % cells)], b = g[(y0 % cells) * cells + ((x0 + 1) % cells)];
    const c = g[((y0 + 1) % cells) * cells + (x0 % cells)], d = g[((y0 + 1) % cells) * cells + ((x0 + 1) % cells)];
    out[y * size + x] = (a + (b - a) * sx) * (1 - sy) + (c + (d - c) * sx) * sy;
  }
  return out;
}
function fbm(size, seed, octaves = 5, base = 4) {
  const out = new Float32Array(size * size);
  let amp = 0.5, tot = 0;
  for (let o = 0; o < octaves; o++) {
    const n = valueNoise(size, base << o, seed + o * 17);
    for (let i = 0; i < out.length; i++) out[i] += n[i] * amp;
    tot += amp; amp *= 0.5;
  }
  for (let i = 0; i < out.length; i++) out[i] /= tot;
  return out;
}

function canvasTex(size, paint, repeat = true) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(size, size);
  paint(img.data, size, ctx);
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  t.colorSpace = THREE.NoColorSpace;
  t.anisotropy = 4;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  return t;
}

// pattern = function(x,y,size) -> [albedoMul 0..2, roughMul] using shared fbm fields
function patternTex(seed, fn) {
  const S = 512;
  const n1 = fbm(S, seed, 6, 4), n2 = fbm(S, seed + 99, 4, 16);
  return canvasTex(S, (d) => {
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const i = y * S + x;
      const [a, r] = fn(x / S, y / S, n1[i], n2[i]);
      const v = Math.max(0, Math.min(255, a * 128));
      d[i * 4] = v; d[i * 4 + 1] = Math.max(0, Math.min(255, r * 128)); d[i * 4 + 2] = v; d[i * 4 + 3] = 255;
    }
  });
}

const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const line = (v, period, width) => { const f = ((v % period) + period) % period; return Math.min(f, period - f) < width ? 1 : 0; };

const patterns = {
  // board-formed concrete: soft horizontal pour lines, stains, tiny pits
  concrete: (u, v, a, b) => {
    const pour = line(v, 0.25, 0.004) * 0.18;
    const stain = smooth(0.55, 0.8, a) * 0.22;
    const pit = b > 0.78 ? 0.25 : 0;
    return [1.04 + (a - 0.5) * 0.35 + (b - 0.5) * 0.14 - pour - stain - pit, 1 + (a - 0.5) * 0.4];
  },
  // painted wall panels, 1 x 2 m, seams and grime at the bottom of each panel
  panel: (u, v, a, b) => {
    const seam = Math.max(line(u, 0.5, 0.0035), line(v, 0.25, 0.0035));
    const grime = smooth(0.6, 0.9, a) * 0.12;
    return [1.03 + (b - 0.5) * 0.08 - seam * 0.45 - grime, 1 - seam * 0.2 + (a - 0.5) * 0.3];
  },
  // deck tiles, 1 m grid with bevel lines
  tile: (u, v, a, b) => {
    const g = Math.max(line(u, 0.25, 0.004), line(v, 0.25, 0.004));
    const cellTone = (Math.sin(Math.floor(u * 4) * 12.9 + Math.floor(v * 4) * 78.2) * 43758.5) % 1;
    return [1 + Math.abs(cellTone) * 0.12 - 0.06 + (a - 0.5) * 0.25 - g * 0.5, 0.9 + (b - 0.5) * 0.5 - g * 0.1];
  },
  // planks 0.2 m wide along u
  plank: (u, v, a, b) => {
    const p = Math.floor(v * 20), fp = v * 20 - p;
    const seam = fp < 0.05 ? 0.5 : 0;
    const grain = Math.sin((u * 60 + Math.sin(v * 70) * 0.6 + p * 3.1) * 6.28) * 0.05;
    const tone = ((Math.sin(p * 91.7) * 43758.5) % 1) * 0.18;
    return [1 + grain + Math.abs(tone) - 0.09 + (a - 0.5) * 0.3 - seam, 1 + (b - 0.5) * 0.4];
  },
  // old stone blocks, running bond
  block: (u, v, a, b) => {
    const row = Math.floor(v * 8), off = row % 2 ? 0.125 : 0;
    const mortar = Math.max(line(v, 0.125, 0.006), line(u + off, 0.25, 0.006));
    const tone = ((Math.sin(row * 17.1 + Math.floor((u + off) * 4) * 7.7) * 43758.5) % 1) * 0.2;
    return [1 + Math.abs(tone) - 0.1 + (a - 0.5) * 0.45 - mortar * 0.55 + (b - 0.5) * 0.1, 1 + mortar * 0.2];
  },
  // brushed and scratched metal
  metal: (u, v, a, b) => {
    const brush = Math.sin(v * 900 + a * 20) * 0.02;
    return [1 + brush + (a - 0.5) * 0.25 - smooth(0.7, 0.9, b) * 0.15, 1 + (a - 0.5) * 0.8];
  },
  plain: (u, v, a, b) => [1 + (a - 0.5) * 0.18, 1 + (b - 0.5) * 0.2]
};

const texCache = {};
function getPattern(name) {
  if (!texCache[name]) texCache[name] = patternTex(name.length * 31 + 7, patterns[name]);
  return texCache[name];
}

// World-space triplanar pattern for MeshStandardMaterial
function triplanar(mat, pattern, scale, o = {}) {
  const tex = getPattern(pattern);
  mat.userData.pattern = pattern;
  mat.customProgramCacheKey = () => 'tri-' + pattern + '-' + scale + '-' + (o.wet !== false);
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.tPat = { value: tex };
    sh.uniforms.uTide = shared.uTide;
    sh.uniforms.uDeepTide = shared.uDeepTide;
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
      .replace('#include <worldpos_vertex>', '#include <worldpos_vertex>\nvWP = (modelMatrix * vec4(transformed,1.0)).xyz; vWN = normalize(mat3(modelMatrix) * objectNormal);');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', `#include <common>
        varying vec3 vWP; varying vec3 vWN; uniform sampler2D tPat; uniform float uTide; uniform float uDeepTide;
        vec2 triSample(vec3 p, vec3 n){
          vec3 w = pow(abs(n), vec3(4.0)); w /= (w.x + w.y + w.z);
          vec2 a = texture2D(tPat, p.zy * ${(1 / scale).toFixed(4)}).rg;
          vec2 b = texture2D(tPat, p.xz * ${(1 / scale).toFixed(4)}).rg;
          vec2 c = texture2D(tPat, p.xy * ${(1 / scale).toFixed(4)}).rg;
          return a * w.x + b * w.y + c * w.z;
        }`)
      .replace('#include <map_fragment>', `#include <map_fragment>
        vec2 pat = triSample(vWP, vWN) * 2.0;
        // slow large-scale variation so big walls are not uniform
        float macro = texture2D(tPat, vWP.xz * 0.013 + vWP.y * 0.004).r * 2.0;
        diffuseColor.rgb *= pat.x * (0.9 + 0.1 * macro);
        float wet = ${o.wet === false ? '0.0' : '1.0'} * max(1.0 - smoothstep(uTide + 0.15, uTide + 0.9, vWP.y), (1.0 - smoothstep(uDeepTide + 0.05, uDeepTide + 0.6, vWP.y)) * step(uDeepTide, vWP.y + 30.0));
        diffuseColor.rgb *= 1.0 - wet * 0.45;`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
        roughnessFactor = clamp(roughnessFactor * pat.y, 0.22, 1.0);
        roughnessFactor = mix(roughnessFactor, 0.3, wet * 0.8);`);
  };
  return mat;
}

export function makeMaterials() {
  const std = (color, rough, metal, pattern, scale, o = {}) => {
    const m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal, vertexColors: true, ...(o.params || {}) });
    if (pattern) triplanar(m, pattern, scale, o);
    return m;
  };
  const glow = (hex, k) => {
    const m = new THREE.MeshBasicMaterial({ color: new THREE.Color(hex).multiplyScalar(k), vertexColors: true, fog: true, toneMapped: false });
    m.userData.noShadow = true; m.userData.noReceive = true;
    return m;
  };
  const M = {
    concrete: std(0x8c877f, 0.92, 0.0, 'concrete', 4),
    concreteDark: std(0x5b5753, 0.95, 0.0, 'concrete', 4),
    concreteWarm: std(0x9a8a78, 0.9, 0.0, 'concrete', 4),
    stone: std(0x6f685d, 0.95, 0.0, 'block', 4),
    panel: std(0xb9b6ad, 0.75, 0.05, 'panel', 4),
    panelDark: std(0x3c434b, 0.7, 0.2, 'panel', 4),
    tile: std(0x40464d, 0.6, 0.15, 'tile', 4),
    tileWarm: std(0x67645e, 0.5, 0.1, 'tile', 4),
    metal: std(0x5a626b, 0.48, 0.7, 'metal', 3),
    steel: std(0x262b32, 0.55, 0.6, 'metal', 3),
    brass: std(0xb5793f, 0.38, 0.85, 'metal', 2),
    copper: std(0x8e5636, 0.5, 0.8, 'metal', 2),
    wood: std(0x6e4c35, 0.85, 0.0, 'plank', 4),
    woodDark: std(0x46342a, 0.9, 0.0, 'plank', 4),
    fabricRed: std(0x8f3b2c, 0.95, 0.0, 'plain', 2),
    fabricTeal: std(0x2f5864, 0.95, 0.0, 'plain', 2),
    fabricPale: std(0xb9ad95, 0.95, 0.0, 'plain', 2),
    rubber: std(0x1d1f22, 0.9, 0.0, 'plain', 2),
    leaf: std(0x3d6a3e, 0.8, 0.0, 'plain', 1, { wet: false }),
    leafDark: std(0x284a30, 0.85, 0.0, 'plain', 1, { wet: false }),
    soil: std(0x3a2c22, 1.0, 0.0, 'plain', 2),
    rock: std(0x4e4a46, 0.95, 0.0, 'concrete', 6),
    paint: std(0xd9cdb0, 0.8, 0.0, 'plain', 2),
    hazard: std(0xc98b2c, 0.7, 0.1, 'plain', 2),
    glass: new THREE.MeshStandardMaterial({ color: 0x0b141c, roughness: 0.06, metalness: 0.0, envMapIntensity: 2.2, vertexColors: true }),
    glassClear: new THREE.MeshStandardMaterial({ color: 0xa8c8d0, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.16, depthWrite: false, vertexColors: true }),
    window: glow(0xffb36b, 1.0),     // warm lit windows (vertex colour scales brightness)
    lampWarm: glow(0xffc283, 4.0),
    lampCyan: glow(0x63f0e2, 4.0),
    lampRed: glow(0xff5a3c, 3.0),
    screen: glow(0x7fd9d0, 1.4),
    white: glow(0xfff4e6, 2.5),
    dark: new THREE.MeshBasicMaterial({ color: 0x000000 })
  };
  M.dark.userData.noShadow = true;
  // Where two surfaces share a plane, finishes win over structure (tile and planks over concrete
  // and rock, trims over walls, paint and lamps over everything) instead of flickering.
  const rank = (k) => /^(concrete|concreteDark|concreteWarm|stone|rock|sea|glass)/.test(k) ? 0
    : /^(tile|tileWarm|wood|woodDark|steel|metal|panel|panelDark)$/.test(k) ? 1 : 2;
  for (const k in M) {
    const m = M[k], r = rank(k);
    if (!r || m.transparent || m.polygonOffset) continue;
    m.polygonOffset = true; m.polygonOffsetFactor = -0.5 * r; m.polygonOffsetUnits = -r;
  }
  M.glass.userData.noShadow = true;
  M.glassClear.userData.noShadow = true;
  return M;
}

// Signs, plaques, stencils and notices: lettered by hand and weathered (see lettering.js).
export function textTexture(lines, o = {}) { return signTexture(lines, o); }

export function decal(tex, w, h, o = {}) {
  const m = new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, toneMapped: false, fog: true,
    polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, opacity: o.opacity ?? 1, blending: o.additive ? THREE.AdditiveBlending : THREE.NormalBlending });
  if (o.color) m.color.set(o.color);
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m);
  return mesh;
}
