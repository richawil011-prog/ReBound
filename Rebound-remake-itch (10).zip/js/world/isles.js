// Lantern Isle (the keeper's rock and lighthouse), Verdant Rise (the glasshouse on piles),
// and the skiff that ferries between them and the Market Pier.
import * as THREE from '../../vendor/three.module.min.js';
import { wallLine, room, deg, crag } from './arch.js';
import { railing, lampPost, sconce, ceilingLight, crate, barrel, bench, table, shelf, slidingDoor, sign, planter, cable, pipeRun , rug, coat } from './props.js';
import { textTexture, decal, shared } from './materials.js';

export const ISLE = { x: -150, z: -58, top: 3 };
export const RISE = { x: -122, z: -202, top: 2.5 };
export const DOCKS = {
  pier: { boat: [-75.5, -124.5], yaw: Math.PI / 2, land: [-70, 2, -120.6], face: -Math.PI / 2, name: 'Market Pier' },
  isle: { boat: [-131.5, -70], yaw: -0.4, land: [-135.6, 3, -64.2], face: 0.9, name: 'Lantern Isle' },
  rise: { boat: [-122, -184.5], yaw: 0, land: [-122, 2.5, -189.6], face: 0, name: 'Verdant Rise' },
  tarn: { boat: [74.5, -104], yaw: 0, land: [81, 1.6, -104], face: -Math.PI / 2, name: 'Tarn Rooftops' }
};

export function buildIsles(W) {
  const M = W.M;

  // ===================== LANTERN ISLE =====================
  {
    const ch = W.chunk('isle');
    const { x: ix, z: iz, top } = ISLE;
    // the rock: overlapping blocks and boulders, flat-topped where people walked
    const rocks = [[0, 0, 22, 20], [-6, 7, 14, 12], [7, -6, 12, 12], [8, 6, 9, 9], [-9, -6, 9, 10]];
    for (const [dx, dz, w, d] of rocks) crag(ch, M.rock, ix + dx, -12, iz + dz, w, top + 12, d, { collide: true, amp: 0.9 });
    for (let i = 0; i < 16; i++) {
      const a = i / 16 * Math.PI * 2, r = 12 + (i % 3) * 1.5;
      const g = new THREE.DodecahedronGeometry(1.6 + (i % 4) * 0.6, 0);
      ch.geo(g, M.rock, new THREE.Matrix4().compose(new THREE.Vector3(ix + Math.sin(a) * r, -0.4 + (i % 2) * 0.6, iz + Math.cos(a) * r), new THREE.Quaternion().setFromEuler(new THREE.Euler(i, i * 2, 0)), new THREE.Vector3(1.3, 0.8, 1.1)), { ao: 1.5 });
      g.dispose();
    }
    // grass on top
    ch.box(ix, top - 0.02, iz, 21.6, 0.05, 19.6, M.leafDark, { collide: false, ao: 0, tint: 0x8a9a6a });
    // dock out to the east, steps down to it
    ch.box(-136.5, top - 0.35, -64, 5.0, 0.35, 5.0, M.wood, { ao: 0 });
    for (const [dx, dz] of [[-1.2, -2.2], [1.2, -2.2], [-1.2, 2.2], [1.2, 2.2]]) ch.cyl(-135.5 + dx, -3, -64 + dz, 0.2, top - 0.35 + 3, M.woodDark, { seg: 8, collide: false });
    railing(ch, M, -134, -61.6, -134, -66.4, top, { mat: M.woodDark, top: M.wood });
    // path stones from the dock to the hut and the tower
    for (let i = 0; i < 7; i++) ch.box(-138.5 - i * 1.6, top, -62.5 + i * 0.9, 0.9, 0.05, 0.7, M.stone, { collide: false, ao: 0, yaw: i * 0.4 });
    // lighthouse
    const lx = ix - 6, lz = iz + 6;
    ch.cyl(lx, top, lz, 3.2, 0.6, M.stone, { seg: 32 });
    // hollow tower: a ring wall with a door, so the base room is inside
    const door = { a: 50 * deg, w: 1.3, h: 2.4 };
    // ring with a door
    {
      const ops = [door];
      const rm = 2.75, da = (door.w / 2) / rm;
      ch.ring(lx, top + 0.6, lz, 2.5, 3.0, 2.4, M.paint, { a0: door.a + da, a1: door.a - da + Math.PI * 2, tint: 0xece6da });
      ch.ring(lx, top + 3.0, lz, 2.3, 2.85, 13, M.paint, { tint: 0xece6da, collide: false });
      ch.ring(lx, top + 3.0, lz, 2.5, 3.0, 0.01, M.paint, { collide: false });
      // red bands
      for (const y of [top + 5.5, top + 10.5]) ch.ring(lx, y, lz, 2.32, 2.88, 1.4, M.fabricRed, { collide: false, tint: 0xd0d0d0 });
    }
    ch.cyl(lx, top + 0.6, lz, 2.5, 0.02, M.stone, { collide: false, seg: 24 });
    ch.cyl(lx, top + 3.0, lz, 2.5, 0.25, M.woodDark, { collide: false, seg: 24 }); // ceiling of the base room
    // gallery and lantern room
    ch.cyl(lx, top + 16, lz, 3.4, 0.35, M.steel, { seg: 32, collide: false });
    ringRail(ch, M, lx, lz, 3.25, top + 16.35);
    ch.cyl(lx, top + 16.35, lz, 1.8, 2.4, M.glassClear, { seg: 16, collide: false });
    for (let i = 0; i < 8; i++) { const a = i * 45 * deg; ch.box(lx + Math.sin(a) * 1.8, top + 16.35, lz + Math.cos(a) * 1.8, 0.1, 2.4, 0.1, M.steel, { collide: false, ao: 0 }); }
    ch.cyl(lx, top + 18.75, lz, 2.0, 1.4, M.copper, { seg: 16, rTop: 0.15, collide: false, tint: 0x6f9a86 });
    ch.cyl(lx, top + 20.1, lz, 0.1, 1.2, M.steel, { collide: false, seg: 6 });
    const lampMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffe2b0).multiplyScalar(0.3), toneMapped: false });
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.6, 16, 12), lampMat);
    lamp.position.set(lx, top + 17.5, lz); W.scene.add(lamp);
    const beamMat = new THREE.MeshBasicMaterial({ color: 0xffd9a0, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    const beamG = new THREE.ConeGeometry(5, 90, 24, 1, true); beamG.translate(0, -45, 0); beamG.rotateX(-Math.PI / 2);
    const beamPivot = new THREE.Group(); beamPivot.position.copy(lamp.position); W.scene.add(beamPivot);
    for (const k of [0, Math.PI]) { const b = new THREE.Mesh(beamG, beamMat); b.rotation.y = k; beamPivot.add(b); }
    W.lighthouse = { lamp, lampMat, beamMat, beamPivot, on: false, light: W.light(lx, top + 17.5, lz, 0xffd9a0, 0, 40, { key: 'lighthouse' }) };
    // switch box inside the base: left and right switches
    {
      const a = 200 * deg, r = 2.35;
      const bx = lx + Math.sin(a) * r, bz = lz + Math.cos(a) * r;
      ch.box(bx, top + 1.2, bz, 0.6, 0.7, 0.12, M.panelDark, { yaw: a, ao: 0 });
      for (const k of [-1, 1]) ch.box(bx + Math.cos(a) * k * 0.15 - Math.sin(a) * 0.08, top + 1.5, bz - Math.sin(a) * k * 0.15 - Math.cos(a) * 0.08, 0.08, 0.2, 0.08, k < 0 ? M.brass : M.steel, { yaw: a, collide: false, ao: 0 });
      W.addInteract({ id: 'beacon', x: bx - Math.sin(a) * 0.3, y: top + 1.5, z: bz - Math.cos(a) * 0.3, r: 2.0, label: 'Use the lamp switches' });
      W.light(lx, top + 2.6, lz, 0xffc27a, 3, 5, { chunk: ch });
      // spiral of steps up the inside (blocked by a fallen beam: decoration)
      for (let i = 0; i < 6; i++) { const sa = 120 * deg + i * 22 * deg; ch.box(lx + Math.sin(sa) * 1.3, top + 0.6 + i * 0.4, lz + Math.cos(sa) * 1.3, 0.95, 0.12, 2.25, M.woodDark, { yaw: sa, ao: 0 }); }   // from the post to the wall
      ch.cyl(lx, top, lz, 0.2, 3.2, M.woodDark, { seg: 12 });   // the stair's centre post
      ch.box(lx + 0.3, top + 0.6, lz - 0.6, 3.4, 0.3, 0.3, M.woodDark, { collide: false, roll: 0.5, yaw: 0.8 });
      ch.collider({ type: 'box', x: lx + 0.3, y: top + 0.9, z: lz - 0.6, hx: 1.45, hy: 0.9, hz: 0.18, yaw: 0.8 });   // the plank leaning on the tower is solid too
    }
    // keeper's hut
    {
      const hx = ix + 4.5, hz = iz + 2.5;
      room(ch, M, hx - 3, hz - 2.4, hx + 3, hz + 2.4, top, 2.8, { wall: M.wood, floorMat: M.woodDark, sides: { s: [{ t: 3, w: 1.2, h: 2.2 }, { t: 1.2, w: 0.9, h: 1.9, sill: 0.9, glass: true }] }, roofCollide: false });
      // pitched roof
      for (const k of [-1, 1]) ch.box(hx, top + 3.1, hz + k * 1.35, 6.8, 0.15, 3.1, M.copper, { collide: false, ao: 0, roll: 0, pitch: k * 0.42, tint: 0x6a6460 });
      ch.box(hx + 2.2, top + 2.8, hz + 0.8, 0.5, 1.4, 0.5, M.stone, {});
      table(ch, M, hx + 1.5, top, hz + 1.4, 1.2, 0.7, {});
      ch.box(hx + 1.4, top + 0.78, hz + 1.4, 0.34, 0.14, 0.26, M.steel, { collide: false, ao: 0 });
      ch.cyl(hx + 1.4, top + 0.86, hz + 1.4, 0.06, 0.24, M.brass, { seg: 10, roll: Math.PI / 2, collide: false });
      W.addInteract({ id: 'keeperLog', x: hx + 1.4, y: top + 1.0, z: hz + 1.4, r: 2.0, label: 'Play Aiden’s cylinder' });
      ch.box(hx - 1.8, top, hz + 1.2, 2.0, 0.5, 1.0, M.woodDark, {});
      ch.box(hx - 1.8, top + 0.5, hz + 1.2, 1.9, 0.15, 0.9, M.fabricTeal, { collide: false, ao: 0 });
      // a pillow at the wall end, a wool blanket folded back at the foot
      { const g = new THREE.SphereGeometry(1, 14, 10); ch.geo(g, M.paint, new THREE.Matrix4().compose(new THREE.Vector3(hx - 2.48, top + 0.69, hz + 1.2), new THREE.Quaternion(), new THREE.Vector3(0.14, 0.05, 0.3)), { ao: 0, tint: 0xd8d0bc }); g.dispose(); }
      ch.box(hx - 1.08, top + 0.65, hz + 1.2, 0.44, 0.05, 0.92, M.paint, { collide: false, ao: 0, tint: 0x7a3a2a });
      ch.cyl(hx + 2.1, top, hz - 1.4, 0.4, 0.9, M.steel, { seg: 12 });
      // boards over the floor (the grass outside sits at the same height), a rug, his coat on a hook
      ch.box(hx, top + 0.04, hz, 5.4, 0.025, 4.2, M.woodDark, { collide: false, ao: 0, tint: 0x9a7a5a });
      rug(W, ch, hx - 0.2, top + 0.065, hz - 0.2, 1.4, 0.9, 0.1, ['#2c3a44', '#d8a83a', '#6a2c24', '#d9c9a4']);
      coat(ch, M, hx - 2.69, top + 1.9, hz - 1.0, Math.PI / 2, 0xd8a83a);
      ceilingLight(W, ch, hx, top + 2.8, hz, 0, { len: 0.8, intensity: 2.5, dist: 6, color: 0xffc890 });
    }
    // garden beds
    for (let i = 0; i < 3; i++) {
      const gx = ix + 1 + i * 2.4, gz = iz - 4;
      ch.box(gx, top, gz, 1.8, 0.35, 3.0, M.woodDark, { ao: 0 });
      ch.box(gx, top + 0.35, gz, 1.6, 0.03, 2.8, M.soil, { collide: false, ao: 0 });
      for (let k = 0; k < 4; k++) {
        const g = new THREE.IcosahedronGeometry(0.28, 0);
        ch.geo(g, M.leaf, new THREE.Matrix4().compose(new THREE.Vector3(gx, top + 0.55, gz - 1.1 + k * 0.72), new THREE.Quaternion(), new THREE.Vector3(1, 0.8, 1)), { ao: 0.5 });
        g.dispose();
      }
    }
    // fence around the top
    for (const [a, b, c, d] of [[-160, -68, -140, -68], [-140, -68, -140, -66.6], [-140, -61.5, -140, -48], [-140, -48, -160, -48], [-160, -48, -160, -68]]) railing(ch, M, a, b, c, d, top, { mat: M.woodDark, top: M.wood, h: 0.9 });
    lampPost(W, ch, -138.6, top, -60.4, { yaw: -2.4, h: 2.8 });
    // a little cairn of smooth pebbles by the path
    for (let k = 0; k < 7; k++) { const g = new THREE.DodecahedronGeometry(0.12 + (k % 3) * 0.05, 0); ch.geo(g, M.rock, new THREE.Matrix4().compose(new THREE.Vector3(-141.2 + (k % 3) * 0.16, top + 0.08 + Math.floor(k / 3) * 0.14, -63.4 + (k % 2) * 0.12), new THREE.Quaternion().setFromEuler(new THREE.Euler(k, k * 2, 0)), new THREE.Vector3(1.2, 0.7, 1)), { tint: 0xb8b0a4 }); g.dispose(); }
    W.addInteract({ id: 'pebble', x: -141.0, y: top + 0.3, z: -63.3, r: 2.0, label: 'Pick up a pebble' });
    // the answer: a tiny light far out over the sea that blinks back once the beacon is lit
    const ans = new THREE.Mesh(new THREE.SphereGeometry(2.2, 8, 6), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xdfefff).multiplyScalar(4), toneMapped: false, fog: false }));
    ans.position.set(-900, 24, 220); ans.visible = false; W.scene.add(ans); W.answerLight = ans;
  }

  // ===================== VERDANT RISE =====================
  {
    const ch = W.chunk('rise');
    const { x: rx, z: rz, top } = RISE;
    ch.box(rx, top - 0.4, rz, 22, 0.4, 20, M.wood, { ao: 0 });
    for (let x = -10; x <= 10; x += 4) for (let z = -9; z <= 9; z += 4.5) ch.cyl(rx + x, -5, rz + z, 0.28, top - 0.4 + 5, M.concreteDark, { seg: 8, collide: false });
    // pier to the north dock
    ch.box(rx, top - 0.4, rz + 13, 3, 0.4, 7, M.wood, { ao: 0 });
    for (const z of [10.5, 13.5, 16]) for (const k of [-1.2, 1.2]) ch.cyl(rx + k, -5, rz + z, 0.2, top - 0.4 + 5, M.woodDark, { seg: 8, collide: false });
    railing(ch, M, rx - 1.5, rz + 10, rx - 1.5, rz + 16.4, top, { mat: M.woodDark, top: M.wood });
    railing(ch, M, rx + 1.5, rz + 10, rx + 1.5, rz + 16.4, top, { mat: M.woodDark, top: M.wood });
    // perimeter rail
    railing(ch, M, rx - 11, rz + 10, rx - 1.5, rz + 10, top, { mat: M.woodDark, top: M.wood });
    railing(ch, M, rx + 1.5, rz + 10, rx + 11, rz + 10, top, { mat: M.woodDark, top: M.wood });
    railing(ch, M, rx - 11, rz - 10, rx + 11, rz - 10, top, { mat: M.woodDark, top: M.wood });
    railing(ch, M, rx - 11, rz - 10, rx - 11, rz + 10, top, { mat: M.woodDark, top: M.wood });
    railing(ch, M, rx + 11, rz - 10, rx + 11, rz + 10, top, { mat: M.woodDark, top: M.wood });
    // glasshouse: steel frame, glass panes, gabled roof, door on the north end
    const gx0 = rx - 5, gx1 = rx + 5, gz0 = rz - 8, gz1 = rz + 6, H = 3.4;
    const frame = (x, z) => ch.box(x, top, z, 0.12, H, 0.12, M.steel, { ao: 0 });
    for (let x = gx0; x <= gx1 + 0.01; x += 2.5) { frame(x, gz0); frame(x, gz1); }
    for (let z = gz0; z <= gz1 + 0.01; z += 2) { frame(gx0, z); frame(gx1, z); }
    wallLine(ch, M, gx0, gz0, gx0, gz1, top, H, 0.04, M.glassClear, []);
    wallLine(ch, M, gx1, gz0, gx1, gz1, top, H, 0.04, M.glassClear, []);
    wallLine(ch, M, gx0, gz0, gx1, gz0, top, H, 0.04, M.glassClear, []);
    wallLine(ch, M, gx0, gz1, gx1, gz1, top, H, 0.04, M.glassClear, [{ t: 5, w: 1.5, h: 2.5, frame: true }]);
    for (const k of [-1, 1]) {
      ch.box(rx + k * 2.55, top + H + 0.9, (gz0 + gz1) / 2, 5.4, 0.04, gz1 - gz0 + 0.3, M.glassClear, { collide: false, ao: 0, roll: -k * 0.42 });
      for (let z = gz0; z <= gz1 + 0.01; z += 2) ch.box(rx + k * 2.55, top + H + 0.9, z, 5.4, 0.08, 0.1, M.steel, { collide: false, ao: 0, roll: -k * 0.42 });
    }
    ch.box(rx, top + H + 2.0, (gz0 + gz1) / 2, 0.2, 0.15, gz1 - gz0 + 0.3, M.steel, { collide: false, ao: 0 });
    // beds and plants inside, grow lights
    for (const bx of [rx - 3, rx + 3]) {
      ch.box(bx, top, rz - 2, 1.6, 0.7, 10, M.woodDark, { ao: 0 });
      ch.box(bx, top + 0.7, rz - 2, 1.4, 0.04, 9.8, M.soil, { collide: false, ao: 0 });
      for (let k = 0; k < 9; k++) {
        const g = new THREE.IcosahedronGeometry(0.3 + (k % 3) * 0.12, 1);
        ch.geo(g, k % 2 ? M.leaf : M.leafDark, new THREE.Matrix4().compose(new THREE.Vector3(bx + ((k * 7) % 3 - 1) * 0.3, top + 0.95 + (k % 3) * 0.08, rz - 6.5 + k * 1.1), new THREE.Quaternion(), new THREE.Vector3(1, 1.2, 1)), { ao: 0.6 });
        g.dispose();
        if (k % 3 === 0) ch.box(bx, top + 0.7, rz - 6.5 + k * 1.1, 0.04, 1.1, 0.04, M.woodDark, { collide: false, ao: 0 });
      }
      for (let z = rz - 5; z <= rz + 3; z += 4) {
        ch.box(bx, top + H - 0.1, z, 0.2, 0.08, 1.4, M.steel, { collide: false, ao: 0 });
        ch.box(bx, top + H - 0.14, z, 0.14, 0.02, 1.3, M.lampWarm, { collide: false, ao: 0, tint: 0xffaa88 });
        W.light(bx, top + H - 0.6, z, 0xffb890, 2.5, 6, { chunk: ch });
      }
    }
    // tomatoes along the back wall, staked, far too many of them
    {
      const tz = rz - 7.4;   // inside the glass, against the back wall
      ch.box(rx, top, tz, 4.6, 0.45, 0.9, M.woodDark, { ao: 0.4 });
      ch.box(rx, top + 0.45, tz, 4.4, 0.03, 0.75, M.soil, { collide: false, ao: 0 });
      for (let i = 0; i < 6; i++) {
        const px = rx - 1.9 + i * 0.76, pz = tz + ((i * 5) % 3 - 1) * 0.12;
        ch.box(px, top + 0.45, pz - 0.12, 0.03, 1.5, 0.03, M.woodDark, { collide: false, ao: 0 });
        for (let k = 0; k < 3; k++) {
          const g = new THREE.IcosahedronGeometry(0.2 + (k % 2) * 0.06, 1);
          ch.geo(g, k % 2 ? M.leaf : M.leafDark, new THREE.Matrix4().compose(new THREE.Vector3(px + (k - 1) * 0.08, top + 0.7 + k * 0.32, pz), new THREE.Quaternion(), new THREE.Vector3(1, 1.3, 0.9)), { ao: 0.5 });
          g.dispose();
        }
        for (let k = 0; k < 4; k++) {
          const g = new THREE.SphereGeometry(0.068 + (k % 2) * 0.014, 10, 8);
          const ang = i * 1.7 + k * 1.9, rr = 0.2;
          ch.geo(g, M.paint, new THREE.Matrix4().makeTranslation(px + Math.cos(ang) * rr, top + 0.68 + ((k * 7 + i) % 4) * 0.2, pz + Math.sin(ang) * rr * 0.8), { tint: k === 3 && i % 2 ? 0xffb028 : 0xf2341a });
          g.dispose();
        }
      }
      ch.box(rx + 2.15, top + 0.45, tz + 0.36, 0.14, 0.2, 0.02, M.paint, { collide: false, ao: 0, tint: 0xe8dcc0 });
      W.addInteract({ id: 'tomato', x: rx - 0.4, y: top + 1.0, z: tz + 0.1, r: 2.0, label: 'Pick a tomato' });
    }
    // the seed bed by the door: one tall shoot
    ch.box(rx + 2.6, top, gz1 - 1.1, 1.2, 0.6, 1.0, M.woodDark, {});
    ch.box(rx + 2.6, top + 0.6, gz1 - 1.1, 1.05, 0.03, 0.85, M.soil, { collide: false, ao: 0 });
    ch.box(rx + 2.6, top + 0.6, gz1 - 1.1, 0.04, 0.55, 0.04, M.leaf, { collide: false, ao: 0 });
    { const g = new THREE.IcosahedronGeometry(0.16, 1); ch.geo(g, M.leaf, new THREE.Matrix4().makeTranslation(rx + 2.6, top + 1.2, gz1 - 1.1), {}); g.dispose(); }
    ch.box(rx + 2.3, top + 0.6, gz1 - 0.75, 0.12, 0.18, 0.02, M.paint, { collide: false, ao: 0 });
    W.addInteract({ id: 'seedbed', x: rx + 2.6, y: top + 0.9, z: gz1 - 1.1, r: 1.8, label: 'Look at the seed bed' });
    // potting bench with the botanist's cylinder
    table(ch, M, rx - 3.2, top, gz1 - 0.9, 1.6, 0.6, {});
    ch.box(rx - 3.4, top + 0.78, gz1 - 0.9, 0.34, 0.14, 0.26, M.steel, { collide: false, ao: 0 });
    ch.cyl(rx - 3.4, top + 0.86, gz1 - 0.9, 0.06, 0.24, M.brass, { seg: 10, roll: Math.PI / 2, collide: false });
    W.addInteract({ id: 'gardenLog', x: rx - 3.4, y: top + 1.0, z: gz1 - 0.9, r: 1.8, label: 'Play the botanist’s cylinder' });
    // water tank and barrels outside
    ch.cyl(rx + 8, top, rz - 6, 1.3, 2.6, M.copper, { seg: 18, tint: 0x6f9a86 });
    // its hoops, a lid, a tap near the bottom and a ladder up the side
    for (const h of [0.5, 1.4, 2.3]) ch.cyl(rx + 8, top + h, rz - 6, 1.33, 0.07, M.steel, { seg: 18, collide: false });
    ch.cyl(rx + 8, top + 2.6, rz - 6, 0.5, 0.06, M.steel, { seg: 14, collide: false });
    ch.cyl(rx + 8 - 1.36, top + 0.32, rz - 6, 0.04, 0.12, M.brass, { seg: 8, collide: false, roll: Math.PI / 2 });
    for (const k of [-1, 1]) ch.box(rx + 8 + k * 0.2, top, rz - 6 + 1.36, 0.04, 2.7, 0.04, M.steel, { collide: false, ao: 0 });
    for (let i = 0; i < 8; i++) ch.box(rx + 8, top + 0.3 + i * 0.3, rz - 6 + 1.36, 0.4, 0.03, 0.03, M.steel, { collide: false, ao: 0 });
    barrel(ch, M, rx - 8, top, rz + 6); barrel(ch, M, rx - 8.7, top, rz + 5.4, { mat: M.woodDark });
    lampPost(W, ch, rx + 2.2, top, rz + 9.2, { yaw: Math.PI, h: 3 });
    for (let i = 0; i < 4; i++) planter(ch, M, rx + 7.5, top, rz + 1 + i * 2, { w: 0.9 });
  }

  // ===================== THE SKIFF =====================
  {
    const g = new THREE.Group();
    const hullShape = new THREE.Shape();
    hullShape.moveTo(-1.2, -3.2); hullShape.lineTo(1.2, -3.2); hullShape.lineTo(1.35, 1.6); hullShape.quadraticCurveTo(0.9, 3.6, 0, 4.0); hullShape.quadraticCurveTo(-0.9, 3.6, -1.35, 1.6); hullShape.lineTo(-1.2, -3.2);
    const hullG = new THREE.ExtrudeGeometry(hullShape, { depth: 0.9, bevelEnabled: true, bevelSize: 0.12, bevelThickness: 0.1, bevelSegments: 2 });
    hullG.rotateX(Math.PI / 2); hullG.translate(0, 0.45, 0);
    const hullMat = new THREE.MeshStandardMaterial({ color: 0x2c3a44, roughness: 0.5, metalness: 0.5 });
    const hull = new THREE.Mesh(hullG, hullMat); hull.castShadow = true; g.add(hull);
    const deck = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.08, 6.2), M.wood); deck.position.set(0, 0.5, 0.4); g.add(deck);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.75, 0.1, 5.2), M.hazard); stripe.position.set(0, 0.2, 0.2); g.add(stripe);
    // canopy on four posts
    for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.9, 6), M.steel); p.position.set(a * 0.95, 1.45, b * 1.1 - 0.8); g.add(p); }
    const roof = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.08, 2.8), M.fabricPale); roof.position.set(0, 2.4, -0.8); g.add(roof);
    const skiffLamp = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x63f0e2).multiplyScalar(1.4), toneMapped: false });
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.2), skiffLamp); lamp.position.set(0, 2.55, 1.2); g.add(lamp);
    W.skiffLamp = skiffLamp;   // its own material, so it can flash back at the lighthouse
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.5, 6), M.steel); pole.position.set(0, 2.5, 0.6); g.add(pole);
    lamp.position.set(0, 2.75, 0.6);
    const bench1 = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.1, 0.4), M.wood); bench1.position.set(0, 0.95, -1.8); g.add(bench1);
    g.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
    W.scene.add(g);
    // the wake: two arms opening out behind the stern and churned water down the middle. The
    // foam pattern is fixed to the water, so the boat moves through it rather than dragging it.
    const wakeMat = new THREE.ShaderMaterial({
      uniforms: { amt: { value: 0 }, time: { value: 0 } },
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`,
      fragmentShader: `uniform float amt; uniform float time; varying vec2 vUv; varying vec3 vW;
        float h(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
        float n2(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(h(i), h(i + vec2(1, 0)), f.x), mix(h(i + vec2(0, 1)), h(i + vec2(1, 1)), f.x), f.y); }
        void main(){
          float along = vUv.y * 18.0, x = abs(vUv.x - 0.5) * 16.0;
          float armX = 1.1 + along * 0.354, armW = 0.12 + along * 0.05;
          float arm = exp(-pow(x - armX, 2.0) / armW);
          float mid = exp(-x * x / (0.4 + along * 0.12)) * (1.0 - vUv.y) * 0.9;
          vec2 q = mat2(0.8, -0.6, 0.6, 0.8) * vW.xz; float n = n2(vW.xz * 1.3 + time * 0.3) * 0.5 + n2(q * 3.1 - time * 0.5) * 0.3 + n2(q.yx * 7.3 + time * 0.2) * 0.2;
          float a = (arm * 1.4 + mid * 0.7) * smoothstep(0.2, 0.8, n) * pow(1.0 - vUv.y, 1.3) * smoothstep(0.0, 0.05, vUv.y) * smoothstep(8.0, 6.5, x);
          gl_FragColor = vec4(vec3(0.75, 0.88, 1.0) * a * amt, 1.0);
        }`
    });
    const wake = new THREE.Mesh(new THREE.PlaneGeometry(16, 18), wakeMat);
    wake.rotation.x = -Math.PI / 2; wake.position.set(0, 0.06, -11.2); wake.renderOrder = 2; wake.frustumCulled = false; g.add(wake);
    W.skiff = { group: g, wake, at: 'pier', light: W.light(0, 3, 0, 0x5fe8dc, 3, 8, { key: 'skiff' }), bob: 0 };
    // the skiff is solid: hull and deck, the canopy posts and roof, the bench, and Luka at the
    // wheel. Its colliders ride along with it (a dynamic chunk, re-placed every frame).
    {
      const sc = W.chunk('skiff', { dynamic: true });
      const parts = [
        { type: 'box', l: [0, 0, 0.4], hx: 1.32, hy: 0.55, hz: 3.62 },          // hull, deck on top
        { type: 'box', l: [0, 2.4, -0.8], hx: 1.1, hy: 0.05, hz: 1.4 },          // canopy roof
        { type: 'box', l: [0, 0.95, -1.8], hx: 1.0, hy: 0.05, hz: 0.2 },         // bench
        ...[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([a, b]) => ({ type: 'cyl', l: [a * 0.95, 0.5, b * 1.1 - 0.8], r: 0.07, h: 1.9 })),
        { type: 'cyl', l: [0, 0.55, 1.6], r: 0.3, h: 1.45 }                      // Luka
      ];
      const cols = parts.map(p => sc.collider(p.type === 'box' ? { type: 'box', x: 0, y: 0, z: 0, hx: p.hx, hy: p.hy, hz: p.hz, yaw: 0 } : { type: 'cyl', x: 0, z: 0, r: p.r, y0: 0, y1: p.h }));
      W.onUpdate(() => {
        const P = g.position, yaw = g.rotation.y, cs = Math.cos(yaw), sn = Math.sin(yaw);
        parts.forEach((p, i) => {
          const c = cols[i], [lx, ly, lz] = p.l;
          c.x = P.x + lx * cs + lz * sn; c.z = P.z - lx * sn + lz * cs;
          if (c.type === 'box') { c.y = P.y + ly; c.c = Math.cos(yaw); c.s = Math.sin(yaw); }
          else { c.y0 = P.y + ly; c.y1 = P.y + ly + p.h; }
        });
      });
    }
    const d = DOCKS.pier;
    g.position.set(d.boat[0], 0, d.boat[1]); g.rotation.y = d.yaw;
    for (const k of Object.keys(DOCKS)) {
      const D = DOCKS[k];
      W.addInteract({ id: 'skiff_' + k, x: D.land[0], y: D.land[1] + 0.9, z: D.land[2], r: 3.2, label: 'Board the skiff' });
    }
  }
}

function ringRail(ch, M, cx, cz, r, y) {
  const n = 24;
  for (let i = 0; i < n; i++) {
    const a = i / n * Math.PI * 2, b = (i + 1) / n * Math.PI * 2;
    ch.box(cx + Math.sin(a) * r, y, cz + Math.cos(a) * r, 0.05, 0.9, 0.05, M.steel, { collide: false, ao: 0 });
    const mx = (Math.sin(a) + Math.sin(b)) / 2 * r, mz = (Math.cos(a) + Math.cos(b)) / 2 * r;
    ch.box(cx + mx, y + 0.9, cz + mz, 0.06, 0.06, 2 * r * Math.sin(Math.PI / n), M.steel, { yaw: (a + b) / 2 + Math.PI / 2, collide: false, ao: 0 });
  }
}
