// Signs, plaques, stencils, notices and chalk: lettered by hand and then left out in the weather.
// Every letter is a pen or brush stroke from js/ui/hand.js with its own wobble, so no two signs, and
// no two letters on one sign, are quite alike. Then the paint flakes, rain runs down, rust bleeds from
// the screws and the bottom edge collects dirt.
//
// signTexture(lines, o) keeps the old textTexture() interface: lines are strings or
// { text, size, color, hand, font } objects; o has w, h, size, color, bg, align, lh, border and style:
//   painted  sign-writer's enamel on a board, with a drop shade and a pinstripe
//   stencil  sprayed through a stencil: bridges in the letters, overspray round them
//   wall     painted straight onto concrete, flaking, with drips
//   carved   cut into stone: dark in the cut, light on the lower edge
//   plaque   cast bronze, raised letters, verdigris
//   enamel   a vitreous enamel street sign, chipped to the steel
//   chalk    chalk on a board or a wall
//   marker   felt pen on tape or card
//   notes    slips of paper pinned to a board, each written by someone else
//   poster   a printed notice, faded and water-stained
import * as THREE from '../../vendor/three.module.min.js';
import { drawLine, measure } from '../ui/hand.js';

function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; }
const hashStr = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; };
const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const rgba = (hex, a) => { const c = new THREE.Color(hex); return `rgba(${Math.round(c.r * 255)},${Math.round(c.g * 255)},${Math.round(c.b * 255)},${a})`; };
const shade = (hex, k) => '#' + new THREE.Color(hex).multiplyScalar(k).getHexString();
const isDark = (hex) => { if (!hex || hex.startsWith('rgba')) return false; const c = new THREE.Color(hex); return c.r * 0.3 + c.g * 0.59 + c.b * 0.11 < 0.35; };

// one line of lettering. y is the top of the capitals; cap is the capital height in pixels.
function letterLine(g, text, x, y, cap, o) {
  let size = cap / 0.97;
  const maxW = o.maxW || Infinity;
  let w = measure(text, size, o.tracking ?? 0.9);
  if (w > maxW) { size *= maxW / w; w = maxW; }
  const x0 = o.align === 'left' ? x : o.align === 'right' ? x - w : x - w / 2;
  drawLine(g, text, x0, y + (cap - size * 0.97) / 2, size, { color: o.color, pen: o.pen ?? 0.12, seed: o.seed ?? 1, slant: o.slant ?? 0.02, bleed: !!o.bleed, wobble: o.wobble ?? 0.5, tracking: o.tracking ?? 0.9 });
  return { x0, w, size };
}

// ---------------- weather ----------------
function flake(g, w, h, r, amount, scale = 1) {
  g.save(); g.globalCompositeOperation = 'destination-out';
  const n = Math.floor(amount * w * h / 260);
  for (let i = 0; i < n; i++) {
    const x = r() * w, y = r() * h, rad = (0.6 + r() * r() * 5) * scale;
    g.fillStyle = `rgba(0,0,0,${0.5 + r() * 0.5})`;
    g.beginPath();
    for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2, rr = rad * (0.5 + r()); g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.8); }
    g.closePath(); g.fill();
  }
  g.restore();
}
function streaks(g, w, h, r, n, color = '40,32,24', strength = 0.12) {
  for (let i = 0; i < n; i++) {
    const x = r() * w, len = h * (0.2 + r() * 0.8), wd = 1 + r() * 5;
    const gr = g.createLinearGradient(0, 0, 0, len);
    gr.addColorStop(0, `rgba(${color},${strength * (0.5 + r())})`); gr.addColorStop(1, `rgba(${color},0)`);
    g.fillStyle = gr; g.fillRect(x, 0, wd, len);
  }
}
function rust(g, x, y, h, r, k = 1) {
  const len = h * (0.25 + r() * 0.5) * k;
  const gr = g.createLinearGradient(0, y, 0, y + len);
  gr.addColorStop(0, 'rgba(130,62,22,.55)'); gr.addColorStop(0.3, 'rgba(120,64,28,.28)'); gr.addColorStop(1, 'rgba(110,60,30,0)');
  g.fillStyle = gr;
  g.beginPath(); g.moveTo(x - 3, y); g.lineTo(x + 3, y); g.lineTo(x + 2 + r() * 4, y + len); g.lineTo(x - 2 - r() * 3, y + len); g.closePath(); g.fill();
}
function grime(g, w, h, r, k = 1) {
  // dirt settles at the bottom and in the corners
  let gr = g.createLinearGradient(0, h * 0.55, 0, h);
  gr.addColorStop(0, 'rgba(30,24,18,0)'); gr.addColorStop(1, `rgba(30,24,18,${0.32 * k})`);
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  for (const [cx, cy] of [[0, 0], [w, 0], [0, h], [w, h]]) {
    gr = g.createRadialGradient(cx, cy, 0, cx, cy, Math.min(w, h) * 0.7);
    gr.addColorStop(0, `rgba(28,22,16,${0.22 * k})`); gr.addColorStop(1, 'rgba(28,22,16,0)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
  }
  for (let i = 0; i < 14; i++) {
    const x = r() * w, y = r() * h, rad = 10 + r() * 60;
    gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, `rgba(30,26,20,${0.08 * k})`); gr.addColorStop(1, 'rgba(30,26,20,0)');
    g.fillStyle = gr; g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
}
function mottle(g, w, h, r, base) {
  g.fillStyle = base; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 40; i++) {
    const x = r() * w, y = r() * h, rad = 20 + r() * 120, light = r() < 0.5;
    const gr = g.createRadialGradient(x, y, 0, x, y, rad);
    gr.addColorStop(0, light ? 'rgba(255,250,235,.05)' : 'rgba(0,0,0,.07)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  // fine grit
  for (let i = 0; i < w * h / 90; i++) { g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,.04)' : 'rgba(0,0,0,.06)'; g.fillRect(r() * w, r() * h, 1 + r() * 2, 1); }
}
function scratches(g, w, h, r, n, color = 'rgba(255,248,230,.12)') {
  g.strokeStyle = color; g.lineCap = 'round';
  for (let i = 0; i < n; i++) {
    const x = r() * w, y = r() * h, a = (r() - 0.5) * 0.9, len = 10 + r() * 70;
    g.lineWidth = 0.6 + r() * 1.1; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * len, y + Math.sin(a) * len); g.stroke();
  }
}
function screws(g, w, h, r, inset = 16) {
  for (const [x, y] of [[inset, inset], [w - inset, inset], [inset, h - inset], [w - inset, h - inset]]) {
    const gr = g.createRadialGradient(x - 2, y - 2, 1, x, y, 8);
    gr.addColorStop(0, '#8a8478'); gr.addColorStop(1, '#2a2620');
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, 7, 0, 7); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.6; g.beginPath(); const a = r() * 3; g.moveTo(x - Math.cos(a) * 5, y - Math.sin(a) * 5); g.lineTo(x + Math.cos(a) * 5, y + Math.sin(a) * 5); g.stroke();
    rust(g, x, y + 6, h, r, 0.5);
  }
}
function roughBorder(g, w, h, r, color, inset, width) {
  g.strokeStyle = color; g.lineWidth = width; g.lineCap = 'round'; g.lineJoin = 'round';
  const j = () => (r() - 0.5) * 2.4;
  const pts = [[inset, inset], [w - inset, inset], [w - inset, h - inset], [inset, h - inset]];
  g.beginPath();
  pts.forEach((p, i) => { const q = pts[(i + 1) % 4]; if (!i) g.moveTo(p[0] + j(), p[1] + j()); g.quadraticCurveTo((p[0] + q[0]) / 2 + j() * 2, (p[1] + q[1]) / 2 + j() * 2, q[0] + j(), q[1] + j()); });
  g.stroke();
}
function drips(g, x0, x1, y, r, color, n) {
  g.fillStyle = color; g.strokeStyle = color; g.lineCap = 'round';
  for (let i = 0; i < n; i++) {
    const x = x0 + r() * (x1 - x0), len = 6 + r() * r() * 50, wd = 1.5 + r() * 2.5;
    g.lineWidth = wd; g.beginPath(); g.moveTo(x, y - 2); g.lineTo(x + (r() - 0.5) * 1.5, y + len); g.stroke();
    g.beginPath(); g.arc(x, y + len, wd * 0.9, 0, 7); g.fill();
  }
}
// stencil bridges: the little uncut ties that hold the middle of an O in a stencil
const BRIDGED = new Set('OQDBPRA04689abdegopq@'.split(''));
function bridges(g, text, x0, y, size, cap, tracking = 0.9) {
  g.save(); g.globalCompositeOperation = 'destination-out'; g.fillStyle = '#000';
  let x = x0; const s = size / 10;
  for (const ch of text) {
    const adv = measure(ch, size, tracking);
    if (BRIDGED.has(ch)) {
      const cx = x + adv * 0.45, bw = Math.max(2, cap * 0.07);
      if (ch === 'A' || ch === '4') g.fillRect(cx - bw / 2, y - 2, bw, cap * 0.3);
      else { g.fillRect(cx - bw / 2, y - 2, bw, cap * 0.22); g.fillRect(cx - bw / 2, y + cap * 0.82, bw, cap * 0.3); }
    }
    x += adv;
  }
  g.restore();
}

// ---------------- the lettering pass, shared by every style ----------------
function layout(lines, o, W, H) {
  const size = o.size || 64, lh = o.lh || 1.25;
  const items = lines.map(l => typeof l === 'object' ? { ...l } : { text: l });
  items.forEach(it => { it.px = it.size || size; it.cap = it.px * 0.8; });
  const total = items.reduce((a, it) => a + it.px * lh, 0) - (items.length ? items[items.length - 1].px * (lh - 1) : 0);
  let y = H / 2 - total / 2;
  for (const it of items) { it.y = y + (it.px - it.cap) / 2; y += it.px * lh; }
  return items;
}
function writeLines(g, items, o, W, style, seed, extra = {}) {
  const align = o.align || 'center', margin = o.align === 'left' ? 34 : 0;
  const placed = [];
  items.forEach((it, i) => {
    const text = it.text; if (!text || !text.trim()) return;
    const handLine = it.hand || /italic/.test(it.font || '');
    const col = it.color || o.color || '#e8e0cc';
    const pen = extra.pen ?? ({ stencil: 0.22, carved: 0.17, wall: 0.2, plaque: 0.2, enamel: 0.2, painted: 0.19, poster: 0.17 }[style] ?? 0.15);
    const p = letterLine(g, text, align === 'left' ? margin : align === 'right' ? W - 30 : W / 2, it.y, it.cap, {
      color: col, pen: handLine ? (extra.pen ?? 0.12) : pen, seed: seed + i * 31, align, maxW: W - 60 - margin,
      slant: handLine ? 0.08 : extra.slant ?? 0.03, wobble: handLine ? 1 : extra.wobble ?? 0.75, bleed: handLine || extra.bleed, tracking: extra.tracking ?? (style === 'stencil' ? 1.6 : 1.1)
    });
    placed.push({ ...p, y: it.y, cap: it.cap, text, hand: handLine, color: col });
  });
  return placed;
}

export function signTexture(lines, o = {}) {
  const W = o.w || 512, H = o.h || 256;
  const key = JSON.stringify(lines) + (o.bg || '') + W + 'x' + H;
  const seed = hashStr(key), r = rng(seed);
  let style = o.style;
  const bg = o.bg && o.bg !== 'rgba(0,0,0,0)' ? o.bg : null;
  if (!style) {
    const serif = /Garamond/.test(o.font || '');
    if (!bg) style = isDark(o.color || '#e8e0cc') ? 'carved' : 'wall';
    else style = serif ? 'painted' : 'stencil';
  }
  const c = canvas(W, H), g = c.getContext('2d');
  const items = layout(lines, o, W, H);
  const L = canvas(W, H), lg = L.getContext('2d');   // lettering layer, weathered on its own

  if (style === 'painted' || style === 'enamel') {
    mottle(g, W, H, r, bg || '#24221e');
    if (style === 'enamel') {
      roughBorder(g, W, H, r, o.color || '#2a2620', 14, 5);
    } else {
      roughBorder(g, W, H, r, rgba(o.color || '#e7dcc2', 0.55), 12, 2.2);
      roughBorder(g, W, H, r, rgba(o.color || '#e7dcc2', 0.25), 19, 1.2);
    }
    // the sign-writer's drop shade, then the letter
    const sh = canvas(W, H), sg = sh.getContext('2d');
    writeLines(sg, items.map(it => ({ ...it, color: '#0c0a08' })), o, W, style, seed);
    lg.globalAlpha = 0.55; lg.drawImage(sh, 4, 4); lg.globalAlpha = 1;
    writeLines(lg, items, o, W, style, seed);
    flake(lg, W, H, r, style === 'enamel' ? 0.08 : 0.17, 1.1);
    g.drawImage(L, 0, 0);
    if (style === 'enamel') {
      // chips knocked out of the enamel, steel showing, rust round them
      for (let i = 0; i < 9; i++) {
        const x = r() * W, y = r() < 0.5 ? r() * H * 0.25 : H - r() * H * 0.25, rad = 4 + r() * 14;
        g.fillStyle = 'rgba(70,40,24,.85)'; g.beginPath(); g.ellipse(x, y, rad, rad * 0.7, r() * 3, 0, 7); g.fill();
        g.fillStyle = 'rgba(40,38,36,.9)'; g.beginPath(); g.ellipse(x, y, rad * 0.6, rad * 0.4, r() * 3, 0, 7); g.fill();
        rust(g, x, y, H, r, 0.4);
      }
    }
    scratches(g, W, H, r, 22);
    streaks(g, W, H, r, 16, '40,32,24', 0.16);
    grime(g, W, H, r, 1.15);
    if (H > 120) screws(g, W, H, r);
  } else if (style === 'stencil') {
    mottle(g, W, H, r, bg || '#1b2026');
    // overspray first, soft, then the paint through the stencil
    const os = canvas(W, H), og = os.getContext('2d');
    writeLines(og, items, o, W, style, seed, { wobble: 0.35, slant: 0 });
    g.save(); g.filter = 'blur(3px)'; g.globalAlpha = 0.28; g.drawImage(os, 0, 0); g.restore();
    const placed = writeLines(lg, items, o, W, style, seed, { wobble: 0.35, slant: 0 });
    for (const p of placed) if (!p.hand) bridges(lg, p.text, p.x0, p.y, p.size, p.cap, 1.6);
    flake(lg, W, H, r, 0.2, 1.1);
    g.drawImage(L, 0, 0);
    scratches(g, W, H, r, 18);
    streaks(g, W, H, r, 14, '20,16,12', 0.15);
    for (let i = 0; i < 3; i++) rust(g, r() * W, 0, H, r, 0.8);
    grime(g, W, H, r, 1.1);
  } else if (style === 'wall') {
    if (bg) mottle(g, W, H, r, bg);
    const placed = writeLines(lg, items, o, W, style, seed, { wobble: 0.35 });
    for (const p of placed) drips(lg, p.x0, p.x0 + p.w, p.y + p.cap, r, p.color, Math.ceil(p.w / 90));
    flake(lg, W, H, r, 0.34, 1.4);
    g.globalAlpha = 0.9; g.drawImage(L, 0, 0); g.globalAlpha = 1;
  } else if (style === 'carved') {
    if (bg) mottle(g, W, H, r, bg);
    const col = o.color || '#3b342c';
    // the light catches the lower edge of the cut; the cut itself is in shadow and holds dirt
    const hi = canvas(W, H), hg = hi.getContext('2d');
    writeLines(hg, items.map(it => ({ ...it, color: bg ? shade(bg, 1.7) : 'rgba(235,225,200,1)' })), o, W, style, seed, { wobble: 0.25, slant: 0, pen: 0.15 });
    g.globalAlpha = bg ? 0.55 : 0.35; g.drawImage(hi, 1.5, 2.5); g.globalAlpha = 1;
    writeLines(lg, items.map(it => ({ ...it, color: it.color || col })), o, W, style, seed, { wobble: 0.25, slant: 0, pen: 0.15 });
    flake(lg, W, H, r, 0.06, 0.7);
    g.drawImage(L, 0, 0);
    if (bg) { streaks(g, W, H, r, 12, '30,28,22', 0.12); grime(g, W, H, r, 0.8); }
  } else if (style === 'plaque') {
    // cast bronze: a dark field, raised rim, raised letters catching the light, green in the hollows
    mottle(g, W, H, r, '#3a2e1e');
    roughBorder(g, W, H, r, '#8a6a3a', 10, 7); roughBorder(g, W, H, r, '#c9a060', 8, 2);
    const sh = canvas(W, H), sg = sh.getContext('2d');
    writeLines(sg, items.map(it => ({ ...it, color: '#120c06' })), o, W, style, seed, { wobble: 0.2, slant: 0 });
    g.globalAlpha = 0.7; g.drawImage(sh, 2, 3); g.globalAlpha = 1;
    writeLines(lg, items.map(it => ({ ...it, color: '#c8a466' })), o, W, style, seed, { wobble: 0.2, slant: 0 });
    g.drawImage(L, 0, 0);
    for (let i = 0; i < 26; i++) {
      const x = r() * W, y = r() * H, rad = 6 + r() * 40;
      const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, 'rgba(70,140,110,.32)'); gr.addColorStop(1, 'rgba(70,140,110,0)');
      g.fillStyle = gr; g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
    }
    streaks(g, W, H, r, 10, '60,120,95', 0.18);
    grime(g, W, H, r, 0.7);
  } else if (style === 'chalk' || style === 'board') {
    if (style === 'board' || bg) {
      mottle(g, W, H, r, bg || '#1d2622');
      // old writing wiped off, never quite gone
      for (let i = 0; i < 10; i++) { g.fillStyle = 'rgba(230,230,220,.04)'; g.save(); g.translate(r() * W, r() * H); g.rotate((r() - 0.5) * 0.4); g.fillRect(-90, -16, 180 + r() * 120, 26 + r() * 20); g.restore(); }
    }
    writeLines(lg, items.map(it => ({ ...it, color: it.color || o.color || 'rgba(236,232,220,1)', hand: true })), o, W, style, seed, { pen: 0.14 });
    // chalk is grainy: knock little holes all through the strokes
    flake(lg, W, H, r, 2.4, 0.55);
    g.globalAlpha = 0.88; g.drawImage(L, 0, 0); g.globalAlpha = 1;
    if (style === 'board') { roughBorder(g, W, H, r, '#5a4630', 6, 12); grime(g, W, H, r, 0.5); }
  } else if (style === 'marker') {
    mottle(g, W, H, r, bg || '#d8c58a');
    // tape: translucent, wrinkled across
    for (let i = 0; i < 7; i++) { const x = r() * W; g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(x, 0, 2 + r() * 6, H); g.fillStyle = 'rgba(0,0,0,.05)'; g.fillRect(x + 6, 0, 2, H); }
    writeLines(lg, items.map(it => ({ ...it, hand: true })), o, W, style, seed, { pen: 0.16 });
    g.drawImage(L, 0, 0);
    grime(g, W, H, r, 0.35);
  } else if (style === 'notes') {
    // a board of pinned slips: the heading painted on the board, every slip in a different hand
    mottle(g, W, H, r, '#6a4a30');
    for (let i = 0; i < 120; i++) { g.fillStyle = 'rgba(30,20,10,.25)'; g.fillRect(r() * W, r() * H, 1 + r() * 2, 1 + r() * 2); }   // pin holes
    const head = items[0];
    letterLine(g, head.text, W / 2, 26, head.cap, { color: '#e8dcc0', pen: 0.15, seed, wobble: 0.4 });
    const slips = items.slice(1).filter(it => it.text && it.text.trim());
    const rows = slips.length, slotH = (H - 100) / rows;
    slips.forEach((it, i) => {
      const sw = W * (0.78 + r() * 0.16), sh = slotH * 0.8, cx = W / 2 + (r() - 0.5) * 40, cy = 92 + slotH * i + slotH / 2;
      g.save(); g.translate(cx, cy); g.rotate((r() - 0.5) * 0.06);
      g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(-sw / 2 + 4, -sh / 2 + 5, sw, sh);
      g.fillStyle = ['#e9e0c8', '#ded6b8', '#eee8d6', '#d9cfa8'][i % 4]; g.fillRect(-sw / 2, -sh / 2, sw, sh);
      const pen = ['#1d2730', '#2c3f6c', '#3a2a20', '#7a2c1c'][i % 4];
      letterLine(g, it.text, 0, -it.cap / 2, it.cap * 0.95, { color: it.color || pen, pen: 0.09 + r() * 0.03, seed: seed + i * 7, wobble: 0.9 + r() * 0.4, slant: 0.04 + r() * 0.08, bleed: true, maxW: sw - 30 });
      g.fillStyle = '#b03a2a'; g.beginPath(); g.arc(0, -sh / 2 + 8, 6, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.arc(-2, -sh / 2 + 6, 2, 0, 7); g.fill();
      g.restore();
    });
    streaks(g, W, H, r, 8, '30,20,10', 0.15);
    grime(g, W, H, r, 0.7);
  } else if (style === 'poster') {
    mottle(g, W, H, r, bg || '#d9cfb4');
    // printed slightly out of register: a red pass then the black
    const ink = canvas(W, H), ig = ink.getContext('2d');
    writeLines(ig, items, o, W, style, seed, { wobble: 0.25, slant: 0, pen: 0.14 });
    g.globalAlpha = 0.25; g.drawImage(ink, 2, 1); g.globalAlpha = 1;
    flake(ig, W, H, r, 0.12, 0.5);
    g.drawImage(ink, 0, 0);
    // a tide mark from the rain, fading, a torn corner
    g.strokeStyle = 'rgba(110,90,60,.3)'; g.lineWidth = 3; g.beginPath();
    for (let x = 0; x <= W; x += 16) g.lineTo(x, H * 0.82 + Math.sin(x * 0.03 + seed) * 12);
    g.stroke();
    g.fillStyle = 'rgba(120,96,60,.08)'; g.fillRect(0, H * 0.82, W, H);
    streaks(g, W, H, r, 14, '90,70,45', 0.12);
    grime(g, W, H, r, 0.5);
    g.save(); g.globalCompositeOperation = 'destination-out'; g.beginPath();
    const tc = W * (0.12 + r() * 0.1); g.moveTo(W, H - tc); for (let i = 0; i <= 8; i++) g.lineTo(W - tc * i / 8 + (r() - 0.5) * 6, H - tc + tc * i / 8 + (r() - 0.5) * 6); g.lineTo(W, H); g.closePath(); g.fill(); g.restore();
  } else {
    if (bg) mottle(g, W, H, r, bg);
    writeLines(lg, items, o, W, style, seed);
    g.drawImage(L, 0, 0);
  }
  if (o.border) roughBorder(g, W, H, r, o.border, 12, 7);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return t;
}

// free-hand writing onto an existing canvas (chalk on a wall, paint on a clock face, a tally note)
export function writeOn(g, text, x, y, cap, o = {}) {
  return letterLine(g, text, x, y, cap, { color: o.color || '#e8e0cc', pen: o.pen ?? 0.11, seed: o.seed ?? hashStr(text), align: o.align || 'left', slant: o.slant ?? 0.06, wobble: o.wobble ?? 1, bleed: o.bleed ?? true, maxW: o.maxW });
}
export function chalkify(g, w, h, seed = 7) { flake(g, w, h, rng(seed), 2.4, 0.55); }
