// The Hollow City: Sky Bridge, Upper Terrace (bell tower, the Reaching memorial), Concourse
// (transit arches with the civic lanterns, Civic Archive, Vale Court apartments), Market Pier,
// the old Service Walk and quay, the transit span, South Plaza and the Deep gatehouse,
// two failing towers, the skyline and the drowned Tarn Quarter.
import * as THREE from '../../vendor/three.module.min.js';
import { writeOn, chalkify } from './lettering.js';
import { wallLine, room, arch, column, deg, crag } from './arch.js';
import { railing, lampPost, sconce, ceilingLight, crate, barrel, bench, table, shelf, slidingDoor, sign, planter, cable, pipeRun, console_ , book , cot, chair, tapedNote } from './props.js';
import { textTexture, decal } from './materials.js';

export const CON = 6;     // concourse height
export const TER = 12;    // upper terrace height
export const WF = 2;      // waterfront height
export const QUAY = 2.2;  // service walk height

let seedState = 1234567;
const rnd = () => { seedState = (seedState * 1103515245 + 12345) & 0x7fffffff; return seedState / 0x7fffffff; };

// facade with a grid of windows (some lit), cornice and plinth. Solid block collider.
export function building(W, ch, x0, z0, x1, z1, y, h, o = {}) {
  const M = W.M, mat = o.mat || M.concrete;
  const w = x1 - x0, d = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
  if (!o.hollow) ch.box(cx, y, cz, w, h, d, mat, { tint: o.tint, ao: 2.5, aoMin: 0.55 });
  // plinth and cornice
  ch.box(cx, y, cz, w + 0.3, 0.9, d + 0.3, o.base || M.concreteDark, { collide: false, ao: 0.6 });
  ch.box(cx, y + h, cz, w + 0.5, 0.45, d + 0.5, o.trim || M.concreteDark, { ao: 0 });
  if (o.roof !== false) ch.box(cx, y + h + 0.45, cz, w - 0.4, 0.5, d - 0.4, M.concreteDark, { ao: 0 });
  // floor bands
  const fh = o.floorH || 3.4;
  const floors = Math.floor((h - 1.2) / fh);
  for (let f = 1; f <= floors; f++) {
    const fy = y + f * fh - 0.15;
    if (fy > y + h - 1) break;
    ch.box(cx, fy, cz, w + 0.12, 0.16, d + 0.12, o.trim || M.concreteDark, { collide: false, ao: 0 });
  }
  // windows on each face
  const lit = o.lit ?? 0.28;
  const face = (ax, az, bx, bz, nx, nz, len) => {
    const n = Math.max(1, Math.floor(len / (o.winSpacing || 2.4)));
    for (let f = (o.skipGround ? 1 : 0); f < floors; f++) {
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n;
        const px = ax + (bx - ax) * t + nx * 0.03, pz = az + (bz - az) * t + nz * 0.03;
        const py = y + f * fh + 0.95;
        const yaw = Math.atan2(nx, nz);
        if (rnd() < (o.broken ?? 0.06)) continue;
        const on = rnd() < lit;
        ch.box(px, py, pz, 1.0, 1.55, 0.06, on ? M.window : M.glass, { yaw, collide: false, ao: 0, tint: on ? new THREE.Color().setScalar(0.25 + rnd() * 0.6) : 0xffffff });
        ch.box(px + nx * 0.02, py - 0.08, pz + nz * 0.02, 1.2, 0.08, 0.14, o.trim || M.concreteDark, { yaw, collide: false, ao: 0 });
      }
    }
  };
  if (o.faces !== false) {
    face(x0, z1, x1, z1, 0, 1, w);   // north
    face(x1, z0, x0, z0, 0, -1, w);  // south
    face(x1, z1, x1, z0, 1, 0, d);   // east
    face(x0, z0, x0, z1, -1, 0, d);  // west
  }
  // balconies on one face of some buildings, a few air vents
  if (o.balconies !== false && h > 9 && rnd() < 0.55) {
    const side = rnd() < 0.5 ? 1 : -1;   // north or south face
    const fz = side > 0 ? z1 : z0;
    const n = Math.max(1, Math.floor(w / 4.5));
    for (let f = 1; f < floors; f++) for (let i = 0; i < n; i++) {
      if (rnd() < 0.35) continue;
      const bx = x0 + (i + 0.5) * w / n, by = y + f * fh;
      ch.box(bx, by - 0.12, fz + side * 0.55, 2.2, 0.14, 1.1, o.trim || M.concreteDark, { collide: false, ao: 0 });
      ch.box(bx, by + 0.02, fz + side * 1.07, 2.2, 0.9, 0.05, M.steel, { collide: false, ao: 0, tint: 0x888888 });
      if (rnd() < 0.3) ch.box(bx + 0.6, by + 0.02, fz + side * 0.6, 0.5, 0.45, 0.4, M.panelDark, { collide: false, ao: 0 });
    }
  }
  // rooftop: water tank or plant room
  if (o.rooftop !== false && h > 8) {
    const r = rnd();
    if (r < 0.5) {
      const tx = cx + (rnd() - 0.5) * w * 0.4, tz = cz + (rnd() - 0.5) * d * 0.4;
      for (const [a, b] of [[-0.8, -0.8], [0.8, -0.8], [-0.8, 0.8], [0.8, 0.8]]) ch.box(tx + a, y + h + 0.95, tz + b, 0.12, 1.6, 0.12, M.steel, { ao: 0 });
      ch.cyl(tx, y + h + 2.55, tz, 1.3, 2.2, M.woodDark, { seg: 16 });
      ch.cyl(tx, y + h + 4.75, tz, 1.4, 0.5, M.steel, { collide: false, seg: 16, rTop: 0.2 });
    } else {
      ch.box(cx + w * 0.15, y + h + 0.95, cz - d * 0.1, w * 0.35, 2.2, d * 0.3, M.concreteDark, {});
      ch.cyl(cx - w * 0.2, y + h + 0.95, cz + d * 0.2, 0.06, 6, M.steel, { seg: 6 });
    }
  }
}

function rockBase(ch, M, x0, z0, x1, z1, top, bottom = -14, o = {}) {
  ch.box((x0 + x1) / 2, bottom, (z0 + z1) / 2, x1 - x0, top - bottom, z1 - z0, o.mat || M.stone, { ao: 0, tint: o.tint });
  // a sea-worn lip at the waterline
  if (o.lip !== false) crag(ch, M.rock, (x0 + x1) / 2, -1.8, (z0 + z1) / 2, x1 - x0 + 0.8, 2.2, z1 - z0 + 0.8, { amp: 0.55 });
}

function stairsDown(ch, M, x, yTop, z, w, n, rise, tread, yaw, mat, base = -6) {
  // steps descending along +direction(yaw); solid down to base
  const s = Math.sin(yaw), c = Math.cos(yaw);
  for (let i = 0; i < n; i++) {
    const top = yTop - rise * (i + 1);
    const along = tread * (i + 0.5);
    ch.box(x + s * along, base, z + c * along, w, top - base, tread + 0.02, mat, { yaw, ao: 0 });
  }
}

// stepped side walls for a flight made by stairsDown, at +-off from its centre line
function stairCheeks(ch, M, x, yTop, z, n, rise, tread, yaw, off, mat, base = -6, h = 1.0) {
  const s = Math.sin(yaw), c = Math.cos(yaw);
  for (let i = 0; i < n; i++) {
    const top = yTop - rise * (i + 1) + h;
    const along = tread * (i + 0.5);
    for (const k of [-1, 1]) ch.box(x + s * along + c * k * off, base, z + c * along - s * k * off, 0.3, top - base, tread + 0.02, mat, { yaw, ao: 0 });
  }
}

export function buildCity(W) {
  const M = W.M;

  // ===================== SKY BRIDGE =====================
  {
    const ch = W.chunk('bridge');
    const z0 = -21, z1 = -62, y0 = 24, y1 = TER;
    const len = z0 - z1;
    ch.ramp(0, (z0 + z1) / 2, 4.2, len, y1, y0, 0.5, M.concrete, { yaw: 0 });
    // the ramp rises towards +z: y1 at z1 (south), y0 at z0 (north)
    // deck surface strip and kerbs
    const pitch = Math.atan2(y0 - y1, len);
    const L = Math.hypot(len, y0 - y1);
    for (const k of [-1, 1]) {
      const m = new THREE.Matrix4().compose(new THREE.Vector3(k * 2.2, (y0 + y1) / 2 + 0.1, (z0 + z1) / 2), new THREE.Quaternion().setFromEuler(new THREE.Euler(-pitch, 0, 0, 'YXZ')), new THREE.Vector3(0.3, 0.3, L));
      ch.geo(new THREE.BoxGeometry(1, 1, 1), M.concreteDark, m, {});
      // rail
      const r = new THREE.Matrix4().compose(new THREE.Vector3(k * 2.2, (y0 + y1) / 2 + 1.15, (z0 + z1) / 2), new THREE.Quaternion().setFromEuler(new THREE.Euler(-pitch, 0, 0, 'YXZ')), new THREE.Vector3(0.1, 0.08, L));
      ch.geo(new THREE.BoxGeometry(1, 1, 1), M.brass, r, {});
      // invisible barrier segments
      for (let i = 0; i < 10; i++) {
        const za = z0 - len * i / 10, zb = z0 - len * (i + 1) / 10;
        const ya = y0 - (y0 - y1) * i / 10;
        ch.collider({ type: 'box', x: k * 2.25, y: ya - 1.5, z: (za + zb) / 2, hx: 0.15, hy: 3.2, hz: len / 20 + 0.05, yaw: 0 });
      }
    }
    // posts along the rails
    for (let i = 0; i <= 20; i++) {
      const z = z0 - len * i / 20, y = y0 - (y0 - y1) * i / 20;
      for (const k of [-1, 1]) ch.box(k * 2.2, y + 0.2, z, 0.08, 0.95, 0.08, M.metal, { collide: false, ao: 0 });
    }
    // underside girder
    const g = new THREE.Matrix4().compose(new THREE.Vector3(0, (y0 + y1) / 2 - 1.0, (z0 + z1) / 2), new THREE.Quaternion().setFromEuler(new THREE.Euler(-pitch, 0, 0, 'YXZ')), new THREE.Vector3(1.6, 1.2, L));
    ch.geo(new THREE.BoxGeometry(1, 1, 1), M.steel, g, {});
    // two pylons with stay cables
    for (const [pz, ph] of [[-30, 22.5], [-49, 17.5]]) {
      const deckY = y0 - (y0 - y1) * ((z0 - pz) / len);
      for (const k of [-1, 1]) {
        ch.box(k * 3.1, -6, pz, 0.9, deckY + 12 + 6, 0.9, M.concreteDark, { collide: false, ao: 0 });
        ch.box(k * 3.1, -1.4, pz, 1.6, 1.6, 1.6, M.rock, { collide: false, ao: 0 });
      }
      ch.box(0, deckY - 1.8, pz, 7.1, 0.7, 1.0, M.concreteDark, { collide: false, ao: 0 });
      ch.box(0, deckY + 11.2, pz, 7.1, 0.8, 1.0, M.concreteDark, { collide: false, ao: 0 });
      // red aircraft lamp on top
      ch.box(0, deckY + 12, pz, 0.3, 0.3, 0.3, M.lampRed, { collide: false, ao: 0 });
      for (const k of [-1, 1]) for (const dz of [-1, 1]) for (let c = 1; c <= 3; c++) {
        const tz = pz + dz * c * 4.2, ty = y0 - (y0 - y1) * ((z0 - tz) / len) + 0.1;
        if (tz > z0 || tz < z1) continue;
        cable(ch, M, [k * 3.1, deckY + 10.5 - c * 0.8, pz], [k * 2.2, ty + 1.2, tz], 0.05, 0.035);
      }
    }
    // lamps every ~8 m
    for (let i = 1; i < 5; i++) {
      const z = z0 - len * i / 5, y = y0 - (y0 - y1) * i / 5;
      lampPost(W, ch, (i % 2 ? -1.75 : 1.75), y, z, { yaw: i % 2 ? Math.PI / 2 : -Math.PI / 2, h: 3.2, intensity: 6, dist: 12 });
    }
  }

  // ===================== UPPER TERRACE (y 12) =====================
  {
    const ch = W.chunk('terrace');
    rockBase(ch, M, -16, -80, 16, -58, TER, -14, { mat: M.concreteWarm });
    ch.box(0, TER - 0.02, -69, 31.6, 0.04, 21.6, M.tile, { collide: false, ao: 0, tint: 0x9a948a });
    // edge balustrades (north edge has the bridge opening)
    railing(ch, M, -16, -58.2, -2.3, -58.2, TER);
    railing(ch, M, 2.3, -58.2, 16, -58.2, TER);
    railing(ch, M, -15.8, -58.2, -15.8, -79.8, TER);
    railing(ch, M, 15.8, -58.2, 15.8, -79.8, TER);
    railing(ch, M, -15.8, -79.8, -4.2, -79.8, TER);
    railing(ch, M, 4.2, -79.8, 15.8, -79.8, TER);
    // the Reaching: two bronze hands that do not quite meet, on a plinth
    ch.box(0, TER, -70, 3.0, 0.5, 3.0, M.concreteDark, {});
    ch.box(0, TER + 0.5, -70, 2.4, 1.1, 2.4, M.stone, {});
    const hand = (x, y, z, ry, rz) => {
      const grp = new THREE.Group();
      const palm = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.16, 0.6), M.brass); grp.add(palm);
      for (let f = 0; f < 4; f++) { const fi = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.42 - Math.abs(f - 1.5) * 0.06), M.brass); fi.position.set(-0.2 + f * 0.135, 0.0, 0.48); fi.rotation.x = -0.15 - f * 0.05; grp.add(fi); }
      const th = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.3), M.brass); th.position.set(0.32, 0.03, 0.12); th.rotation.y = -0.7; grp.add(th);
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 2.2, 10), M.brass); arm.rotation.x = Math.PI / 2; arm.position.set(0, 0, -1.3); grp.add(arm);
      grp.position.set(x, y, z); grp.rotation.set(0, ry, rz);
      grp.traverse(m => { if (m.isMesh) m.castShadow = true; });
      ch.mesh(grp);
    };
    // the lower arm rises out of the plinth, the upper reaches down to it
    ch.box(0.9, TER + 1.6, -70, 0.42, 1.6, 0.42, M.brass, {});
    hand(0.55, TER + 3.4, -70, -Math.PI / 2, 0.45);
    ch.box(-0.9, TER + 1.6, -70, 0.42, 3.2, 0.42, M.brass, {});
    hand(-0.4, TER + 4.95, -70, Math.PI / 2, 0.55);
    sign(W, ch, textTexture(['TO THOSE WHO WENT AHEAD', { text: 'and to those who stayed to see them off', size: 30, font: '"EB Garamond", serif' }], { w: 768, h: 192, size: 36, color: '#e7dcc2', bg: '#2a2620', style: 'plaque' }), 0, TER + 1.05, -68.79, 1.8, 0.45, 0, { backing: false });
    W.addInteract({ id: 'memorial', x: 0, y: TER + 1.2, z: -68.6, r: 2.6, label: 'Read the memorial' });
    for (const [x, z] of [[-6, -64], [6, -64], [-6, -76], [6, -76]]) planter(ch, M, x, TER, z, { w: 1.1 });
    bench(ch, M, -3.6, TER, -66, Math.PI, 1.8); bench(ch, M, 3.6, TER, -66, Math.PI, 1.8);
    lampPost(W, ch, -10, TER, -61, { yaw: 0.5 }); lampPost(W, ch, 10, TER, -61, { yaw: -0.5 });
    lampPost(W, ch, 12, TER, -77, { yaw: Math.PI }); lampPost(W, ch, -4.8, TER, -78.6, { yaw: Math.PI });
    // retaining wall face above the concourse with a carved name
    sign(W, ch, textTexture(['THE HOLLOW CITY'], { w: 1024, h: 128, size: 72, color: '#3b342c', bg: 'rgba(0,0,0,0)', font: '"IBM Plex Sans", sans-serif', weight: 500 }), 9.8, CON + 3.6, -80.02, 6.0, 0.75, Math.PI, { backing: false, transparent: true });
    // stairs down to the concourse
    stairsDown(ch, M, 0, TER, -80, 8, 15, 0.4, 0.7, Math.PI, M.concreteWarm, -8);
    stairCheeks(ch, M, 0, TER, -80, 15, 0.4, 0.7, Math.PI, 4.15, M.concreteWarm, -8);
  }

  // ===================== BELL TOWER =====================
  {
    const ch = W.chunk('bell');
    const bx = -10.5, bz = -70.5, y = TER;
    // walls (hollow) with door on the east face
    const H = 17;
    room(ch, M, bx - 2.7, bz - 2.7, bx + 2.7, bz + 2.7, y, H, { wall: M.stone, floor: false, ceiling: false, thick: 0.5, sides: { e: [{ t: 2.2, w: 1.4, h: 2.6 }] } });
    ch.box(bx, y + 3.3, bz, 4.4, 0.25, 4.4, M.woodDark, { collide: false, ao: 0 }); // first floor ceiling
    ch.box(bx, y + H, bz, 5.8, 0.6, 5.8, M.stone, { collide: false, ao: 0 });
    // belfry: four corner piers and a roof, the bell inside
    for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) ch.box(bx + a * 2.3, y + H + 0.6, bz + b * 2.3, 1.0, 4.2, 1.0, M.stone, { collide: false });
    ch.box(bx, y + H + 4.8, bz, 6.0, 0.7, 6.0, M.stone, { collide: false, ao: 0 });
    ch.cyl(bx, y + H + 5.5, bz, 3.6, 6.5, M.copper, { seg: 4, rTop: 0.05, collide: false, yaw: Math.PI / 4, tint: 0x6f9a86 });
    ch.box(bx, y + H + 4.1, bz, 0.2, 0.7, 0.2, M.steel, { collide: false, ao: 0 });
    const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 1.2, 1.6, 20, 1, true), M.brass);
    bell.material = M.brass; bell.position.set(bx, y + H + 3.2, bz); bell.castShadow = true;
    ch.mesh(bell); W.bell = { mesh: bell, swing: 0 };
    // clock faces with 22 marks; the hands show the loop
    W.clockHands = [];
    const faceTex = (() => {
      const c = document.createElement('canvas'); c.width = c.height = 512; const g = c.getContext('2d');
      g.fillStyle = '#e9dfc4'; g.beginPath(); g.arc(256, 256, 240, 0, 7); g.fill();
      g.strokeStyle = '#2e2a24'; g.lineWidth = 10; g.beginPath(); g.arc(256, 256, 232, 0, 7); g.stroke();
      for (let i = 0; i < 22; i++) {
        const a = i / 22 * Math.PI * 2; g.lineWidth = i % 2 ? 4 : 9;
        g.beginPath(); g.moveTo(256 + Math.sin(a) * 210, 256 - Math.cos(a) * 210); g.lineTo(256 + Math.sin(a) * (i % 2 ? 190 : 175), 256 - Math.cos(a) * (i % 2 ? 190 : 175)); g.stroke();
      }
      writeOn(g, '22', 256, 98, 46, { color: '#2e2a24', align: 'center', pen: 0.14, wobble: 0.4, slant: 0, bleed: false });
      writeOn(g, '11', 256, 372, 46, { color: '#2e2a24', align: 'center', pen: 0.14, wobble: 0.4, slant: 0, bleed: false });
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
    })();
    const faceMat = new THREE.MeshBasicMaterial({ map: faceTex, color: new THREE.Color(1.4, 1.25, 1.0), toneMapped: false });
    for (let i = 0; i < 4; i++) {
      const a = i * Math.PI / 2;
      const nx = Math.sin(a), nz = Math.cos(a);
      const f = new THREE.Mesh(new THREE.CircleGeometry(1.5, 40), faceMat);
      f.position.set(bx + nx * 2.73, y + 13, bz + nz * 2.73); f.rotation.y = a; ch.mesh(f);
      ch.cyl(bx + nx * 2.7, y + 13, bz + nz * 2.7, 1.65, 0.12, M.brass, { seg: 40, pitch: Math.PI / 2, yaw: a, collide: false });
      const hand = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.25, 0.04), M.steel);
      hand.geometry.translate(0, 0.55, 0);
      hand.position.set(bx + nx * 2.8, y + 13, bz + nz * 2.8); hand.rotation.y = a;
      ch.mesh(hand); W.clockHands.push(hand);
    }
    W.light(bx + 3.5, y + 13, bz, 0xffd9a0, 4, 8, { chunk: ch });
    // interior: the keeper's desk and the recording
    table(ch, M, bx - 0.9, y, bz - 1.2, 1.4, 0.7, { yaw: Math.PI / 2 });
    ch.box(bx - 0.9, y + 0.78, bz - 1.2, 0.34, 0.14, 0.26, M.steel, { collide: false, ao: 0 });
    ch.cyl(bx - 0.9, y + 0.86, bz - 1.2, 0.06, 0.24, M.brass, { seg: 10, roll: Math.PI / 2, collide: false });
    W.addInteract({ id: 'cityLog', x: bx - 0.9, y: y + 1.0, z: bz - 1.2, r: 2.0, label: 'Play the keeper’s cylinder' });
    chair(ch, M, bx - 1.55, y, bz - 1.2, Math.PI / 2);
    // ladder to the upper floor (blocked by a hatch)
    for (let i = 0; i < 8; i++) ch.box(bx - 2.15, y + 0.3 + i * 0.4, bz + 1.2, 0.04, 0.04, 0.5, M.steel, { collide: false, ao: 0 });
    for (const k of [-0.25, 0.25]) ch.box(bx - 2.15, y, bz + 1.2 + k, 0.05, 3.3, 0.05, M.steel, { collide: false, ao: 0 });
    // rope coils, a bell-pull, crates of cylinders
    crate(ch, M, bx + 1.4, y, bz - 1.6, 0.7);
    crate(ch, M, bx + 1.5, y, bz + 1.5, 0.8, { yaw: 0.3 });
    ceilingLight(W, ch, bx, y + 3.3, bz, 0, { len: 0.8, intensity: 3, dist: 6, color: 0xffcf9a });
  }

  // ===================== CONCOURSE (y 6) =====================
  {
    const ch = W.chunk('concourse');
    // ground: rock base with a gap for nothing; the archive and apartments sit on it
    rockBase(ch, M, -24, -131, 24, -80, CON, -14, { mat: M.concreteWarm });
    ch.box(0, CON - 0.02, -105.5, 47.6, 0.04, 50.6, M.tile, { collide: false, ao: 0, tint: 0x8f8a80 });
    // avenue paving strip
    ch.box(0, CON, -110, 6.2, 0.03, 40, M.stone, { collide: false, ao: 0, tint: 0xa89a88 });
    // the four transit arches and their lanterns, numbered from the descent
    W.lanterns = [];
    [-96, -104, -112, -120].forEach((z, i) => {
      arch(ch, M, 0, CON, z, 7.2, 6.4, 0, M.concreteWarm, 1.0, 0.9);
      // lantern on top: plinth, cage, glass
      ch.box(0, CON + 7.3, z, 1.0, 0.35, 1.0, M.concreteDark, { collide: false, ao: 0 });
      for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) ch.box(a * 0.36, CON + 7.65, z + b * 0.36, 0.07, 1.0, 0.07, M.steel, { collide: false, ao: 0 });
      ch.box(0, CON + 8.65, z, 0.95, 0.12, 0.95, M.steel, { collide: false, ao: 0 });
      ch.cyl(0, CON + 8.77, z, 0.5, 0.45, M.steel, { seg: 4, rTop: 0.05, yaw: Math.PI / 4, collide: false });
      const glassMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffd29a).multiplyScalar(0.6), toneMapped: false });
      const glass = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.85, 0.6), glassMat);
      glass.position.set(0, CON + 8.15, z); ch.mesh(glass);
      const light = W.light(0, CON + 8.2, z, 0xffc070, 1.5, 14, { chunk: ch });
      // a stencilled numeral on the arch keystone, facing the descent
      const num = textTexture([['I', 'II', 'III', 'IV'][i]], { w: 256, h: 256, size: 150, color: '#3b342c', font: '"EB Garamond", serif' });
      const nm = decal(num, 0.8, 0.8); nm.position.set(0, CON + 6.75, z + 0.52); ch.mesh(nm);
      W.lanterns.push({ glass, glassMat, light, z, level: 0 });
    });
    // concourse furniture and lamps
    for (const z of [-92, -108, -124]) { lampPost(W, ch, -6, CON, z, { yaw: Math.PI / 2 }); lampPost(W, ch, 6, CON, z, { yaw: -Math.PI / 2 }); }
    bench(ch, M, -5.5, CON, -100, Math.PI / 2); bench(ch, M, 5.5, CON, -116, -Math.PI / 2);
    planter(ch, M, -8, CON, -88, { w: 1.2 }); planter(ch, M, 8, CON, -88, { w: 1.2, dead: true });
    planter(ch, M, -8, CON, -127, { w: 1.2, dead: true });
    // abandoned luggage: the evacuation was orderly, mostly
    crate(ch, M, 3.2, CON, -99.5, 0.6, { mat: M.fabricTeal, yaw: 0.4 });
    crate(ch, M, 3.9, CON, -99.2, 0.5, { mat: M.fabricPale, yaw: -0.2 });
    barrel(ch, M, -9.5, CON, -122); barrel(ch, M, -10.3, CON, -122.6, { tint: 0x99aa99 });
    // edges: balustrades. west edge has the market stairs (z -114..-126) open.
    railing(ch, M, -23.8, -88, -23.8, -113.8, CON);
    railing(ch, M, -23.8, -126.2, -23.8, -130.8, CON);
    // east edge: archive occupies -96..-116; service gate at z -125..-127 (between rails)
    railing(ch, M, 23.8, -80.5, 23.8, -95.8, CON);
    railing(ch, M, 23.8, -116.2, 23.8, -124.8, CON);
    railing(ch, M, 23.8, -127.2, 23.8, -130.8, CON);
    // south edge: span opening at |x| < 2.2
    railing(ch, M, -23.8, -130.8, -2.4, -130.8, CON);
    railing(ch, M, 2.4, -130.8, 23.8, -130.8, CON);
    // north corners beside the stair
    railing(ch, M, -23.8, -80.3, -4.4, -80.3, CON, { collide: false });
    railing(ch, M, 4.4, -80.3, 23.8, -80.3, CON, { collide: false });
    // service gate (an old iron gate in a stone frame), unlocks at 15:00
    ch.box(23.8, CON, -124.6, 0.6, 3.0, 0.5, M.stone, {});
    ch.box(23.8, CON, -127.4, 0.6, 3.0, 0.5, M.stone, {});
    ch.box(23.8, CON + 3.0, -126, 0.7, 0.5, 3.3, M.stone, {});
    W.serviceGate = slidingDoor(W, ch, 23.8, CON, -126, 2.3, 2.8, Math.PI / 2, { mat: M.steel, thick: 0.08, speed: 0.5 });
    W.addInteract({ id: 'serviceGate', x: 23.3, y: CON + 1.4, z: -126, r: 2.2, label: 'Try the service gate' });
    // stairs down to the market (west)
    stairsDown(ch, M, -24, CON, -120, 12, 10, 0.4, 0.6, -Math.PI / 2, M.concreteWarm, -6);
    stairCheeks(ch, M, -24, CON, -120, 10, 0.4, 0.6, -Math.PI / 2, 6.15, M.concreteWarm, -6);
    // stairs down to the quay (east of the service gate)
    stairsDown(ch, M, 24, CON, -126, 2.4, 10, 0.38, 0.6, Math.PI / 2, M.stone, -6);
    stairCheeks(ch, M, 24, CON, -126, 10, 0.38, 0.6, Math.PI / 2, 1.35, M.stone, -6);
  }

  // ===================== CIVIC ARCHIVE =====================
  {
    const ch = W.chunk('archive');
    const x0 = 12, x1 = 24, z0 = -116, z1 = -96, y = CON, H = 9;
    // exterior shell with columns on the west front
    room(ch, M, x0, z0, x1, z1, y, H, { wall: M.concreteWarm, floorMat: M.tile, thick: 0.5, sides: { w: [{ t: 10, w: 2.2, h: 3.4 }, { t: 4, w: 1.2, h: 3, sill: 1.2, glass: true }, { t: 16, w: 1.2, h: 3, sill: 1.2, glass: true }] } });
    ch.box((x0 + x1) / 2, y + H + 0.35, (z0 + z1) / 2, x1 - x0 + 0.8, 0.6, z1 - z0 + 0.8, M.concreteDark, { collide: false, ao: 0 });
    // pediment
    ch.box(x0 - 0.4, y + H - 1.6, -106, 0.6, 1.6, 20.4, M.concreteDark, { collide: false, ao: 0 });
    for (const z of [-99, -103.2, -108.8, -113]) column(ch, M, x0 - 1.2, y, z, 0.38, H - 1.6, M.concreteWarm);
    ch.box(x0 - 1.2, y + H - 1.6, -106, 1.4, 0.4, 20.4, M.concreteWarm, { collide: false, ao: 0 });
    sign(W, ch, textTexture(['CIVIC ARCHIVE'], { w: 1024, h: 128, size: 80, color: '#2e2a24', font: '"EB Garamond", serif', bg: 'rgba(0,0,0,0)' }), x0 - 0.71, y + H - 0.8, -106, 6, 0.75, -Math.PI / 2, { backing: false, transparent: true });
    // inside: reading room, shelves, the map table
    for (const z of [-99.5, -102.5, -109.5, -112.5]) shelf(ch, M, 16.5, y, z, 0, 3.2, { h: 2.6 });
    table(ch, M, 15.2, y, -106, 1.6, 2.6, {});
    ch.box(15.2, y + 0.79, -106, 1.3, 0.01, 2.2, M.paint, { collide: false, ao: 0, tint: 0xd8cfb0 });
    W.addInteract({ id: 'tarnMap', x: 15.2, y: y + 1.0, z: -106, r: 2.2, label: 'Study the basin map' });
    // pendant lamps hung on rods from the high ceiling
    for (const [px, pz] of [[15, -100], [15, -106], [15, -112]]) {
      ch.box(px, y + 4.2, pz, 0.03, H - 4.2, 0.03, M.steel, { collide: false, ao: 0 });
      ch.cyl(px, y + 3.9, pz, 0.45, 0.35, M.brass, { seg: 16, rTop: 0.12, collide: false });
      ch.cyl(px, y + 3.86, pz, 0.38, 0.04, M.lampWarm, { seg: 16, collide: false });
      W.light(px, y + 3.4, pz, 0xffc890, 7, 11, { chunk: ch });
    }
    // reading lamps on the map table
    ch.box(15.2, y + 0.8, -104.6, 0.05, 0.45, 0.05, M.brass, { collide: false, ao: 0 });
    ch.box(15.2, y + 1.2, -104.75, 0.24, 0.1, 0.3, M.lampWarm, { collide: false, ao: 0 });
    W.light(15.2, y + 1.6, -105.4, 0xffd0a0, 3, 5, { chunk: ch });
    // vault: partition at x = 19.6 with a round door
    wallLine(ch, M, 19.6, -115.6, 19.6, -96.4, y, H, 0.6, M.concreteDark, [{ t: 9.6, w: 2.0, h: 2.6 }]);
    W.vaultDoor = slidingDoor(W, ch, 19.6, y, -106, 2.0, 2.6, Math.PI / 2, { mat: M.brass, thick: 0.3, speed: 0.4 });
    // the lantern keypad: four little lanterns in a brass plate
    ch.box(19.25, y + 1.0, -108.0, 0.12, 0.8, 0.6, M.brass, { collide: false, ao: 0 });
    for (let i = 0; i < 4; i++) ch.box(19.17, y + 1.15 + (i % 2) * 0.28, -108.15 + Math.floor(i / 2) * 0.3, 0.05, 0.14, 0.1, M.lampWarm, { collide: false, ao: 0, tint: 0x553322 });
    W.addInteract({ id: 'vault', x: 19.1, y: y + 1.35, z: -108, r: 2.0, label: 'Use the lantern lock' });
    // inside the vault: a pedestal with the operator cylinder
    ch.box(22, y, -106, 0.8, 1.0, 0.8, M.stone, {});
    ch.cyl(22, y + 0.93, -106, 0.08, 0.3, M.brass, { seg: 10, roll: Math.PI / 2, collide: false });
    W.addInteract({ id: 'cylinder', x: 22, y: y + 1.15, z: -106, r: 1.8, label: 'Take the operator cylinder' });
    W.light(22, y + 2.6, -106, 0x7fe8dc, 3, 6, { chunk: ch, key: 'vaultLight' });
  }

  // ===================== VALE COURT (west apartments) =====================
  {
    const ch = W.chunk('apartments');
    const x0 = -23.5, x1 = -12, z0 = -110, z1 = -91;
    building(W, ch, x0, z0, x1, z1 - 0.01, CON + 4.2, 16, { tint: 0xb8aa9a, lit: 0.22, skipGround: false });
    // ground floor lobby (open room under the block)
    room(ch, M, x0, z0, x1, z1, CON, 4.2, { wall: M.concreteWarm, floorMat: M.tile, ceiling: true, sides: { e: [{ t: 9.5, w: 2.2, h: 3 }, { t: 3.5, w: 1.6, h: 2.8, sill: 0.9, glass: true }, { t: 15.5, w: 1.6, h: 2.8, sill: 0.9, glass: true }] } });
    sign(W, ch, textTexture(['VALE COURT'], { w: 512, h: 96, size: 56, color: '#e7dcc2', bg: '#2a2620', font: '"EB Garamond", serif' }), x1 + 0.05, CON + 3.5, -100.5, 1.8, 0.33, Math.PI / 2, {});
    // tag board: three hundred hooks, six tags still hanging
    const tc = document.createElement('canvas'); tc.width = 1024; tc.height = 512; const g = tc.getContext('2d');
    g.fillStyle = '#3a2e24'; g.fillRect(0, 0, 1024, 512);
    let k = 0; const stay = new Set([17, 58, 103, 166, 241, 290]);
    for (let r = 0; r < 12; r++) for (let c = 0; c < 26; c++, k++) {
      const x = 30 + c * 37.5, yy = 30 + r * 39;
      g.fillStyle = '#9c8a62'; g.beginPath(); g.arc(x, yy, 3, 0, 7); g.fill();
      if (stay.has(k)) { g.fillStyle = '#e4d6b0'; g.fillRect(x - 8, yy + 4, 16, 24); g.fillStyle = '#a5402c'; g.fillRect(x - 8, yy + 4, 16, 5); }
    }
    const tt = new THREE.CanvasTexture(tc); tt.colorSpace = THREE.SRGBColorSpace;
    const tm = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.6), new THREE.MeshStandardMaterial({ map: tt, roughness: 0.9 }));
    tm.position.set(x0 + 0.32, CON + 1.6, -100.5); tm.rotation.y = Math.PI / 2; ch.mesh(tm);
    W.addInteract({ id: 'tags', x: x0 + 0.5, y: CON + 1.6, z: -100.5, r: 2.6, label: 'Look at the tag board' });
    // mailboxes, a collapsed stair, a fallen lamp
    for (let i = 0; i < 4; i++) ch.box(x0 + 2 + i * 0.62, CON + 0.9, z1 - 0.48, 0.58, 1.3, 0.3, M.brass, { ao: 0, tint: 0x9a8a7a });
    for (let i = 0; i < 4; i++) {
      const mx = x0 + 2 + i * 0.62, fz = z1 - 0.48 - 0.155;
      ch.box(mx, CON + 1.84, fz, 0.32, 0.035, 0.02, M.steel, { collide: false, ao: 0 });                         // slot
      ch.box(mx, CON + 1.6, fz, 0.2, 0.06, 0.012, M.paint, { collide: false, ao: 0, tint: i === 1 ? 0xe8d8b0 : 0x8a8070 }); // name card
      ch.box(mx + 0.2, CON + 1.3, fz, 0.03, 0.08, 0.025, M.brass, { collide: false, ao: 0 });                    // latch
    }
    sconce(W, ch, x0 + 2.9, CON + 2.65, z1 - 0.3, Math.PI, { intensity: 2.6, dist: 6, flicker: 0.35 });
    ch.box(x0 + 4.4, CON, z1 - 0.6, 2.8, 1.0, 0.5, M.concreteDark, {});
    stairsDown(ch, M, -20, CON + 4.0, -108.6, 1.6, 6, 0.6, 0.5, Math.PI / 2, M.concreteWarm, CON);
    crate(ch, M, -16, CON, -108.4, 0.8, { yaw: 0.3 }); crate(ch, M, -15.4, CON + 0.64, -108.3, 0.6, { yaw: -0.2 });
    ceilingLight(W, ch, -17.5, CON + 4.2, -100.5, 0, { len: 1.6, intensity: 4, dist: 9, flicker: 0.5, color: 0xffd0a0 });
  }

  // ===================== MARKET PIER (y 2) =====================
  {
    const ch = W.chunk('market');
    // deck on piles
    ch.box(-40, WF - 0.4, -120, 20, 0.4, 20, M.wood, { ao: 0 });
    for (let x = -49; x <= -31; x += 3) for (let z = -129; z <= -111; z += 3) ch.cyl(x, -4, z, 0.25, WF - 0.4 + 4, M.woodDark, { seg: 8, collide: false });
    // pier out to the west
    ch.box(-61, WF - 0.4, -120, 22, 0.4, 4.2, M.wood, { ao: 0 });
    for (let x = -71; x <= -51; x += 3) for (const z of [-118.2, -121.8]) ch.cyl(x, -4, z, 0.22, WF - 0.4 + 4, M.woodDark, { seg: 8, collide: false });
    // rails
    railing(ch, M, -50, -110.2, -30, -110.2, WF, { mat: M.woodDark, top: M.wood });
    railing(ch, M, -50, -129.8, -30, -129.8, WF, { mat: M.woodDark, top: M.wood });
    railing(ch, M, -49.8, -110.2, -49.8, -117.8, WF, { mat: M.woodDark, top: M.wood });
    railing(ch, M, -49.8, -122.2, -49.8, -129.8, WF, { mat: M.woodDark, top: M.wood });
    railing(ch, M, -50, -117.9, -71.8, -117.9, WF, { mat: M.woodDark, top: M.wood });
    railing(ch, M, -50, -122.1, -68, -122.1, WF, { mat: M.woodDark, top: M.wood }); // gap at the end for the skiff
    railing(ch, M, -71.9, -117.9, -71.9, -122.1, WF, { mat: M.woodDark, top: M.wood });
    // east side meets the concourse wall; rails up to the stair
    railing(ch, M, -30.2, -110.2, -30.2, -113.9, WF, { mat: M.woodDark, top: M.wood });
    railing(ch, M, -30.2, -126.1, -30.2, -129.8, WF, { mat: M.woodDark, top: M.wood });
    // Skye's stall: counter, posts, striped awning
    const sx = -38, sz = -113;
    ch.box(sx, WF, sz, 3.4, 1.0, 0.9, M.woodDark, {});
    ch.box(sx, WF + 1.0, sz, 3.5, 0.06, 1.0, M.wood, { collide: false, ao: 0 });
    for (const k of [-1.65, 1.65]) for (const d of [-0.4, 1.3]) ch.box(sx + k, WF, sz + d, 0.1, 2.6, 0.1, M.woodDark, { ao: 0 });
    for (let i = 0; i < 6; i++) ch.box(sx - 1.5 + i * 0.5, WF + 2.55, sz + 0.45, 0.5, 0.06, 2.2, i % 2 ? M.fabricPale : M.fabricRed, { collide: false, ao: 0, pitch: -0.18 });
    {
      // the last strip of the awning has come loose at the front and flaps about, every cycle,
      // until somebody ties it down. It hangs from its back edge, so it is never floating
      const g0 = new THREE.BoxGeometry(0.5, 0.06, 2.2);
      g0.setAttribute('color', new THREE.Float32BufferAttribute(new Array(g0.attributes.position.count * 3).fill(1), 3));
      const strip = new THREE.Mesh(g0, M.fabricRed); strip.position.set(0, 0.03, -1.1); strip.castShadow = true; strip.receiveShadow = true;
      const pivot = new THREE.Group(); pivot.position.set(sx + 1.5, WF + 2.58 + 1.1 * Math.sin(0.18), sz + 0.45 + 1.1 * Math.cos(0.18)); pivot.add(strip);
      ch.group.add(pivot);
      // the cord it should be tied with, hanging from the post
      const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.7, 4), new THREE.MeshStandardMaterial({ color: 0xcdbb94, roughness: 0.9 }));
      cord.position.set(sx + 1.706, WF + 2.0, sz - 0.4); ch.group.add(cord);
      // a tomato on the counter, once somebody has brought her one this cycle
      const tom = new THREE.Mesh(new THREE.SphereGeometry(0.065, 12, 10), new THREE.MeshStandardMaterial({ color: 0xb8301a, roughness: 0.35 }));
      tom.scale.y = 0.85; tom.position.set(sx + 0.82, WF + 1.06 + 0.052, sz - 0.36); tom.visible = false; tom.castShadow = true; ch.group.add(tom);
      W.stallTomato = tom;
      const it = W.addInteract({ id: 'awning', x: sx + 1.6, y: WF + 2.15, z: sz - 0.2, r: 2.6, label: 'Tie down the loose awning' });
      let loop = -1;
      W.awning = { fixed: false };
      let flapT = 0;
      W.onUpdate((dt, t, st, cam) => {
        if (st.loop !== loop) { loop = st.loop; W.awning.fixed = false; tom.visible = false; }
        // you hear it before you see it
        if (!W.awning.fixed && cam && W.sound && (flapT -= dt) < 0) {
          const d = Math.hypot(cam.x - pivot.position.x, cam.z - pivot.position.z);
          flapT = 1.1 + Math.random() * 2.6;
          if (d < 12) W.sound.flap(1 - d / 12);
        }
        const a = W.awning;
        a.k = Math.max(0, Math.min(1, (a.k ?? 1) + (a.fixed ? -dt * 2.5 : dt)));
        const flap = Math.sin(t * 2.3) * 0.09 + Math.sin(t * 5.3 + 1) * 0.035;
        pivot.rotation.x = -0.18 - a.k * (0.4 + flap);
        cord.visible = !a.fixed;
        it.y = a.fixed ? -999 : WF + 2.15;
      });
    }
    // shallow baskets of apples (red and green), heaped
    for (let i = 0; i < 6; i++) {
      const bx = sx - 1.2 + i * 0.45, bz = sz - 0.1, br = 0.17;
      ch.cyl(bx, WF + 1.03, bz, br, 0.09, M.woodDark, { seg: 14, rTop: br + 0.03, collide: false, tint: 0xa07a50 });
      const green = i % 3 === 0;
      for (let k = 0; k < 8; k++) {
        const ring = k < 5 ? 0.095 : k < 7 ? 0.04 : 0, a = k * 2.4 + i, y = WF + 1.13 + (k < 5 ? 0 : k < 7 ? 0.05 : 0.09);
        const g = new THREE.SphereGeometry(0.048 + ((k * 3 + i) % 3) * 0.004, 10, 8);
        ch.geo(g, M.paint, new THREE.Matrix4().makeTranslation(bx + Math.cos(a) * ring, y, bz + Math.sin(a) * ring), { tint: green ? ((k + i) % 4 ? 0x86b83a : 0xb4c84a) : ((k + i) % 5 ? 0xd8301e : 0xe0702a) });
        g.dispose();
      }
    }
    book(W, ch, sx + 1.45, WF + 1.06, sz + 0.12, -0.3, { id: 'fishBook', label: 'Read \u201cHow to Speak Fish\u201d', cover: 0x2a5a6a,
      tex: textTexture(['HOW TO', 'SPEAK', { text: 'FISH', size: 92, color: '#f2a65a' }, { text: 'mostly vowels', size: 26, color: '#cfe0e4', hand: true }], { w: 256, h: 356, size: 58, color: '#eaf2f2', bg: '#2a5a6a', style: 'stencil' }) });
    // the water off the end of the pier, where Charley's line goes in
    W.addInteract({ id: 'npcFishWater', x: -65.85, y: WF + 0.4, z: -122.45, r: 2.6, label: 'Listen to the water', npc: true });
    crate(ch, M, sx + 2.4, WF, sz - 0.2, 0.7); crate(ch, M, sx + 2.5, WF + 0.56, sz - 0.1, 0.55, { yaw: 0.5 });
    // a string of bulbs under the awning
    for (let i = 0; i < 5; i++) ch.cyl(sx - 1.4 + i * 0.7, WF + 2.2 - (i % 2) * 0.06, sz - 0.1, 0.05, 0.08, M.lampWarm, { seg: 8, collide: false });
    cable(ch, M, [sx - 1.65, WF + 2.35, sz - 0.1], [sx + 1.65, WF + 2.35, sz - 0.1], 0.18, 0.01);
    W.light(sx, WF + 2.35, sz - 1.5, 0xffc080, 4, 7, { chunk: ch });   // out over the counter, not on her head
    // harbour notice board
    sign(W, ch, textTexture([
      { text: 'HARBOUR NOTICES', size: 40, color: '#2e2a24' }, ' ',
      { text: 'Skiff runs whenever it is called.', font: '"EB Garamond", serif', size: 34 },
      { text: 'Lantern Isle keeper wanted. Quiet work.', font: '"EB Garamond", serif', size: 34 },
      { text: 'Please stop feeding the relay.', font: '"EB Garamond", serif', size: 34 },
      { text: 'Ask what the rehearsal counter is really counting.', font: 'italic 32px "EB Garamond", serif', size: 30, color: '#7a2c1c' }
    ], { w: 768, h: 512, size: 34, color: '#2e2a24', bg: '#d8cba8', style: 'notes' }), -31.2, WF + 1.6, -121, 1.6, 1.05, -Math.PI / 2, { backMat: M.woodDark });
    ch.box(-31.15, WF, -121.8, 0.1, 2.2, 0.1, M.woodDark, { ao: 0 }); ch.box(-31.15, WF, -120.2, 0.1, 2.2, 0.1, M.woodDark, { ao: 0 });
    W.addInteract({ id: 'pierBoard', x: -31.6, y: WF + 1.6, z: -121, r: 2.2, label: 'Read the harbour notices' });
    // nets, barrels, a lamp at the pier end, mooring bollards
    for (let i = 0; i < 4; i++) barrel(ch, M, -47.6 + (i % 2) * 0.7, WF, -128 + Math.floor(i / 2) * 0.7, { mat: M.woodDark });
    for (const x of [-56, -64, -70.6]) ch.cyl(x, WF, -121.6, 0.16, 0.6, M.steel, { seg: 10 });
    lampPost(W, ch, -34, WF, -128.4, { yaw: 0 }); lampPost(W, ch, -46, WF, -111.5, { yaw: Math.PI });
    lampPost(W, ch, -71, WF, -118.6, { yaw: Math.PI, h: 3.8 });
    // the skiff landing step
    ch.box(-70, WF - 1.0, -123.35, 3.0, 0.6, 2.5, M.woodDark, {});   // solid: you can stand on it, and climb back up from the boat
    for (const px of [-71.3, -68.7]) ch.cyl(px, -4, -124.4, 0.13, WF - 1.0 + 4, M.woodDark, { seg: 8 });   // and it stands on two piles
  }

  // ===================== SERVICE WALK & QUAY (y 2.2) =====================
  {
    const ch = W.chunk('quay');
    // quay along the east cliff of the concourse
    ch.box(29.5, -10, -122, 11, QUAY + 10, 28, M.stone, { ao: 0 });
    railing(ch, M, 34.8, -108.5, 34.8, -133.5, QUAY, { mat: M.steel });
    railing(ch, M, 27.2, -108.3, 34.8, -108.3, QUAY, { mat: M.steel });
    // the shelter: an older stone hut built into the cliff
    room(ch, M, 27.5, -118, 34.5, -110, QUAY, 3.4, { wall: M.stone, floorMat: M.stone, sides: { s: [{ t: 3.5, w: 1.4, h: 2.4 }] } });
    ch.box(31, QUAY + 3.4, -114, 7.6, 0.5, 8.6, M.stone, { collide: false, ao: 0 });
    table(ch, M, 31, QUAY, -112, 1.8, 0.8, { top: M.woodDark });
    ch.box(31, QUAY + 0.78, -112, 0.5, 0.08, 0.35, M.fabricRed, { collide: false, ao: 0, tint: 0x7a4030 });
    W.addInteract({ id: 'code', x: 31, y: QUAY + 1.0, z: -112.2, r: 2.0, label: 'Read the shelter ledger' });
    // someone's left a book on the crates by the wall
    book(W, ch, 28.6, QUAY + 0.4, -116.5, 0.4, { id: 'robotBook', label: 'Read \u201cHow to Speak Robot\u201d', cover: 0x3a3f4a,
      tex: textTexture(['HOW TO', 'SPEAK', { text: 'ROBOT', size: 84, color: '#63f0e2' }, { text: 'beeps, boops & feelings', size: 24, color: '#c8ccd2', hand: true }], { w: 256, h: 356, size: 58, color: '#e4e6ea', bg: '#3a3f4a', style: 'stencil' }) });
    for (let i = 0; i < 3; i++) ch.box(28.6, QUAY, -116.5 + i * 0.9, 0.8, 0.4, 0.8, M.woodDark, { ao: 0.3, tint: 0x998877 });
    // memorial stone for Tarn Quarter
    ch.box(33.6, QUAY, -116.6, 0.9, 1.6, 0.4, M.stone, {});
    sign(W, ch, textTexture(['TARN QUARTER', { text: '1,214 souls', size: 34 }, { text: 'the water took them first', size: 30, font: 'italic 30px "EB Garamond", serif' }], { w: 512, h: 256, size: 44, color: '#1e1c18', bg: '#6a655c', style: 'carved' }), 33.6, QUAY + 1.1, -116.38, 0.8, 0.4, 0, { backing: false });
    W.addInteract({ id: 'tarnStone', x: 33.6, y: QUAY + 1.2, z: -116.2, r: 2.0, label: 'Read the stone' });
    // where people waited for the boats: cots, folded blankets, tins on the table, a child's drawing
    cot(ch, M, 33.55, QUAY, -112.4, 0, 0x6a4a3a);
    cot(ch, M, 29.3, QUAY, -110.85, Math.PI / 2, 0x3a4a5a);
    for (let i = 0; i < 3; i++) ch.cyl(30.35 + i * 0.12, QUAY + 0.78, -111.85 + (i % 2) * 0.1, 0.045, 0.11, M.steel, { seg: 10, collide: false, tint: 0xb0a890 });
    ch.box(28.6, QUAY + 0.4, -114.7, 0.6, 0.1, 0.45, M.paint, { collide: false, ao: 0, tint: 0x5a3a30 });
    tapedNote(W, ch, 27.81, QUAY + 1.45, -113.4, Math.PI / 2, ['WREN', 'waited here', 'for the boat'], { tilt: 0.08, paper: '#f2ead8', ink: '#3a4a7a', size: 38 });
    sconce(W, ch, 31, QUAY + 2.6, -117.7, 0, { intensity: 3, dist: 6, flicker: 0.6 });
    ceilingLight(W, ch, 31, QUAY + 3.4, -114, 0, { len: 1, intensity: 2.5, dist: 6, color: 0xffc890 });
    // footbridge across the channel (old stone, low)
    ch.box(32, QUAY - 0.6, -140, 3.4, 0.6, 13, M.stone, { ao: 0 });
    for (const z of [-136, -142]) { ch.box(32, -6, z, 2.4, QUAY - 0.6 + 6, 1.2, M.stone, { collide: false }); }
    railing(ch, M, 30.4, -133.5, 30.4, -146.4, QUAY, { mat: M.steel });
    railing(ch, M, 33.6, -133.5, 33.6, -146.4, QUAY, { mat: M.steel });
    railing(ch, M, 30.4, -133.5, 27.2, -133.5, QUAY, { mat: M.steel });
    // stairs up to the plaza (heading west)
    ch.box(32, -6, -149.5, 5, QUAY + 6, 6.5, M.stone, { ao: 0 });
    stairsDown(ch, M, 24.4, CON, -149.2, 2.6, 10, 0.38, 0.6, Math.PI / 2, M.stone, -6);
    railing(ch, M, 34.4, -146.5, 34.4, -152.6, QUAY);
    stairCheeks(ch, M, 24.4, CON, -149.2, 10, 0.38, 0.6, Math.PI / 2, 1.45, M.stone, -6);
    lampPost(W, ch, 34.0, QUAY, -120.5, { yaw: -Math.PI / 2, h: 3, flicker: 0.3 });
    lampPost(W, ch, 30.8, QUAY, -145.8, { yaw: Math.PI / 2, h: 3 });
  }

  // ===================== TRANSIT SPAN =====================
  {
    const ch = W.chunk('span');
    ch.box(0, CON - 0.7, -138, 4.2, 0.7, 14.6, M.concrete, {});
    ch.box(0, CON - 1.6, -138, 2.6, 0.9, 14.6, M.steel, { collide: false });
    railing(ch, M, -2.0, -130.8, -2.0, -145.2, CON);
    railing(ch, M, 2.0, -130.8, 2.0, -145.2, CON);
    // a cracked support pier in the channel
    ch.box(0, -6, -138, 2.0, CON - 1.6 + 6, 1.6, M.concreteDark, { collide: false });
    ch.box(0.7, CON - 3.2, -137.2, 0.12, 1.4, 0.3, M.dark, { collide: false, ao: 0 });
    W.span = ch;
  }

  // ===================== SOUTH PLAZA & GATEHOUSE =====================
  {
    const ch = W.chunk('plaza');
    // base around the stair shaft (|x|<2.6 for z < -158 is left open for the descent)
    rockBase(ch, M, -16, -158, 24, -145, CON, -14, { mat: M.concreteWarm });
    rockBase(ch, M, -16, -174, -2.6, -158, CON, -14, { mat: M.concreteWarm, lip: false });
    rockBase(ch, M, 2.6, -174, 24, -158, CON, -14, { mat: M.concreteWarm, lip: false });
    // the rock under the plaza, in two pieces either side of the stairwell down to the tidal lock
    crag(ch, M.rock, -9.95, -1.8, -166, 13.1, 2.2, 17, { amp: 0.6 });
    crag(ch, M.rock, 13.95, -1.8, -166, 21.1, 2.2, 17, { amp: 0.6 });
    // the plaza's tiled surface, laid round the stairwell opening and the gatehouse landing (never across them)
    const tile = (x0, x1, z0, z1) => ch.box((x0 + x1) / 2, CON - 0.02, (z0 + z1) / 2, x1 - x0, 0.04, z1 - z0, M.tile, { collide: false, ao: 0, tint: 0x8c867c });
    tile(-15.8, -2.7, -173.8, -145.2);
    tile(2.7, 23.8, -173.8, -145.2);
    tile(-2.7, 2.7, -153.2, -145.2);
    railing(ch, M, -15.8, -145.2, -2.4, -145.2, CON);
    railing(ch, M, 2.4, -145.2, 23.8, -145.2, CON);
    railing(ch, M, -15.8, -145.2, -15.8, -173.8, CON);
    railing(ch, M, -15.8, -173.8, 23.8, -173.8, CON);
    railing(ch, M, 23.8, -151, 23.8, -173.8, CON);
    railing(ch, M, 23.8, -145.2, 23.8, -147.4, CON);
    // the other end of the service walk is gated too, and releases with the span
    ch.box(23.8, CON, -147.2, 0.5, 2.8, 0.4, M.stone, {});
    ch.box(23.8, CON, -151.2, 0.5, 2.8, 0.4, M.stone, {});
    ch.box(23.8, CON + 2.8, -149.2, 0.6, 0.45, 4.4, M.stone, { collide: false });
    W.serviceGate2 = slidingDoor(W, ch, 23.8, CON, -149.2, 3.6, 2.6, Math.PI / 2, { mat: M.steel, thick: 0.08, speed: 0.5 });
    W.addInteract({ id: 'serviceGate2', x: 23.3, y: CON + 1.4, z: -149.2, r: 2.2, label: 'Try the service gate' });
    // gatehouse over the stair: walls, door on the north, roof
    room(ch, M, -4.2, -163, 4.2, -153, CON, 5.5, { wall: M.concreteDark, floor: false, sides: { n: [{ t: 4.2, w: 2.2, h: 3.2 }] } });
    ch.box(0, CON - 0.4, -155.5, 8.0, 0.4, 4.6, M.tile, { ao: 0 }); // landing floor
    ch.box(0, CON + 5.5, -158, 9.2, 0.5, 11, M.concreteDark, { collide: false, ao: 0 });
    sign(W, ch, textTexture(['TIDAL INTAKE', { text: 'authorised personnel', size: 30 }], { w: 512, h: 160, size: 48, color: '#d9d2bf', bg: '#1b2026' }), 0, CON + 3.9, -152.95, 2.0, 0.6, 0, {});
    sconce(W, ch, -1.8, CON + 2.6, -152.94, 0, { cyan: true, intensity: 3, dist: 6 });
    sconce(W, ch, 1.8, CON + 2.6, -152.94, 0, { cyan: true, intensity: 3, dist: 6 });
    // view south: a rail and a pair of coin telescopes facing the Core vent
    for (const x of [-8, 12]) {
      ch.cyl(x, CON, -172.4, 0.18, 1.1, M.steel, { seg: 8 });
      ch.box(x, CON + 1.1, -172.4, 0.3, 0.3, 0.6, M.brass, { collide: false, pitch: 0.2 });
    }
    lampPost(W, ch, -12, CON, -148, { yaw: Math.PI }); lampPost(W, ch, 18, CON, -170, { yaw: 0 });
    lampPost(W, ch, -12, CON, -170, { yaw: 0, cyan: true }); lampPost(W, ch, 8, CON, -148, { yaw: Math.PI });
    bench(ch, M, -8, CON, -166, Math.PI / 2); bench(ch, M, 12, CON, -158, -Math.PI / 2);
    planter(ch, M, -10, CON, -156, { w: 1.2 }); planter(ch, M, 16, CON, -164, { w: 1.2, dead: true });
    W.plazaChunk = ch;
  }

  // ===================== NOTICES, CHALK, LEFT LUGGAGE =====================
  {
    const ch = W.named.concourse;
    const poster = (x, y, z, yaw, w = 0.9, h = 1.25) => {
      const t = textTexture([
        { text: 'EVACUATION', size: 64, weight: 500, color: '#2a2620', font: '"IBM Plex Sans", sans-serif' },
        { text: 'LEVEL THREE', size: 40, color: '#a5402c' }, ' ',
        { text: 'Proceed to the Market Pier.', size: 30, font: '"EB Garamond", serif', color: '#2a2620' },
        { text: 'One tag per resident.', size: 30, font: '"EB Garamond", serif', color: '#2a2620' },
        { text: 'Leave the lights on.', size: 30, font: '"EB Garamond", serif', color: '#2a2620' }, ' ',
        { text: 'THE AUTHORITY THANKS YOU', size: 24, color: '#5a544a' }
      ], { w: 512, h: 720, size: 30, bg: '#d9cfb4', style: 'poster' });
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ map: t, roughness: 0.95 }));
      m.position.set(x + Math.sin(yaw) * 0.02, y, z + Math.cos(yaw) * 0.02); m.rotation.y = yaw; m.rotation.z = (Math.random() - 0.5) * 0.04;
      ch.mesh(m);
    };
    poster(-11.99, CON + 1.7, -98.0, Math.PI / 2);
    poster(-11.99, CON + 1.6, -104.9, Math.PI / 2, 0.8, 1.1);
    poster(-4.21, CON + 1.7, -157.5, -Math.PI / 2);
    poster(-7.79, TER + 1.7, -71.8, Math.PI / 2, 0.8, 1.1);
    // shopfronts along the concourse: names that belonged to somebody
    const shop = (x, y, z, yaw, name, sub) => sign(W, ch, textTexture([name, { text: sub, size: 28, color: '#8a8070', font: '"IBM Plex Mono", monospace' }], { w: 768, h: 160, size: 54, color: '#e7dcc2', bg: '#24221e', font: '"EB Garamond", serif' }), x, y, z, 2.4, 0.5, yaw, { backMat: M.steel });
    shop(-11.99, CON + 3.55, -95.0, Math.PI / 2, 'Halloran\u2019s Tea Room', 'open late \u00b7 closed for good');
    shop(-11.99, CON + 3.55, -107.6, Math.PI / 2, 'Basin Survey Office', 'tide tables \u00b7 charts \u00b7 permits');
    shop(11.97, CON + 3.6, -99.0, -Math.PI / 2, 'Reading Room', 'civic archive');
    // puddles that catch the lamps, and loose papers from the evacuation
    const puddleMat = new THREE.MeshStandardMaterial({ color: 0x1c1e26, roughness: 0.02, metalness: 0.0, envMapIntensity: 7, transparent: true, opacity: 0.7, polygonOffset: true, polygonOffsetFactor: -2 });
    puddleMat.userData.noShadow = true;
    const puddle = (chn, x, y, z, w, d, rot) => {
      const g = new THREE.CircleGeometry(1, 20); g.rotateX(-Math.PI / 2);
      W.named[chn].geo(g, puddleMat, new THREE.Matrix4().compose(new THREE.Vector3(x, y + 0.012, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, rot, 0)), new THREE.Vector3(w, 1, d)), {});
      g.dispose();
    };
    for (const [chn, x, y, z, w, d, r] of [['concourse', -2.2, CON, -97, 1.4, 0.7, 0.3], ['concourse', 1.6, CON, -108.5, 0.9, 0.5, 1.1], ['concourse', -1, CON, -117, 1.8, 0.8, -0.4],
      ['concourse', 9, CON, -122, 1.1, 0.6, 0.2], ['concourse', -14, CON, -115, 1.3, 0.7, 0.9], ['terrace', 4, TER, -73, 1.2, 0.6, 0.5], ['terrace', -9, TER, -63, 0.9, 0.5, -0.6],
      ['plaza', -4, CON, -150, 1.5, 0.8, 0.2], ['plaza', 10, CON, -166, 1.0, 0.5, 1.3], ['market', -42, WF, -124, 1.0, 0.5, 0.4]]) puddle(chn, x, y, z, w, d, r);
    const paperMat = new THREE.MeshStandardMaterial({ color: 0xd8d0bc, roughness: 0.95, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -3 });
    paperMat.userData.noShadow = true;
    let s2 = 99;
    const r2 = () => { s2 = (s2 * 16807) % 2147483647; return s2 / 2147483647; };
    for (const [chn, cx, y, cz, spread, n] of [['concourse', 0, CON, -110, 14, 14], ['terrace', 0, TER, -70, 10, 6], ['plaza', 4, CON, -150, 7, 6], ['market', -40, WF, -118, 8, 5]]) {
      for (let i = 0; i < n; i++) {
        const g = new THREE.PlaneGeometry(0.21, 0.29); g.rotateX(-Math.PI / 2);
        const px = cx + (r2() - 0.5) * spread * 2, pz = cz + (r2() - 0.5) * spread * 2;
        W.named[chn].geo(g, paperMat, new THREE.Matrix4().compose(new THREE.Vector3(px, y + 0.015 + i * 0.0004, pz), new THREE.Quaternion().setFromEuler(new THREE.Euler((r2() - 0.5) * 0.08, r2() * 6.28, (r2() - 0.5) * 0.08)), new THREE.Vector3(1, 1, 1)), {});
        g.dispose();
      }
    }
    // chalk by the Vale Court door
    const cc = document.createElement('canvas'); cc.width = 512; cc.height = 256; const cg = cc.getContext('2d');
    cg.strokeStyle = 'rgba(235,232,220,0.75)'; cg.fillStyle = 'rgba(235,232,220,0.8)'; cg.lineWidth = 5; cg.lineCap = 'round';
    writeOn(cg, 'we stayed', 40, 52, 58, { color: 'rgba(235,232,220,0.85)', pen: 0.12, slant: 0.1 });
    for (let i = 0; i < 6; i++) { cg.beginPath(); cg.moveTo(60 + i * 26, 150); cg.lineTo(64 + i * 26, 220); cg.stroke(); }
    cg.beginPath(); cg.moveTo(48, 200); cg.lineTo(214, 165); cg.stroke();
    chalkify(cg, 512, 256, 3);
    const ct = new THREE.CanvasTexture(cc); ct.colorSpace = THREE.SRGBColorSpace;
    const cm = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshBasicMaterial({ map: ct, transparent: true, depthWrite: false, color: 0x8a8a84 }));
    cm.position.set(-11.985, CON + 0.75, -103.0); cm.rotation.y = Math.PI / 2; ch.mesh(cm);
    // left luggage by the skiff steps
    const mk = W.named.market;
    crate(mk, M, -66, WF, -118.8, 0.55, { mat: M.fabricRed, yaw: 0.3 });
    crate(mk, M, -65.3, WF, -118.6, 0.45, { mat: M.fabricTeal, yaw: -0.4 });
    crate(mk, M, -65.6, WF + 0.44, -118.7, 0.35, { mat: M.fabricPale, yaw: 0.1 });
  }

  // ===================== FAILING TOWERS =====================
  W.fallers = [];
  const faller = (name, x, z, w, d, h, dirX, dirZ, time) => {
    const ch = W.chunk(name);
    rockBase(ch, M, x - w / 2 - 1.5, z - d / 2 - 1.5, x + w / 2 + 1.5, z + d / 2 + 1.5, 1.5, -14, { mat: M.rock });
    const top = W.chunk(name + 'Top');
    building(W, top, x - w / 2, z - d / 2, x + w / 2, z + d / 2, 1.5, h, { tint: 0xa69a8c, lit: 0.18, floorH: 3.6 });
    // spire
    top.cyl(x, 1.5 + h + 0.95, z, 0.15, 8, M.steel, { seg: 6 });
    top.box(x, 1.5 + h + 8.9, z, 0.3, 0.3, 0.3, M.lampRed, { collide: false, ao: 0 });
    W.fallers.push({ chunk: top, x, z, h, dirX, dirZ, time, done: false });
  };
  faller('towerW', -40, -96, 9, 9, 40, -1, 0.15, 'towerA');
  faller('towerE', 44, -100, 8, 10, 34, 1, -0.2, 'towerB');

  // ===================== SKYLINE (unreachable, on their own rocks) =====================
  {
    const ch = W.chunk('skyline');
    const spots = [
      [-58, -70, 10, 10, 26], [-48, -150, 12, 9, 22], [52, -70, 9, 12, 30], [60, -140, 12, 12, 18],
      [-70, -110, 8, 8, 14], [48, -168, 10, 8, 26], [-34, -180, 9, 9, 16], [74, -96, 10, 10, 40],
      [-86, -84, 10, 12, 30], [30, -60, 8, 8, 12], [-30, -62, 9, 7, 16], [88, -160, 12, 10, 24]
    ];
    for (const [x, z, w, d, h] of spots) {
      rockBase(ch, M, x - w / 2 - 1.2, z - d / 2 - 1.2, x + w / 2 + 1.2, z + d / 2 + 1.2, 1.2, -12, { mat: M.rock });
      building(W, ch, x - w / 2, z - d / 2, x + w / 2, z + d / 2, 1.2, h, { tint: new THREE.Color().setHSL(0.08 + rnd() * 0.05, 0.12, 0.5 + rnd() * 0.15), lit: 0.15 + rnd() * 0.15 });
    }
  }

  // ===================== TARN QUARTER (drowned) =====================
  {
    const ch = W.chunk('tarn');
    for (let i = 0; i < 38; i++) {
      const x = 70 + rnd() * 70, z = -40 - rnd() * 140;
      const w = 5 + rnd() * 8, d = 5 + rnd() * 8, h = rnd() * 3.5 - 1.5;
      if (Math.abs(x - 74) < 8 && Math.abs(z + 96) < 8) continue;
      if (x + w / 2 > 74 && x - w / 2 < 108 && z - d / 2 < -94 && z + d / 2 > -128) continue;   // the Tarn Rooftops
      if (x - w / 2 < 80 && x + w / 2 > 64 && z < -92) continue;                              // the skiff's channel
      ch.box(x, -14, z, w, 14 + h, d, M.concreteDark, { collide: false, ao: 0, tint: 0x7a7470 });
      if (rnd() < 0.5) ch.box(x + (rnd() - 0.5) * w * 0.5, h, z + (rnd() - 0.5) * d * 0.5, 0.8, 1.6 + rnd() * 2, 0.8, M.stone, { collide: false });
      if (rnd() < 0.35) ch.box(x, h, z, w * 0.9, 0.3, 0.2, M.steel, { collide: false, ao: 0, roll: (rnd() - 0.5) * 0.3 });
    }
  }
}
