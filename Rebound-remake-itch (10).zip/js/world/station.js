// Halcyon Station: a round research habitat on a mast above the basin.
// Plan (seen from above, 0 deg = north/+z, clockwise):
//   centre r<7     Engine Hall (domed), the Rebound Engine on its plinth
//   r 7.5..10      ring corridor
//   r 10.3..15.6   six rooms: Berths 0, Radio 60, Lift 120, Airlock 180, Gallery 240, Archive 300 (sealed)
import * as THREE from '../../vendor/three.module.min.js';
import { writeOn } from './lettering.js';
import { wallRing, deg } from './arch.js';
import { railing, ringRailing, sconce, ceilingLight, bunk, locker, shelf, table, console_, crate, slidingDoor, sign, planter, pipeRun, cable, bench, barrel, rug, tapedNote, chair, painting, coat, poster, pottedPlant } from './props.js';
import { textTexture, decal, shared } from './materials.js';

export const F = 24;               // station floor height
export const SPAWN = { x: 0, y: F, z: 11.2, yaw: 0 };
const at = (r, a) => [Math.sin(a) * r, Math.cos(a) * r];

export function buildStation(W) {
  const M = W.M;
  const ch = W.chunk('station');
  const mast = W.chunk('mast');

  // ---------------- structure ----------------
  // mast and skirt below the floor
  mast.cyl(0, -40, 0, 6.2, F - 5.6 + 40, M.concreteDark, { seg: 40, rTop: 5.2 });
  mast.cyl(0, F - 5.6, 0, 9.5, 5.0, M.steel, { seg: 48, rTop: 16.4, collide: false });
  for (let i = 0; i < 8; i++) {
    const a = i * 45 * deg + 22.5 * deg;
    const [x0, z0] = at(6.0, a), [x1, z1] = at(14.5, a);
    pipeRun(mast, M, x0, -2, z0, x1, F - 1.2, z1, 0.45, M.steel);
    // collars where the struts meet the mast, at the waterline
    mast.box(x0, -2.5, z0, 1.6, 1.0, 1.6, M.concreteDark, { yaw: a, collide: false });
  }
  // service rings on the mast
  for (const y of [-1, 8, 16]) mast.ring(0, y, 0, 5.9, 6.9, 0.6, M.steel, { collide: false });
  // floor slab
  ch.cyl(0, F - 0.6, 0, 16.3, 0.6, M.steel, { seg: 64 });
  ch.ring(0, F - 0.015, 0, 7.5, 16.2, 0.02, M.tileWarm, { collide: false });
  ch.cyl(0, F - 0.015, 0, 7.0, 0.02, M.tile, { seg: 48, collide: false, tint: 0x8f939c });

  // outer wall with windows; door at 180
  const win = (a, w = 1.3) => ({ a: a * deg, w, sill: 0.95, h: 2.75, glass: true });
  wallRing(ch, M, 0, F, 0, 15.6, 16.2, 4.2, M.panel, [
    win(-12), win(12),                          // berths
    win(50), win(70),                           // radio
    win(112, 1.0),                              // lift
    { a: 180 * deg, w: 2.4, h: 2.9 },           // airlock outer door
    { a: 243 * deg, w: 0.7, sill: 0.35, h: 3.7, glass: true, mullion: false }, // the gallery slit
    win(222, 1.6), win(262, 1.0),
    win(306, 0.9)                               // archive
  ]);
  // wall dressing inside the rooms: a dark lower band, a chair rail, and a cable tray high up
  // with brackets. Skipped across the airlock door, the gallery slit and the corridor doors.
  {
    const skip = (aDeg, list) => list.some(([c, h]) => Math.abs(((aDeg - c + 540) % 360) - 180) < h);
    const outerGaps = [[180, 5.5], [243, 2]], innerGaps = [[0, 5.5], [60, 5.5], [120, 5.5], [180, 5.5], [240, 5.5]];
    const step = 2.5;
    for (let d = 0; d < 360; d += step) {
      const a = (d + step / 2) * deg;
      if (!skip(d + step / 2, outerGaps)) {
        const w = 2 * 15.56 * Math.sin(step * deg / 2) * 1.03;
        let [x, z] = at(15.555, a);
        ch.box(x, F, z, w, 0.9, 0.06, M.panelDark, { yaw: a, collide: false, ao: 0.5 });
        [x, z] = at(15.5, a);
        ch.box(x, F + 0.88, z, w, 0.07, 0.1, M.metal, { yaw: a, collide: false, ao: 0 });
        if (!skip(d + step / 2, [[243, 3]])) {
          [x, z] = at(15.42, a);
          ch.box(x, F + 3.74, z, w, 0.07, 0.28, M.steel, { yaw: a, collide: false, ao: 0, tint: 0x8a8f96 });
          if (d % 15 === 0) { [x, z] = at(15.5, a); ch.box(x, F + 3.62, z, 0.05, 0.12, 0.2, M.metal, { yaw: a, collide: false, ao: 0 }); }
        }
      }
      if (!skip(d + step / 2, innerGaps)) {
        const w = 2 * 10.36 * Math.sin(step * deg / 2) * 1.03;
        let [x, z] = at(10.335, a);
        ch.box(x, F, z, w, 0.9, 0.06, M.panelDark, { yaw: a, collide: false, ao: 0.5 });
        [x, z] = at(10.37, a);
        ch.box(x, F + 0.88, z, w, 0.07, 0.1, M.metal, { yaw: a, collide: false, ao: 0 });
      }
    }
    // the same band on both faces of the walls between rooms
    for (const r of [30, 90, 150, 210, 270, 330]) {
      const a = r * deg, tx = Math.cos(a), tz = -Math.sin(a);
      for (const k of [-1, 1]) {
        const segs = r === 270 ? [[10.3, 12.3], [13.7, 15.6]] : [[10.3, 15.6]];
        for (const [r0, r1] of segs) {
          const [x, z] = at((r0 + r1) / 2, a);
          ch.box(x + tx * k * 0.18, F, z + tz * k * 0.18, 0.06, 0.9, r1 - r0, M.panelDark, { yaw: a, collide: false, ao: 0.5 });
          ch.box(x + tx * k * 0.2, F + 0.88, z + tz * k * 0.2, 0.1, 0.07, r1 - r0, M.metal, { yaw: a, collide: false, ao: 0 });
        }
      }
    }
    // a cable drops from the tray to each room's light switch box
    for (const r of [22, 82, 135, 195, 232, 290]) {
      const a = r * deg;
      let [x, z] = at(15.47, a);
      ch.box(x, F + 1.05, z, 0.05, 2.68, 0.05, M.steel, { yaw: a, collide: false, ao: 0, tint: 0x555a60 });
      [x, z] = at(15.48, a);
      ch.box(x, F + 1.2, z, 0.16, 0.22, 0.08, M.panelDark, { yaw: a, collide: false, ao: 0 });
    }
  }
  // exterior skin: ribs every 15 degrees, cornice and plinth band
  for (let i = 0; i < 24; i++) {
    const a = i * 15 * deg + 7.5 * deg;
    if (Math.abs(a - Math.PI) < 0.2) continue;
    const [x, z] = at(16.35, a);
    ch.box(x, F - 0.6, z, 0.35, 5.3, 0.35, M.steel, { yaw: a, collide: false, ao: 0 });
  }
  ch.ring(0, F + 4.2, 0, 7.5, 16.5, 0.45, M.steel, { collide: false });
  ch.ring(0, F + 4.65, 0, 15.6, 16.5, 0.3, M.metal, { collide: false });
  ch.ring(0, F - 0.65, 0, 16.2, 16.6, 0.4, M.metal, { collide: false });
  // inner ceiling panels (lighter, so rooms are not black overhead)
  ch.ring(0, F + 4.05, 0, 7.5, 15.6, 0.15, M.panel, { collide: false, tint: 0xd8d6d0, under: 0.9 });

  // corridor / room wall with doors; archive (300) is sealed
  const door = (a) => ({ a: a * deg, w: 1.7, h: 2.6 });
  wallRing(ch, M, 0, F, 0, 10.0, 10.3, 4.05, M.panel, [door(0), door(60), door(120), door(180), door(240)]);
  // radial walls between rooms. The wall at 270 has the archive hatch.
  for (const a of [30, 90, 150, 210, 330]) {
    const [x, z] = at(12.95, a * deg);
    ch.box(x, F, z, 0.3, 4.05, 5.3, M.panel, { yaw: a * deg });
  }
  {
    const a = 270 * deg;
    // pieces either side of the hatch opening (r 12.3..13.7)
    for (const [r0, r1] of [[10.3, 12.3], [13.7, 15.6]]) {
      const [x, z] = at((r0 + r1) / 2, a);
      ch.box(x, F, z, 0.3, 4.05, r1 - r0, M.panel, { yaw: a });
    }
    const [x, z] = at(13.0, a);
    ch.box(x, F + 2.4, z, 0.3, 1.65, 1.4, M.panel, { yaw: a });
    W.hatch = slidingDoor(W, ch, x, F, z, 1.4, 2.4, a - Math.PI / 2, { mat: M.steel, thick: 0.18 });
  }

  // Engine Hall wall (drum), two doorways, and the dome
  wallRing(ch, M, 0, F, 0, 7.0, 7.5, 8.6, M.panel, [{ a: 0, w: 2.3, h: 3.1 }, { a: Math.PI, w: 2.3, h: 3.1 }], { tint: 0x8e949c });
  for (const a of [45, 135, 225, 315]) { const [sx, sz] = at(6.96, a * deg); sconce(W, ch, sx, F + 3.2, sz, a * deg + Math.PI, { intensity: 5, dist: 9 }); }
  // tall slot windows in the drum above the corridor roof
  for (let i = 0; i < 12; i++) {
    const a = i * 30 * deg + 15 * deg;
    const [x, z] = at(7.52, a);
    ch.box(x, F + 5.2, z, 0.5, 2.6, 0.04, M.lampCyan, { yaw: a, collide: false, ao: 0, tint: 0x334a48 });
  }
  {
    const g = new THREE.SphereGeometry(7.5, 48, 16, 0, Math.PI * 2, 0.22, Math.PI / 2 - 0.22);
    ch.geo(g, M.metal, new THREE.Matrix4().makeTranslation(0, F + 8.6, 0), { tint: 0x7a7f88 });
    g.dispose();
    const gi = new THREE.SphereGeometry(7.2, 48, 16, 0, Math.PI * 2, 0.24, Math.PI / 2 - 0.24);
    gi.scale(-1, 1, 1); // inside face
    ch.geo(gi, M.panelDark, new THREE.Matrix4().makeTranslation(0, F + 8.6, 0), { tint: 0x9aa0a8 });
    gi.dispose();
    ch.ring(0, F + 8.55, 0, 6.6, 7.0, 0.12, M.steel, { collide: false });
    ch.ring(0, F + 8.5, 0, 6.62, 6.68, 0.05, M.lampWarm, { collide: false, tint: 0x806050 });
    W.light(0, F + 7.5, 4, 0xffc89a, 4, 10, { chunk: ch }); W.light(0, F + 7.5, -4, 0xffc89a, 4, 10, { chunk: ch });
    // oculus ring and glass
    ch.ring(0, F + 15.75, 0, 1.6, 2.1, 0.35, M.brass, { collide: false });
    ch.cyl(0, F + 15.9, 0, 1.62, 0.04, M.glass, { collide: false, seg: 24 });
    // dome ribs
    for (let i = 0; i < 12; i++) {
      const a = i * 30 * deg;
      const pts = [];
      for (let k = 0; k <= 10; k++) { const th = 0.22 + (Math.PI / 2 - 0.22) * k / 10; pts.push(new THREE.Vector3(Math.sin(a) * Math.sin(th) * 7.58, F + 8.6 + Math.cos(th) * 7.58, Math.cos(a) * Math.sin(th) * 7.58)); }
      const tg = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 12, 0.12, 5);
      ch.geo(tg, M.steel, new THREE.Matrix4(), {}); tg.dispose();
    }
  }
  // the name on the drum, facing the bridge
  {
    const tex = textTexture(['H A L C Y O N'], { w: 1024, h: 128, size: 92, color: '#d9d2bf', font: '"IBM Plex Sans", sans-serif', weight: 500 });
    const m = decal(tex, 7.5, 0.95);
    m.position.set(0, F + 6.0, -7.56); m.rotation.y = Math.PI;
    m.material.color.setScalar(0.55);
    ch.mesh(m);
  }
  // antenna mast above the radio room, with a slow red beacon
  {
    const [x, z] = at(13, 60 * deg);
    ch.cyl(x, F + 4.6, z, 0.12, 9, M.steel, { seg: 8, collide: false });
    for (let k = 0; k < 3; k++) ch.box(x, F + 7 + k * 2.2, z, 1.6 - k * 0.4, 0.06, 0.06, M.steel, { yaw: 60 * deg, collide: false, ao: 0 });
    ch.cyl(x, F + 13.6, z, 0.16, 0.25, M.lampRed, { seg: 8, collide: false });
    W.beaconRed = W.light(x, F + 13.9, z, 0xff3a2a, 6, 14, { chunk: ch });
    cable(ch, M, [x, F + 13, z], [x - 3, F + 4.6, z + 4.2], 0.2, 0.02);
  }

  // ---------------- the Rebound Engine ----------------
  ch.cyl(0, F, 0, 2.6, 0.35, M.steel, { seg: 40 });
  ch.cyl(0, F + 0.35, 0, 2.2, 0.35, M.steel, { seg: 40, tint: 0x8a8e96 });
  ch.ring(0, F + 0.7, 0, 2.05, 2.2, 0.04, M.metal, { collide: false });
  ringRailing(ch, M, 0, 0, 4.3, F, 200 * deg, 520 * deg, { h: 1.0, top: M.steel });
  // two pylons carry the gimbal frame
  for (const k of [-1, 1]) {
    ch.box(k * 3.1, F, 0, 0.5, 3.4, 0.7, M.steel, { ao: 0.8 });
    ch.box(k * 3.1, F + 3.4, 0, 0.8, 0.4, 0.9, M.metal, { collide: false, ao: 0 });
  }
  // dial plate with the taped-over counter, at the south rail gap
  ch.box(0, F, -3.0, 0.9, 1.05, 0.4, M.panelDark, {});
  {
    const t = textTexture([{ text: 'RESIDENTS RETAINED', size: 34 }, { text: '0 0 6', size: 70, color: '#f2a65a' }], { w: 512, h: 256, color: '#cfd8d4', bg: '#14181c' });
    W.counterPlate = decal(t, 0.7, 0.35); W.counterPlate.position.set(0, F + 0.82, -3.205); W.counterPlate.rotation.y = Math.PI;
    W.counterPlate.rotation.x = 0; ch.mesh(W.counterPlate);
    const tape = textTexture(['DO NOT READ'], { w: 512, h: 128, size: 58, color: '#1d1a24', bg: '#d8c58a', style: 'marker' });
    W.counterTape = decal(tape, 0.78, 0.2); W.counterTape.position.set(0, F + 0.82, -3.21); W.counterTape.rotation.y = Math.PI; W.counterTape.rotation.z = 0.06;
    ch.mesh(W.counterTape);
  }
  const engine = new THREE.Group();
  engine.position.set(0, F + 3.6, 0);
  W.scene.add(engine);
  const rings = [];
  const torus = (r, tube, mat) => { const m = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 12, 96), mat); m.castShadow = true; return m; };
  const outer = torus(3.0, 0.14, M.brass); engine.add(outer);
  const pivotA = new THREE.Group(); engine.add(pivotA);
  const r1 = torus(2.45, 0.1, M.metal); pivotA.add(r1);
  const pivotB = new THREE.Group(); pivotA.add(pivotB);
  const r2 = torus(1.9, 0.09, M.brass); r2.rotation.x = Math.PI / 2; pivotB.add(r2);
  const pivotC = new THREE.Group(); pivotB.add(pivotC);
  const r3 = torus(1.4, 0.07, M.copper); pivotC.add(r3);
  // pins joining the rings
  for (const k of [-1, 1]) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.7, 8), M.steel); p.rotation.z = Math.PI / 2; p.position.x = k * 2.75; engine.add(p);
  }
  const coreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x63f0e2).multiplyScalar(3.5), toneMapped: false });
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.75, 3), coreMat);
  pivotC.add(core);
  const shellMat = new THREE.MeshBasicMaterial({ color: 0x3fd0c8, transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
  const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(1.05, 2), shellMat);
  pivotC.add(shell);
  // the axle the core hangs on
  const engineLight = W.light(0, F + 3.6, 0, 0x5ff0e0, 18, 16, { key: 'engine' });
  W.engine = { group: engine, pivotA, pivotB, pivotC, core, coreMat, shell, light: engineLight, speed: 1, wobble: 0 };
  W.onUpdate((dt, t, st) => {
    const e = W.engine, k = e.speed;
    e.pivotA.rotation.x += dt * 0.35 * k;
    e.pivotB.rotation.y += dt * 0.5 * k;
    e.pivotC.rotation.z += dt * 0.8 * k;
    const pulse = 0.8 + 0.2 * Math.sin(t * 2.2) + e.wobble * Math.sin(t * 17) * 0.4;
    e.coreMat.color.setRGB(0.39 * 3.5 * pulse, 0.94 * 3.5 * pulse, 0.89 * 3.5 * pulse);
    e.shell.scale.setScalar(1 + 0.04 * Math.sin(t * 2.2) + e.wobble * 0.1 * Math.sin(t * 9));
    e.group.position.y = F + 3.6 + ch.offset.y + e.wobble * 0.03 * Math.sin(t * 31);
    e.light.intensity = 18 * pulse;
  });
  W.addInteract({ id: 'engine', x: 0, y: F + 0.9, z: -3.3, r: 2.4, label: 'Examine the Rebound Engine' });

  // floor up-lights around the plinth
  for (let i = 0; i < 4; i++) {
    const a = i * 90 * deg + 45 * deg;
    const [x, z] = at(5.6, a);
    ch.box(x, F, z, 0.5, 0.08, 0.5, M.steel, { collide: false, ao: 0 });
    ch.box(x, F + 0.08, z, 0.36, 0.02, 0.36, M.lampWarm, { collide: false, ao: 0 });
  }

  // ---------------- corridor ----------------
  for (let i = 0; i < 6; i++) {
    const a = i * 60 * deg + 30 * deg;
    const [x, z] = at(8.75, a);
    ceilingLight(W, ch, x, F + 4.05, z, a + Math.PI / 2, { len: 1.2, intensity: 6, dist: 9, color: 0xffd2a8 });
  }
  // a run of conduit along the corridor ceiling, tied to the wall
  ch.ring(0, F + 3.7, 0, 9.85, 9.95, 0.1, M.copper, { collide: false });
  ch.ring(0, F + 3.55, 0, 9.85, 9.95, 0.06, M.steel, { collide: false });
  // skirting strip lights low on the drum wall: way-finding
  ch.ring(0, F + 0.12, 0, 7.5, 7.53, 0.04, M.lampCyan, { collide: false, a0: 5 * deg, a1: 175 * deg, tint: 0x557070 });
  ch.ring(0, F + 0.12, 0, 7.5, 7.53, 0.04, M.lampCyan, { collide: false, a0: 185 * deg, a1: 355 * deg, tint: 0x557070 });

  // room name plates above each door, corridor side
  const plate = (a, text) => {
    const [x, z] = at(9.98, a * deg);
    const tex = textTexture([text], { w: 512, h: 96, size: 46, color: '#d9d2bf', bg: '#1b2026', font: '"IBM Plex Mono", monospace' });
    sign(W, ch, tex, x, F + 2.95, z, 1.3, 0.24, a * deg + Math.PI, { backing: false });
  };
  plate(0, 'BERTHS'); plate(60, 'RADIO'); plate(120, 'LIFT'); plate(180, 'AIRLOCK'); plate(240, 'GALLERY');
  {
    const [x, z] = at(9.98, 300 * deg);
    const tex = textTexture(['ARCHIVE', { text: 'sealed', size: 34, color: '#f2a65a', hand: true }], { w: 512, h: 160, size: 46, color: '#d9d2bf', bg: '#1b2026' });
    sign(W, ch, tex, x, F + 2.6, z, 1.3, 0.4, 300 * deg + Math.PI, { backing: false });
  }

  // notices pinned along the corridor, between the doors
  {
    const pin = (a, draw, o = {}) => { const [x, z] = at(9.99, a * deg); poster(W, ch, x, F + 1.62, z, a * deg + Math.PI, draw, o); };
    const ink = '#2a2430', orange = '#d9772e', teal = '#2f7f86', plum = '#5a3a6a';
    // the basin authority's tide notice
    pin(24, (g, Wd, Hd, write) => {
      g.fillStyle = teal; g.fillRect(0, 0, Wd, 150);
      write('MIND THE TIDE', Wd / 2, 40, 54, { color: '#efe6d0', pen: 0.24 });
      g.strokeStyle = teal; g.lineWidth = 7; g.lineCap = 'round';
      for (let row = 0; row < 3; row++) { g.beginPath(); for (let x = 50; x < Wd - 50; x += 46) { const y = 250 + row * 42; g.moveTo(x, y); g.quadraticCurveTo(x + 11, y - 16, x + 23, y); g.quadraticCurveTo(x + 34, y + 16, x + 46, y); } g.stroke(); }
      write('Keep off the lower walks', Wd / 2, 420, 30);
      write('when the bell rings.', Wd / 2, 462, 30);
      write('Water comes up quicker', Wd / 2, 530, 30);
      write('than you think.', Wd / 2, 572, 30);
      write('HALCYON BASIN AUTHORITY', Wd / 2, Hd - 70, 20, { color: teal });
    }, { seed: 5 });
    // a map of the basin, drawn by someone with a ruler and patience
    pin(97, (g, Wd, Hd, write) => {
      write('THE BASIN', Wd / 2, 30, 46, { color: plum });
      const mx = (x) => Wd / 2 + (x + 30) * 1.55, mz = (z) => 140 + (-z) * 1.95;
      g.fillStyle = 'rgba(47,127,134,.16)'; g.fillRect(24, 110, Wd - 48, Hd - 180);
      g.strokeStyle = ink; g.lineWidth = 3;
      // the skiff's rounds, dotted
      g.setLineDash([6, 9]); g.strokeStyle = orange; g.lineWidth = 3; g.beginPath();
      g.moveTo(mx(-75), mz(-124)); g.lineTo(mx(-150), mz(-58)); g.moveTo(mx(-75), mz(-124)); g.lineTo(mx(-122), mz(-202)); g.stroke();
      g.setLineDash([]);
      // the bridge down from the station
      g.strokeStyle = ink; g.lineWidth = 4; g.beginPath(); g.moveTo(mx(0), mz(-16)); g.lineTo(mx(0), mz(-55)); g.stroke();
      // station, city blocks, isle, rise, tarn
      g.lineWidth = 3; g.beginPath(); g.arc(mx(0), mz(0), 22, 0, 7); g.stroke();
      g.fillStyle = 'rgba(42,36,48,.75)';
      for (const [x, z, w, d] of [[-14, -66, 12, 10], [6, -72, 14, 12], [-20, -96, 10, 16], [14, -104, 12, 12], [-6, -118, 18, 10], [24, -130, 10, 16], [-16, -136, 12, 12], [-30, -150, 14, 8], [0, -150, 20, 8]]) g.fillRect(mx(x) - w * 0.8, mz(z) - d * 0.8, w * 1.6, d * 1.6);
      g.fillRect(mx(-70) - 22, mz(-122) - 6, 44, 12);
      g.beginPath(); g.arc(mx(-150), mz(-58), 18, 0, 7); g.fill();
      g.beginPath(); g.arc(mx(-122), mz(-202), 16, 0, 7); g.fill();
      // where Tarn was, somebody has pencilled a question
      write('?', mx(90), mz(-112) - 18, 34, { color: 'rgba(60,56,70,.55)', pen: 0.12, wobble: 1.5 });
      const lab = (t, x, z, dy = 26, al = 'center') => write(t, mx(x), mz(z) + dy, 22, { align: al, color: ink, maxW: 200 });
      lab('HALCYON', -16, 0, -10, 'right'); lab('CITY', 30, -86, -12, 'left'); lab('PIER', -70, -122, 16); lab('ISLE', -150, -58, 24); lab('RISE', -122, -202, 22);
      // you are here
      g.fillStyle = orange; g.beginPath(); g.arc(mx(0), mz(0), 7, 0, 7); g.fill();
      write('you are here', mx(0) + 34, mz(0) - 18, 18, { align: 'left', color: orange });
      write('skiff - - -', Wd - 40, Hd - 52, 18, { align: 'right', color: orange });
    }, { seed: 9, w: 0.7, h: 0.84, curl: -1 });
    // the kettle rota, argued over
    pin(143, (g, Wd, Hd, write) => {
      write('KETTLE ROTA', Wd / 2, 40, 52, { color: '#c4581e', pen: 0.24 });
      g.strokeStyle = ink; g.lineWidth = 2;
      const rows = [['MON', 'Absol'], ['TUE', 'Skye'], ['WED', 'Charley'], ['THU', 'Christian'], ['FRI', 'Aiden'], ['SAT', 'Luka'], ['SUN', 'Keanu']];
      rows.forEach(([d, n], i) => {
        const y = 150 + i * 70;
        g.beginPath(); g.moveTo(40, y + 52); g.lineTo(Wd - 40, y + 52); g.stroke();
        write(d, 50, y + 8, 26, { align: 'left' });
        write(n, 170, y + 6, 30, { align: 'left', color: '#22305a', pen: 0.17, wobble: 1.3, slant: 0.08 });
      });
      // two entries crossed out by other hands
      g.strokeStyle = '#a33a2a'; g.lineWidth = 4;
      g.beginPath(); g.moveTo(160, 150 + 5 * 70 + 24); g.lineTo(300, 150 + 5 * 70 + 18); g.stroke();
      g.beginPath(); g.moveTo(160, 150 + 6 * 70 + 24); g.lineTo(310, 150 + 6 * 70 + 20); g.stroke();
      write('no tea', 320, 150 + 5 * 70 + 12, 18, { align: 'left', color: '#a33a2a', wobble: 1.4 });
      write('is a dog', 330, 150 + 6 * 70 + 12, 18, { align: 'left', color: '#a33a2a', wobble: 1.4 });
    }, { seed: 13, paper: '#e4d9bf' });
    // lights out
    pin(206, (g, Wd, Hd, write) => {
      g.fillStyle = '#26283a'; g.fillRect(0, 0, Wd, Hd);
      g.fillStyle = '#e9dfc6'; g.beginPath(); g.arc(Wd / 2, 210, 80, 0, 7); g.fill();
      g.fillStyle = '#26283a'; g.beginPath(); g.arc(Wd / 2 + 38, 186, 74, 0, 7); g.fill();
      for (let i = 0; i < 26; i++) { g.fillStyle = 'rgba(233,223,198,' + (0.3 + (i * 37 % 10) / 14) + ')'; g.fillRect((i * 97) % Wd, 40 + (i * 53) % 300, 3, 3); }
      write('LIGHTS OUT', Wd / 2, 360, 56, { color: '#e9dfc6', pen: 0.24 });
      write('23:00', Wd / 2, 440, 44, { color: '#f2a65a' });
      write('quiet in the berths,', Wd / 2, 540, 28, { color: '#e9dfc6' });
      write('please', Wd / 2, 584, 28, { color: '#e9dfc6' });
    }, { seed: 17, paper: '#26283a' });
    // the skiff timetable, which is not a timetable
    pin(263, (g, Wd, Hd, write) => {
      write('THE SKIFF', Wd / 2, 40, 54, { color: plum, pen: 0.24 });
      g.fillStyle = '#26283a'; g.beginPath(); g.moveTo(110, 300); g.lineTo(400, 300); g.lineTo(370, 345); g.lineTo(135, 345); g.closePath(); g.fill();
      g.fillRect(200, 230, 120, 70); g.fillStyle = '#5ed8cc'; g.fillRect(220, 246, 30, 24); g.fillRect(268, 246, 30, 24);
      g.strokeStyle = teal; g.lineWidth = 5; g.beginPath(); for (let x = 70; x < Wd - 70; x += 40) { g.moveTo(x, 362); g.quadraticCurveTo(x + 10, 350, x + 20, 362); g.quadraticCurveTo(x + 30, 374, x + 40, 362); } g.stroke();
      write('from Market Pier', Wd / 2, 420, 32);
      write('to the Isle, the Rise', Wd / 2, 466, 32);
      write('and back again', Wd / 2, 512, 32);
      write('ask Luka', Wd / 2, 600, 36, { color: orange, wobble: 1.2, slant: 0.08 });
    }, { seed: 21, curl: -1 });
    // plants somebody keeps alive along the corridor
    for (const [a, sd] of [[46, 1], [168, 3], [287, 5]]) { const [x, z] = at(9.66, a * deg); pottedPlant(ch, M, x, F, z, { seed: sd }); }
    // somebody's mug
    { const [x, z] = at(9.99, 331 * deg); tapedNote(W, ch, x, F + 1.5, z, 331 * deg + Math.PI, ['LOST', 'blue mug,', 'chipped.', 'it was', 'my mum\u2019s', '- S'], { tilt: -0.05, size: 30, h: 0.5 }); }
  }

  // ---------------- rooms ----------------
  const roomLight = (a, r = 13, o = {}) => { const [x, z] = at(r, a * deg); return ceilingLight(W, ch, x, F + 4.05, z, a * deg + Math.PI / 2, { len: 1.6, intensity: 6, dist: 10, ...o }); };

  // BERTHS (0)
  roomLight(0);
  for (const [a, n] of [[-17, 2], [0, 1], [17, 3]]) {
    const [x, z] = at(14.35, a * deg);
    bunk(ch, M, x, F, z, a * deg, { blanket: n === 1 ? M.fabricRed : M.fabricTeal, noBlanket: n === 3 });   // berth 03 is Keanu's
    const [px, pz] = at(15.55, a * deg);
    const tex = textTexture([`BERTH 0${n}`, { text: n === 1 ? 'I. Vale' : n === 3 ? 'Keanu' : 'vacant', size: 44, color: n !== 2 ? '#f2a65a' : '#8a9496', hand: true }], { w: 512, h: 200, size: 52, color: '#d9d2bf', bg: '#1b2026' });
    sign(W, ch, tex, px, F + 1.75, pz, 0.6, 0.24, a * deg + Math.PI, {});
  }
  { // Keanu's tartan blanket, rucked up on berth 03 where he sleeps
    const c = document.createElement('canvas'); c.width = 256; c.height = 512; const g = c.getContext('2d');
    g.fillStyle = '#7e3a30'; g.fillRect(0, 0, 256, 512);
    for (const [col, w, step, off] of [['rgba(44,58,68,.75)', 34, 96, 10], ['rgba(226,196,140,.32)', 5, 96, 58], ['rgba(20,16,18,.35)', 14, 48, 30]]) {
      g.fillStyle = col; for (let p = off; p < 512; p += step) { g.fillRect(0, p, 256, w); if (p < 256) g.fillRect(p, 0, w, 512); }
    }
    for (let i = 0; i < 900; i++) { g.fillStyle = `rgba(${i % 2 ? '255,240,220' : '0,0,0'},.05)`; g.fillRect((i * 37) % 256, (i * 91) % 512, 2, 2); }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    const a = 17 * deg, [bx, bz] = at(14.25, a);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 1.62), new THREE.MeshStandardMaterial({ map: t, roughness: 0.95, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
    m.rotation.set(-Math.PI / 2, a, 0, 'YXZ');
    m.position.set(bx, F + 0.612, bz); m.receiveShadow = true; ch.mesh(m);
  }
  for (const a of [-26, -8.5, 8.5, 26]) { const [x, z] = at(15.25, a * deg); locker(ch, M, x, F, z, a * deg + Math.PI, { tint: a > 0 ? 0xb8c0c8 : 0xffffff }); }
  { // manifest clipboard on a stand next to berth 01
    const [x, z] = at(12.9, -6 * deg);
    ch.box(x, F, z, 0.08, 1.05, 0.08, M.steel, { collide: false, ao: 0 });
    ch.box(x, F + 1.05, z, 0.42, 0.04, 0.32, M.steel, { collide: false, ao: 0, pitch: 0.4 });
    ch.box(x, F + 1.08, z, 0.32, 0.01, 0.24, M.paint, { collide: false, ao: 0, pitch: 0.4 });
    W.addInteract({ id: 'identity', x, y: F + 1.1, z, r: 2.2, label: 'Read the berth manifest' });
  }
  { // small writing desk with the cycle note
    const [x, z] = at(11.2, 22 * deg);
    table(ch, M, x, F, z, 1.1, 0.6, { yaw: 22 * deg });
    ch.box(x, F + 0.78, z, 0.3, 0.02, 0.22, M.paint, { yaw: 0.4, collide: false, ao: 0 });
    ch.cyl(x + 0.3, F + 0.78, z + 0.1, 0.05, 0.12, M.paint, { collide: false, seg: 8, tint: 0x996644 });
    // the kettle, on a little hotplate
    const kx = x - 0.32, kz = z - 0.02;
    ch.box(kx, F + 0.78, kz, 0.24, 0.03, 0.24, M.steel, { yaw: 22 * deg, collide: false, ao: 0, tint: 0x55595e });
    ch.cyl(kx, F + 0.81, kz, 0.085, 0.15, M.metal, { seg: 16, rTop: 0.065, collide: false, tint: 0xc8ccd0 });
    ch.cyl(kx, F + 0.96, kz, 0.045, 0.02, M.metal, { seg: 12, collide: false, tint: 0x9aa0a6 });
    ch.cyl(kx, F + 0.98, kz, 0.012, 0.02, M.rubber, { seg: 8, collide: false });
    { const ya = 22 * deg; ch.cyl(kx + Math.sin(ya) * 0.1, F + 0.86, kz + Math.cos(ya) * 0.1, 0.013, 0.1, M.metal, { seg: 8, collide: false, tint: 0xc8ccd0, pitch: 0.9, yaw: ya }); }
    { const ya = 22 * deg; ch.box(kx - Math.sin(ya) * 0.09, F + 0.86, kz - Math.cos(ya) * 0.09, 0.025, 0.1, 0.06, M.rubber, { collide: false, ao: 0, yaw: ya }); }
    W.addInteract({ id: 'kettle', x: kx, y: F + 0.95, z: kz, r: 1.8, label: 'Make a cup of tea' });
  }

  // RADIO (60)
  roomLight(60, 12.6, { intensity: 5 });
  {
    const a = 60 * deg;
    const [x, z] = at(14.7, a);
    console_(W, ch, x, F, z, a + Math.PI, { w: 2.2 });
    // receiver cabinet with dials
    const [cx, cz] = at(14.9, 72 * deg);
    ch.box(cx, F, cz, 1.0, 1.9, 0.55, M.panelDark, { yaw: 72 * deg + Math.PI });
    // three dials across the cabinet's front face
    for (let i = 0; i < 3; i++) {
      const a72 = 72 * deg, t = (i - 1) * 0.3;
      const dx = cx - Math.sin(a72) * 0.3 + Math.cos(a72) * t, dz = cz - Math.cos(a72) * 0.3 - Math.sin(a72) * t;
      ch.cyl(dx, F + 1.3, dz, 0.07, 0.05, M.brass, { collide: false, seg: 14, roll: Math.PI / 2, yaw: 72 * deg + Math.PI / 2 });
    }
    const [sx, sz] = at(14.58, 72 * deg);
    ch.box(sx, F + 0.9, sz, 0.6, 0.28, 0.02, M.panelDark, { yaw: 72 * deg, collide: false, ao: 0 });
    {
      // the tuning window: a lit scale with the bands marked, a red needle; a speaker grille below
      const c = document.createElement('canvas'); c.width = 512; c.height = 240; const g = c.getContext('2d');
      const bg = g.createLinearGradient(0, 0, 0, 240); bg.addColorStop(0, '#d9a45a'); bg.addColorStop(1, '#b8803e'); g.fillStyle = bg; g.fillRect(0, 0, 512, 240);
      g.strokeStyle = '#3a2412'; g.fillStyle = '#3a2412'; g.lineWidth = 2; g.font = '600 26px "IBM Plex Mono", monospace'; g.textAlign = 'center';
      for (let f = 88; f <= 108; f += 0.5) { const x = 36 + (f - 88) / 20 * 440, big = f % 4 === 0; g.beginPath(); g.moveTo(x, 150); g.lineTo(x, big ? 112 : f % 1 === 0 ? 126 : 136); g.stroke(); if (big) g.fillText(String(f), x, 96); }
      g.font = '400 20px "IBM Plex Mono", monospace'; g.fillText('MHz  \u00b7  FIELD RECEIVER  \u00b7  BASIN AUTHORITY', 256, 196);
      // somebody's pencil marks at the two bands that matter
      for (const f of [91.8, 107.3]) { const x = 36 + (f - 88) / 20 * 440; g.strokeStyle = 'rgba(40,30,60,.75)'; g.lineWidth = 3; g.beginPath(); g.arc(x, 132, 15, 0, 7); g.stroke(); }
      g.strokeStyle = '#c42a18'; g.lineWidth = 4; g.beginPath(); g.moveTo(36 + 3.8 / 20 * 440, 40); g.lineTo(36 + 3.8 / 20 * 440, 160); g.stroke();
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
      const [wx, wz] = at(14.566, 72 * deg);
      sign(W, ch, t, wx, F + 1.04, wz, 0.56, 0.26, 72 * deg + Math.PI, { backing: false, glow: 0.55 });
      const gc = document.createElement('canvas'); gc.width = 256; gc.height = 192; const gg = gc.getContext('2d');
      gg.fillStyle = '#4a4e56'; gg.fillRect(0, 0, 256, 192);
      for (let y = 14; y < 192; y += 16) for (let x = 14 + ((y / 16) % 2) * 8; x < 250; x += 16) { gg.fillStyle = '#0c0d0f'; gg.beginPath(); gg.arc(x, y, 4.5, 0, 7); gg.fill(); gg.fillStyle = 'rgba(255,255,255,.06)'; gg.beginPath(); gg.arc(x - 1, y - 1, 2, 0, 7); gg.fill(); }
      const gt = new THREE.CanvasTexture(gc); gt.colorSpace = THREE.SRGBColorSpace;
      const [gx, gz] = at(14.622, 72 * deg);
      sign(W, ch, gt, gx, F + 0.42, gz, 0.72, 0.52, 72 * deg + Math.PI, { backing: false });
    }
    { // a little book left on the radio desk, much thumbed
      const yaw = a + Math.PI, s = Math.sin(yaw), c = Math.cos(yaw), off = 0.78;
      const bx = x + c * off + s * 0.14, bz = z - s * off + c * 0.14, by = F + 0.92;
      const book = new THREE.Group(); book.position.set(bx, by, bz); book.rotation.y = yaw + 0.35;
      const cover = new THREE.MeshStandardMaterial({ color: 0x2c4a3c, roughness: 0.85 });
      const b1 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.032, 0.25), cover); b1.position.y = 0.016; book.add(b1);
      const pg = new THREE.Mesh(new THREE.BoxGeometry(0.172, 0.026, 0.236), new THREE.MeshStandardMaterial({ color: 0xe6dcc4, roughness: 0.95 })); pg.position.set(0.006, 0.016, 0); book.add(pg);
      const t = textTexture(['HOW TO', 'SPEAK', { text: 'DOG', size: 96, color: '#f2a65a' }, { text: 'a pocket guide', size: 26, color: '#cfc4a4', hand: true }], { w: 256, h: 356, size: 58, color: '#eadfc2', bg: '#2c4a3c', style: 'stencil' });
      const lab = new THREE.Mesh(new THREE.PlaneGeometry(0.17, 0.236), new THREE.MeshStandardMaterial({ map: t, roughness: 0.8 }));
      lab.rotation.x = -Math.PI / 2; lab.position.y = 0.0325; book.add(lab);
      book.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
      ch.mesh(book);
      W.addInteract({ id: 'dogBook', x: bx, y: by + 0.1, z: bz, r: 2.0, label: 'Read \u201cHow to Speak Dog\u201d' });
    }
    W.addInteract({ id: 'radio', x: Math.sin(a) * 14.1, y: F + 1.15, z: Math.cos(a) * 14.1, r: 2.4, label: 'Use the field receiver' });
    // directory board flat on the radial wall at 90, on its radio side
    const bx = at(12.9, 90 * deg)[0], bz = 0.19;
    const tex = textTexture([
      { text: 'HALCYON · DIRECTORY', size: 40, color: '#f2a65a' }, ' ',
      'ENGINE HALL ........ CENTRE', 'BERTHS ............. N', 'RADIO .............. NE', 'OBSERVER LIFT ...... SE',
      'AIRLOCK / BRIDGE ... S', 'GALLERY ............ SW', 'ARCHIVE ............ NW'
    ], { w: 768, h: 640, size: 34, color: '#d9d2bf', bg: '#1a1f24', align: 'left', lh: 1.35 });
    sign(W, ch, tex, bx, F + 1.65, bz, 1.2, 1.0, 90 * deg - Math.PI / 2, {});
    W.addInteract({ id: 'directory', x: bx - 0.4, y: F + 1.6, z: bz, r: 2.2, label: 'Read the directory' });
    const [ox, oz] = at(11.3, 48 * deg);
    bench(ch, M, ox, F, oz, 48 * deg, 1.4);
    cable(ch, M, [x + 0.6, F + 0.9, z - 0.2], [cx, F + 1.7, cz], 0.3, 0.025);
  }

  // LIFT (120)
  roomLight(120, 12.4, { intensity: 5, color: 0xcfe8ff });
  {
    const a = 120 * deg;
    const [x, z] = at(14.2, a);
    // cage: four posts, roof, floor
    const s = Math.sin(a), c = Math.cos(a);
    for (const [u, v] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      ch.box(x + c * u * 1.05 + s * v * 0.95, F, z - s * u * 1.05 + c * v * 0.95, 0.14, 3.6, 0.14, M.steel, { yaw: a, ao: 0 });
    }
    ch.box(x, F + 3.6, z, 2.3, 0.2, 2.1, M.steel, { yaw: a, collide: false, ao: 0 });
    ch.box(x, F - 0.01, z, 2.1, 0.03, 1.9, M.metal, { yaw: a, collide: false, ao: 0, tint: 0x9aa0a6 });
    // mesh sides (thin dark panels)
    for (const u of [-1, 1]) ch.box(x + c * u * 1.05, F + 0.1, z - s * u * 1.05, 0.04, 3.4, 1.9, M.steel, { yaw: a, ao: 0, tint: 0x444444 });
    ch.box(x + s * 1.0, F + 0.1, z + c * 1.0, 2.1, 3.4, 0.04, M.steel, { yaw: a, ao: 0, tint: 0x444444 });
    // gate (front, inner side)
    W.liftGateStation = slidingDoor(W, ch, x - s * 0.98, F, z - c * 0.98, 1.9, 2.6, a, { mat: M.steel, thick: 0.06, speed: 1.0 });
    const [px, pz] = at(12.6, 112 * deg);
    ch.box(px, F, pz, 0.35, 1.15, 0.25, M.panelDark, { yaw: a + Math.PI, collide: true });
    W.liftLampStation = W.light(px, F + 1.5, pz, 0xff5a3c, 2, 4, { chunk: ch });
    W.addInteract({ id: 'liftStation', x: px, y: F + 1.1, z: pz, r: 2.0, label: 'Call the observer lift' });
    pipeRun(ch, M, x + c * 1.2, F, z - s * 1.2, x + c * 1.2, F + 4, z - s * 1.2, 0.08, M.copper);
  }

  // AIRLOCK (180)
  roomLight(180, 12.4);
  {
    // schedule board on radial wall 150 (airlock side)
    // flat against the wall: a point on the wall line, stepped out past the wall's face
    const [wx, wz] = at(13.2, 150 * deg), bx = wx + Math.cos(150 * deg) * 0.2, bz = wz - Math.sin(150 * deg) * 0.2;
    W.scheduleBoard = sign(W, ch, textTexture([
      { text: 'BASIN OPERATIONS', size: 40, color: '#f2a65a' }, ' ',
      '06:00  intake drains', '12:00  intake surges', '15:00  transit span · rated failure',
      '       service gate releases', { text: '-- -- -- -- -- -- -- --', color: '#6b6b6b' }, { text: '-- -- -- -- -- -- -- --', color: '#6b6b6b' }
    ], { w: 768, h: 560, size: 32, color: '#e6e2d6', bg: '#1d2622', align: 'left', lh: 1.4, style: 'board' }), bx, F + 1.65, bz, 1.25, 0.92, 150 * deg + Math.PI / 2, {});
    W.addInteract({ id: 'schedule', x: bx, y: F + 1.6, z: bz, r: 2.2, label: 'Read the operations board' });
    // (the oilskins on the radial wall 210 are hung further down, with the rest of the lived-in things)
    const [lx, lz] = at(13.0, 196 * deg);
    bench(ch, M, lx, F, lz, 196 * deg + Math.PI / 2 + Math.PI, 1.6);
    // amber pressure lamps beside the outer door
    for (const k of [-1, 1]) {
      const [sx, sz] = at(15.5, (180 + k * 6) * deg);
      sconce(W, ch, sx, F + 2.4, sz, 0, { intensity: 3, dist: 6 });
    }
  }

  // GALLERY (240)
  roomLight(232, 12.2, { intensity: 4 });
  {
    // four stencilled frames on the floor, along the line the light falls
    W.frames = [];
    const digits = ['5', '9', '0', '2'];
    const fa = 243 * deg;
    for (let i = 0; i < 4; i++) {
      const r = 14.3 - i * 0.95;
      const [x, z] = at(r, fa);
      const frame = textTexture([''], { w: 256, h: 256, border: '#cfc6ae' });
      const fm = decal(frame, 0.8, 0.8, { opacity: 0.55 });
      fm.rotation.x = -Math.PI / 2; fm.rotation.z = -fa; fm.position.set(x, F + 0.012, z); ch.mesh(fm);
      const dt = textTexture([digits[i]], { w: 256, h: 256, size: 190, color: '#ffe2b8', style: 'plain' });
      const dm = decal(dt, 0.7, 0.7, { opacity: 0, additive: true });
      dm.rotation.x = -Math.PI / 2; dm.rotation.z = -fa + Math.PI; dm.position.set(x, F + 0.016, z);
      ch.mesh(dm); W.frames.push(dm);
    }
    // the beam: a soft shaft from the slit to the floor, and a warm patch of light along the frames
    const soft = (() => {
      const c = document.createElement('canvas'); c.width = 64; c.height = 256; const g = c.getContext('2d');
      const gr = g.createLinearGradient(0, 0, 64, 0); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, 64, 256);
      const v = g.createLinearGradient(0, 0, 0, 256); v.addColorStop(0, 'rgba(0,0,0,0.0)'); v.addColorStop(0.15, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.85)');
      g.globalCompositeOperation = 'destination-out'; g.fillStyle = v; g.fillRect(0, 0, 64, 256);
      const t = new THREE.CanvasTexture(c); return t;
    })();
    const beamMat = new THREE.MeshBasicMaterial({ map: soft, color: 0xffb070, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    const [wx, wz] = at(15.9, fa), [fx, fz] = at(12.9, fa);
    const top = new THREE.Vector3(wx, F + 3.2, wz), bottom = new THREE.Vector3((wx + fx) / 2 - Math.sin(fa) * 0.6, F, (wz + fz) / 2 - Math.cos(fa) * 0.6);
    const shaft = new THREE.Group();
    const len = top.distanceTo(bottom);
    for (let i = 0; i < 2; i++) {
      const pl = new THREE.Mesh(new THREE.PlaneGeometry(0.7, len), beamMat);
      pl.rotation.y = i * Math.PI / 2; shaft.add(pl);
    }
    shaft.position.copy(top).add(bottom).multiplyScalar(0.5);
    shaft.lookAt(bottom); shaft.rotateX(Math.PI / 2);
    ch.mesh(shaft);
    const patchMat = new THREE.MeshBasicMaterial({ map: soft, color: 0xffc080, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, polygonOffset: true, polygonOffsetFactor: -3 });
    const patch = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 4.4), patchMat);
    patch.rotation.x = -Math.PI / 2; patch.rotation.z = -fa;
    const [px, pz] = at(12.95, fa); patch.position.set(px, F + 0.01, pz);
    ch.mesh(patch);
    W.beam = { material: beamMat, patch: patchMat };
    W.sunPatch = W.light(fx, F + 0.6, fz, 0xffb070, 0, 5, { chunk: ch, key: 'sunPatch' });
    // hatch keypad, gallery side of the 270 wall
    const [kx, kz] = at(14.05, 266.5 * deg);
    ch.box(kx, F + 1.15, kz, 0.3, 0.42, 0.06, M.panelDark, { yaw: 270 * deg - Math.PI / 2 + Math.PI, collide: false, ao: 0 });
    ch.box(kx, F + 1.25, kz, 0.2, 0.12, 0.07, M.screen, { yaw: 270 * deg - Math.PI / 2 + Math.PI, collide: false, ao: 0, tint: 0xffb36b });
    W.addInteract({ id: 'hatch', x: kx, y: F + 1.3, z: kz, r: 2.0, label: 'Use the hatch keypad' });
    // furniture: a bench facing the slit, a telescope, dead planters
    const [bx, bz] = at(11.6, 236 * deg);
    bench(ch, M, bx, F, bz, 243 * deg + Math.PI, 1.8);
    const [tx, tz] = at(14.9, 226 * deg);
    ch.cyl(tx, F, tz, 0.3, 0.1, M.steel, { seg: 12 });
    ch.cyl(tx, F + 0.1, tz, 0.05, 1.2, M.steel, { seg: 8, collide: false });
    ch.cyl(tx, F + 0.95, tz, 0.11, 0.9, M.brass, { seg: 12, collide: false, pitch: 1.1, yaw: 226 * deg });   // seated on its post
    for (const a of [212, 257]) { const [px, pz] = at(15.0, a * deg); planter(ch, M, px, F, pz, { dead: true, w: 0.7 }); }
    W.addInteract({ id: 'telescope', x: tx, y: F + 1.5, z: tz, r: 2.0, label: 'Look through the telescope' });
    W.addInteract({ id: 'gallery', x: fx, y: F + 0.5, z: fz, r: 2.6, label: 'Look at the floor frames' });
  }

  // ARCHIVE (300): Iona's room. Tally marks cover the outer wall.
  roomLight(300, 12.8, { intensity: 3.5, flicker: 0.4 });
  {
    const a = 300 * deg;
    const [x, z] = at(14.4, a);
    table(ch, M, x, F, z, 1.8, 0.75, { yaw: a });
    // recording cylinders on the desk (two players)
    for (const k of [-1, 1]) {
      const s = Math.sin(a), c = Math.cos(a);
      const px = x + c * k * 0.45, pz = z - s * k * 0.45;
      ch.box(px, F + 0.78, pz, 0.36, 0.14, 0.26, M.steel, { yaw: a, collide: false, ao: 0 });
      ch.cyl(px, F + 0.86, pz, 0.06, 0.24, M.brass, { seg: 10, collide: false, roll: Math.PI / 2, yaw: a });   // lying on the player
    }
    const s = Math.sin(a), c = Math.cos(a);
    W.addInteract({ id: 'cellA', x: x - c * 0.45, y: F + 1.0, z: z + s * 0.45, r: 1.8, label: 'Play the first cylinder' });
    W.addInteract({ id: 'cellB', x: x + c * 0.45, y: F + 1.0, z: z - s * 0.45, r: 1.8, label: 'Play the second cylinder' });
    // tally wall: a canvas of thousands of marks
    const c2 = document.createElement('canvas'); c2.width = 1024; c2.height = 512;
    const g = c2.getContext('2d');
    g.strokeStyle = 'rgba(30,26,22,0.78)'; g.lineWidth = 2.2;
    let n = 0;
    for (let row = 0; row < 18; row++) for (let col = 0; col < 34; col++) {
      if (Math.random() < 0.08 && row > 12) continue;
      const bx = 14 + col * 29.5, by = 14 + row * 27;
      for (let k = 0; k < 4; k++) { g.beginPath(); g.moveTo(bx + k * 5 + Math.random(), by); g.lineTo(bx + k * 5 + Math.random() * 2, by + 20); g.stroke(); }
      g.beginPath(); g.moveTo(bx - 3, by + 15); g.lineTo(bx + 21, by + 4); g.stroke();
      n += 5;
    }
    writeOn(g, 'don\u2019t trust the count', 620, 468, 34, { color: 'rgba(120,40,24,0.92)', pen: 0.13, slant: 0.12 });
    const tt = new THREE.CanvasTexture(c2); tt.colorSpace = THREE.SRGBColorSpace;
    const tm = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 2.1), new THREE.MeshStandardMaterial({ map: tt, transparent: true, roughness: 0.9, polygonOffset: true, polygonOffsetFactor: -2 }));
    const [wx, wz] = at(15.56, 292 * deg);
    tm.position.set(wx, F + 2.1, wz); tm.rotation.y = 292 * deg + Math.PI; ch.mesh(tm);
    W.addInteract({ id: 'tally', x: wx, y: F + 1.7, z: wz, r: 3.0, label: 'Look at the marks on the wall' });
    // cot and piled notes
    const [cx, cz] = at(12.0, 316 * deg);
    bunk(ch, M, cx, F, cz, 316 * deg - Math.PI / 2, { blanket: M.fabricPale });
    for (let i = 0; i < 9; i++) {
      const [px, pz] = at(11.0 + (i % 3) * 0.3, (288 + i * 2.2) * deg);
      ch.box(px, F, pz, 0.32, 0.02 + (i % 4) * 0.03, 0.24, M.paint, { yaw: i * 0.7, collide: false, ao: 0, tint: 0xe8e0c8 });
    }
    const [shx, shz] = at(14.9, 324 * deg);
    shelf(ch, M, shx, F, shz, 324 * deg + Math.PI, 1.4);
  }

  // ---------------- outside: landing and lamps ----------------
  ch.box(0, F - 0.6, -18.6, 7, 0.6, 5.2, M.steel, {});
  ch.box(0, F - 0.015, -18.6, 6.6, 0.02, 4.8, M.tile, { collide: false, ao: 0, tint: 0x8a8f96 });
  railing(ch, M, -3.4, -16.6, -3.4, -21.1, F);
  railing(ch, M, 3.4, -16.6, 3.4, -21.1, F);
  railing(ch, M, -3.4, -21.1, -2.15, -21.1, F);
  railing(ch, M, 2.15, -21.1, 3.4, -21.1, F);
  // canopy over the door on two posts
  for (const k of [-1, 1]) ch.box(k * 2.6, F, -19.2, 0.18, 3.3, 0.18, M.steel, { ao: 0 });
  ch.box(0, F + 3.3, -18.2, 5.8, 0.18, 3.2, M.metal, { collide: false, ao: 0 });
  ceilingLight(W, ch, 0, F + 3.3, -18.6, Math.PI / 2, { len: 2.4, intensity: 6, dist: 10, color: 0xffcf9e });

  // ---------------- lived in: the small things in each room ----------------
  {
    // a point on a radial wall line, stepped out to its face on one side
    const onWall = (A, r, side, out = 0.18) => { const [x, z] = at(r, A * deg), nx = side * Math.cos(A * deg), nz = -side * Math.sin(A * deg); return [x + nx * out, z + nz * out, Math.atan2(nx, nz)]; };
    const facing = (A) => A * deg + Math.PI;   // things against the outer wall face the middle

    // BERTHS: a rug by your bed, a bedside cabinet with a lamp and a mug, your own notes taped up
    { const [x, z] = at(12.75, 0); rug(W, ch, x, F, z, 1.25, 0.85, 0, ['#5c2a24', '#c08a4a', '#2c3a44', '#d9c9a4']); }
    {
      const [x, z] = at(15.0, -4.6 * deg), yaw = facing(-4.6);
      ch.box(x, F, z, 0.46, 0.56, 0.4, M.woodDark, { yaw, tint: 0x8a6a50 });
      ch.box(x + Math.sin(yaw) * 0.201, F + 0.3, z + Math.cos(yaw) * 0.201, 0.36, 0.015, 0.01, M.brass, { yaw, collide: false, ao: 0 });
      ch.cyl(x - 0.06, F + 0.56, z, 0.07, 0.03, M.brass, { seg: 12, collide: false });
      ch.cyl(x - 0.06, F + 0.59, z, 0.012, 0.24, M.brass, { seg: 6, collide: false });
      ch.cyl(x - 0.06, F + 0.8, z, 0.15, 0.15, M.lampWarm, { seg: 14, rTop: 0.09, open: true, collide: false, tint: 0xd8b890 });
      W.light(x - 0.06, F + 0.82, z, 0xffc890, 1.4, 3.2, { chunk: ch });
      ch.cyl(x + 0.13, F + 0.56, z + 0.06, 0.04, 0.09, M.paint, { seg: 10, collide: false, tint: 0xe8e2d6 });
    }
    { const [x, z] = at(15.57, -3.4 * deg); tapedNote(W, ch, x, F + 1.42, z, facing(-3.4), ['Wake up.', 'Read the', 'journal.'], { tilt: 0.05 }); }
    { const [x, z] = at(15.57, 3.6 * deg); tapedNote(W, ch, x, F + 1.22, z, facing(3.6), ['Keanu:', 'walk, then', 'breakfast'], { tilt: -0.07, paper: '#f2e6c4' }); }
    { const [x, z] = at(15.57, 20.6 * deg); tapedNote(W, ch, x, F + 1.3, z, facing(20.6), ['GOOD BOY', 'ON DUTY'], { tilt: 0.06, size: 46, paper: '#dfeee8' }); }

    // RADIO: a chair at the console, a shelf of spares on the wall, the frequency log taped up
    { const [x, z] = at(13.85, 60 * deg); chair(ch, M, x, F, z, 60 * deg); }
    { const [x, z, yaw] = onWall(90, 14.75, -1, 0.37); shelf(ch, M, x, F, z, yaw, 1.4, { h: 1.9 }); }
    { const [x, z] = at(15.57, 47 * deg); tapedNote(W, ch, x, F + 1.5, z, facing(47), ['LOG', '91.8 static', '91.8 static', '91.8 ???'], { tilt: -0.04, size: 34, h: 0.46 }); }

    // LIFT: freight waiting by the wall
    { const [x, z] = at(14.9, 102 * deg); crate(ch, M, x, F, z, 0.8); crate(ch, M, x + 0.05, F + 0.8, z - 0.04, 0.58); }
    { const [x, z] = at(15.0, 137 * deg); barrel(ch, M, x, F, z, {}); }

    // AIRLOCK: oilskins on hooks for the walk across the bridge, boots underneath
    {
      [[12.1, 0xd8a83a], [12.7, 0x2d3a4e], [13.3, 0xd8a83a]].forEach(([r, col]) => {
        const [x, z, yaw] = onWall(210, r, -1, 0.16);
        coat(ch, M, x, F + 1.85, z, yaw, col);
        for (const k of [-1, 1]) ch.box(x + Math.sin(yaw) * 0.1 + Math.cos(yaw) * k * 0.08, F, z + Math.cos(yaw) * 0.1 - Math.sin(yaw) * k * 0.08, 0.1, 0.3, 0.24, M.rubber, { yaw, collide: false, ao: 0.2 });
      });
      const [x, z, yaw] = onWall(210, 12.7, -1, 0.17);
      ch.box(x, F + 1.84, z, 0.04, 0.05, 1.6, M.woodDark, { yaw: yaw + Math.PI / 2, collide: false, ao: 0 });
    }

    // GALLERY: paintings of the basin on its walls
    { const [x, z, yaw] = onWall(210, 11.9, 1); painting(W, ch, x, F + 1.75, z, yaw, { w: 1.1, h: 0.72, seed: 5, lighthouse: true }); }
    { const [x, z, yaw] = onWall(210, 14.3, 1); painting(W, ch, x, F + 1.75, z, yaw, { w: 0.9, h: 0.65, seed: 9, sky0: '#1e2a4a', sky1: '#6a5a8a', orb: 'rgba(230,236,255,.9)', boat: true }); }
    { const [x, z, yaw] = onWall(270, 14.65, -1); painting(W, ch, x, F + 1.75, z, yaw, { w: 1.2, h: 0.62, seed: 13, sky0: '#e8a06a', sky1: '#f2d6a4', bridge: true }); }
  }

  // regions of the station are all interior; outside landing counts as station too
  W.stationChunk = ch;
}
