// Milky, the explorer: a cameo. A small, plush, white-furred creature with big ears, a short muzzle, teal
// eyes and a thick fluffy tail with a cream tip, standing on digitigrade legs. Goggles pushed up on
// the forehead, a leather satchel, a notebook in both paws, a ball of string unrolled behind them
// back up the stairs. Found at the bottom of the long stairs into the Deep, drawing the tidal lock.
import * as THREE from '../../vendor/three.module.min.js';
import { prim, sdfField, surfZ, sdfMesh, furMat, merged, at } from './people.js';
import { DF } from './deep.js';

const C = { FUR: 0xe9e5de, FURS: 0xd2ccc3, PINK: 0xe8b8b4, CREAM: 0xe9cf9a, CREAMD: 0xdcbb80, NOSE: 0x3a2a2c, PAD: 0xb88f8c, EYE: 0x2f8f96, PUPIL: 0x0d1416, LEATHER: 0x6b4a2e, LEATHERD: 0x523822, PLUM: 0x6a3a6a, BRASS: 0xb88a3e, PAPER: 0xf1e8d2 };

function fur(prims, lo, hi, cell) { const m = new THREE.Mesh(sdfMesh(prims, lo, hi, cell), furMat()); m.castShadow = true; m.receiveShadow = true; return m; }
// fur that's a touch shadowed under the arms and in the fold of the legs, so white doesn't read flat
const shade = (p) => (p.y < 0.5 || (Math.abs(p.x) > 0.11 && p.y > 0.7 && p.y < 0.9)) ? C.FURS : C.FUR;

function body() {
  const { FUR, PAD, NOSE } = C;
  const B = [
    prim('ell', { c: [0, 0.62, -0.01], r: [0.13, 0.095, 0.105], col: FUR, k: 0.06 }),
    prim('ell', { c: [0, 0.74, 0], r: [0.088, 0.08, 0.075], col: FUR, k: 0.06 }),
    prim('ell', { c: [0, 0.86, 0.012], r: [0.128, 0.125, 0.112], col: FUR, k: 0.06 }),        // soft round belly and chest
    prim('cone', { a: [0, 0.95, 0], b: [0, 1.02, 0.012], ra: 0.064, rb: 0.058, col: FUR, k: 0.05 }),
    // a ruff of fur at the chest
    prim('ell', { c: [0, 0.93, 0.07], r: [0.09, 0.06, 0.05], col: FUR, k: 0.04 })
  ];
  // digitigrade legs: thigh forward to the knee, shin back to the hock, then up onto the toes
  for (const k of [-1, 1]) {
    B.push(prim('cone', { a: [k * 0.078, 0.62, 0], b: [k * 0.09, 0.41, 0.07], ra: 0.074, rb: 0.05, col: shade, k: 0.05 }));
    B.push(prim('cone', { a: [k * 0.09, 0.41, 0.07], b: [k * 0.09, 0.17, -0.055], ra: 0.046, rb: 0.034, col: shade, k: 0.04 }));
    B.push(prim('cone', { a: [k * 0.09, 0.17, -0.055], b: [k * 0.09, 0.045, 0.035], ra: 0.033, rb: 0.03, col: shade, k: 0.03 }));
    B.push(prim('ell', { c: [k * 0.09, 0.032, 0.085], r: [0.046, 0.032, 0.072], col: (p) => p.y < 0.012 ? PAD : FUR, k: 0.03 }));
    for (const t of [-1, 0, 1]) B.push(prim('cone', { a: [k * 0.09 + t * 0.022, 0.02, 0.14], b: [k * 0.09 + t * 0.024, 0.008, 0.162], ra: 0.006, rb: 0.002, col: NOSE, k: 0.004 }));
  }
  // arms: both paws up in front, holding the notebook open; little claws
  for (const k of [-1, 1]) {
    const sh = [k * 0.125, 0.93, 0], el = [k * 0.17, 0.77, 0.05], wr = [k * 0.095, 0.84, 0.17], hand = [k * 0.085, 0.85, 0.2];
    B.push(prim('cone', { a: sh, b: el, ra: 0.045, rb: 0.037, col: shade, k: 0.035 }));
    B.push(prim('cone', { a: el, b: wr, ra: 0.039, rb: 0.033, col: FUR, k: 0.03 }));
    B.push(prim('ell', { c: hand, r: [0.036, 0.034, 0.036], col: FUR, k: 0.025 }));
    for (const t of [-1, 0, 1]) B.push(prim('cone', { a: [hand[0] - k * 0.01 + t * 0.012, hand[1] + 0.02, hand[2] + 0.025], b: [hand[0] - k * 0.012 + t * 0.013, hand[1] + 0.03, hand[2] + 0.04], ra: 0.005, rb: 0.0015, col: NOSE, k: 0.003 }));
  }
  return fur(B, [-0.3, -0.02, -0.17], [0.3, 1.07, 0.3], 0.0105);
}

function head() {
  const { FUR, PINK, NOSE, EYE, PUPIL } = C;
  const H = [
    prim('ell', { c: [0, 0, 0], r: [0.15, 0.135, 0.135], col: FUR, k: 0.05 }),                   // a slightly big, round head
    prim('ell', { c: [0, -0.05, 0.098], r: [0.066, 0.048, 0.055], col: FUR, k: 0.05 }),          // short muzzle
    prim('ell', { c: [0, -0.03, 0.15], r: [0.018, 0.013, 0.011], col: NOSE, k: 0.012 })
  ];
  // cheek fluff
  for (const k of [-1, 1]) H.push(prim('cone', { a: [k * 0.1, -0.05, 0.04], b: [k * 0.17, -0.09, 0.0], ra: 0.04, rb: 0.004, col: FUR, k: 0.025 }));
  // big expressive ears, rounded at the tips, pink inside
  for (const k of [-1, 1]) {
    const m = at(k * 0.085, 0.085, -0.015, -0.1, -k * 0.15, -k * 0.42, 1, 1, 0.42);
    H.push(prim('cone', { m, a: [0, 0, 0], b: [0, 0.19, 0], ra: 0.075, rb: 0.022, sc: 0.42, k: 0.04, col: (p) => (p.z > 0.012 && p.y > 0.035 && p.y < 0.17) ? PINK : FUR }));
  }
  // a tuft on top
  H.push(prim('cone', { a: [0, 0.11, 0.03], b: [0.01, 0.17, 0.07], ra: 0.03, rb: 0.003, col: FUR, k: 0.03 }));
  const g = new THREE.Group();
  g.add(fur(H, [-0.33, -0.17, -0.18], [0.33, 0.33, 0.2], 0.0055));
  const f = sdfField(H, 0.02), F = [];
  for (const k of [-1, 1]) {
    const ex = k * 0.058, ey = 0.005, ez = surfZ(f, ex, ey) - 0.008;
    F.push({ g: new THREE.SphereGeometry(1, 16, 12), color: EYE, m: at(ex, ey, ez, 0, k * 0.35, 0, 0.032, 0.036, 0.016) });
    F.push({ g: new THREE.SphereGeometry(1, 12, 10), color: PUPIL, m: at(ex, ey - 0.002, ez + 0.01, 0, k * 0.35, 0, 0.018, 0.022, 0.008) });
    F.push({ g: new THREE.SphereGeometry(0.0065, 8, 6), color: 0xffffff, m: at(ex - k * 0.006, ey + 0.014, ez + 0.017) });
    F.push({ g: new THREE.SphereGeometry(0.003, 6, 4), color: 0xffffff, m: at(ex + k * 0.008, ey - 0.01, ez + 0.016) });
  }
  // a little smile
  { const t = new THREE.TorusGeometry(0.016, 0.0028, 6, 14, Math.PI * 0.8); F.push({ g: t, color: NOSE, m: at(0, -0.062, surfZ(f, 0, -0.062) - 0.004, 0, 0, Math.PI * 1.1) }); }
  // brass goggles pushed up on the forehead, on a plum strap
  for (const k of [-1, 1]) {
    const gx = k * 0.047, gy = 0.085, gz = surfZ(f, gx, gy) - 0.002;
    F.push({ g: new THREE.TorusGeometry(0.026, 0.008, 8, 18), color: C.BRASS, m: at(gx, gy, gz, -0.5, k * 0.25, 0) });
    F.push({ g: new THREE.CircleGeometry(0.022, 16), color: 0x5fb8c0, m: at(gx, gy, gz - 0.002, -0.5, k * 0.25, 0) });
  }
  F.push({ g: new THREE.TorusGeometry(0.148, 0.007, 6, 40), color: C.PLUM, m: at(0, 0.06, -0.01, Math.PI / 2 - 0.5, 0, 0, 1, 1, 0.95) });
  g.add(merged(F, 0.5));
  return g;
}

// the tail: thick and fluffy, curving up behind, cream at the tip
function tail() {
  const { FUR, CREAM, CREAMD } = C;
  const pts = [[0, 0.62, -0.09, 0.05], [0.02, 0.55, -0.24, 0.09], [0.05, 0.6, -0.39, 0.125], [0.07, 0.76, -0.47, 0.14], [0.08, 0.94, -0.44, 0.125], [0.08, 1.07, -0.35, 0.09], [0.07, 1.13, -0.24, 0.045]];
  const col = (p) => {
    const tip = 1.0 + Math.sin(p.x * 70 + p.z * 50) * 0.025;
    return p.y > tip ? (p.y > tip + 0.05 ? CREAM : CREAMD) : (p.y < 0.6 ? C.FURS : FUR);
  };
  const T = [];
  for (let i = 0; i < pts.length - 1; i++) { const [x, y, z, r] = pts[i], [x2, y2, z2, r2] = pts[i + 1]; T.push(prim('cone', { a: [x, y, z], b: [x2, y2, z2], ra: r, rb: r2, col, k: 0.07 })); }
  return fur(T, [-0.16, 0.42, -0.72], [0.3, 1.24, -0.02], 0.012);
}

// the satchel across the body, the neckerchief, the notebook in their paws
function kit() {
  const { LEATHER, LEATHERD, PLUM } = C;
  const P = [
    prim('box', { c: [0.15, 0.62, 0.03], b: [0.035, 0.07, 0.085], rr: 0.02, col: LEATHER, k: 0.01 }),
    prim('box', { c: [0.188, 0.65, 0.03], b: [0.006, 0.04, 0.08], rr: 0.01, col: LEATHERD, k: 0.005 }),
    prim('cone', { a: [-0.1, 0.97, 0.075], b: [0.15, 0.69, 0.115], ra: 0.013, rb: 0.013, col: LEATHERD, k: 0.005 }),
    prim('cone', { a: [-0.1, 0.97, -0.07], b: [0.15, 0.69, -0.05], ra: 0.013, rb: 0.013, col: LEATHERD, k: 0.005 }),
    prim('cone', { a: [-0.1, 0.97, -0.07], b: [-0.1, 0.97, 0.075], ra: 0.014, rb: 0.014, col: LEATHERD, k: 0.005 }),
    prim('torus', { c: [0, 1.0, 0.008], R: 0.066, t: 0.016, rot: [0.1, 0, 0], col: PLUM, k: 0.01 }),
    prim('cone', { a: [0, 0.99, 0.07], b: [0, 0.92, 0.1], ra: 0.03, rb: 0.006, col: PLUM, k: 0.01 })
  ];
  const m = new THREE.Mesh(sdfMesh(P, [-0.16, 0.5, -0.12], [0.24, 1.06, 0.18], 0.008), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 }));
  m.castShadow = true;
  // the notebook: two pages open in a V, a plum cover
  const N = [], tilt = 0.55;
  for (const k of [-1, 1]) {
    N.push({ g: new THREE.BoxGeometry(0.085, 0.004, 0.12), color: C.PAPER, m: at(k * 0.042, 0.885, 0.215, -tilt, 0, k * 0.16) });
    N.push({ g: new THREE.BoxGeometry(0.09, 0.004, 0.125), color: PLUM, m: at(k * 0.043, 0.881, 0.213, -tilt, 0, k * 0.16) });
  }
  // a few pencil lines on the pages
  for (let i = 0; i < 4; i++) N.push({ g: new THREE.BoxGeometry(0.05, 0.001, 0.002), color: 0x6a6470, m: at(0.042, 0.888 + i * 0.012, 0.225 - i * 0.02, -tilt, 0, 0.16) });
  const g = new THREE.Group(); g.add(m); g.add(merged(N, 0.85));
  return g;
}

export function buildExplorer(W) {
  const x = 3.15, z = -184.3, yaw = -2.6;
  const root = new THREE.Group(); root.position.set(x, DF, z); root.rotation.y = yaw;
  const sway = new THREE.Group(); root.add(sway);
  sway.add(body()); sway.add(kit());
  const tl = new THREE.Group(); tl.position.set(0, 0.62, -0.09); const tm = tail(); tm.position.set(0, -0.62, 0.09); tl.add(tm); sway.add(tl);
  const hd = new THREE.Group(); hd.position.set(0, 1.135, 0.025); hd.add(head()); sway.add(hd);
  W.scene.add(root);

  // the ball of string by their feet, and the line of it laid back along the floor to the stairs
  const sm = new THREE.MeshStandardMaterial({ color: 0xb8402e, roughness: 0.9 });
  const ball = new THREE.Mesh(new THREE.SphereGeometry(0.06, 14, 10), sm);
  const bx = x - 0.45, bz = z + 0.15; ball.position.set(bx, DF + 0.06, bz); ball.castShadow = true; W.scene.add(ball);
  const pts = [[bx, bz], [bx - 0.6, bz + 0.5], [bx - 1.0, bz + 1.1], [bx - 1.25, bz + 1.75]];
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, az] = pts[i], [cx, cz] = pts[i + 1], L = Math.hypot(cx - ax, cz - az);
    const s = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, L, 4), sm);
    s.position.set((ax + cx) / 2, DF + 0.005, (az + cz) / 2); s.rotation.set(Math.PI / 2, Math.atan2(cx - ax, cz - az), 0, 'YXZ');
    W.scene.add(s);
  }

  const ch = W.chunk('ante');
  ch.collider({ type: 'cyl', x, z, r: 0.3, y0: DF, y1: DF + 1.35, npc: true });
  W.addInteract({ id: 'npcExplorer', x, y: DF + 1.15, z, r: 2.6, label: 'Talk to Milky', npc: true });

  W.explorer = { root, head: hd };
  const v = new THREE.Vector3();
  let twitchAt = 3, twitch = 0;
  W.onUpdate((dt, t, st, cam) => {
    const d = cam ? Math.hypot(cam.x - x, cam.z - z) : 99;
    if (d > 40) return;
    // breathing, a little weight shift, the tail swaying, an ear twitch now and then
    sway.position.y = Math.sin(t * 1.8) * 0.004;
    sway.rotation.z = Math.sin(t * 0.6) * 0.012;
    tl.rotation.y = Math.sin(t * 0.9) * 0.2; tl.rotation.x = Math.sin(t * 0.7 + 1) * 0.05;
    if (t > twitchAt) { twitch = 1; twitchAt = t + 2.5 + Math.random() * 4; }
    twitch = Math.max(0, twitch - dt * 5);
    // looking down at the notebook, or up at you when you're close
    let want = Math.sin(t * 0.3) * 0.15, up = 0.22 + Math.sin(t * 0.8) * 0.03;
    if (cam && d < 5) {
      v.set(cam.x - x, 0, cam.z - z); const a = Math.atan2(v.x, v.z) - yaw;
      want = Math.max(-1.0, Math.min(1.0, Math.atan2(Math.sin(a), Math.cos(a)))); up = -0.08;
    }
    hd.rotation.y += (want - hd.rotation.y) * Math.min(1, dt * 4);
    hd.rotation.x += (up - hd.rotation.x) * Math.min(1, dt * 3);
    hd.rotation.z = Math.sin(t * 1.3) * 0.03 + Math.sin(twitch * 9) * twitch * 0.06;
  });
}
