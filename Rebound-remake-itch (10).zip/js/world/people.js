// The six residents who stayed. Simple sculpted figures with their own silhouettes; they turn
// to face you when you come near and nod along while they talk.
import * as THREE from '../../vendor/three.module.min.js';
import { F } from './station.js';

const skinTones = [0xd9a882, 0xb98563, 0x8a5a3c, 0xe8c09a, 0xa8714f, 0xc99a74];

function std(color, rough = 0.8, metal = 0) { return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal }); }

// merge several small coloured parts into one mesh (one draw call)
function merged(parts, rough = 0.8) {
  const pos = [], nor = [], col = [];
  const m3 = new THREE.Matrix3(), v = new THREE.Vector3(), c = new THREE.Color();
  for (const { g, color, m } of parts) {
    const geo = g.index ? g.toNonIndexed() : g;
    m3.getNormalMatrix(m); c.set(color);
    const P = geo.attributes.position, N = geo.attributes.normal, C = geo.attributes.color;
    for (let i = 0; i < P.count; i++) {
      v.fromBufferAttribute(P, i).applyMatrix4(m); pos.push(v.x, v.y, v.z);
      v.fromBufferAttribute(N, i).applyMatrix3(m3).normalize(); nor.push(v.x, v.y, v.z);
      if (C) col.push(C.getX(i), C.getY(i), C.getZ(i)); else col.push(c.r, c.g, c.b);
    }
    if (geo !== g) geo.dispose(); g.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  out.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  const mesh = new THREE.Mesh(out, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: rough, side: THREE.DoubleSide }));
  mesh.castShadow = true; mesh.receiveShadow = true;
  return mesh;
}
const at = (x, y, z, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) => new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(sx, sy, sz));

// His fox mask, after the real one: one sculpted face split down the middle, the markings painted
// sharp onto it (his right half glossy black with a grey mesh eye, his left fox-red with a white jaw,
// a white blaze and a black-rimmed eye), a long snout, tall ears full of white fluff, and a big soft
// ruff of fur round the cheeks and chin. The shell comes back as its own textured mesh; the fur,
// ears and trinkets come back as parts built red-side on -x, which the caller mirrors.
let maskTex = null;
function foxMask() {
  const R = 0.142, smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  const shape = (v) => {
    const d = Math.hypot(v.x / 0.066, (v.y + 0.04) / 0.054);
    const k = Math.pow(Math.max(0, 1 - d), 1.3) * smooth(0.0, 0.08, v.z);
    v.z += k * 0.16;                                    // a long snout
    v.x *= 1 - k * 0.32;                                // narrowing to the nose
    v.y += k * (v.y < -0.04 ? 0.016 : -0.008);
    v.x *= 1 + 0.12 * Math.exp(-Math.pow((v.y + 0.045) / 0.04, 2)) * smooth(0.02, 0.1, Math.abs(v.x));   // cheeks
    return k;
  };
  const eye = new THREE.Vector2(0.052, 0.032);
  const g = new THREE.SphereGeometry(R, 56, 40, 0, Math.PI, Math.PI * 0.12, Math.PI * 0.74);
  const P = g.attributes.position, uv = g.attributes.uv, v = new THREE.Vector3(), S = 0.17;
  let nose = new THREE.Vector3(0, 0, -1);
  for (let i = 0; i < P.count; i++) {
    v.fromBufferAttribute(P, i);
    const ex = Math.hypot((Math.abs(v.x) - eye.x) / 1.6, v.y - eye.y);
    if (ex < 0.026 && v.z > 0.08) v.z -= 0.009;          // the eyes sit a little deeper
    shape(v);
    if (v.z > nose.z) nose.copy(v);
    P.setXYZ(i, v.x * 0.97, v.y * 1.05, v.z * 1.03 + 0.004);
    uv.setXY(i, 0.5 + v.x / (2 * S), 0.5 + v.y / (2 * S));   // painted from the front
  }
  g.computeVertexNormals();
  if (!maskTex) maskTex = paintMask((nose.y) / (2 * S) * -1 + 0.5);
  const shell = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: maskTex, roughness: 0.42, metalness: 0.02 }));
  shell.castShadow = true;

  const parts = [];
  const WHT = 0xeee8dc, CRM = 0xd9d0c0, GRY = 0x9a958e, RED = 0xb03c1c, DRK = 0x7a2412, BLK = 0x0e0e11;
  const up = new THREE.Vector3(0, 1, 0), q = new THREE.Quaternion(), d = new THREE.Vector3();
  let s = 11; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  // one tuft of fur: a thin cone from a root, pointing along dir
  const tuft = (x, y, z, dx, dy, dz, len, rad, color) => {
    d.set(dx, dy, dz).normalize(); q.setFromUnitVectors(up, d);
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x + d.x * len / 2, y + d.y * len / 2, z + d.z * len / 2), q, new THREE.Vector3(1, 1, 0.55));
    parts.push({ g: lock(), color, m: m.multiply(new THREE.Matrix4().makeScale(rad * 1.25, len, rad * 1.25)).multiply(new THREE.Matrix4().makeTranslation(0, -0.5, 0)) });
  };
  // a lock of fur: a soft round root, full in the middle, drawn out to a gentle point
  const LOCK = [[0.001, 0], [0.6, 0.04], [0.95, 0.16], [1, 0.32], [0.8, 0.55], [0.45, 0.8], [0.14, 0.96], [0.001, 1]].map(([a, b]) => new THREE.Vector2(a, b));
  const lock = () => new THREE.LatheGeometry(LOCK, 7);
  for (const k of [-1, 1]) {
    const red = k < 0;
    // the ruff: three layers of fur sweeping out and back off the cheeks, longest at the jaw
    for (let layer = 0; layer < 4; layer++) for (let i = 0; i < 12; i++) {
      const t = i / 11, y = 0.08 - t * 0.19, side = 0.128 + Math.sin(t * Math.PI) * 0.02 + layer * 0.006;
      const len = 0.05 + Math.sin(t * Math.PI) * 0.045 + layer * 0.012 + r() * 0.015;
      const col = t < 0.2 ? (red ? RED : BLK) : (r() < 0.18 ? CRM : (r() < 0.1 && !red ? GRY : WHT));
      tuft(k * (side - 0.012), y + (r() - 0.5) * 0.012, 0.02 - layer * 0.02, k * (0.8 + r() * 0.3), -0.35 - t * 0.5 + (r() - 0.5) * 0.3, -0.45 - layer * 0.15, len, 0.027 + r() * 0.01 - layer * 0.003, col);
    }
    // (no fur under the chin: from the front it read as teeth)
    // the brow: short fur standing up between the ears, in each half's own colour
    for (let i = 0; i < 4; i++) tuft(k * (0.012 + i * 0.022), 0.118 - i * 0.008, -0.02 - i * 0.01, k * 0.2, 1, -0.55, 0.04 + r() * 0.015, 0.016, red ? (i === 0 ? WHT : RED) : BLK);
    // ears: tall, pointed, white fluff spilling out of the hollow, black tips
    const H = 0.2, Rr = 0.068;
    const earM = at(k * 0.086, 0.178, -0.015, -0.12, 0, -k * 0.28, 1, 1, 0.5);
    parts.push({ g: new THREE.ConeGeometry(Rr, H, 16), color: red ? RED : BLK, m: earM });
    parts.push({ g: new THREE.ConeGeometry(Rr * 0.68, H * 0.78, 12), color: 0x2a1c18, m: earM.clone().multiply(at(0, -H * 0.11, 0.024, 0, 0, 0, 1, 1, 0.55)) });
    const ht = 0.06;
    parts.push({ g: new THREE.ConeGeometry(Rr * ht / H * 1.06, ht, 16), color: 0x08080a, m: earM.clone().multiply(at(0, H / 2 - ht / 2 + 0.001, 0, 0, 0, 0, 1.04, 1, 1.04)) });
    // the fluff in the ear: white tufts rooted in the hollow, combed up and out
    const e = new THREE.Vector3();
    for (let i = 0; i < 10; i++) {
      e.set((r() - 0.5) * 0.045, -H * 0.42 + i * 0.012, 0.03).applyMatrix4(earM);
      tuft(e.x, e.y, e.z, k * (0.1 + r() * 0.3), 1, 0.35 + r() * 0.2, 0.045 + r() * 0.025 - i * 0.002, 0.014, r() < 0.2 ? CRM : WHT);
    }
    // (the ear stays clean along its outer edge)
  }
  // the fang on the black side, and the beads hanging by its eye
  parts.push({ g: new THREE.ConeGeometry(0.008, 0.032, 8), color: 0xf2ece0, m: at(0.02, -0.088, 0.225, Math.PI) });
  [[0.0, 0xa82020], [-0.021, 0xeae4d8], [-0.042, 0xa82020], [-0.062, 0xeae4d8]].forEach(([dy, col]) => parts.push({ g: new THREE.SphereGeometry(0.0085, 10, 8), color: col, m: at(0.108, dy + 0.005, 0.1) }));
  parts.push({ g: new THREE.CylinderGeometry(0.0015, 0.0015, 0.075, 4), color: 0x2a2a2a, m: at(0.108, -0.03, 0.1) });
  return { shell, parts };
}

// The paint on the mask, drawn crisp at 1024px in the front view the shell is mapped with. As worn:
// his right (canvas left) black, his left (canvas right) red.
function paintMask(noseV) {
  const N = 1024, c = document.createElement('canvas'); c.width = c.height = N;
  const x = c.getContext('2d');
  const S = 0.17, X = (mx) => (0.5 + mx / (2 * S)) * N, Y = (my) => (0.5 - my / (2 * S)) * N;
  let s = 5; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const ny = noseV * N;
  // base: the two halves
  x.fillStyle = '#121216'; x.fillRect(0, 0, N / 2, N);
  const red = x.createRadialGradient(N * 0.56, N * 0.45, 20, N * 0.6, N * 0.5, N * 0.55);
  red.addColorStop(0, '#c4481f'); red.addColorStop(0.7, '#a83618'); red.addColorStop(1, '#7c2410');
  x.fillStyle = red; x.fillRect(N / 2, 0, N / 2, N);
  // white on the red half: the jaw and cheek, sweeping up behind the eye; and the blaze up the forehead
  x.fillStyle = '#efe9de';
  x.beginPath(); x.moveTo(N / 2, ny + 6); x.bezierCurveTo(X(0.03), Y(-0.03), X(0.075), Y(-0.02), X(0.1), Y(-0.005));
  x.bezierCurveTo(X(0.125), Y(0.01), X(0.15), Y(-0.01), X(0.17), Y(-0.03)); x.lineTo(N, N); x.lineTo(N / 2, N); x.closePath(); x.fill();
  x.beginPath(); x.moveTo(N / 2, Y(0.17)); x.lineTo(X(0.04), Y(0.17)); x.bezierCurveTo(X(0.035), Y(0.1), X(0.022), Y(0.06), X(0.008), Y(0.035)); x.lineTo(N / 2, Y(0.03)); x.closePath(); x.fill();
  // fur: thousands of short strokes combed back from the nose, a shade either side of the base
  x.lineCap = 'round';
  for (let i = 0; i < 5200; i++) {
    const px = r() * N, py = r() * N, dx = px - N / 2, dy = py - ny, L = Math.hypot(dx, dy) || 1;
    const len = 7 + r() * 12, ux = dx / L, uy = dy / L * 0.7 - 0.25;
    const right = px > N / 2;
    x.strokeStyle = right ? (r() < 0.5 ? 'rgba(255,230,210,0.13)' : 'rgba(60,10,0,0.16)') : (r() < 0.5 ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.3)');
    x.lineWidth = 1.2 + r() * 1.2;
    x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + ux * len * 0.5 + uy * 2, py + uy * len * 0.5 - ux * 2, px + ux * len, py + uy * len); x.stroke();
  }
  // a fine seam down the middle
  x.strokeStyle = 'rgba(0,0,0,0.55)'; x.lineWidth = 2; x.beginPath(); x.moveTo(N / 2, 0); x.lineTo(N / 2, N); x.stroke();
  // fox eyes: almond, tipped up at the outside corner
  const eyeShape = (cx, cy, w, h, k) => {
    x.beginPath(); x.moveTo(X(cx - k * w), Y(cy - h * 0.3));
    x.bezierCurveTo(X(cx - k * w * 0.4), Y(cy + h), X(cx + k * w * 0.6), Y(cy + h * 1.1), X(cx + k * w * 1.15), Y(cy + h * 0.75));
    x.bezierCurveTo(X(cx + k * w * 0.5), Y(cy - h * 0.75), X(cx - k * w * 0.3), Y(cy - h * 0.9), X(cx - k * w), Y(cy - h * 0.3)); x.closePath();
  };
  // red side: thick black rim, a dark red eye
  x.fillStyle = '#060606'; eyeShape(0.052, 0.03, 0.04, 0.026, 1); x.fill();
  x.fillStyle = '#4e120e'; eyeShape(0.052, 0.031, 0.029, 0.017, 1); x.fill();
  // black side: grey mesh, cross-hatched, a thin pale rim
  x.save(); eyeShape(-0.052, 0.03, 0.036, 0.022, -1); x.clip();
  x.fillStyle = '#4c4f55'; x.fillRect(0, 0, N / 2, N);
  x.strokeStyle = '#1a1b1e'; x.lineWidth = 2;
  for (let t = -N; t < N; t += 7) { x.beginPath(); x.moveTo(t, 0); x.lineTo(t + N, N); x.stroke(); x.beginPath(); x.moveTo(t + N, 0); x.lineTo(t, N); x.stroke(); }
  x.restore();
  x.strokeStyle = '#8b8e94'; x.lineWidth = 3; eyeShape(-0.052, 0.03, 0.036, 0.022, -1); x.stroke();
  // the nose, glossy black with a highlight, and the mouth line under it
  x.fillStyle = '#050506'; x.beginPath(); x.ellipse(N / 2, ny + 4, 40, 28, 0, 0, Math.PI * 2); x.fill();
  x.fillStyle = 'rgba(255,255,255,0.35)'; x.beginPath(); x.ellipse(N / 2 + 10, ny - 8, 12, 6, -0.3, 0, Math.PI * 2); x.fill();
  x.strokeStyle = '#0a0a0a'; x.lineWidth = 5;
  x.beginPath(); x.moveTo(N / 2, ny + 30); x.lineTo(N / 2, ny + 52); x.quadraticCurveTo(N / 2 + 40, ny + 70, X(0.065), ny + 40); x.stroke();
  // a few spots of red on the blaze, like the real one
  x.fillStyle = '#7a1010';
  for (const [mx, my, rr] of [[0.028, 0.1, 9], [0.018, 0.088, 6], [0.034, 0.078, 7], [0.024, 0.07, 4], [0.03, 0.12, 5]]) { x.beginPath(); x.arc(X(mx), Y(my), rr, 0, Math.PI * 2); x.fill(); }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

// Absol's hair: long spiral ringlets, each a tube wound round a path that leaves the scalp and falls
// past the shoulders, plus short coils over the crown. Head-local, built clear of the mask.
function ringlets(hair) {
  const parts = [];
  let s = 7; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const one = (root, out, len, hr, tube, color, turns = 0.034) => {
    const pts = [], N = Math.max(24, Math.round(len / 0.006));
    const down = new THREE.Vector3(0, -1, 0), u = new THREE.Vector3(), w = new THREE.Vector3(), ax = new THREE.Vector3();
    const ph = r() * Math.PI * 2;
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      // the axis bows out from the scalp, then hangs
      ax.copy(root).addScaledVector(out, 0.035 * Math.sin(Math.min(1, t * 3) * Math.PI / 2) + 0.015 * t).addScaledVector(down, len * t);
      u.copy(out).cross(down).normalize(); w.copy(out);
      const th = ph + t * len / turns * Math.PI * 2, rad = hr * Math.min(1, t * 6) * (1 - t * 0.25);
      pts.push(ax.clone().addScaledVector(u, Math.cos(th) * rad).addScaledVector(w, Math.sin(th) * rad));
    }
    parts.push({ g: new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), Math.round(N * 0.8), tube, 4, false), color, m: new THREE.Matrix4() });
  };
  // long ringlets in rings round the back and sides
  for (let row = 0; row < 4; row++) {
    const y = 0.07 - row * 0.045, R = 0.112 + row * 0.006;
    const a0 = 1.25 + row * 0.03, a1 = Math.PI * 2 - a0, n = 9 + row;
    for (let i = 0; i <= n; i++) {
      const a = a0 + (a1 - a0) * i / n + (r() - 0.5) * 0.15;
      const root = new THREE.Vector3(Math.sin(a) * R, y, Math.cos(a) * R * 1.05);
      const out = new THREE.Vector3(Math.sin(a), 0.15, Math.cos(a)).normalize();
      const back = -Math.cos(a);   // longer down the back
      one(root, out, 0.24 + back * 0.12 + r() * 0.08, 0.015 + r() * 0.005, 0.0085 + r() * 0.002, r() < 0.3 ? 0x1c1a1e : hair);
    }
  }
  // short coils over the crown
  for (let i = 0; i < 30; i++) {
    const a = Math.PI * 0.35 + r() * Math.PI * 1.3, t = 0.15 + r() * 0.55;
    const root = new THREE.Vector3(Math.sin(a) * Math.sin(t) * 0.118, Math.cos(t) * 0.125 + 0.02, Math.cos(a) * Math.sin(t) * 0.125 - 0.01);
    const out = root.clone().normalize();
    one(root, out, 0.05 + r() * 0.03, 0.012, 0.009, r() < 0.3 ? 0x1c1a1e : hair, 0.025);
  }
  return parts;
}

function figure(o) {
  const g = new THREE.Group();
  const body = new THREE.Group(); g.add(body);
  // skin is pulled a little towards grey so warm lamps don't turn faces orange
  const coat = o.coat, trousers = o.trousers ?? 0x2b2d33, skin = new THREE.Color(o.skin).lerp(new THREE.Color(0x9a8f88), 0.2).getHex(), shoe = 0x1a1a1c;
  const sleeve = o.sleeves ?? coat, trim = o.sleeves ?? 0x161618;
  const W = o.broad ? 1.09 : 1;   // a broader build across the chest and shoulders
  const SH = 0.004;   // clothes meet at sharp seams
  // ---- the body, one surface: hips, a waist, a ribcage, shoulders, a neck; thighs, knees, calves, shoes
  const B = [
    prim('ell', { c: [0, 0.87, -0.005], r: [o.broad ? 0.152 : 0.16, 0.115, 0.115], col: o.hoodie ? (p) => p.y > 0.03 ? trim : trousers : o.broad ? (p) => p.y > 0.055 ? coat : p.y > 0.04 ? 0x1c1712 : trousers : trousers, k: 0.05, sharp: SH }),
    prim('ell', { c: [0, 1.05, 0.0], r: [o.broad ? 0.16 : 0.148, 0.15, o.broad ? 0.108 : 0.1], col: coat, k: 0.06, sharp: SH }),   // a straighter waist on a broad build
    prim('ell', { c: [0, 1.25, 0.0], r: [0.172 * W, 0.165, 0.115 * (o.broad ? 1.06 : 1)], col: coat, k: 0.06, sharp: SH }),
    prim('ell', { c: [0, 1.37, -0.012], r: [0.185 * W, 0.06, 0.09], col: coat, k: 0.06, sharp: SH }),
    prim('cone', { a: [0, 1.41, -0.01], b: [0, 1.6, 0.005], ra: 0.056, rb: 0.05, col: skin, k: 0.035, sharp: SH })
  ];
  for (const k of [-1, 1]) B.push(prim('ell', { c: [k * 0.19 * W, 1.355, -0.008], r: [0.062 * W, 0.058 * W, 0.062 * W], col: sleeve, k: 0.06, sharp: SH }));   // shoulders
  // ---- legs: each its own smooth piece hung from the hip so they can walk: thigh, knee, shin, calf, shoe
  const legs = [], hipY = 0.86;
  for (const k of [-1, 1]) {
    const L = [
      prim('cone', { a: [0, 0.03, 0], b: [0, 0.5 - hipY, 0.012], ra: 0.08, rb: 0.054, col: trousers, k: 0.05, sharp: SH }),
      prim('ell', { c: [0, 0.5 - hipY, 0.018], r: [0.05, 0.05, 0.05], col: trousers, k: 0.03, sharp: SH }),
      prim('cone', { a: [0, 0.49 - hipY, 0.005], b: [0, 0.1 - hipY, -0.005], ra: 0.05, rb: 0.038, col: o.boots ? (q) => q.y < 0.34 - hipY ? o.boots : trousers : trousers, k: 0.04, sharp: SH }),
      prim('ell', { c: [0, 0.33 - hipY, -0.022], r: [0.048, 0.1, 0.05], col: o.boots ? (q) => q.y < 0.34 - hipY ? o.boots : trousers : trousers, k: 0.04, sharp: SH }),
      prim('ell', { c: [0, 0.055 - hipY, 0.045], r: [0.054, 0.05, 0.125], col: o.boots || shoe, k: 0.02, sharp: SH }),
      prim('box', { c: [0, 0.012 - hipY, 0.045], b: [0.05, 0.01, 0.12], rr: 0.006, col: 0x0c0c0d, k: 0.01, sharp: SH })
    ];
    const pivot = new THREE.Group(); pivot.position.set(k * 0.088, hipY, 0); body.add(pivot);
    pivot.add(sculpt(L, [-0.1, -0.9, -0.16], [0.1, 0.13, 0.2], 0.014));
    legs.push(pivot);
  }
  const fb = sdfField(B, 0.03), front = (y, x = 0) => surfZ(fb, x, y);
  const extra = [];
  if (o.peaCoat) {
  
  }
  if (o.longCoat) extra.push(prim('cone', { m: at(0, 0, 0, 0, 0, 0, 1.1, 1, 0.85), a: [0, 1.02, 0], b: [0, 0.32, 0], ra: 0.15, rb: 0.235, sc: 0.85, col: coat, k: 0.05, sharp: SH }));
  if (o.apron) {
    extra.push(prim('box', { c: [0, 0.8, front(0.86) + 0.006], b: [0.15, 0.2, 0.006], rr: 0.004, rot: [-0.07, 0, 0], col: o.apron, k: 0.012, sharp: SH }));
    extra.push(prim('box', { c: [0, 1.14, front(1.14) + 0.002], b: [0.105, 0.15, 0.006], rr: 0.004, col: o.apron, k: 0.012, sharp: SH }));
  }
  if (o.scarf) {
    extra.push(prim('torus', { c: [0, 1.46, 0.005], R: 0.085, t: 0.04, rot: [0.15, 0, 0], col: o.scarf, k: 0.02, sharp: SH }));
    extra.push(prim('box', { c: [0.05, 1.33, front(1.33, 0.05) + 0.012], b: [0.035, 0.11, 0.012], rr: 0.008, rot: [-0.1, 0, 0.12], col: o.scarf, k: 0.015, sharp: SH }));
  }
  if (o.hoodie) {
    // the hood lying down round the neck and over the shoulders, a pouch pocket
    extra.push(prim('torus', { c: [0, 1.45, -0.015], R: 0.09, t: 0.042, rot: [0.3, 0, 0], col: trim, k: 0.03, sharp: SH }));
    extra.push(prim('ell', { c: [0, 1.45, -0.115], r: [0.12, 0.085, 0.06], rot: [0.35, 0, 0], col: trim, k: 0.04, sharp: SH }));
    extra.push(prim('box', { c: [0, 0.97, front(0.97) + 0.004], b: [0.12, 0.06, 0.01], rr: 0.008, rot: [-0.08, 0, 0], col: trim, k: 0.01, sharp: SH }));
  } else if (!o.scarf) extra.push(prim('torus', { c: [0, 1.45, 0.0], R: 0.08, t: 0.022, rot: [0.12, 0, 0], col: new THREE.Color(coat).multiplyScalar(0.7).getHex(), k: 0.012, sharp: SH }));
  const torso = sculpt(B.concat(extra), [-0.36, 0.2, -0.24], [0.36, 1.64, 0.3], 0.016);
  body.add(torso);
  if (o.hoodie) {
    const D = [];
    for (const k of [-1, 1]) D.push({ g: new THREE.CylinderGeometry(0.004, 0.004, 0.11, 5), color: 0x8e8a84, m: at(k * 0.035, 1.37, front(1.37, k * 0.035) + 0.006, -0.2) });
    body.add(merged(D));
  }
  // ---- arms: shoulder to elbow, a little bend, forearm, a hand with a thumb, one surface each
  const arms = [], bend = -0.2, cb = Math.cos(bend), sb = Math.sin(bend);
  for (const k of [-1, 1]) {
    const pivot = new THREE.Group(); pivot.position.set(k * 0.215 * W, 1.405, 0); body.add(pivot);
    const el = [0, -0.295, 0], wr = [0, -0.295 - 0.235 * cb, -0.235 * sb];
    const A = [
      prim('cone', { a: [0, -0.03, 0], b: el, ra: 0.05, rb: 0.04, col: sleeve, k: 0.03, sharp: SH }),
      prim('ell', { c: [0, -0.13, 0.008], r: [0.05, 0.1, 0.05], col: sleeve, k: 0.03, sharp: SH }),
      prim('cone', { a: el, b: wr, ra: 0.041, rb: 0.031, col: sleeve, k: 0.03, sharp: SH }),
      prim('cone', { a: [wr[0], wr[1] + 0.01, wr[2]], b: [0, wr[1] - 0.02, wr[2] + 0.005], ra: 0.024, rb: 0.024, col: skin, k: 0.015, sharp: SH }),
      prim('ell', { c: [0, wr[1] - 0.058, wr[2] + 0.012], r: [0.022, 0.05, 0.04], rot: [bend, 0, 0], col: skin, k: 0.02, sharp: SH }),
      prim('cone', { a: [-k * 0.012, wr[1] - 0.03, wr[2] + 0.03], b: [-k * 0.02, wr[1] - 0.065, wr[2] + 0.05], ra: 0.011, rb: 0.009, col: skin, k: 0.012, sharp: SH })
    ];
    pivot.add(sculpt(A, [-0.08, -0.7, -0.09], [0.08, 0.1, 0.16], 0.0095));
    pivot.rotation.z = k * 0.14;
    arms.push(pivot);
  }
  // ---- the head: cranium, jaw, cheekbones, brow, nose, ears, chin, lips, a hairline
  const head = new THREE.Group(); head.position.y = 1.64; body.add(head);
  const lip = new THREE.Color(skin).lerp(new THREE.Color(0x8a3a34), 0.35).getHex();
  const brow = o.brow ?? o.hair ?? o.beard ?? 0x2a211b;
  const Hd = [
    prim('ell', { c: [0, 0.025, -0.012], r: [0.096, 0.112, 0.116], col: skin, k: 0.04, sharp: SH }),
    prim('ell', { c: [0, o.masc ? -0.052 : -0.045, 0.03], r: [o.masc ? 0.084 : 0.078, o.masc ? 0.09 : 0.085, 0.085], col: skin, k: 0.05, sharp: SH }),
    prim('cone', { a: [0, -0.12, -0.06], b: [0, -0.06, 0], ra: 0.055, rb: 0.05, col: skin, k: 0.04, sharp: SH })   // the neck rising into it
  ];
  for (const k of [-1, 1]) Hd.push(prim('ell', { c: [k * 0.098, -0.005, -0.008], r: [0.012, 0.03, 0.021], rot: [0, 0, k * 0.1], col: skin, k: 0.014, sharp: SH }));   // ears
  if (!o.mask) {
    Hd.push(prim('ell', { c: [0, 0.046, o.masc ? 0.094 : 0.09], r: [0.072, o.masc ? 0.024 : 0.02, 0.03], col: skin, k: 0.03, sharp: SH }));   // brow ridge
    if (o.masc) for (const k of [-1, 1]) Hd.push(prim('ell', { c: [k * 0.055, -0.085, 0.045], r: [0.032, 0.03, 0.04], col: skin, k: 0.03, sharp: SH }));   // the angle of the jaw
    Hd.push(prim('cone', { a: [0, 0.035, 0.105], b: [0, -0.018, 0.128], ra: 0.011, rb: 0.017, col: skin, k: 0.016, sharp: SH }));   // nose
    Hd.push(prim('ell', { c: [0, -0.022, 0.124], r: [0.019, 0.014, 0.016], col: skin, k: 0.014, sharp: SH }));
    Hd.push(prim('ell', { c: [0, -0.1, 0.074], r: [0.034, 0.028, 0.03], col: skin, k: 0.03, sharp: SH }));   // chin
    Hd.push(prim('ell', { c: [0, -0.058, 0.103], r: [0.025, 0.008, 0.011], col: lip, k: 0.012, sharp: 0.003 }));   // lips
    for (const k of [-1, 1]) Hd.push(prim('ell', { c: [k * 0.05, -0.008, 0.07], r: [0.03, 0.022, 0.03], col: skin, k: 0.03, sharp: SH }));   // cheekbones
  }
  if (o.bun) { Hd.push(prim('ell', { c: [0, 0.075, -0.125], r: [0.055, 0.05, 0.05], col: o.hair, k: 0.03, sharp: 0.003 })); }
  if (o.hair && !o.curls) Hd.push(prim('ell', { c: [0, 0.045, -0.016], r: [0.107, 0.108, 0.125], col: o.hair, k: 0.012, sharp: 0.003 }));
  if (o.curls) Hd.push(prim('ell', { c: [0, 0.03, -0.02], r: [0.102, 0.112, 0.12], col: o.hair, k: 0.012, sharp: 0.003 }));
  if (o.shortBeard) {
    Hd.push(prim('ell', { c: [0, -0.082, 0.055], r: [0.088, 0.06, 0.078], col: o.shortBeard, k: 0.014, sharp: 0.003 }));
    Hd.push(prim('ell', { c: [0, -0.106, 0.085], r: [0.04, 0.03, 0.04], col: o.shortBeard, k: 0.014, sharp: 0.003 }));
    Hd.push(prim('ell', { c: [0, -0.041, 0.112], r: [0.036, 0.012, 0.014], col: o.shortBeard, k: 0.008, sharp: 0.003 }));
  }
  if (o.beard) {
    Hd.push(prim('ell', { c: [0, -0.085, 0.048], r: [0.074, 0.055, 0.068], col: o.beard, k: 0.015, sharp: 0.003 }));
    Hd.push(prim('ell', { c: [0, -0.04, 0.108], r: [0.036, 0.011, 0.013], col: o.beard, k: 0.01, sharp: 0.003 }));
  }
  const hf = sdfField(Hd, 0.02);
  head.add(sculpt(Hd, [-0.16, -0.17, -0.17], [0.16, 0.18, 0.18], 0.0062));
  const H = [], L = [];
  if (!o.mask) {
    // eyes set into the face where its surface is, brows over them
    for (const k of [-1, 1]) {
      const ez = surfZ(hf, k * 0.036, 0.02);
      H.push({ g: new THREE.SphereGeometry(1, 10, 8), color: 0xe9e3da, m: at(k * 0.036, 0.02, ez - 0.004, 0, 0, 0, 0.015, 0.01, 0.008) });
      H.push({ g: new THREE.SphereGeometry(1, 10, 8), color: 0x1e1612, m: at(k * 0.035, 0.02, ez + 0.0015, 0, 0, 0, 0.0075, 0.008, 0.005) });
      // a lid over each eye, closed for a blink now and then (scaled from nothing)
      L.push({ g: new THREE.SphereGeometry(1, 10, 8), color: skin, m: at(k * 0.036, 0.021, ez - 0.002, 0, 0, 0, 0.0172, 0.0122, 0.0098) });
      const bz = surfZ(hf, k * 0.04, 0.05);
      H.push({ g: new THREE.SphereGeometry(1, 8, 6), color: brow, m: at(k * 0.04, 0.05, bz, 0, 0, k * -0.12, 0.022, 0.0055, 0.006) });
    }
  }
  if (o.curls) { const hairMesh = merged(ringlets(o.hair), 0.7); hairMesh.castShadow = false; head.add(hairMesh); }
  if (o.mask === 'fox') {
    const maskStart = H.length, fox = foxMask();
    H.push(...fox.parts);
    // as he wears it: the black half on his right (the shell is painted that way already)
    const mirror = new THREE.Matrix4().makeScale(-1, 1, 1);
    for (let i = maskStart; i < H.length; i++) H[i].m.premultiply(mirror);
    head.add(fox.shell);
  }
  if (o.hat === 'cap') { H.push({ g: new THREE.CylinderGeometry(0.14, 0.145, 0.08, 18), color: o.hatColor, m: at(0, 0.1, 0) }); H.push({ g: new THREE.BoxGeometry(0.2, 0.015, 0.1), color: o.hatColor, m: at(0, 0.07, 0.15) }); }
  if (o.hat === 'beanie') { H.push({ g: new THREE.SphereGeometry(0.143, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), color: o.hatColor, m: at(0, 0.062, -0.018, -0.1, 0, 0, 1, 1.05, 1.03) }); H.push({ g: new THREE.TorusGeometry(0.135, 0.024, 8, 24), color: o.hatColor, m: at(0, 0.074, -0.02, Math.PI / 2 - 0.06) }); }
  if (o.hat === 'straw') { H.push({ g: new THREE.CylinderGeometry(0.11, 0.135, 0.1, 18), color: 0xcaa863, m: at(0, 0.13, -0.01) }); H.push({ g: new THREE.CylinderGeometry(0.3, 0.3, 0.015, 28), color: 0xcaa863, m: at(0, 0.09, -0.01) }); }
  // the sou'wester sits back on his head, brim tipped up at the front so you can see his eyes
  if (o.hat === 'sou') { H.push({ g: new THREE.SphereGeometry(0.148, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), color: o.hatColor, m: at(0, 0.06, -0.022, -0.12) }); H.push({ g: new THREE.CylinderGeometry(0.2, 0.235, 0.02, 28), color: o.hatColor, m: at(0, 0.075, -0.024, -0.2) }); }
  if (H.length) head.add(merged(H, 0.75));
  let lids = null;
  if (L.length) { lids = merged(L, 0.7); lids.castShadow = false; lids.visible = false; head.add(lids); }
  g.scale.setScalar(o.scale ?? 1);
  return { group: g, body, head, arms, torso, legs, lids };
}

function robot() {
  const g = new THREE.Group(); const body = new THREE.Group(); g.add(body);
  const shell = std(0xc9c2b2, 0.45, 0.3), dark = std(0x23272c, 0.5, 0.4);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 0.5, 16), dark); base.position.y = 0.25; body.add(base);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.55, 0.36), shell); torso.position.y = 0.82; body.add(torso);
  const plate = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.14, 0.02), std(0xb5793f, 0.4, 0.8)); plate.position.set(0, 0.88, 0.19); body.add(plate);
  const arms = [];
  for (const k of [-1, 1]) { const p = new THREE.Group(); p.position.set(k * 0.3, 1.0, 0); body.add(p); const a = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.45, 8), dark); a.position.y = -0.22; p.add(a); const h = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), shell); h.position.y = -0.46; p.add(h); arms.push(p); }
  const head = new THREE.Group(); head.position.y = 1.22; body.add(head);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.2, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2), shell); head.add(dome);
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.06, 0.04), new THREE.MeshBasicMaterial({ color: new THREE.Color(0x63f0e2).multiplyScalar(3), toneMapped: false })); visor.position.set(0, 0.07, 0.17); head.add(visor);
  const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.3, 4), dark); ant.position.y = 0.32; head.add(ant);
  const tip = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 4), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff5a3c).multiplyScalar(3), toneMapped: false })); tip.position.y = 0.48; head.add(tip);
  g.traverse(m => { if (m.isMesh) { m.castShadow = true; } });
  return { group: g, body, head, arms, torso, visor };
}

// Smooth sculpted shapes: a signed-distance field made of blended ellipsoids, tapered limbs,
// rounded boxes and rings, meshed with surface nets, each vertex pulled onto the true surface and lit
// by the field's own normal, so the whole thing is one continuous skin. Colours blend between the
// parts that make it (softly for fur, sharply for the seams of clothes).
const _v = new THREE.Vector3();
function prim(kind, o) {
  // 'ell': centre c, radii r, rotation rot. 'cone': a -> b, radii ra -> rb, optional frame m (+ sc for
  // its smallest scale). 'box': centre c, half-size b, rounding rr, rotation rot. 'torus': centre c,
  // ring R and tube t, rotation rot. o.col is a colour or a function of the local point.
  const P = { kind, col: o.col, k: o.k ?? 0.045, sharp: o.sharp };
  const lo = new THREE.Vector3(Infinity, Infinity, Infinity), hi = new THREE.Vector3(-Infinity, -Infinity, -Infinity);
  const grow = (x, y, z, r, m) => { for (let i = 0; i < 8; i++) { _v.set(x + (i & 1 ? r : -r), y + (i & 2 ? r : -r), z + (i & 4 ? r : -r)); if (m) _v.applyMatrix4(m); lo.min(_v); hi.max(_v); } };
  if (kind === 'ell' || kind === 'box' || kind === 'torus') {
    P.inv = at(o.c[0], o.c[1], o.c[2], ...(o.rot || [0, 0, 0])).invert();
    if (kind === 'ell') { P.r = o.r; grow(o.c[0], o.c[1], o.c[2], Math.max(...o.r)); }
    if (kind === 'box') { P.b = o.b; P.rr = o.rr ?? 0.005; grow(o.c[0], o.c[1], o.c[2], Math.hypot(...o.b) + P.rr); }
    if (kind === 'torus') { P.R = o.R; P.t = o.t; grow(o.c[0], o.c[1], o.c[2], o.R + o.t); }
  } else {
    const m = o.m ? o.m.clone() : new THREE.Matrix4();
    P.inv = m.clone().invert(); P.sc = o.sc ?? 1;
    P.a = new THREE.Vector3(...o.a); P.b = new THREE.Vector3(...o.b); P.ra = o.ra; P.rb = o.rb;
    P.ab = P.b.clone().sub(P.a); P.l2 = Math.max(1e-9, P.ab.lengthSq());
    grow(o.a[0], o.a[1], o.a[2], Math.max(o.ra, o.rb), m); grow(o.b[0], o.b[1], o.b[2], Math.max(o.ra, o.rb), m);
  }
  P.lo = lo; P.hi = hi;
  return P;
}
function primD(P, x, y, z, out) {
  _v.set(x, y, z).applyMatrix4(P.inv);
  if (out) out.copy(_v);
  if (P.kind === 'ell') {
    const [a, b, c] = P.r, k0 = Math.hypot(_v.x / a, _v.y / b, _v.z / c), k1 = Math.hypot(_v.x / (a * a), _v.y / (b * b), _v.z / (c * c));
    return k1 < 1e-9 ? -Math.min(a, b, c) : k0 * (k0 - 1) / k1;
  }
  if (P.kind === 'box') {
    const qx = Math.abs(_v.x) - P.b[0], qy = Math.abs(_v.y) - P.b[1], qz = Math.abs(_v.z) - P.b[2];
    return Math.hypot(Math.max(qx, 0), Math.max(qy, 0), Math.max(qz, 0)) + Math.min(Math.max(qx, qy, qz), 0) - P.rr;
  }
  if (P.kind === 'torus') return Math.hypot(Math.hypot(_v.x, _v.z) - P.R, _v.y) - P.t;
  const px = _v.x - P.a.x, py = _v.y - P.a.y, pz = _v.z - P.a.z;
  const t = Math.max(0, Math.min(1, (px * P.ab.x + py * P.ab.y + pz * P.ab.z) / P.l2));
  return (Math.hypot(px - P.ab.x * t, py - P.ab.y * t, pz - P.ab.z * t) - (P.ra + (P.rb - P.ra) * t)) * P.sc;
}
const smin = (a, b, k) => { if (k <= 0) return Math.min(a, b); const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.min(a, b) - h * h * k * 0.25; };
// the field of a set of parts; parts far from the point are skipped (they can't change it)
function sdfField(prims, margin) {
  return (x, y, z) => {
    let d = 1e9;
    for (const P of prims) {
      const m = P.k + margin;
      if (x < P.lo.x - m || x > P.hi.x + m || y < P.lo.y - m || y > P.hi.y + m || z < P.lo.z - m || z > P.hi.z + m) continue;
      d = smin(d, primD(P, x, y, z), P.k);
    }
    return d;
  };
}
// where a ray from in front (along -z at x, y) first meets the surface: for placing eyes, pockets
function surfZ(f, x, y, z0 = 0.5) { let z = z0; for (let i = 0; i < 200 && z > -0.3; i++) { const d = f(x, y, z); if (d < 0.0005) return z; z -= Math.min(0.01, Math.max(0.0008, d * 0.8)); } return 0; }
function sdfMesh(prims, lo, hi, cell, soft = 0.012) {
  const f = sdfField(prims, cell * 3);
  const nx = Math.ceil((hi[0] - lo[0]) / cell) + 1, ny = Math.ceil((hi[1] - lo[1]) / cell) + 1, nz = Math.ceil((hi[2] - lo[2]) / cell) + 1;
  const F = new Float32Array(nx * ny * nz), id = (i, j, k) => i + nx * (j + ny * k);
  for (let k = 0; k < nz; k++) for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) F[id(i, j, k)] = f(lo[0] + i * cell, lo[1] + j * cell, lo[2] + k * cell);
  // one vertex per cell that the surface passes through, at the mean of its edge crossings
  const V = new Int32Array(nx * ny * nz).fill(-1), pos = [];
  const E = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
  const cv = new Float32Array(8);
  for (let k = 0; k < nz - 1; k++) for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
    let neg = 0;
    for (let c = 0; c < 8; c++) { cv[c] = F[id(i + (c & 1), j + ((c >> 1) & 1), k + (c >> 2))]; if (cv[c] < 0) neg++; }
    if (neg === 0 || neg === 8) continue;
    let sx = 0, sy = 0, sz = 0, n = 0;
    for (const [a, b] of E) {
      if ((cv[a] < 0) === (cv[b] < 0)) continue;
      const t = cv[a] / (cv[a] - cv[b]);
      sx += (a & 1) + ((b & 1) - (a & 1)) * t; sy += ((a >> 1) & 1) + (((b >> 1) & 1) - ((a >> 1) & 1)) * t; sz += (a >> 2) + ((b >> 2) - (a >> 2)) * t; n++;
    }
    V[id(i, j, k)] = pos.length / 3;
    pos.push(lo[0] + (i + sx / n) * cell, lo[1] + (j + sy / n) * cell, lo[2] + (k + sz / n) * cell);
  }
  // pull each vertex onto the surface, and take its normal from the field
  const nrm = new Float32Array(pos.length), e = cell * 0.5;
  for (let q = 0; q < pos.length; q += 3) {
    for (let it = 0; it < 2; it++) {
      const x = pos[q], y = pos[q + 1], z = pos[q + 2], d = f(x, y, z);
      let gx = f(x + e, y, z) - f(x - e, y, z), gy = f(x, y + e, z) - f(x, y - e, z), gz = f(x, y, z + e) - f(x, y, z - e);
      const L = Math.hypot(gx, gy, gz) || 1; gx /= L; gy /= L; gz /= L;
      const step = Math.max(-cell, Math.min(cell, d));
      pos[q] -= gx * step; pos[q + 1] -= gy * step; pos[q + 2] -= gz * step;
      nrm[q] = gx; nrm[q + 1] = gy; nrm[q + 2] = gz;
    }
  }
  // a quad across every grid edge the surface crosses
  const idx = [];
  const quad = (a, b, c, d) => { if (a < 0 || b < 0 || c < 0 || d < 0) return; idx.push(a, b, c, a, c, d); };
  for (let k = 1; k < nz - 1; k++) for (let j = 1; j < ny - 1; j++) for (let i = 1; i < nx - 1; i++) {
    const s0 = F[id(i, j, k)] < 0;
    if (s0 !== (F[id(i + 1, j, k)] < 0)) quad(V[id(i, j - 1, k - 1)], V[id(i, j, k - 1)], V[id(i, j, k)], V[id(i, j - 1, k)]);
    if (s0 !== (F[id(i, j + 1, k)] < 0)) quad(V[id(i - 1, j, k - 1)], V[id(i - 1, j, k)], V[id(i, j, k)], V[id(i, j, k - 1)]);
    if (s0 !== (F[id(i, j, k + 1)] < 0)) quad(V[id(i - 1, j - 1, k)], V[id(i, j - 1, k)], V[id(i, j, k)], V[id(i - 1, j, k)]);
  }
  // colour: a blend of whichever parts lie nearest (a part may ask for a sharper edge)
  const col = new Float32Array(pos.length), c = new THREE.Color(), lp = new THREE.Vector3(), ds = new Float32Array(prims.length);
  for (let q = 0; q < pos.length; q += 3) {
    let r = 0, g = 0, b = 0, w = 0, dm = Infinity;
    for (let i = 0; i < prims.length; i++) { ds[i] = primD(prims[i], pos[q], pos[q + 1], pos[q + 2]); dm = Math.min(dm, ds[i]); }
    for (let i = 0; i < prims.length; i++) {
      const P = prims[i], wi = Math.exp(-(ds[i] - dm) / (P.sharp ?? soft)); if (wi < 0.01) continue;
      primD(P, pos[q], pos[q + 1], pos[q + 2], lp);
      c.set(typeof P.col === 'function' ? P.col(lp) : P.col);
      r += c.r * wi; g += c.g * wi; b += c.b * wi; w += wi;
    }
    col[q] = r / w; col[q + 1] = g / w; col[q + 2] = b / w;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  // wind every face to look outward along the field normal
  const I = new Uint32Array(idx), A = new THREE.Vector3(), Bv = new THREE.Vector3(), C = new THREE.Vector3();
  for (let t = 0; t < I.length; t += 3) {
    A.fromArray(pos, I[t] * 3); Bv.fromArray(pos, I[t + 1] * 3); C.fromArray(pos, I[t + 2] * 3);
    const fn = Bv.sub(A).cross(C.sub(A));
    const sx = nrm[I[t] * 3] + nrm[I[t + 1] * 3] + nrm[I[t + 2] * 3], sy = nrm[I[t] * 3 + 1] + nrm[I[t + 1] * 3 + 1] + nrm[I[t + 2] * 3 + 1], sz = nrm[I[t] * 3 + 2] + nrm[I[t + 1] * 3 + 2] + nrm[I[t + 2] * 3 + 2];
    if (fn.x * sx + fn.y * sy + fn.z * sz < 0) { const s = I[t + 1]; I[t + 1] = I[t + 2]; I[t + 2] = s; }
  }
  geo.setIndex(new THREE.BufferAttribute(I, 1));
  geo.computeBoundingSphere();
  return geo;
}
const furMat = () => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.88 });
const skinMat = () => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.78 });
const sculpt = (prims, lo, hi, cell, soft) => { const m = new THREE.Mesh(sdfMesh(prims, lo, hi, cell, soft), skinMat()); m.castShadow = true; m.receiveShadow = true; return m; };

// Keanu: a black German Shepherd with tan legs and tan brows. He has two poses, each sculpted as
// smooth surfaces: lying on the bed like a sphinx (front legs out, back legs tucked) and standing,
// with legs of their own so he can trot after you. +z is forward, y = 0 is what he lies or stands on.
const DOG = { BLK: 0x151316, SBL: 0x221e20, TAN: 0x7e5a3c, NOSE: 0x070707 };
const dogLeg = (y0, y1) => (p) => { const t = Math.max(0, Math.min(1, (p.y - y0) / (y1 - y0))); return new THREE.Color(DOG.TAN).lerp(new THREE.Color(DOG.BLK), t).getHex(); };
const furMesh = (prims, lo, hi, cell) => { const m = new THREE.Mesh(sdfMesh(prims, lo, hi, cell), furMat()); m.castShadow = true; m.receiveShadow = true; return m; };
// the head: broad skull, a long tapering muzzle, a black nose, tall ears with dark insides
function dogHead() {
  const { BLK, SBL, TAN, NOSE } = DOG;
  const head = new THREE.Group();
  const H = [
    prim('ell', { c: [0, 0.005, -0.005], r: [0.078, 0.074, 0.092], col: BLK, k: 0.03 }),
    prim('ell', { c: [0, 0.028, 0.05], r: [0.054, 0.04, 0.05], col: BLK, k: 0.03 }),
    prim('cone', { a: [0, -0.018, 0.05], b: [0, -0.021, 0.18], ra: 0.044, rb: 0.024, col: BLK, k: 0.035 }),
    prim('cone', { a: [0, -0.046, 0.04], b: [0, -0.043, 0.155], ra: 0.032, rb: 0.017, col: SBL, k: 0.02 }),
    prim('ell', { c: [0, -0.012, 0.197], r: [0.021, 0.016, 0.014], col: NOSE, k: 0.012 }),
    prim('ell', { c: [0, -0.07, -0.02], r: [0.06, 0.05, 0.06], col: BLK, k: 0.04 })     // where the neck meets the head
  ];
  for (const k of [-1, 1]) {
    const m = at(k * 0.048, 0.05, -0.025, -0.08, 0, -k * 0.2, 1, 1, 0.42);
    H.push(prim('cone', { m, a: [0, 0, 0], b: [0, 0.17, 0], ra: 0.05, rb: 0.003, sc: 0.42, k: 0.025,
      col: (p) => (p.z > 0.004 && Math.abs(p.x) < 0.75 * (0.05 - p.y * 0.27) && p.y > 0.012) ? 0x4a2e2a : BLK }));
  }
  head.add(furMesh(H, [-0.14, -0.13, -0.13], [0.14, 0.24, 0.23], 0.0058));
  const F = [];
  for (const k of [-1, 1]) {
    F.push({ g: new THREE.SphereGeometry(1, 12, 8), color: 0x3a2210, m: at(k * 0.041, 0.022, 0.08, 0, 0, 0, 0.015, 0.014, 0.011) });
    F.push({ g: new THREE.SphereGeometry(0.0035, 6, 4), color: 0xeeeeee, m: at(k * 0.038, 0.027, 0.09) });
    F.push({ g: new THREE.SphereGeometry(1, 10, 6), color: TAN, m: at(k * 0.039, 0.043, 0.074, 0, 0, 0, 0.013, 0.006, 0.008) });
  }
  head.add(merged(F, 0.5));
  return head;
}
// the tail: long and bushy; 'lie' curls it round his hip along the bed, 'stand' lets it hang
function dogTail(pose) {
  const { BLK, SBL } = DOG;
  const tail = new THREE.Group();
  const T = []; let px = 0, py = 0, pz = 0;
  for (let i = 0; i < 9; i++) {
    let nx, ny, nz;
    if (pose === 'lie') { const a = i * 0.17; nx = px + Math.sin(a) * 0.06; ny = Math.max(-0.15, py - 0.026 - i * 0.002); nz = pz - Math.cos(a) * 0.06; }
    else { const a = 0.5 + i * 0.09; nx = px; ny = py - Math.sin(a) * 0.055; nz = pz - Math.cos(a) * 0.055; }
    const r0 = 0.032 + Math.sin(Math.min(i, 8) / 8 * Math.PI) * 0.024, r1 = 0.032 + Math.sin(Math.min(i + 1, 8) / 8 * Math.PI) * 0.024;
    T.push(prim('cone', { a: [px, py, pz], b: [nx, ny, nz], ra: r0, rb: i === 8 ? 0.012 : r1, col: i < 2 ? BLK : SBL, k: 0.03 }));
    px = nx; py = ny; pz = nz;
  }
  tail.add(furMesh(T, pose === 'lie' ? [-0.1, -0.22, -0.62] : [-0.1, -0.5, -0.32], pose === 'lie' ? [0.42, 0.08, 0.06] : [0.1, 0.08, 0.06], 0.009));
  return tail;
}
function dogLying() {
  const { BLK, SBL, TAN } = DOG;
  const g = new THREE.Group();
  const B = [
    prim('ell', { c: [0, 0.19, 0.11], r: [0.128, 0.185, 0.21], rot: [-0.1, 0, 0], col: BLK, k: 0.07 }),
    prim('ell', { c: [0, 0.155, -0.17], r: [0.122, 0.145, 0.22], col: BLK, k: 0.08 }),
    prim('ell', { c: [0, 0.07, -0.02], r: [0.11, 0.07, 0.3], col: SBL, k: 0.06 }),
    prim('cone', { a: [0, 0.24, 0.2], b: [0, 0.43, 0.34], ra: 0.088, rb: 0.062, col: BLK, k: 0.06 }),
    prim('cone', { a: [0, 0.18, -0.36], b: [0, 0.19, -0.43], ra: 0.05, rb: 0.04, col: BLK, k: 0.05 })
  ];
  for (const k of [-1, 1]) {
    B.push(prim('cone', { a: [k * 0.088, 0.2, 0.18], b: [k * 0.086, 0.045, 0.3], ra: 0.056, rb: 0.038, col: BLK, k: 0.05 }));
    B.push(prim('cone', { a: [k * 0.086, 0.04, 0.3], b: [k * 0.085, 0.032, 0.53], ra: 0.037, rb: 0.031, col: dogLeg(0.03, 0.07), k: 0.03 }));
    B.push(prim('ell', { c: [k * 0.085, 0.028, 0.575], r: [0.04, 0.027, 0.055], col: TAN, k: 0.025 }));
    B.push(prim('ell', { c: [k * 0.112, 0.14, -0.26], r: [0.065, 0.12, 0.145], rot: [0, 0, k * 0.2], col: BLK, k: 0.06 }));
    B.push(prim('cone', { a: [k * 0.14, 0.045, -0.34], b: [k * 0.16, 0.032, -0.15], ra: 0.036, rb: 0.03, col: dogLeg(0.03, 0.08), k: 0.035 }));
    B.push(prim('ell', { c: [k * 0.163, 0.028, -0.11], r: [0.038, 0.026, 0.05], col: TAN, k: 0.025 }));
  }
  const body = furMesh(B, [-0.26, -0.03, -0.5], [0.26, 0.5, 0.68], 0.011); g.add(body);
  const head = dogHead(); head.position.set(0, 0.44, 0.36); g.add(head);
  const tail = dogTail('lie'); tail.position.set(0, 0.19, -0.4); g.add(tail);
  return { group: g, body, head, tail };
}
function dogStanding() {
  const { BLK, SBL, TAN } = DOG;
  const g = new THREE.Group();
  const B = [
    prim('ell', { c: [0, 0.5, 0.15], r: [0.118, 0.165, 0.2], rot: [-0.12, 0, 0], col: BLK, k: 0.07 }),
    prim('ell', { c: [0, 0.48, -0.19], r: [0.112, 0.13, 0.2], col: BLK, k: 0.08 }),
    prim('ell', { c: [0, 0.43, -0.03], r: [0.095, 0.09, 0.24], col: SBL, k: 0.06 }),
    prim('cone', { a: [0, 0.55, 0.22], b: [0, 0.71, 0.36], ra: 0.085, rb: 0.062, col: BLK, k: 0.06 }),
    prim('cone', { a: [0, 0.52, -0.35], b: [0, 0.5, -0.42], ra: 0.05, rb: 0.04, col: BLK, k: 0.05 })
  ];
  const body = furMesh(B, [-0.2, 0.22, -0.48], [0.2, 0.8, 0.46], 0.011); g.add(body);
  // legs: each its own smooth piece hung from the hip or shoulder, so they can swing
  const legs = [];
  const leg = (x, z, front) => {
    const pivot = new THREE.Group(); pivot.position.set(x, 0.47, z); g.add(pivot);
    const L = front ? [
      prim('cone', { a: [0, 0.04, 0], b: [0, -0.2, 0.01], ra: 0.052, rb: 0.034, col: dogLeg(-0.26, -0.12), k: 0.03 }),
      prim('cone', { a: [0, -0.2, 0.01], b: [0, -0.44, 0], ra: 0.031, rb: 0.026, col: TAN, k: 0.02 }),
      prim('ell', { c: [0, -0.452, 0.028], r: [0.032, 0.018, 0.046], col: TAN, k: 0.02 })
    ] : [
      prim('ell', { c: [0, -0.07, 0.02], r: [0.058, 0.13, 0.095], col: BLK, k: 0.04 }),
      prim('cone', { a: [0, -0.15, -0.02], b: [0, -0.31, -0.1], ra: 0.038, rb: 0.03, col: dogLeg(-0.3, -0.18), k: 0.03 }),
      prim('cone', { a: [0, -0.31, -0.1], b: [0, -0.44, -0.07], ra: 0.028, rb: 0.025, col: TAN, k: 0.02 }),
      prim('ell', { c: [0, -0.452, -0.045], r: [0.031, 0.018, 0.045], col: TAN, k: 0.02 })
    ];
    pivot.add(furMesh(L, [-0.08, -0.49, -0.16], [0.08, 0.1, 0.1], 0.009));
    legs.push(pivot);
  };
  leg(-0.07, 0.17, true); leg(0.07, 0.17, true); leg(-0.08, -0.25, false); leg(0.08, -0.25, false);
  const head = dogHead(); head.position.set(0, 0.72, 0.4); g.add(head);
  const tail = dogTail('stand'); tail.position.set(0, 0.51, -0.42); g.add(tail);
  return { group: g, body, head, tail, legs };
}
function dog() {
  const root = new THREE.Group();
  const lie = dogLying(), stand = dogStanding();
  root.add(lie.group); root.add(stand.group); stand.group.visible = false;
  return { group: root, lie, stand, head: lie.head, tail: lie.tail, body: lie.body, torso: lie.body };
}

// Keanu's behaviour: on the bed until you give him some attention, then down and trotting after you
// round the station, back to his bed if you leave it, and every new cycle he's on the bed again.
function updateKeanu(W, p, dt, time, st, cam) {
  const oc = W.named.station, oy = oc ? oc.offset.y : 0, floor = F + oy;
  if (p.loop !== st.loop && p.ball) { const b = p.ball; b.state = 'floor'; b.x = b.hx; b.z = b.hz; b.mesh.visible = true; b.mesh.position.set(b.hx, F + 0.034, b.hz); }
  if (p.loop !== st.loop) { p.loop = st.loop; p.mode = 'bed'; p.petT = 0; p.howled = false; p.hop = 0; p.petted = false; p.called = false; p.wentHome = false; p.dogs.lie.group.rotation.z = 0; p.dogs.lie.group.position.set(0, 0, 0); }
  const D = p.dogs, lie = D.lie, stand = D.stand;
  const dx = cam.x - p.wx, dz = cam.z - p.wz, d = Math.hypot(dx, dz);
  const inStation = Math.hypot(cam.x, cam.z) < 22 && Math.abs(cam.y - (floor + 1.6)) < 2.5;
  // the end of the world: he lifts his head and howls, once
  const collapse = st.elapsed > 1280 && !st.ended;
  if (collapse && !p.howled) { p.howled = true; p.howlT = 3.2; if (W.sound && d < 30) W.sound.howl(); }
  p.howlT = Math.max(0, (p.howlT || 0) - dt);
  // you're back: he was waiting for you
  if (p.mode === 'bed' && p.wentHome && p.called && inStation && d < 4.5 && !collapse) {
    p.wentHome = false; p.mode = 'hop'; p.hop = 0;
    if (W.sound) { W.sound.woof(0.0, 1.2); W.sound.woof(0.25, 1.28); W.sound.whine(0.6); }
  }
  if (p.mode === 'bed' || p.mode === 'pet') {
    lie.group.visible = true; stand.group.visible = false;
    D.head = lie.head; D.tail = lie.tail;
    D.group.position.set(p.bx, p.by + oy, p.bz); D.group.rotation.y = p.byaw;
    p.wx = p.bx; p.wz = p.bz;
    // a belly rub: he flops onto his side, paws up, tail going, then rolls back
    if (p.mode === 'pet') {
      p.petT += dt;
      const roll = p.petT < 0.35 ? p.petT / 0.35 : p.petT < 2.4 ? 1 : Math.max(0, 1 - (p.petT - 2.4) / 0.35);
      lie.group.rotation.z = -1.25 * (roll * roll * (3 - 2 * roll)); lie.group.position.y = 0.12 * Math.sin(roll * Math.PI / 2);
      lie.group.position.x = -0.05 * roll;
      if (p.petT > 2.8) { lie.group.rotation.z = 0; lie.group.position.set(0, 0, 0); p.mode = 'hop'; p.hop = 0; }
    }
  }
  if (p.mode === 'hop') {
    // down off the bed to the floor beside it
    lie.group.visible = false; stand.group.visible = true; D.head = stand.head; D.tail = stand.tail;
    p.hop += dt / 0.6; const t = Math.min(1, p.hop);
    const tx = p.bx - Math.sin(p.byaw) * 0.0 + Math.cos(p.byaw) * 0.8, tz = p.bz + Math.sin(p.byaw) * -0.8;
    p.wx = p.bx + (tx - p.bx) * t; p.wz = p.bz + (tz - p.bz) * t;
    D.group.position.set(p.wx, floor + (0.61 * (1 - t)) + Math.sin(t * Math.PI) * 0.3, p.wz);
    if (t >= 1) { p.mode = 'follow'; p.yaw = p.byaw; }
  }
  if (p.mode === 'follow' || p.mode === 'home') {
    lie.group.visible = false; stand.group.visible = true; D.head = stand.head; D.tail = stand.tail;
    // where to go: a step behind you, or back to the bed
    let gx, gz, keep, fetch = null;
    if (p.mode === 'follow') {
      if (!inStation) p.mode = 'home';
      gx = cam.x - Math.sin(cam.yaw ?? 0) * 0; gz = cam.z; keep = 1.3;
      const b = p.ball;
      if (b && (b.state === 'flying' || b.state === 'landed')) { fetch = 'go'; gx = b.state === 'landed' ? b.x : b.tx; gz = b.state === 'landed' ? b.z : b.tz; keep = 0.32; }
      else if (b && b.state === 'mouth') { fetch = 'back'; keep = 1.05; }
    }
    if (p.mode === 'home') {
      p.wentHome = true;
      if (inStation && d < 6 && p.mode === 'home' && p.called) { p.mode = 'follow'; p.wentHome = false; if (W.sound) { W.sound.woof(0.05, 1.2); W.sound.woof(0.3, 1.25); } }
      gx = p.bx + Math.cos(p.byaw) * 0.8; gz = p.bz - Math.sin(p.byaw) * 0.8; keep = 0.15;
      if (d > 30) { p.mode = 'bed'; }
    }
    const tx = gx - p.wx, tz = gz - p.wz, td = Math.hypot(tx, tz);
    let speed = 0;
    if (fetch) p.fetchT = (p.fetchT || 0) + dt;
    if (fetch === 'go' && p.ball.state === 'landed' && (td <= keep + 0.1 || p.fetchT > 7)) {
      // got it (or, stuck behind something for too long, he found his own way round)
      if (td > keep + 0.1) { p.wx = gx - Math.sin(p.yaw) * 0.3; p.wz = gz - Math.cos(p.yaw) * 0.3; }
      p.ball.state = 'mouth'; p.fetchT = 0; if (W.sound) W.sound.woof(0.05, 1.3);
    } else if (fetch === 'back' && (td <= keep + 0.12 || p.fetchT > 9)) {
      p.ball.state = 'held'; p.ball.mesh.visible = false; p.fetchT = 0;
      if (W.sound) { W.sound.woof(0.02, 1.15); W.sound.woof(0.3, 1.2); }
      if (W.fetched) W.fetched();
    }
    if (td > keep) {
      speed = Math.min(fetch === 'go' ? 4.4 : td > 4 ? 3.6 : 2.2, (td - keep) * (fetch ? 4 : 2.5));
      const want = Math.atan2(tx, tz);
      let diff = ((want - p.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      p.yaw += diff * Math.min(1, dt * 6);
      const nx = p.wx + Math.sin(p.yaw) * speed * dt, nz = p.wz + Math.cos(p.yaw) * speed * dt;
      if (!dogBlocked(W, nx, nz, floor)) { p.wx = nx; p.wz = nz; }
      else if (!dogBlocked(W, nx, p.wz, floor)) p.wx = nx;
      else if (!dogBlocked(W, p.wx, nz, floor)) p.wz = nz;
      else { speed = 0; p.stuck = (p.stuck || 0) + dt; }
    } else if (p.mode === 'home') { p.mode = 'bed'; }
    if (speed > 0) p.stuck = 0;
    // stuck for long behind something while you're out of sight: he finds his own way
    if ((p.stuck || 0) > 4 && d > 8) { p.wx = cam.x - Math.sin(p.yaw) * 1.2; p.wz = cam.z - Math.cos(p.yaw) * 1.2; if (dogBlocked(W, p.wx, p.wz, floor)) { p.mode = 'bed'; } p.stuck = 0; }
    // a trot: diagonal pairs of legs swing together, a little bounce
    p.gait = (p.gait || 0) + dt * (2 + speed * 3.2);
    const sw = Math.min(1, speed / 1.5) * 0.55;
    stand.legs[0].rotation.x = Math.sin(p.gait) * sw; stand.legs[3].rotation.x = Math.sin(p.gait) * sw;
    stand.legs[1].rotation.x = -Math.sin(p.gait) * sw; stand.legs[2].rotation.x = -Math.sin(p.gait) * sw;
    D.group.position.set(p.wx, floor + Math.abs(Math.sin(p.gait)) * 0.02 * Math.min(1, speed), p.wz);
    D.group.rotation.y = p.yaw;
  }
  // Absol notices when he's up and about
  const A = W.people.npcPell;
  if (A && p.mode === 'follow' && p.saidLoop !== st.loop && A.group && Math.hypot(A.group.position.x - p.wx, A.group.position.z - p.wz) < 2.6 && d < 8) {
    p.saidLoop = st.loop;
    if (W.say) W.say(p.ball && p.ball.state === 'mouth' ? 'Absol: \u201cIs that the ball? Have you got the ball? Go on then. Go on!\u201d' : 'Absol: \u201cKeanu! Who let you off the bed? \u2026Fine. Fine. Good boy.\u201d');
  }
  // the head follows you, the tail wags when you're close
  const near = d < 6, gyaw = D.group.rotation.y;
  const rel = ((Math.atan2(dx, dz) - gyaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
  const head = D.head;
  if (p.howlT > 0) { head.rotation.x += (-0.9 - head.rotation.x) * Math.min(1, dt * 4); head.rotation.y *= 0.9; }
  else {
    const hy = near ? Math.max(-1.1, Math.min(1.1, rel)) : Math.sin(time * 0.17) * 0.4;
    head.rotation.y += (hy - head.rotation.y) * Math.min(1, dt * 3);
    const tilt = p.talking > 0 ? Math.sin(time * 14) * 0.08 - 0.12 : (near ? Math.sin(time * 0.7) * 0.12 : 0);
    head.rotation.z += (tilt * 0.6 - head.rotation.z) * Math.min(1, dt * 3);
    head.rotation.x += ((p.talking > 0 ? -0.25 : near ? -Math.atan2(cam.y - D.group.position.y - 0.6, Math.max(d, 0.5)) * 0.5 : 0.1) - head.rotation.x) * Math.min(1, dt * 4);
  }
  const happy = p.mode === 'pet' ? 2 : (near || p.talking > 0 || p.mode === 'follow') ? 1 : 0;
  D.tail.rotation.y = happy === 2 ? Math.sin(time * 18) * 0.6 : happy ? Math.sin(time * 11) * 0.45 : Math.sin(time * 2.2) * 0.12;
  lie.body.scale.y = 1 + Math.sin(time * (near ? 3.4 : 1.7)) * 0.018;
  // the interaction point travels with his head, and says what he'd like
  const hp = p._hp || (p._hp = new THREE.Vector3()); D.head.getWorldPosition(hp);
  p.it.x = hp.x; p.it.y = hp.y; p.it.z = hp.z;
  const b = p.ball;
  p.it.label = b && b.state === 'held' ? 'Throw the ball for Keanu' : p.mode === 'bed' && !p.petted ? 'Pet Keanu' : 'Talk to Keanu';
  if (b) {
    if (b.state === 'flying') {
      b.t += dt / b.dur; const t = Math.min(1, b.t);
      b.x = b.fx + (b.tx - b.fx) * t; b.z = b.fz + (b.tz - b.fz) * t;
      b.mesh.position.set(b.x, b.fy + (floor + 0.034 - b.fy) * t + Math.sin(t * Math.PI) * b.arc, b.z);
      b.mesh.rotation.x += dt * 14;
      if (t >= 1) { b.state = 'landed'; b.t = 0; if (W.sound) W.sound.bounce(); }
    } else if (b.state === 'landed' || b.state === 'floor') {
      // a last little bounce where it lands
      b.t += dt; const k = b.state === 'landed' ? Math.max(0, 1 - b.t / 0.35) : 0;
      b.mesh.position.set(b.x, floor + 0.034 + Math.abs(Math.sin(b.t * 9)) * 0.09 * k, b.z);
    } else if (b.state === 'mouth') {
      const yawD = D.group.rotation.y;
      b.mesh.position.set(hp.x + Math.sin(yawD) * 0.2, hp.y - 0.07, hp.z + Math.cos(yawD) * 0.2);
    }
    // you can pick it up wherever it lies
    const lying = b.state === 'floor' || (b.state === 'landed' && p.mode !== 'follow');
    b.it.x = lying ? b.x : 0; b.it.y = lying ? floor + 0.12 : -999; b.it.z = lying ? b.z : 0;
  }
  p.head = D.head;
}
// The residents' day: at set times each walks a short path to something they do every cycle, stays at
// it a while, and walks back. Close by, you'll hear what they mutter over it (once per cycle each).
// Returns what they're up to: { walking, heading } on the way, { act, face } once there.
function routine(W, p, dt, time, st, d) {
  if (!p.route) return null;
  if (p.loopSeen !== st.loop || st.elapsed + 2 < (p.lastEl ?? 0)) { p.loopSeen = st.loop; p.px = p.x; p.pz = p.z; p.queue = []; p.seg = null; p.said = {}; }
  const jumped = Math.abs(st.elapsed - (p.lastEl ?? st.elapsed)) > 6; p.lastEl = st.elapsed;
  let seg = null;
  for (const r of p.route) if (st.elapsed >= r.from && st.elapsed < r.to && !(r.needs === 'keanu' && (!W.people.npcKeanu || W.people.npcKeanu.mode !== 'bed'))) seg = r;
  if (seg !== p.seg) {
    // a new leg of the day: out along the path, or back along the one we came by
    const back = p.seg ? p.seg.path.slice(0, -1).reverse().concat([[p.x, p.z]]) : [[p.x, p.z]];
    p.queue = seg ? seg.path.slice() : back;
    p.seg = seg;
  }
  if (jumped && p.queue.length) { const last = p.queue[p.queue.length - 1]; p.px = last[0]; p.pz = last[1]; p.queue = []; }
  if (p.talking > 0) return seg && !p.queue.length ? { act: seg.act } : null;
  let out = null;
  if (p.queue.length) {
    const [tx, tz] = p.queue[0], ddx = tx - p.px, ddz = tz - p.pz, dd = Math.hypot(ddx, ddz);
    const step = Math.min(dd, 1.15 * dt);
    if (dd > 0.02) { p.px += ddx / dd * step; p.pz += ddz / dd * step; out = { walking: true, heading: Math.atan2(ddx, ddz) }; }
    if (dd - step < 0.03) p.queue.shift();
  } else if (seg) {
    out = { act: seg.act, face: seg.face };
    if (d < 5 && !p.said[seg.from] && W.say) { p.said[seg.from] = true; W.say(seg.say, p.it.id + '@' + seg.from); }
  }
  // move the body, the collider and the place you talk to them
  const oc = W.named[p.chunk];
  p.group.position.x = p.px; p.group.position.z = p.pz;
  p.col.x = p.px; p.col.z = p.pz;
  p.it.x = p.px; p.it.z = p.pz;
  if (p.line) p.line.visible = !(p.px !== p.x || p.pz !== p.z);
  return out;
}

// is there anything in the way at a dog's height?
const _near = [];
function dogBlocked(W, x, z, floor) {
  const P = W.phys; if (!P) return false;
  P.near(x, z, 0.6, _near);
  const r = 0.22;
  for (const c of _near) {
    if (c.npc) continue;
    const ox = c.chunk.offset.x, oy = c.chunk.offset.y, oz = c.chunk.offset.z;
    if (c.type === 'cyl') { if (Math.hypot(x - c.x - ox, z - c.z - oz) < c.r + r && c.y1 + oy > floor + 0.15 && c.y0 + oy < floor + 0.6) return true; continue; }
    const dx = x - c.x - ox, dz = z - c.z - oz, lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
    if (Math.abs(lx) > c.hx + r || Math.abs(lz) > c.hz + r) continue;
    if (c.type === 'box') { if (c.y + c.hy + oy > floor + 0.15 && c.y - c.hy + oy < floor + 0.6) return true; continue; }
    const t = Math.max(0, Math.min(1, (lz + c.hz) / (2 * c.hz))), top = c.y0 + (c.y1 - c.y0) * t + oy;
    if (top > floor + 0.2) return true;
  }
  return false;
}

// the sculpting kit, for anyone else who wants to make a body
export { prim, sdfField, surfZ, sdfMesh, furMat, merged, at };

export function buildPeople(W) {
  const ch = W.chunk('people', { dynamic: true });   // their colliders walk with them
  const list = [
    { id: 'npcPell', route: [
      { from: 120, to: 300, path: [[-3.0, 13.0], [-3.43, 13.96]], face: -1.87, act: 'bed', say: 'Absol: \u201cCorners tucked. Nobody\u2019s slept in it. Corners tucked anyway.\u201d' },
      { from: 420, to: 560, path: [[-1.6, 12.0]], face: -0.1, act: 'read', say: 'Absol: \u201cOne name on the manifest. One. And six beds made.\u201d' },
      { from: 700, to: 860, path: [[-1.0, 12.3], [1.5, 13.0], [3.35, 13.95]], face: 1.86, act: 'pet', say: 'Absol: \u201cMorning, Keanu. Yes. Yes, you are. Who\u2019s a good boy.\u201d', needs: 'keanu' }
    ],  chunk: 'station', name: 'Absol', x: -2.9, y: F, z: 11.6, yaw: 1.75, look: { coat: 0x5c151a, sleeves: 0x161618, hoodie: true, trousers: 0x1c1c20, skin: 0x8c5a38, hair: 0x0c0b0e, curls: true, mask: 'fox' } },
    { id: 'npcJuniper', route: [
      { from: 240, to: 420, path: [[-36.8, -112.1], [-35.6, -112.35]], face: Math.PI, act: 'sort', say: 'Skye: \u201cSame apples as yesterday. Exactly the same apples. I\u2019d know that bruise anywhere.\u201d' },
      { from: 880, to: 1000, path: [[-36.8, -112.1], [-35.6, -112.35]], face: Math.PI, act: 'sort', say: 'Skye: \u201cSomebody paid me in favours for these. I can\u2019t think who.\u201d' }
    ],  chunk: 'market', name: 'Skye', x: -38, y: 2, z: -112.05, yaw: Math.PI, look: { coat: 0x7a3f34, skin: skinTones[2], hair: 0x120d0b, bun: true, apron: 0xa8987a, scarf: 0xd8a24a } },
    { id: 'npcSef', route: [
      { from: 520, to: 680, path: [[-64.75, -120.85]], face: 2.36, act: 'sort', say: 'Charley: \u201cFour hundred days and the bucket\u2019s still empty. It was empty yesterday too, I expect.\u201d' },
      { from: 1040, to: 1160, path: [[-64.75, -120.85]], face: 2.36, act: 'sort', say: 'Charley: \u201cRed sky. Means something, a red sky. Sailors know. I was never a sailor.\u201d' }
    ],  chunk: 'market', name: 'Charley', x: -66.5, y: 2, z: -121.2, yaw: Math.PI * 0.85, look: { coat: 0x3d5248, trousers: 0x30302e, skin: skinTones[3], beard: 0xd7d2c6, hat: 'beanie', hatColor: 0x8f3b2c }, rod: true },
    { id: 'npcKeeper', route: [
      { from: 330, to: 470, path: [[-142.3, -59.5], [-142.1, -62.2]], face: 2.36, act: 'sort', say: 'Aiden: \u201cOne more on the cairn. One for every time somebody came out by boat. \u2026That makes one.\u201d' },
      { from: 960, to: 1180, path: [[-147.6, -59.1], [-150.6, -58.4], [-152.2, -51.4]], face: -1.0, act: 'read', say: 'Aiden: \u201cAlmost dark. Two switches, and only ever the one. Somebody out there blinks back.\u201d' }
    ],  chunk: 'isle', name: 'Aiden', x: -144.4, y: 3, z: -59.3, yaw: Math.PI * 0.75, look: { coat: 0x2d3a4e, trousers: 0x3a3630, skin: skinTones[1], hair: 0x6e675e, shortBeard: 0x6a6258, brow: 0x5a544c, hat: 'sou', hatColor: 0xd8a83a, peaCoat: true, boots: 0x22201e, broad: true, masc: true } },
    { id: 'npcGardener', route: [
      { from: 300, to: 480, path: [[-121.2, -200.5], [-120.4, -198.4]], face: 0.6, act: 'water', say: 'Christian: \u201cNot the bed by the door. Not the bed by the door\u2026 Just a little, then.\u201d' },
      { from: 820, to: 960, path: [[-122, -208.2]], face: Math.PI, act: 'water', say: 'Christian: \u201cTomatoes. More tomatoes. Who planted this many tomatoes? \u2026Oh. Me.\u201d' }
    ],  chunk: 'rise', name: 'Christian', x: -122, y: 2.5, z: -203.5, yaw: 0, look: { coat: 0x5c6b3a, trousers: 0x4a3c2c, skin: skinTones[4], hair: 0x3a2a1e, hat: 'straw', apron: 0x7a5a3a } }
  ];
  W.people = {};
  for (const p of list) {
    let line = null;
    const f = figure(p.look);
    f.group.position.set(p.x, p.y, p.z);
    f.group.rotation.y = p.yaw;
    if (p.rod) {
      const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.02, 2.6, 6), std(0x6e4c35));
      rod.position.set(0.1, 0.4, 1.0); rod.rotation.x = 1.0; f.arms[1].add(rod);
      f.arms[1].rotation.x = -0.6;
      line = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 3.2, 3), new THREE.MeshBasicMaterial({ color: 0xcccccc }));
      line.position.set(p.x + Math.sin(p.yaw) * 2.2, 0.9, p.z + Math.cos(p.yaw) * 2.2); W.scene.add(line);
    }
    W.scene.add(f.group);
    const col = ch.collider({ type: 'cyl', x: p.x, z: p.z, r: 0.32, y0: p.y, y1: p.y + 1.8, npc: true });
    const it = W.addInteract({ id: p.id, x: p.x, y: p.y + 1.45, z: p.z, r: 2.8, label: 'Talk to ' + p.name, npc: true });
    W.people[p.id] = { ...f, x: p.x, y: p.y, z: p.z, yaw: p.yaw, baseYaw: p.yaw, talking: 0, it, chunk: p.chunk, still: !!p.rod, phase: p.x * 0.37 + p.z * 0.11,
      route: p.route || null, col, px: p.x, pz: p.z, queue: [], seg: null, said: {}, line: p.rod ? line : null };
  }
  // Luka rides the skiff
  const t = robot();
  W.skiff.group.add(t.group); t.group.position.set(0, 0.54, 1.6); t.group.rotation.y = Math.PI;
  const it = W.addInteract({ id: 'npcPilot', x: 0, y: 0, z: 0, r: 3.6, label: 'Talk to Luka', npc: true });
  W.people.npcPilot = { ...t, robot: true, talking: 0, it, baseYaw: Math.PI };

  // Keanu, on the bed in berth 03, next to yours, lying the length of it and facing the room
  {
    const a = 17 * Math.PI / 180, r = 14.35, fx = Math.sin(a), fz = Math.cos(a);
    const bx = fx * r - fx * 0.15, bz = fz * r - fz * 0.15, by = F + 0.61;
    const k = dog();
    W.scene.add(k.group);
    ch.collider({ type: 'box', x: fx * r, y: by + 0.25, z: fz * r, hx: 0.24, hy: 0.25, hz: 0.6, yaw: a, npc: true });
    const it = W.addInteract({ id: 'npcKeanu', x: bx, y: by + 0.45, z: bz, r: 2.6, label: 'Pet Keanu', npc: true });
    const K = W.people.npcKeanu = { group: k.group, dogs: k, head: k.lie.head, dog: true, x: bx, y: F, z: bz, talking: 0, it, bx, by, bz, byaw: a + Math.PI, wx: bx, wz: bz, yaw: a + Math.PI, mode: 'bed', chunk: 'station' };
    // his ball: chewed, lying by the writing desk. Pick it up, then throw it for him
    const bc = document.createElement('canvas'); bc.width = 128; bc.height = 64; const bg = bc.getContext('2d');
    bg.fillStyle = '#b9cf34'; bg.fillRect(0, 0, 128, 64);
    for (let i = 0; i < 400; i++) { bg.fillStyle = `rgba(${i % 3 ? '96,104,34' : '236,246,170'},${0.05 + (i * 37 % 17) / 90})`; bg.fillRect((i * 53) % 128, (i * 29) % 64, 2, 2); }
    for (let i = 0; i < 6; i++) { bg.fillStyle = 'rgba(120,110,70,.35)'; bg.beginPath(); bg.ellipse((i * 41) % 128, 10 + (i * 23) % 44, 6, 3, i, 0, 7); bg.fill(); }
    bg.strokeStyle = 'rgba(244,242,226,.95)'; bg.lineWidth = 3; bg.beginPath();
    for (let x = 0; x <= 128; x += 2) { const y = 32 + Math.sin(x / 128 * Math.PI * 4) * 15; if (x) bg.lineTo(x, y); else bg.moveTo(x, y); } bg.stroke();
    const btex = new THREE.CanvasTexture(bc); btex.colorSpace = THREE.SRGBColorSpace;
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.034, 16, 12), new THREE.MeshStandardMaterial({ map: btex, roughness: 0.95 }));
    const ha = 27 * Math.PI / 180, hx = Math.sin(ha) * 11.9, hz = Math.cos(ha) * 11.9;
    ball.position.set(hx, F + 0.034, hz); ball.castShadow = true; W.scene.add(ball);
    const bit = W.addInteract({ id: 'keanuBall', x: hx, y: F + 0.12, z: hz, r: 1.9, label: 'Pick up the ball' });
    K.ball = { mesh: ball, it: bit, hx, hz, state: 'floor', x: hx, y: F + 0.034, z: hz, t: 0 };
    // a throw from where you stand, along where you look: as far as it can go before a wall or a bed
    K.throwBall = (cx, cy, cz, fx, fz) => {
      const b = K.ball, oy = W.named.station ? W.named.station.offset.y : 0, floor = F + oy;
      let tx = cx, tz = cz, dist = 0;
      for (let s = 0.5; s <= 6.5; s += 0.25) {
        const x = cx + fx * s, z = cz + fz * s, r = Math.hypot(x, z);
        if (r > 15.2 || dogBlocked(W, x, z, floor)) break;
        tx = x; tz = z; dist = s;
      }
      b.state = 'flying'; b.t = 0; b.dur = 0.45 + dist * 0.07; b.arc = 0.35 + dist * 0.12;
      b.fx = cx + fx * 0.3; b.fy = cy - 0.35; b.fz = cz + fz * 0.3; b.tx = tx; b.tz = tz;
      b.mesh.visible = true; b.mesh.position.set(b.fx, b.fy, b.fz);
      if (K.mode === 'bed') { K.mode = 'hop'; K.hop = 0; }
      K.fetchT = 0;
    };
  }

  W.onUpdate((dt, time, st, cam) => {
    for (const id in W.people) {
      const p = W.people[id];
      if (W.cutscene) continue;   // the finale moves everyone itself
      const wp = new THREE.Vector3(); p.group.getWorldPosition(wp);
      // far off, a person is a speck: don't spend triangles on them
      const far = Math.hypot(cam.x - wp.x, cam.y - wp.y, cam.z - wp.z) > 60;
      if (!p.robot) p.group.visible = !far;
      if (p.dog) { updateKeanu(W, p, dt, time, st, cam); continue; }
      if (p.robot) { p.it.x = wp.x; p.it.y = wp.y + 1.2; p.it.z = wp.z; }
      const dx = cam.x - wp.x, dz = cam.z - wp.z, d = Math.hypot(dx, dz);
      const busy = !p.robot && routine(W, p, dt, time, st, d);
      // whole-body turn towards the player within 7 m, head follows more closely
      const parentYaw = p.robot ? W.skiff.group.rotation.y : 0;
      let target = p.baseYaw;
      const want = Math.atan2(dx, dz) - parentYaw;
      if (d < 7 && !p.still && !busy) target = want;
      if (busy && busy.face !== undefined) target = busy.face;
      if (busy && busy.walking) target = busy.heading;
      let diff = ((target - p.group.rotation.y + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      p.group.rotation.y += diff * Math.min(1, dt * (busy && busy.walking ? 6 : 1.6));
      // the head gets there first; out of range it drifts, looking at the water, the sky, nothing
      const ph = p.phase || 0;
      let headYaw = Math.sin(time * 0.21 + ph) * 0.3 + Math.sin(time * 0.53 + ph * 2) * 0.12;
      if (d < 7) headYaw = Math.max(-0.75, Math.min(0.75, ((want - p.group.rotation.y + Math.PI * 3) % (Math.PI * 2)) - Math.PI));
      p.head.rotation.y += (headYaw - p.head.rotation.y) * Math.min(1, dt * 4);
      if (p.body) p.body.rotation.z = Math.sin(time * 0.6 + ph) * 0.018;
      const breathe = Math.sin(time * 1.6 + wp.x) * 0.005;
      p.torso.scale.y = 1 + breathe;
      if (p.lids) {
        // a blink every three to six seconds, sometimes two in a row
        p.blinkAt = p.blinkAt ?? time + 1 + (ph % 3);
        if (time > p.blinkAt) p.blinkAt = time + (Math.random() < 0.2 ? 0.35 : 3 + Math.random() * 3);
        p.lids.visible = d < 14 && time > p.blinkAt - 0.13;
      }
      const talk = p.talking > 0 ? Math.sin(time * 9) * 0.05 : 0;
      p.head.rotation.x = talk + (d < 7 ? -Math.atan2(cam.y - (wp.y + 1.6), Math.max(d, 0.5)) * 0.4 : 0.05);
      if (p.robot) p.arms[0].rotation.x = Math.sin(time * 1.3 + wp.z) * 0.04 + (p.talking > 0 ? Math.sin(time * 4) * 0.25 - 0.2 : 0);
      if (!p.robot) {
        // walking: legs and arms swing opposite; at a task, the hands get busy
        const walk = busy && busy.walking ? 1 : 0;
        p.stride = (p.stride || 0) + dt * 7.5 * walk;
        const sw = Math.sin(p.stride) * 0.42 * walk;
        if (p.legs) { p.legs[0].rotation.x += (sw - p.legs[0].rotation.x) * Math.min(1, dt * 12); p.legs[1].rotation.x += (-sw - p.legs[1].rotation.x) * Math.min(1, dt * 12); }
        const act = busy && !busy.walking ? busy.act : null;
        const armW = act === 'read' ? -0.9 : act ? -0.55 + Math.sin(time * 3.2) * 0.18 : 0;
        const armT = (k) => walk ? -sw * 0.6 * k : armW + (act && act !== 'read' ? Math.sin(time * 3.2 + k) * 0.12 : 0);
        if (!p.still || walk) { p.arms[0].rotation.x += (armT(1) + (p.talking > 0 ? Math.sin(time * 4) * 0.25 - 0.2 : 0) - p.arms[0].rotation.x) * Math.min(1, dt * 8); }
        if (!p.line || walk) p.arms[1].rotation.x += (armT(-1) - p.arms[1].rotation.x) * Math.min(1, dt * 8);
        if (act === 'read' || act === 'water' || act === 'sort' || act === 'bed' || act === 'pet') p.head.rotation.x += 0.35;
        p.body.position.y = walk ? Math.abs(Math.cos(p.stride)) * 0.025 : 0;
      }
      if (p.robot && p.visor) p.visor.material.color.setRGB(0.39 * 3, 0.94 * 3 * (p.talking > 0 ? 0.6 + 0.4 * Math.sin(time * 20) : 1), 0.89 * 3);
      if (!p.robot) { const oc = W.named[p.chunk]; p.group.position.y = p.y + (oc ? oc.offset.y : 0); }
    }
  });
}
