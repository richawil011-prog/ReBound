// Architecture helpers: curved and straight walls with doorways and glazed windows.
import * as THREE from '../../vendor/three.module.min.js';

// Curved wall between radii r0..r1 around (cx,cz), floor y, height h.
// openings: [{a (radians), w (metres), h (top of opening above floor), sill (bottom), glass: bool}]
export function wallRing(ch, M, cx, y, cz, r0, r1, h, mat, openings = [], o = {}) {
  const rm = (r0 + r1) / 2;
  const ops = openings.map(op => ({ ...op, da: (op.w / 2) / rm })).sort((a, b) => a.a - b.a);
  const A0 = o.a0 ?? 0, A1 = o.a1 ?? Math.PI * 2;
  let cur = A0;
  const seg = (a0, a1, y0, hh) => { if (a1 - a0 > 1e-3 && hh > 0.01) ch.ring(cx, y0, cz, r0, r1, hh, mat, { a0, a1, tint: o.tint }); };
  // an opening that straddles angle 0 cuts the end of the circle instead
  let end = A1;
  for (const op of ops) if (op.a - op.da < A0) end = Math.min(end, A1 + (op.a - op.da));
  for (const op of ops) {
    const s0 = op.a - op.da, s1 = op.a + op.da;
    seg(cur, s0, y, h);
    const top = op.h ?? 2.6, sill = op.sill ?? 0;
    seg(s0, s1, y + top, h - top);                 // lintel
    if (sill > 0) seg(s0, s1, y, sill);             // under the window
    if (op.glass) {
      ch.ring(cx, y + sill, cz, rm - 0.03, rm + 0.03, top - sill, o.glassMat || M.glassClear, { a0: s0, a1: s1 });
      // frame
      ch.ring(cx, y + sill - 0.04, cz, r0 - 0.04, r1 + 0.04, 0.08, M.steel, { a0: s0, a1: s1, collide: false });
      if (op.mullion !== false) {
        const n = Math.max(1, Math.round(op.w / 1.1));
        for (let i = 1; i < n; i++) {
          const a = s0 + (s1 - s0) * i / n;
          ch.box(cx + Math.sin(a) * rm, y + sill, cz + Math.cos(a) * rm, 0.06, top - sill, r1 - r0 + 0.04, M.steel, { yaw: a, collide: false, ao: 0 });
        }
      }
    } else if (op.frame !== false) {
      // door frame jambs
      for (const a of [s0, s1]) ch.box(cx + Math.sin(a) * rm, y, cz + Math.cos(a) * rm, 0.12, top, r1 - r0 + 0.1, o.frameMat || M.steel, { yaw: a, ao: 0 });
      ch.ring(cx, y + top - 0.1, cz, r0 - 0.05, r1 + 0.05, 0.12, o.frameMat || M.steel, { a0: s0, a1: s1, collide: false });
    }
    cur = s1;
  }
  seg(cur, end, y, h);
}

// Straight wall from (x0,z0) to (x1,z1). openings: [{t: distance from start to centre, w, h, sill, glass}]
export function wallLine(ch, M, x0, z0, x1, z1, y, h, thick, mat, openings = [], o = {}) {
  const len = Math.hypot(x1 - x0, z1 - z0);
  const dx = (x1 - x0) / len, dz = (z1 - z0) / len;
  const yaw = Math.atan2(dx, dz) + Math.PI / 2; // local x runs along the wall
  const at = (t) => [x0 + dx * t, z0 + dz * t];
  const piece = (t0, t1, y0, hh) => {
    if (t1 - t0 < 0.01 || hh < 0.01) return;
    const [mx, mz] = at((t0 + t1) / 2);
    ch.box(mx, y0, mz, t1 - t0, hh, thick, mat, { yaw, tint: o.tint, ao: y0 === y ? undefined : 0 });
  };
  const ops = [...openings].sort((a, b) => a.t - b.t);
  let cur = 0;
  for (const op of ops) {
    const s0 = op.t - op.w / 2, s1 = op.t + op.w / 2;
    piece(cur, s0, y, h);
    const top = op.h ?? 2.6, sill = op.sill ?? 0;
    piece(s0, s1, y + top, h - top);
    if (sill > 0) piece(s0, s1, y, sill);
    const [mx, mz] = at(op.t);
    if (op.glass) {
      ch.box(mx, y + sill, mz, op.w, top - sill, 0.05, o.glassMat || M.glassClear, { yaw, ao: 0 });
      ch.box(mx, y + sill - 0.05, mz, op.w + 0.1, 0.08, thick + 0.08, M.steel, { yaw, collide: false, ao: 0 });
      ch.box(mx, y + top - 0.04, mz, op.w + 0.1, 0.08, thick + 0.08, M.steel, { yaw, collide: false, ao: 0 });
    } else if (op.frame !== false) {
      for (const k of [-1, 1]) { const [fx, fz] = at(op.t + k * op.w / 2); ch.box(fx, y, fz, 0.12, top, thick + 0.1, o.frameMat || M.steel, { yaw, ao: 0 }); }
      ch.box(mx, y + top - 0.12, mz, op.w + 0.12, 0.12, thick + 0.1, o.frameMat || M.steel, { yaw, collide: false, ao: 0 });
    }
    cur = s1;
  }
  piece(cur, len, y, h);
  return { yaw, at, len, dx, dz };
}

// A rectangular room shell: floor, four walls (with openings per side), ceiling.
// sides: {n, s, e, w} arrays of openings (t measured from the west/north end)
export function room(ch, M, x0, z0, x1, z1, y, h, o = {}) {
  const t = o.thick ?? 0.3, wm = o.wall || M.concrete;
  if (o.floor !== false) ch.box((x0 + x1) / 2, y - (o.floorThick ?? 0.4), (z0 + z1) / 2, x1 - x0, o.floorThick ?? 0.4, z1 - z0, o.floorMat || M.tile, { ao: 0 });
  const S = o.sides || {};
  // north side is z1 (larger z), south is z0
  wallLine(ch, M, x0, z1 - t / 2, x1, z1 - t / 2, y, h, t, wm, S.n || [], o);
  wallLine(ch, M, x0, z0 + t / 2, x1, z0 + t / 2, y, h, t, wm, S.s || [], o);
  wallLine(ch, M, x0 + t / 2, z1 - t, x0 + t / 2, z0 + t, y, h, t, wm, S.w || [], o);
  wallLine(ch, M, x1 - t / 2, z1 - t, x1 - t / 2, z0 + t, y, h, t, wm, S.e || [], o);
  if (o.ceiling !== false) ch.box((x0 + x1) / 2, y + h, (z0 + z1) / 2, x1 - x0, o.roofThick ?? 0.35, z1 - z0, o.roofMat || wm, { ao: 0, collide: o.roofCollide ?? true });
}

export function column(ch, M, x, y, z, r, h, mat, o = {}) {
  ch.cyl(x, y, z, r * 1.25, 0.3, mat, { seg: 16 });
  ch.cyl(x, y + 0.3, z, r, h - 0.6, mat, { seg: 16, collide: false });
  ch.cyl(x, y + h - 0.3, z, r * 1.25, 0.3, mat, { seg: 16, collide: false });
  ch.collider({ type: 'cyl', x, z, r: r * 1.1, y0: y, y1: y + h });
}

// round-headed arch: an extruded outline with a semicircular opening
export function arch(ch, M, x, y, z, span, h, yaw, mat, depth = 0.9, post = 0.8) {
  const W = span / 2 + post, r = span / 2, spring = h - r;
  const sh = new THREE.Shape();
  sh.moveTo(-W, 0); sh.lineTo(-r, 0); sh.lineTo(-r, spring);
  sh.absarc(0, spring, r, Math.PI, 0, true);
  sh.lineTo(r, 0); sh.lineTo(W, 0); sh.lineTo(W, h + 0.9); sh.lineTo(-W, h + 0.9); sh.lineTo(-W, 0);
  const g = new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: false, curveSegments: 16 });
  g.translate(0, 0, -depth / 2);
  const m = new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, yaw, 0)), new THREE.Vector3(1, 1, 1));
  ch.geo(g, mat, m, { ao: 1.2 });
  g.dispose();
  const s = Math.sin(yaw), c = Math.cos(yaw);
  for (const k of [-1, 1]) {
    const off = k * (r + post / 2);
    ch.collider({ type: 'box', x: x + c * off, y: y + h / 2, z: z - s * off, hx: post / 2, hy: h / 2, hz: depth / 2, yaw });
  }
}

export const deg = Math.PI / 180;

// ---------- craggy rock ----------
// 3D value noise for weathering (deterministic, so every build of the world is the same).
function h3(x, y, z) { const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453; return s - Math.floor(s); }
function vnoise(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  let xf = x - xi, yf = y - yi, zf = z - zi;
  xf = xf * xf * (3 - 2 * xf); yf = yf * yf * (3 - 2 * yf); zf = zf * zf * (3 - 2 * zf);
  const l = (a, b, t) => a + (b - a) * t;
  return l(l(l(h3(xi, yi, zi), h3(xi + 1, yi, zi), xf), l(h3(xi, yi + 1, zi), h3(xi + 1, yi + 1, zi), xf), yf),
    l(l(h3(xi, yi, zi + 1), h3(xi + 1, yi, zi + 1), xf), l(h3(xi, yi + 1, zi + 1), h3(xi + 1, yi + 1, zi + 1), xf), yf), zf);
}
export function rockNoise(x, y, z) { return vnoise(x * 0.35, y * 0.35, z * 0.35) * 0.6 + vnoise(x * 0.9, y * 0.9, z * 0.9) * 0.3 + vnoise(x * 2.1, y * 2.1, z * 2.1) * 0.1; }

// A block of rock (base at y0, size w x h x d) whose sides are weathered in and out by up to
// `amp` metres. The top stays flat and its edge keeps its line, so walkable tops are unchanged.
// The collider (if any) is the plain box.
export function crag(ch, mat, x, y0, z, w, h, d, o = {}) {
  const amp = o.amp ?? 0.7, yaw = o.yaw || 0;
  const g = new THREE.BoxGeometry(w, h, d, Math.max(1, Math.ceil(w / 1.2)), Math.max(1, Math.ceil(h / 1.2)), Math.max(1, Math.ceil(d / 1.2)));
  const P = g.attributes.position, c = Math.cos(yaw), s = Math.sin(yaw);
  for (let i = 0; i < P.count; i++) {
    const lx = P.getX(i), ly = P.getY(i), lz = P.getZ(i);
    const fromTop = h / 2 - ly;
    if (fromTop < 1e-3) continue;                       // the top face stays as it is
    const wx = x + lx * c + lz * s, wy = y0 + h / 2 + ly, wz = z - lx * s + lz * c;
    const n = rockNoise(wx, wy, wz) * 2 - 0.7;
    const k = Math.min(1, fromTop / 1.2) * amp * n;
    // push out from the block's middle, horizontally; corners round off a little
    const ex = Math.abs(lx) / (w / 2), ez = Math.abs(lz) / (d / 2);
    P.setX(i, lx + Math.sign(lx) * k * (ex > 0.98 ? 1 : ex * 0.6));
    P.setZ(i, lz + Math.sign(lz) * k * (ez > 0.98 ? 1 : ez * 0.6));
    P.setY(i, ly + (ly < -h / 2 + 1e-3 ? 0 : (rockNoise(wz, wx, wy) - 0.5) * amp * 0.5 * Math.min(1, fromTop / 1.2)));
  }
  g.computeVertexNormals();
  const m = new THREE.Matrix4().compose(new THREE.Vector3(x, y0 + h / 2, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, yaw, 0)), new THREE.Vector3(1, 1, 1));
  ch.geo(g, mat, m, { ao: o.ao ?? 0, tint: o.tint });
  g.dispose();
  if (o.collide) ch.collider({ type: 'box', x, y: y0 + h / 2, z, hx: w / 2, hy: h / 2, hz: d / 2, yaw });
}
