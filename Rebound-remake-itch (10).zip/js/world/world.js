// The world: owns chunks, lights, doors, interactables, regions and the scheduled events.
import * as THREE from '../../vendor/three.module.min.js';
import { Chunk, LightPool } from '../core/build.js';
import { Physics } from '../core/physics.js';
import { makeMaterials, shared } from './materials.js';
import { makeSky, makeSea, makeRim, skyU } from './sky.js';
import { buildStation } from './station.js';
import { buildCity } from './city.js';
import { buildDeep } from './deep.js';
import { buildIsles } from './isles.js';
import { buildPeople } from './people.js';
import { buildExplorer } from './explorer.js';
import { buildTarn } from './tarn.js';
import { Motes } from './particles.js';
import { FX } from './fx.js';
import { Birds } from './birds.js';
import { Life } from './life.js';
import { buildFoam } from './foam.js';
import { buildLetters } from './letters.js';

export const REGIONS = {
  station: { name: 'Halcyon Station', fog: 0x2b2a3c, den: 0.010, hemiSky: 0x9aa6c8, hemiGround: 0x2a2630, hemi: 2.1, env: 0.22, sun: 1.0,
    grade: { lift: [0.01, 0.008, 0.02], gamma: [1, 1, 1.02], gain: [1.03, 1.0, 0.98], sat: 1.0, contrast: 1.04, exposure: 1.05, bloom: 0.7 } },
  city: { name: 'The Hollow City', fog: 0x3b3550, den: 0.0105, hemiSky: 0x8f93c0, hemiGround: 0x3a2f35, hemi: 2.2, env: 0.4, sun: 2.6,
    grade: { lift: [0.012, 0.006, 0.025], gamma: [1, 1, 1.03], gain: [1.05, 1.0, 0.97], sat: 1.02, contrast: 1.05, exposure: 1.1, bloom: 0.75 } },
  deep: { name: 'The Deep', fog: 0x0a1a20, den: 0.026, hemiSky: 0x8ab8bc, hemiGround: 0x26302f, hemi: 2.7, env: 0.08, sun: 0.0,
    grade: { lift: [0.0, 0.012, 0.016], gamma: [0.98, 1.02, 1.04], gain: [0.95, 1.03, 1.05], sat: 0.92, contrast: 1.06, exposure: 1.35, bloom: 0.95 } },
  core: { name: 'The Core', fog: 0x130f22, den: 0.016, hemiSky: 0x9a8ad8, hemiGround: 0x2a2036, hemi: 2.0, env: 0.1, sun: 0.0,
    grade: { lift: [0.015, 0.0, 0.03], gamma: [1, 0.98, 1.04], gain: [1.02, 0.98, 1.06], sat: 1.05, contrast: 1.1, exposure: 1.1, bloom: 1.1 } },
  isle: { name: 'Lantern Isle', fog: 0x3d3852, den: 0.009, hemiSky: 0x8f93c0, hemiGround: 0x3a2f35, hemi: 2.2, env: 0.4, sun: 2.6,
    grade: { lift: [0.012, 0.006, 0.025], gamma: [1, 1, 1.03], gain: [1.05, 1.0, 0.97], sat: 1.02, contrast: 1.05, exposure: 1.05, bloom: 0.75 } },
  tarn: { name: 'Tarn Rooftops', fog: 0x3a3a4c, den: 0.012, hemiSky: 0x8c90b0, hemiGround: 0x2c2a30, hemi: 2.0, env: 0.35, sun: 2.2,
    grade: { lift: [0.01, 0.01, 0.025], gamma: [1, 1, 1.03], gain: [1.0, 0.99, 1.0], sat: 0.85, contrast: 1.05, exposure: 1.05, bloom: 0.7 } },
  rise: { name: 'Verdant Rise', fog: 0x38384e, den: 0.0095, hemiSky: 0x93a0b8, hemiGround: 0x2f3328, hemi: 2.2, env: 0.4, sun: 2.6,
    grade: { lift: [0.008, 0.012, 0.02], gamma: [1, 1, 1.02], gain: [1.03, 1.02, 0.97], sat: 1.05, contrast: 1.04, exposure: 1.05, bloom: 0.7 } }
};

export class World {
  updateEnv() {
    if (!this.pmrem) return;
    try {
      const rt = this.pmrem.fromScene(this.envScene, 0.02, 0.1, 1000);
      if (this.envRT) this.envRT.dispose();
      this.envRT = rt; this.scene.environment = rt.texture;
    } catch (e) { this.pmrem = null; }
  }
  constructor(scene, renderer) {
    this.scene = scene;
    this.renderer = renderer;
    this.M = makeMaterials();
    this.phys = new Physics();
    this.chunks = [];
    this.doors = [];
    this.interact = [];
    this.updaters = [];
    this.pool = new LightPool(scene, 12);
    this.anchors = {};
    this.named = {};
    this.state = null;

    this.hemi = new THREE.HemisphereLight(0x9aa6c8, 0x2a2630, 1.0);
    scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xffb27a, 2.2);
    this.sun.castShadow = true;
    const sc = this.sun.shadow.camera;
    sc.left = -45; sc.right = 45; sc.top = 45; sc.bottom = -45; sc.near = 1; sc.far = 260;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.04;
    scene.add(this.sun); scene.add(this.sun.target);
    scene.fog = new THREE.FogExp2(0x3b3550, 0.0105);

    this.sky = makeSky(scene);
    // light from the sky itself, for reflections on metal, glass and wet stone. Rebuilt every few
    // seconds as the sky darkens.
    this.envScene = new THREE.Scene();
    this.envScene.add(new THREE.Mesh(new THREE.SphereGeometry(100, 32, 16), this.sky.material));
    this.pmrem = renderer && renderer.r ? new THREE.PMREMGenerator(renderer.r) : null;
    this.envRT = null;
    this.sea = makeSea(scene);
    this.rim = makeRim(scene);
    this.seaLevel = 0;

    buildStation(this);
    buildCity(this);
    buildDeep(this);
    buildIsles(this);
    buildTarn(this);
    buildPeople(this);
    buildExplorer(this);
    buildLetters(this);
    for (const ch of this.chunks) { ch.finalize(); scene.add(ch.group); this.phys.addChunk(ch); }
    this.motes = new Motes(scene);
    this.fx = new FX(scene);
    this.birds = new Birds(scene);
    this.life = new Life(this);
    this.foam = buildFoam(this);
    this.regionKey = 'station';
    this.fogTarget = new THREE.Color();
  }

  chunk(name, opts) { const c = new Chunk(name, opts); this.chunks.push(c); this.named[name] = c; return c; }
  light(x, y, z, color, intensity, dist, o = {}) { const a = this.pool.add(x, y, z, color, intensity, dist, o); if (o.key) this.anchors[o.key] = a; return a; }
  addInteract(def) { def.r = def.r ?? 2.4; this.interact.push(def); return def; }
  onUpdate(fn) { this.updaters.push(fn); }

  regionAt(x, y, z) {
    if (Math.hypot(x, z) < 23 && y > 17) return 'station';
    if (z < -256 && y < 2 && Math.abs(x) < 30) return 'core';
    if (y < -1.5 && z < -150 && z > -262 && Math.abs(x) < 30) return 'deep';
    if (z < -158 && z > -262 && Math.abs(x) < 6 && y < 5) return 'deep';   // the stair shaft down from the plaza
    if (Math.hypot(x + 150, z + 58) < 34) return 'isle';
    if (Math.hypot(x + 122, z + 202) < 32) return 'rise';
    if (x > 76 && x < 108 && z < -96 && z > -126 && y > -3) return 'tarn';
    return 'city';
  }

  placeName(x, y, z) {
    const r = this.regionAt(x, y, z);
    if (r !== 'city') return REGIONS[r].name;
    if (z > -60 && y > 11) return 'The Sky Bridge';
    if (x < -24 && z < -100) return 'Market Pier';
    if (y < 4.5 && x > 24 && z < -106 && z > -158) return x > 27.5 && x < 34.5 && z > -118 && z < -110 ? 'The Shelter' : 'The Service Walk';
    if (x > 12 && x < 24 && z < -96 && z > -116 && y < 15) return 'Civic Archive';
    if (x > -23.5 && x < -12 && z < -91 && z > -110 && y < 10.2) return 'Vale Court';
    if (Math.abs(x + 10.5) < 2.7 && Math.abs(z + 70.5) < 2.7 && y > 11) return 'The Bell Tower';
    if (z < -143 && z > -175) return 'South Plaza';
    if (y > 10 && z > -90) return 'Upper Terrace';
    return 'The Hollow City';
  }

  update(dt, t, st, cam) {
    shared.uTime.value = t;
    for (const d of this.doors) d.update(dt);
    for (const f of this.updaters) f(dt, t, st, cam);
    this.pool.update(cam, t);
    this.motes.update(dt, t, cam, this.regionKey);
    this.fx.update(dt, this.seaLevel);
    this.birds.update(dt, t, this.seaLevel);
    this.life.update(dt, t, st, cam, this.seaLevel);
    this.sea.u.camPos.value.copy(cam);
    this.sea.mesh.position.y = this.seaLevel;
    if (this.foam) this.foam.update(t, this.seaLevel, this.scene.fog && this.scene.fog.color);
    shared.uTide.value = this.seaLevel;
    // keep the shadow camera centred on the player, snapped to texels to avoid shimmering
    const s = this.sun, dir = skyU.sunDir.value;
    const step = 90 / s.shadow.mapSize.x;
    const cx = Math.round(cam.x / step) * step, cz = Math.round(cam.z / step) * step;
    s.target.position.set(cx, cam.y - 4, cz);
    s.position.set(cx + dir.x * 120, cam.y - 4 + Math.max(0.25, dir.y) * 120, cz + dir.z * 120);
  }
}
