// Six letters the six who stayed wrote to each other on the night of the boats, each left where
// its reader would pass: Skye and Absol to each other, Christian and Charley, Aiden and Luka.
// An envelope (cream paper, a dark red seal) and an interactable; reading one learns it.
import * as THREE from '../../vendor/three.module.min.js';
import { F } from './station.js';
import { textTexture } from './materials.js';
import { CON, QUAY } from './city.js';
import { DF } from './deep.js';
import { ISLE, RISE } from './isles.js';

const deg = Math.PI / 180;

export function buildLetters(W) {
  const M = W.M;
  const spots = [
    // Absol: on the airlock bench, where you would sit to put your boots on
    { id: 'letterPell', chunk: 'station', x: Math.sin(196 * deg) * 13.0 + 0.1, y: F + 0.485, z: Math.cos(196 * deg) * 13.0, yaw: 0.5, to: 'Absol', from: 'Skye', label: 'Read the letter for Absol' },
    // Skye: sticking out of a Vale Court mailbox
    { id: 'letterJuniper', chunk: 'apartments', x: -20.88, y: CON + 1.86, z: -91.66, yaw: 0, upright: true, to: 'Skye', from: 'Absol', label: 'Read the letter for Skye' },
    // Charley: on the crates in the old shelter on the Service Walk
    { id: 'letterSef', chunk: 'quay', x: 28.6, y: QUAY + 0.41, z: -114.7, yaw: 1.2, to: 'Charley', from: 'Christian', label: 'Read the letter for Charley' },
    // Aiden: weighed down with a stone on a barrel on Verdant Rise
    { id: 'letterKeeper', chunk: 'rise', x: RISE.x - 8, y: RISE.top + 0.955, z: RISE.z + 6, yaw: -0.4, stone: true, to: 'Aiden', from: 'Luka', label: 'Read the letter for Aiden' },
    // Christian: on the cot in the keeper's hut on Lantern Isle
    { id: 'letterGardener', chunk: 'isle', x: ISLE.x + 4.5 - 1.6, y: ISLE.top + 0.655, z: ISLE.z + 2.5 + 1.1, yaw: 2.2, to: 'Christian', from: 'Charley', label: 'Read the letter for Christian' },
    // Luka: on a crate in the Deep antechamber, by the lock
    { id: 'letterPilot', chunk: 'ante', x: -3.6, y: DF + 0.645, z: -184, yaw: 0.3, to: 'Luka', from: 'Aiden', label: 'Read the letter for Luka' }
  ];
  for (const s of spots) {
    const ch = W.named[s.chunk];
    if (!ch) { console.warn('letters: no chunk', s.chunk); continue; }
    // the name on the front, in the writer's hand
    const face = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.13), new THREE.MeshStandardMaterial({ map: textTexture([{ text: s.to, hand: true, size: 80, color: '#2a2430' }, { text: 'from ' + s.from, hand: true, size: 38, color: '#5a4a44' }], { w: 320, h: 208, size: 80, color: '#2a2430', bg: '#e6dabd', style: 'marker' }), roughness: 0.9, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
    face.receiveShadow = true;
    if (s.upright) {
      // half out of a slot: standing on its edge, tipped forward
      ch.box(s.x, s.y, s.z, 0.2, 0.13, 0.008, M.paint, { yaw: s.yaw, pitch: 0.25, collide: false, ao: 0, tint: 0xe8dcc0 });
      // on the side that faces out of the slot, tipped with the envelope
      const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0.25, s.yaw, 0, 'YXZ'));
      face.quaternion.copy(q).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI));
      face.position.set(s.x, s.y + 0.065, s.z).add(new THREE.Vector3(0, 0, -0.0055).applyQuaternion(q));
      face.scale.set(0.98, 0.98, 1);
    } else {
      ch.box(s.x, s.y, s.z, 0.22, 0.008, 0.15, M.paint, { yaw: s.yaw, collide: false, ao: 0, tint: 0xe8dcc0 });
      face.position.set(s.x, s.y + 0.0095, s.z);
      face.rotation.set(-Math.PI / 2, 0, 0); face.rotateOnWorldAxis(new THREE.Vector3(0, 1, 0), s.yaw);
      // the seal sits in the corner, clear of the name
      const sx = s.x + Math.cos(s.yaw) * 0.088 + Math.sin(s.yaw) * 0.056, sz = s.z - Math.sin(s.yaw) * 0.088 + Math.cos(s.yaw) * 0.056;
      ch.cyl(sx, s.y + 0.008, sz, 0.016, 0.005, M.fabricRed, { seg: 10, collide: false, tint: 0x8a2a22 });
      if (s.stone) ch.cyl(s.x - 0.06, s.y + 0.01, s.z - 0.035, 0.04, 0.035, M.stone, { seg: 7, collide: false });
    }
    ch.mesh(face);
    W.addInteract({ id: s.id, x: s.x, y: s.y + 0.1, z: s.z, r: 1.8, label: s.label });
  }
}
