// Reusable set dressing. Every prop rests on something; nothing floats.
import * as THREE from '../../vendor/three.module.min.js';
import { textTexture } from './materials.js';
import { writeOn } from './lettering.js';

const TAU = Math.PI * 2;

// a straight railing between two points at floor height y (posts, top rail, mid rail)
export function railing(ch, M, x0, z0, x1, z1, y, o = {}) {
  const len = Math.hypot(x1 - x0, z1 - z0), yaw = Math.atan2(x1 - x0, z1 - z0);
  const h = o.h ?? 1.05, mat = o.mat || M.metal;
  const n = Math.max(1, Math.round(len / (o.spacing || 1.6)));
  for (let i = 0; i <= n; i++) {
    const t = i / n, x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
    ch.box(x, y, z, 0.07, h, 0.07, mat, { collide: false, ao: 0 });
  }
  const mx = (x0 + x1) / 2, mz = (z0 + z1) / 2;
  ch.box(mx, y + h - 0.05, mz, 0.09, 0.07, len + 0.06, o.top || M.brass, { yaw, collide: false, ao: 0 });
  ch.box(mx, y + h * 0.5, mz, 0.04, 0.04, len, mat, { yaw, collide: false, ao: 0 });
  // invisible barrier, a little taller than the rail so you cannot hop it
  if (o.collide !== false) ch.collider({ type: 'box', x: mx, y: y + 0.9, z: mz, hx: 0.12, hy: 1.0, hz: len / 2 + 0.05, yaw, rail: true });
}

// railing that follows a circle
export function ringRailing(ch, M, cx, cz, r, y, a0 = 0, a1 = TAU, o = {}) {
  const n = Math.max(4, Math.round((a1 - a0) * r / 1.4));
  for (let i = 0; i < n; i++) {
    const u0 = a0 + (a1 - a0) * i / n, u1 = a0 + (a1 - a0) * (i + 1) / n;
    railing(ch, M, cx + Math.sin(u0) * r, cz + Math.cos(u0) * r, cx + Math.sin(u1) * r, cz + Math.cos(u1) * r, y, { ...o, spacing: 99 });
  }
}

// lamp post: base, pole, arm, lantern head; registers a warm light
export function lampPost(W, ch, x, y, z, o = {}) {
  const M = W.M, h = o.h ?? 3.4, yaw = o.yaw || 0;
  ch.cyl(x, y, z, 0.16, 0.25, M.steel, { seg: 10 });
  ch.cyl(x, y + 0.25, z, 0.06, h - 0.25, M.steel, { seg: 8, collide: false });
  ch.collider({ type: 'cyl', x, z, r: 0.12, y0: y, y1: y + h });
  const ax = x + Math.sin(yaw) * 0.45, az = z + Math.cos(yaw) * 0.45;
  ch.box((x + ax) / 2, y + h - 0.06, (z + az) / 2, 0.05, 0.05, 0.5, M.steel, { yaw, collide: false, ao: 0 });
  ch.box(ax, y + h - 0.42, az, 0.26, 0.36, 0.26, M.steel, { yaw, collide: false, ao: 0 });
  ch.box(ax, y + h - 0.38, az, 0.2, 0.26, 0.2, o.cyan ? M.lampCyan : M.lampWarm, { yaw, collide: false, ao: 0 });
  return W.light(ax, y + h - 0.6, az, o.cyan ? 0x5fe8dc : 0xffb46a, o.intensity ?? 7, o.dist ?? 11, { chunk: ch, flicker: o.flicker });
}

// wall-mounted fixture (sconce) facing direction yaw
export function sconce(W, ch, x, y, z, yaw, o = {}) {
  const M = W.M;
  ch.box(x, y, z, 0.34, 0.14, 0.12, M.steel, { yaw, collide: false, ao: 0 });
  ch.box(x + Math.sin(yaw) * 0.05, y + 0.02, z + Math.cos(yaw) * 0.05, 0.28, 0.08, 0.06, o.cyan ? M.lampCyan : M.lampWarm, { yaw, collide: false, ao: 0 });
  // cyan wall lamps throw their light further out and a little softer, so they don't burn a hot spot beside themselves
  const out = o.cyan ? 1.35 : 0.5, k = o.cyan ? 0.8 : 1;
  if (o.light !== false) return W.light(x + Math.sin(yaw) * out, y, z + Math.cos(yaw) * out, o.cyan ? 0x58e0d4 : 0xffb070, (o.intensity ?? 4) * k, o.dist ?? 7, { chunk: ch, flicker: o.flicker });
}

// ceiling strip light (hangs from a ceiling at height ceilY)
export function ceilingLight(W, ch, x, ceilY, z, yaw, o = {}) {
  const M = W.M, len = o.len ?? 1.6;
  ch.box(x, ceilY - 0.12, z, 0.32, 0.12, len, M.steel, { yaw, collide: false, ao: 0 });
  ch.box(x, ceilY - 0.14, z, 0.2, 0.03, len - 0.1, o.cyan ? M.lampCyan : M.white, { yaw, collide: false, ao: 0 });
  if (o.light !== false) return W.light(x, ceilY - 0.6, z, o.color ?? (o.cyan ? 0x6fe8e0 : 0xffd9b0), o.intensity ?? 5, o.dist ?? 9, { chunk: ch, flicker: o.flicker });
}

export function crate(ch, M, x, y, z, s = 0.9, o = {}) {
  const yaw = o.yaw || 0, mat = o.mat || M.wood;
  ch.box(x, y, z, s, s * 0.8, s, mat, { yaw, ao: 0.4, tint: o.tint });
  // banding
  ch.box(x, y + s * 0.15, z, s + 0.03, 0.06, s + 0.03, M.steel, { yaw, collide: false, ao: 0 });
  ch.box(x, y + s * 0.62, z, s + 0.03, 0.06, s + 0.03, M.steel, { yaw, collide: false, ao: 0 });
}

export function barrel(ch, M, x, y, z, o = {}) {
  ch.cyl(x, y, z, 0.32, 0.95, o.mat || M.copper, { seg: 14, tint: o.tint });
  ch.cyl(x, y + 0.2, z, 0.335, 0.05, M.steel, { seg: 14, collide: false });
  ch.cyl(x, y + 0.72, z, 0.335, 0.05, M.steel, { seg: 14, collide: false });
}

export function bench(ch, M, x, y, z, yaw = 0, len = 1.8) {
  const s = Math.sin(yaw), c = Math.cos(yaw);
  for (const k of [-0.42, 0.42]) {
    const lx = x + c * k * len, lz = z - s * k * len;
    ch.box(lx, y, lz, 0.08, 0.42, 0.42, M.steel, { yaw, collide: false, ao: 0.3 });
  }
  // seat of three planks with a gap between, back of two
  for (const k of [-0.15, 0, 0.15]) ch.box(x + s * k, y + 0.42, z + c * k, len, 0.05, 0.135, M.wood, { yaw, collide: false, ao: 0 });
  ch.collider({ type: 'box', x, y: y + 0.235, z, hx: len / 2, hy: 0.235, hz: 0.23, yaw });
  for (const h of [0.58, 0.76]) ch.box(x - s * 0.21, y + h, z - c * 0.21, len, 0.13, 0.04, M.wood, { yaw, collide: false, ao: 0 });
  for (const k of [-0.42, 0.42]) ch.box(x - s * 0.21 + c * k * len, y + 0.47, z - c * 0.21 - s * k * len, 0.05, 0.43, 0.05, M.steel, { yaw, collide: false, ao: 0 });
}

export function table(ch, M, x, y, z, w, d, o = {}) {
  const yaw = o.yaw || 0, h = o.h ?? 0.78, mat = o.mat || M.metal;
  ch.box(x, y + h - 0.05, z, w, 0.05, d, o.top || M.woodDark, { yaw, ao: 0 });
  const s = Math.sin(yaw), c = Math.cos(yaw);
  for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const lx = a * (w / 2 - 0.06), lz = b * (d / 2 - 0.06);
    ch.box(x + lx * c + lz * s, y, z - lx * s + lz * c, 0.05, h - 0.05, 0.05, mat, { yaw, collide: false, ao: 0 });
  }
  // an apron under the top, so it reads as a made table rather than a slab on sticks
  if (o.apron !== false && w > 0.5 && d > 0.4) {
    for (const b of [-1, 1]) {
      const lz = b * (d / 2 - 0.06); ch.box(x + lz * s, y + h - 0.13, z + lz * c, w - 0.14, 0.08, 0.025, o.top || M.woodDark, { yaw, collide: false, ao: 0 });
      const lx = b * (w / 2 - 0.06); ch.box(x + lx * c, y + h - 0.13, z - lx * s, 0.025, 0.08, d - 0.14, o.top || M.woodDark, { yaw, collide: false, ao: 0 });
    }
  }
  ch.collider({ type: 'box', x, y: y + h / 2, z, hx: w / 2, hy: h / 2, hz: d / 2, yaw });
}

// a console desk with a sloped screen
export function console_(W, ch, x, y, z, yaw, o = {}) {
  const M = W.M, s = Math.sin(yaw), c = Math.cos(yaw);
  ch.box(x, y, z, o.w ?? 1.4, 0.92, 0.7, M.panelDark, { yaw });
  ch.box(x - s * 0.18, y + 0.92, z - c * 0.18, (o.w ?? 1.4) - 0.1, 0.42, 0.06, M.steel, { yaw, collide: false, ao: 0, pitch: -0.5 });
  ch.box(x - s * 0.16, y + 0.98, z - c * 0.16, (o.w ?? 1.4) - 0.3, 0.3, 0.02, o.screen || M.screen, { yaw, collide: false, ao: 0, pitch: -0.5 });
  // small indicator row
  for (let i = -2; i <= 2; i++) {
    const lx = i * 0.12;
    ch.box(x + lx * c + s * 0.22, y + 0.92, z - lx * s + c * 0.22, 0.05, 0.02, 0.05, i % 2 ? M.lampCyan : M.lampWarm, { yaw, collide: false, ao: 0 });
  }
}

export function bunk(ch, M, x, y, z, yaw, o = {}) {
  const s = Math.sin(yaw), c = Math.cos(yaw);
  ch.box(x, y, z, 0.95, 0.45, 2.05, M.steel, { yaw, ao: 0.3 });
  ch.box(x, y + 0.45, z, 0.88, 0.16, 1.98, o.sheet || M.fabricPale, { yaw, collide: false, ao: 0 });
  ch.box(x + s * 0.75, y + 0.6, z + c * 0.75, 0.6, 0.12, 0.35, M.fabricPale, { yaw, collide: false, ao: 0, tint: 0xeeeeee });
  // blanket folded at the foot
  if (!o.noBlanket) ch.box(x - s * 0.7, y + 0.6, z - c * 0.7, 0.9, 0.08, 0.5, o.blanket || M.fabricTeal, { yaw, collide: false, ao: 0 });
  // headboard
  ch.box(x + s * 1.04, y, z + c * 1.04, 0.95, 1.1, 0.06, M.steel, { yaw, ao: 0.4 });
}

export function locker(ch, M, x, y, z, yaw, o = {}) {
  ch.box(x, y, z, 0.6, 1.9, 0.5, M.panelDark, { yaw, tint: o.tint });
  const s = Math.sin(yaw), c = Math.cos(yaw);
  ch.box(x + s * 0.252, y + 0.2, z + c * 0.252, 0.02, 1.5, 0.02, M.steel, { yaw, collide: false, ao: 0 });
  for (let i = 0; i < 4; i++) ch.box(x + s * 0.253 + c * 0.12, y + 1.55 + i * 0.05, z + c * 0.253 - s * 0.12, 0.3, 0.015, 0.01, M.steel, { yaw, collide: false, ao: 0 });
}

export function shelf(ch, M, x, y, z, yaw, w = 1.6, o = {}) {
  const h = o.h ?? 2.1, d = 0.42;
  const s = Math.sin(yaw), c = Math.cos(yaw);
  for (const k of [-1, 1]) ch.box(x + c * k * w / 2, y, z - s * k * w / 2, 0.05, h, d, M.steel, { yaw, collide: false, ao: 0 });
  for (let i = 0; i < 5; i++) {
    const yy = y + 0.12 + i * (h - 0.2) / 4;
    ch.box(x, yy, z, w, 0.03, d, M.steel, { yaw, collide: false, ao: 0 });
    if (i < 4 && o.items !== false) {
      // boxes and folders on each shelf
      let off = -w / 2 + 0.1;
      let k = (x * 7 + z * 3 + i * 11) | 0;
      while (off < w / 2 - 0.2) {
        k = (k * 1103515245 + 12345) & 0x7fffffff;
        const bw = 0.08 + (k % 7) * 0.035, bh = 0.18 + ((k >> 3) % 5) * 0.05;
        if ((k >> 5) % 5 !== 0) {
          const t = [0xd8cdb4, 0x9a8a70, 0x6a7a80, 0xb06a4a, 0x8c8c86][(k >> 7) % 5];
          ch.box(x + c * (off + bw / 2), yy + 0.03, z - s * (off + bw / 2), bw - 0.01, bh, d - 0.08, M.paint, { yaw, collide: false, ao: 0, tint: t });
        }
        off += bw;
      }
    }
  }
  ch.collider({ type: 'box', x, y: y + h / 2, z, hx: w / 2, hy: h / 2, hz: d / 2, yaw });
}

export function pipeRun(ch, M, x0, y0, z0, x1, y1, z1, r = 0.12, mat) {
  const len = Math.hypot(x1 - x0, y1 - y0, z1 - z0);
  const g = new THREE.CylinderGeometry(r, r, len, 10, 1, true);
  const dir = new THREE.Vector3(x1 - x0, y1 - y0, z1 - z0).normalize();
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
  const m = new THREE.Matrix4().compose(new THREE.Vector3((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), q, new THREE.Vector3(1, 1, 1));
  ch.geo(g, mat || M.metal, m, {});
  g.dispose();
  // an upright pipe is something you walk into, not through
  if (Math.abs(dir.y) > 0.95) ch.collider({ type: 'cyl', x: (x0 + x1) / 2, z: (z0 + z1) / 2, r, y0: Math.min(y0, y1), y1: Math.max(y0, y1) });
}

// sagging cable between two attachment points
export function cable(ch, M, a, b, sag = 0.6, r = 0.025) {
  const pts = [];
  for (let i = 0; i <= 12; i++) {
    const t = i / 12;
    pts.push(new THREE.Vector3(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t - Math.sin(t * Math.PI) * sag, a[2] + (b[2] - a[2]) * t));
  }
  const g = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 16, r, 5, false);
  ch.geo(g, M.rubber, new THREE.Matrix4(), {});
  g.dispose();
}

// planter box with a small shrub or a dead stalk
export function planter(ch, M, x, y, z, o = {}) {
  const w = o.w ?? 0.9;
  ch.box(x, y, z, w, 0.5, w, M.concreteDark, { ao: 0.3 });
  ch.box(x, y + 0.5, z, w - 0.1, 0.04, w - 0.1, M.soil, { collide: false, ao: 0 });
  if (o.dead) {
    for (let i = 0; i < 3; i++) ch.box(x + (i - 1) * 0.12, y + 0.5, z + (i % 2) * 0.1, 0.03, 0.4 + i * 0.15, 0.03, M.woodDark, { collide: false, ao: 0, roll: (i - 1) * 0.2 });
  } else {
    const g = new THREE.IcosahedronGeometry(w * 0.45, 1);
    ch.geo(g, M.leaf, new THREE.Matrix4().compose(new THREE.Vector3(x, y + 0.5 + w * 0.35, z), new THREE.Quaternion(), new THREE.Vector3(1, 0.8, 1)), { ao: 0.8, aoMin: 0.5 });
    g.dispose();
  }
}

// a potted plant: a terracotta pot, a stem or two, leaves turned towards the light
export function pottedPlant(ch, M, x, y, z, o = {}) {
  const r = o.r ?? 0.22, h = o.h ?? 0.42, seed = o.seed ?? 1;
  ch.cyl(x, y, z, r * 0.78, h, M.paint, { seg: 16, rTop: r, tint: 0xb8643a });
  ch.cyl(x, y + h - 0.05, z, r + 0.02, 0.06, M.paint, { seg: 16, collide: false, tint: 0xa85a34 });
  ch.cyl(x, y + h - 0.03, z, r - 0.02, 0.02, M.soil, { seg: 14, collide: false });
  const q = new THREE.Quaternion(), e = new THREE.Euler();
  const n = o.leaves ?? 15, top = o.tall ?? 0.95;
  for (let k = 0; k < 2; k++) ch.cyl(x + (k - 0.5) * 0.05, y + h - 0.02, z, 0.012, top * (0.8 + k * 0.25), M.woodDark, { seg: 5, collide: false, roll: (k - 0.5) * 0.12, tint: 0x5a6a3a });
  for (let i = 0; i < n; i++) {
    const a = i * 2.39996 + seed, t = i / n, rad = 0.08 + (1 - t) * 0.1, yy = y + h + 0.15 + t * top * 0.85;
    q.setFromEuler(e.set(0.9 - t * 0.5, a, 0, 'YXZ'));
    const g = new THREE.SphereGeometry(1, 8, 6);
    ch.geo(g, i % 3 ? M.leaf : M.leafDark, new THREE.Matrix4().compose(new THREE.Vector3(x + Math.sin(a) * rad, yy, z + Math.cos(a) * rad), q, new THREE.Vector3(0.09, 0.012, 0.16)), { ao: 0.4 });
    g.dispose();
  }
}

// a door that slides sideways along local x when opened
export function slidingDoor(W, ch, x, y, z, w, h, yaw, o = {}) {
  const M = W.M;
  const group = new THREE.Group();
  const leafMat = o.mat || M.panelDark;
  const g = new THREE.BoxGeometry(w, h, o.thick ?? 0.14);
  const leaf = new THREE.Mesh(g, leafMat);
  leaf.castShadow = true; leaf.receiveShadow = true;
  leaf.position.set(0, h / 2, 0);
  group.add(leaf);
  // a light strip down the leaf edge
  const strip = new THREE.Mesh(new THREE.BoxGeometry(0.05, h * 0.7, (o.thick ?? 0.14) + 0.02), o.locked === false ? M.lampCyan : M.lampRed);
  strip.position.set(w / 2 - 0.12, h / 2, 0);
  group.add(strip);
  group.position.set(x, y, z);
  group.rotation.y = yaw;
  W.scene.add(group);
  const col = ch.collider({ type: 'box', x, y: y + h / 2, z, hx: w / 2, hy: h / 2, hz: (o.thick ?? 0.14) / 2 + 0.05, yaw });
  const door = { group, leaf, strip, col, open: 0, target: 0, w, h, yaw, chunk: ch, speed: o.speed ?? 1.4 };
  door.set = (v) => { door.target = v ? 1 : 0; };
  door.update = (dt) => {
    door.open += Math.sign(door.target - door.open) * Math.min(Math.abs(door.target - door.open), dt * door.speed);
    leaf.position.x = -door.open * (w - 0.1);
    strip.position.x = w / 2 - 0.12 - door.open * (w - 0.1);
    strip.material = door.target ? M.lampCyan : (o.idle || M.lampRed);
    col.enabled = door.open < 0.6;
    group.position.y = y + ch.offset.y;
  };
  W.doors.push(door);
  return door;
}

// circular plaque/sign with a canvas texture
export function sign(W, ch, tex, x, y, z, w, h, yaw, o = {}) {
  const m = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.8, metalness: 0.0, transparent: !!o.transparent, emissive: o.glow ? 0xffffff : 0x000000, emissiveMap: o.glow ? tex : null, emissiveIntensity: o.glow || 0 });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m);
  mesh.position.set(x, y, z); mesh.rotation.y = yaw;
  mesh.receiveShadow = true;
  if (o.backing !== false) ch.box(x - Math.sin(yaw) * 0.03, y - h / 2 - 0.04, z - Math.cos(yaw) * 0.03, w + 0.08, h + 0.08, 0.04, o.backMat || W.M.steel, { yaw, collide: o.collide !== false, ao: 0 });
  mesh.position.x += Math.sin(yaw) * 0.002; mesh.position.z += Math.cos(yaw) * 0.002;
  ch.mesh(mesh);
  return mesh;
}

// a soft cone of light hanging under a lamp, for dusty or misty spaces
let coneMat = null;
export function lightCone(W, ch, x, y, z, h, r, color = 0x63f0e2, strength = 0.22) {
  if (!coneMat) {
    coneMat = new THREE.ShaderMaterial({
      uniforms: { col: { value: new THREE.Color(1, 1, 1) } },
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, vertexColors: true,
      vertexShader: 'varying float vY; varying float vRim; varying vec3 vC; void main(){ vC = color; vY = uv.y; vec3 n = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position, 1.0); vRim = abs(dot(n, normalize(-mv.xyz))); gl_Position = projectionMatrix * mv; }',
      fragmentShader: 'varying float vY; varying float vRim; varying vec3 vC; void main(){ float a = pow(vRim, 2.0) * smoothstep(0.0, 0.9, vY) * (0.35 + 0.65 * vY); gl_FragColor = vec4(vC * a, 1.0); }'
    });
  }
  const g = new THREE.CylinderGeometry(0.15, r, h, 20, 1, true);
  const c = new THREE.Color(color).multiplyScalar(strength);
  const cols = []; for (let i = 0; i < g.attributes.position.count; i++) cols.push(c.r, c.g, c.b);
  g.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
  const m = new THREE.Mesh(g, coneMat);
  m.position.set(x, y - h / 2, z);
  m.renderOrder = 2;
  ch.mesh(m);
  return m;
}

// a little hardback lying flat, its title on the cover, that you can pick up and read
export function book(W, ch, x, y, z, yaw, o) {
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = yaw;
  const cover = new THREE.MeshStandardMaterial({ color: o.cover, roughness: 0.85 });
  const b1 = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.032, 0.25), cover); b1.position.y = 0.016; g.add(b1);
  const pg = new THREE.Mesh(new THREE.BoxGeometry(0.172, 0.026, 0.236), new THREE.MeshStandardMaterial({ color: 0xe6dcc4, roughness: 0.95 })); pg.position.set(0.006, 0.016, 0); g.add(pg);
  const lab = new THREE.Mesh(new THREE.PlaneGeometry(0.17, 0.236), new THREE.MeshStandardMaterial({ map: o.tex, roughness: 0.8 }));
  lab.rotation.x = -Math.PI / 2; lab.position.y = 0.0325; g.add(lab);
  g.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
  ch.mesh(g);
  W.addInteract({ id: o.id, x, y: y + 0.1, z, r: 2.0, label: o.label });
  return g;
}

// A note taped to a wall: hand-lettered on paper, two strips of tape across the top corners,
// tilted a little. Flat against the wall (pass the wall's facing as yaw).
export function tapedNote(W, ch, x, y, z, yaw, lines, o = {}) {
  const w = o.w ?? 0.32, h = o.h ?? 0.42, tilt = o.tilt ?? 0.04;
  const tex = textTexture(lines, { w: 320, h: Math.round(320 * h / w), size: o.size ?? 40, color: o.ink || '#2a2430', bg: o.paper || '#eee5cf', style: 'marker', align: o.align || 'center' });
  const paper = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.95, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
  paper.position.set(x + Math.sin(yaw) * 0.004, y, z + Math.cos(yaw) * 0.004);
  paper.rotation.set(0, yaw, tilt, 'YXZ');
  paper.receiveShadow = true;
  ch.mesh(paper);
  // tape
  const tapeMat = new THREE.MeshStandardMaterial({ color: 0xe8dcae, transparent: true, opacity: 0.75, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
  for (const k of [-1, 1]) {
    const t = new THREE.Mesh(new THREE.PlaneGeometry(0.11, 0.035), tapeMat);
    const lx = k * (w / 2 - 0.02), ly = h / 2 - 0.01;
    const cx = lx * Math.cos(tilt) - ly * Math.sin(tilt), cy = lx * Math.sin(tilt) + ly * Math.cos(tilt);
    t.position.set(x + Math.cos(yaw) * cx + Math.sin(yaw) * 0.006, y + cy, z - Math.sin(yaw) * cx + Math.cos(yaw) * 0.006);
    t.rotation.set(0, yaw, tilt - k * 0.6, 'YXZ');
    ch.mesh(t);
  }
  return paper;
}

// a woven rug: stripes and a fringe, lying flat
export function rug(W, ch, x, y, z, w, d, yaw, colors) {
  const c = document.createElement('canvas'); c.width = 256; c.height = Math.round(256 * d / w);
  const g = c.getContext('2d'), cols = colors || ['#6a2c24', '#c08a4a', '#2c3a44', '#d9c9a4'];
  g.fillStyle = cols[0]; g.fillRect(0, 0, c.width, c.height);
  // bands across, with a darker border
  const bands = [0.12, 0.2, 0.42, 0.5, 0.58, 0.8, 0.88];
  bands.forEach((b, i) => { g.fillStyle = cols[1 + (i % (cols.length - 1))]; g.fillRect(0, b * c.height - 4, c.width, 8 + (i === 3 ? 10 : 0)); });
  g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 10; g.strokeRect(10, 10, c.width - 20, c.height - 20);
  // the weave
  for (let i = 0; i < 2600; i++) { g.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.07)'; g.fillRect(Math.random() * c.width, Math.random() * c.height, 2, 1); }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.012, d), new THREE.MeshStandardMaterial({ map: tex, roughness: 1 }));
  m.position.set(x, y + 0.006, z); m.rotation.y = yaw; m.receiveShadow = true;
  ch.mesh(m);
  // fringe at the two short ends
  const fr = new THREE.MeshStandardMaterial({ color: 0xd9c9a4, roughness: 1 });
  for (const k of [-1, 1]) {
    const f = new THREE.Mesh(new THREE.BoxGeometry(w * 0.96, 0.006, 0.05), fr);
    f.position.set(x + Math.sin(yaw) * k * (d / 2 + 0.025), y + 0.003, z + Math.cos(yaw) * k * (d / 2 + 0.025)); f.rotation.y = yaw;
    ch.mesh(f);
  }
  return m;
}

// a plain chair: seat, back, four legs. Faces along yaw.
export function chair(ch, M, x, y, z, yaw, o = {}) {
  const s = Math.sin(yaw), c = Math.cos(yaw), mat = o.mat || M.woodDark;
  ch.box(x, y + 0.42, z, 0.44, 0.05, 0.42, mat, { yaw, ao: 0 });
  // back: two posts and three slats
  for (const a of [-1, 1]) ch.box(x - s * 0.2 + c * a * 0.2, y + 0.47, z - c * 0.2 - s * a * 0.2, 0.04, 0.47, 0.04, mat, { yaw, collide: false, ao: 0 });
  for (let i = 0; i < 3; i++) ch.box(x - s * 0.2, y + 0.58 + i * 0.13, z - c * 0.2, 0.38, 0.07, 0.025, mat, { yaw, collide: false, ao: 0 });
  for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const lx = a * 0.19, lz = b * 0.18;
    ch.box(x + lx * c + lz * s, y, z - lx * s + lz * c, 0.04, 0.42, 0.04, M.steel, { yaw, collide: false, ao: 0 });
  }
}

// a framed painting of the basin: sky, the hills, the water, sometimes the lighthouse or the bridge,
// painted onto a canvas in a few loose strokes; with a brass plate underneath
export function painting(W, ch, x, y, z, yaw, o = {}) {
  const w = o.w ?? 1.0, h = o.h ?? 0.7, M = W.M;
  const c = document.createElement('canvas'); c.width = 384; c.height = Math.round(384 * h / w);
  const g = c.getContext('2d'), Wd = c.width, Hd = c.height;
  let s = o.seed ?? 3; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const sky = g.createLinearGradient(0, 0, 0, Hd * 0.6);
  sky.addColorStop(0, o.sky0 || '#4a3a6a'); sky.addColorStop(1, o.sky1 || '#e8a06a');
  g.fillStyle = sky; g.fillRect(0, 0, Wd, Hd);
  // the sun or the moon
  g.fillStyle = o.orb || 'rgba(255,236,200,.9)'; g.beginPath(); g.arc(Wd * (0.2 + r() * 0.6), Hd * (0.18 + r() * 0.2), Hd * 0.06, 0, 7); g.fill();
  // hills, two layers
  for (const [col, base, amp] of [[o.far || '#6a5a7a', 0.55, 0.12], [o.near || '#3a3048', 0.62, 0.08]]) {
    g.fillStyle = col; g.beginPath(); g.moveTo(0, Hd);
    for (let i = 0; i <= 12; i++) g.lineTo(Wd * i / 12, Hd * (base - amp * (0.4 + 0.6 * r())));
    g.lineTo(Wd, Hd); g.fill();
  }
  // water, with streaks of reflected light
  g.fillStyle = o.water || '#2a3a4e'; g.fillRect(0, Hd * 0.64, Wd, Hd);
  for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(255,220,180,' + (0.1 + r() * 0.25) + ')'; g.fillRect(Wd * (0.3 + r() * 0.4), Hd * (0.66 + r() * 0.3), 6 + r() * 30, 2); }
  if (o.lighthouse) { g.fillStyle = '#e8e2d6'; g.fillRect(Wd * 0.72, Hd * 0.4, Wd * 0.03, Hd * 0.25); g.fillStyle = '#ffd890'; g.fillRect(Wd * 0.715, Hd * 0.37, Wd * 0.04, Hd * 0.04); }
  if (o.bridge) { g.strokeStyle = '#1e1a24'; g.lineWidth = 4; g.beginPath(); g.moveTo(0, Hd * 0.5); g.quadraticCurveTo(Wd * 0.5, Hd * 0.42, Wd, Hd * 0.5); g.stroke(); for (let i = 1; i < 8; i++) { g.beginPath(); g.moveTo(Wd * i / 8, Hd * 0.47); g.lineTo(Wd * i / 8, Hd * 0.64); g.stroke(); } }
  if (o.boat) { g.fillStyle = '#1e1a24'; g.beginPath(); g.moveTo(Wd * 0.3, Hd * 0.72); g.lineTo(Wd * 0.42, Hd * 0.72); g.lineTo(Wd * 0.4, Hd * 0.75); g.lineTo(Wd * 0.32, Hd * 0.75); g.fill(); g.fillStyle = '#63f0e2'; g.fillRect(Wd * 0.36, Hd * 0.68, 4, 4); }
  // brush texture over everything
  for (let i = 0; i < 1800; i++) { g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,.04)' : 'rgba(0,0,0,.05)'; g.fillRect(r() * Wd, r() * Hd, 4 + r() * 10, 2); }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sn = Math.sin(yaw), cs = Math.cos(yaw);
  // frame: four mitred bars, then the canvas a little inset
  const fw = 0.06, fd = 0.05, fm = o.frame || M.woodDark;
  ch.box(x, y + h / 2, z, w + fw * 2, fw, fd, fm, { yaw, collide: false, ao: 0 });
  ch.box(x, y - h / 2 - fw, z, w + fw * 2, fw, fd, fm, { yaw, collide: false, ao: 0 });
  for (const k of [-1, 1]) ch.box(x + cs * k * (w / 2 + fw / 2), y - h / 2, z - sn * k * (w / 2 + fw / 2), fw, h, fd, fm, { yaw, collide: false, ao: 0 });
  const pic = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.85 }));
  pic.position.set(x + sn * 0.01, y, z + cs * 0.01); pic.rotation.y = yaw; pic.receiveShadow = true;
  ch.mesh(pic);
  // brass plate
  ch.box(x + sn * 0.012, y - h / 2 - fw - 0.13, z + cs * 0.012, 0.22, 0.06, 0.01, M.brass, { yaw, collide: false, ao: 0 });
}

// an oilskin coat hung on a hook: shoulders, body, a hood hanging behind
// an oilskin hung from a hook by its collar: a soft tapering body, shoulders, sleeves hanging
// by its sides, a collar and three toggles down the front
export function coat(ch, M, x, y, z, yaw, color) {
  const s = Math.sin(yaw), c = Math.cos(yaw), q = new THREE.Quaternion(), e = new THREE.Euler();
  const place = (geo, lx, ly, lz, sx = 1, sy = 1, sz = 1, roll = 0, pitch = 0, tint = color) => {
    q.setFromEuler(e.set(pitch, yaw, roll, 'YXZ'));
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x + c * lx + s * lz, y + ly, z - s * lx + c * lz), q, new THREE.Vector3(sx, sy, sz));
    ch.geo(geo, M.paint, m, { ao: 0, tint }); geo.dispose();
  };
  const dark = new THREE.Color(color).multiplyScalar(0.62).getHex();
  ch.cyl(x - s * 0.02, y - 0.06, z - c * 0.02, 0.02, 0.08, M.steel, { seg: 6, collide: false });
  place(new THREE.CylinderGeometry(0.16, 0.26, 0.95, 16, 3), 0, -0.6, 0.1, 1, 1, 0.44, 0, 0.04);
  place(new THREE.CylinderGeometry(0.262, 0.262, 0.05, 16), 0, -1.05, 0.12, 1, 1, 0.46, 0, 0.04, dark);
  place(new THREE.SphereGeometry(1, 16, 10), 0, -0.17, 0.09, 0.22, 0.085, 0.085);
  place(new THREE.CylinderGeometry(0.075, 0.1, 0.09, 14), 0, -0.1, 0.085, 1, 1, 0.7, 0, 0, dark);
  for (const k of [-1, 1]) {
    place(new THREE.CylinderGeometry(0.052, 0.068, 0.6, 10), k * 0.2, -0.48, 0.12, 1, 1, 0.85, -k * 0.09);
    place(new THREE.CylinderGeometry(0.07, 0.07, 0.05, 10), k * 0.227, -0.79, 0.12, 1, 1, 0.85, -k * 0.09, 0, dark);
  }
  for (let i = 0; i < 3; i++) place(new THREE.BoxGeometry(0.05, 0.016, 0.02), 0, -0.34 - i * 0.2, 0.2 + i * 0.008, 1, 1, 1, 0, 0, 0x2a2420);
}

// a canvas camp cot with a folded blanket and a pillow; long side along yaw
export function cot(ch, M, x, y, z, yaw, blanket = 0x6a4a3a) {
  const s = Math.sin(yaw), c = Math.cos(yaw), q = new THREE.Quaternion(), e = new THREE.Euler();
  const P = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c];
  const put = (geo, mat, lx, ly, lz, rx = 0, rz = 0, sc = [1, 1, 1], tint) => {
    const [px, pz] = P(lx, lz); q.setFromEuler(e.set(rx, yaw, rz, 'YXZ'));
    ch.geo(geo, mat, new THREE.Matrix4().compose(new THREE.Vector3(px, y + ly, pz), q, new THREE.Vector3(...sc)), { ao: 0, tint }); geo.dispose();
  };
  // folding legs, crossed at each end
  for (const b of [-1, 1]) for (const a of [-1, 1]) put(new THREE.CylinderGeometry(0.015, 0.015, 0.42, 6), M.steel, 0, 0.17, b * 0.84, 0, a * 0.95);
  // the two side rails and the end bars, the canvas slung between them and sagging a little
  for (const a of [-1, 1]) put(new THREE.CylinderGeometry(0.02, 0.02, 1.9, 8), M.steel, a * 0.33, 0.34, 0, Math.PI / 2);
  for (const b of [-1, 1]) put(new THREE.CylinderGeometry(0.018, 0.018, 0.66, 8), M.steel, 0, 0.34, b * 0.93, 0, Math.PI / 2);
  for (let i = 0; i < 6; i++) { const t = i / 5 - 0.5, sag = 0.035 * Math.cos(t * Math.PI); put(new THREE.BoxGeometry(0.66, 0.014, 0.31), M.fabricTeal, 0, 0.335 - sag, t * 1.55, 0, 0, [1, 1, 1], 0x8a8a70); }
  ch.collider({ type: 'box', x, y: y + 0.18, z, hx: 0.36, hy: 0.18, hz: 0.95, yaw });
  // a rolled blanket at the foot, a pillow at the head
  put(new THREE.CapsuleGeometry(0.07, 0.42, 4, 12), M.paint, 0, 0.38, -0.68, 0, Math.PI / 2, [1, 0.75, 1], blanket);
  put(new THREE.SphereGeometry(1, 14, 10), M.paint, 0, 0.36, 0.72, 0, 0, [0.22, 0.06, 0.12], 0xd8d0bc);
}

// a printed notice pinned to a wall: drawn by a callback onto aged paper (sun-faded, folded in
// quarters once, a corner lifting), with a pin in each top corner
export function poster(W, ch, x, y, z, yaw, draw, o = {}) {
  const w = o.w ?? 0.6, h = o.h ?? 0.84, M = W.M;
  const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w);
  const g = c.getContext('2d'), Wd = c.width, Hd = c.height;
  let s = o.seed ?? 11; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  g.fillStyle = o.paper || '#e9dfc6'; g.fillRect(0, 0, Wd, Hd);
  const write = (t, x, y, cap, oo = {}) => writeOn(g, t, x, y, cap, { color: oo.color || o.ink || '#2a2430', pen: oo.pen ?? 0.2, wobble: oo.wobble ?? 0.6, slant: oo.slant ?? 0.02, align: oo.align || 'center', seed: oo.seed, maxW: oo.maxW ?? Wd - 60 });
  draw(g, Wd, Hd, write, r);
  // ink a little uneven, paper faded toward the top where the light reaches it
  const fade = g.createLinearGradient(0, 0, 0, Hd); fade.addColorStop(0, 'rgba(240,232,214,.1)'); fade.addColorStop(1, 'rgba(240,232,214,0)');
  g.fillStyle = fade; g.fillRect(0, 0, Wd, Hd);
  for (let i = 0; i < 140; i++) { g.fillStyle = `rgba(${r() < 0.5 ? '120,100,70' : '250,244,230'},${0.02 + r() * 0.05})`; g.beginPath(); g.arc(r() * Wd, r() * Hd, 2 + r() * 16, 0, 7); g.fill(); }
  // fold lines, a soft shadow on one side of each
  g.strokeStyle = 'rgba(90,76,60,.22)'; g.lineWidth = 2;
  g.beginPath(); g.moveTo(Wd / 2 + (r() - 0.5) * 6, 0); g.lineTo(Wd / 2 + (r() - 0.5) * 6, Hd); g.moveTo(0, Hd / 2 + (r() - 0.5) * 6); g.lineTo(Wd, Hd / 2 + (r() - 0.5) * 6); g.stroke();
  g.strokeStyle = 'rgba(255,250,240,.25)'; g.lineWidth = 2;
  g.beginPath(); g.moveTo(Wd / 2 + 3, 0); g.lineTo(Wd / 2 + 3, Hd); g.moveTo(0, Hd / 2 + 3); g.lineTo(Wd, Hd / 2 + 3); g.stroke();
  // the bottom corner curling off the wall
  const k = o.curl ?? 1, cx = k > 0 ? Wd : 0, cs = 46 + r() * 20;
  g.fillStyle = 'rgba(0,0,0,.5)'; g.beginPath(); g.moveTo(cx, Hd - cs); g.lineTo(cx, Hd); g.lineTo(cx - k * cs, Hd); g.closePath(); g.globalCompositeOperation = 'destination-out'; g.fill(); g.globalCompositeOperation = 'source-over';
  g.fillStyle = 'rgba(210,198,172,1)'; g.beginPath(); g.moveTo(cx, Hd - cs); g.lineTo(cx - k * cs * 0.85, Hd - cs * 0.15); g.lineTo(cx - k * cs, Hd); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(80,66,50,.4)'; g.lineWidth = 1.5; g.stroke();
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const paper = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.92, transparent: true, alphaTest: 0.5, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
  paper.position.set(x + Math.sin(yaw) * 0.006, y, z + Math.cos(yaw) * 0.006);
  paper.rotation.set(0, yaw, o.tilt ?? 0, 'YXZ');
  paper.receiveShadow = true;
  ch.mesh(paper);
  for (const kk of [-1, 1]) {
    const lx = kk * (w / 2 - 0.035), ly = h / 2 - 0.035;
    ch.cyl(x + Math.cos(yaw) * lx + Math.sin(yaw) * 0.004, y + ly - 0.007, z - Math.sin(yaw) * lx + Math.cos(yaw) * 0.004, 0.011, 0.014, o.pin || M.fabricRed, { seg: 8, collide: false });
  }
  return paper;
}
