// The Deep (tidal intake beneath South Plaza) and the Core (the pressure ring under the sea).
//   stair shaft      z -158..-182  (y 6 -> -8)
//   antechamber      z -182..-193  tidal lock in the south wall
//   low-water run    z -193..-223  floods outside 06:00-12:00 until the pump is latched
//   laboratory       z -223..-241  pump, protocol, echo recorder, observer lift
//   ramp             z -241..-253  down to y -12, bulkhead
//   Core             centre (0, -12, -275), walkway r 13..20, platform r 4.5 at the centre
import * as THREE from '../../vendor/three.module.min.js';
import { wallLine, room, column, deg } from './arch.js';
import { railing, ringRailing, sconce, ceilingLight, crate, barrel, table, shelf, slidingDoor, sign, pipeRun, cable, console_, lightCone, poster } from './props.js';
import { textTexture, decal, shared } from './materials.js';
import { makePool } from './sky.js';

export const DF = -8;          // Deep floor
export const CF = -12;         // Core floor
export const CORE = { x: 0, z: -275 };

function steps(ch, M, x, yTop, z, w, n, rise, tread, mat, base) {
  for (let i = 0; i < n; i++) {
    const top = yTop - rise * (i + 1);
    ch.box(x, base, z - tread * (i + 0.5), w, top - base, tread + 0.02, mat, { ao: 0 });
  }
}

export function buildDeep(W) {
  const M = W.M;

  // ===================== STAIR SHAFT =====================
  {
    const ch = W.chunk('shaft');
    // flight 1: z -158 -> -168, y 6 -> 0 ; landing ; flight 2: z -171 -> -182, y 0 -> -8
    steps(ch, M, 0, 6, -158, 4.6, 15, 0.4, 0.667, M.concreteDark, -9);
    ch.box(0, -9, -169.5, 4.6, 9, 3.0, M.concreteDark, { ao: 0 });
    steps(ch, M, 0, 0, -171, 4.6, 20, 0.4, 0.55, M.concreteDark, -9);
    // side walls, full height under the plaza, then a sealed tube out under the sea
    for (const k of [-1, 1]) {
      ch.box(k * 2.5, -9, -170, 0.4, 15, 24, M.concrete, { tint: 0x8a8a8a });
      // handrails following each flight
      for (const [za, zb, ya, yb] of [[-158, -168, 6, 0], [-171, -182, 0, -8]]) {
        const L = Math.hypot(za - zb, ya - yb), p = Math.atan2(ya - yb, za - zb);
        const m = new THREE.Matrix4().compose(new THREE.Vector3(k * 2.2, (ya + yb) / 2 + 0.95, (za + zb) / 2), new THREE.Quaternion().setFromEuler(new THREE.Euler(p, 0, 0)), new THREE.Vector3(0.07, 0.07, L));
        ch.geo(new THREE.BoxGeometry(1, 1, 1), M.brass, m, {});
      }
    }
    ch.box(0, 5.6, -168.5, 5.4, 0.4, 11, M.concrete, { ao: 0 });            // cap under the plaza
    // ceiling out under the sea: stepped down with the stairs, and solid all the way up to the lid so
    // there is nothing to see between the steps of the ceiling but concrete
    for (let z = -174; z > -182; z -= 2) {
      const top = Math.max(0 - 0.4 * Math.floor((-171 - (z)) / 0.55), -8);
      const under = Math.max(top, -8) + 3.4;
      ch.box(0, under, z - 1, 5.4, 6 - under, 2.02, M.concrete, { ao: 0 });
    }
    ch.box(0, 5.6, -178.1, 5.4, 0.4, 8.2, M.concrete, { ao: 0 });                // lid over the tube
    // wall lights down the flights
    for (const [z, y] of [[-161, 4.6], [-166, 2.4], [-169.5, 1.6], [-175, -1.0], [-180, -4.2]]) {
      sconce(W, ch, (z % 2 ? -2.27 : 2.27), y + 1.6, z, z % 2 ? Math.PI / 2 : -Math.PI / 2, { cyan: true, intensity: 6, dist: 9 });
    }
    // painted depth marks on the wall
    for (const [z, y, t] of [[-163.5, 4.4, '+2 m'], [-169.5, 1.5, '0 m  mean sea level'], [-176, -2.2, '-4 m'], [-181, -6.0, '-8 m']]) {
      const tex = textTexture([t], { w: 512, h: 64, size: 40, color: '#d9d2bf', align: 'left' });
      const m = decal(tex, 2.4, 0.3); m.position.set(-2.29, y + 0.4, z); m.rotation.y = Math.PI / 2; ch.mesh(m);
    }
  }

  // ===================== ANTECHAMBER =====================
  {
    const ch = W.chunk('ante');
    room(ch, M, -5, -193, 5, -182, DF, 5, { wall: M.concrete, floorMat: M.tile, sides: { n: [{ t: 5, w: 4.6, h: 4.6, frame: false }], s: [{ t: 5, w: 2.2, h: 2.9 }] } });
    W.tideDoor = slidingDoor(W, ch, 0, DF, -192.85, 2.2, 2.9, 0, { mat: M.steel, thick: 0.3, speed: 0.6 });
    // keypad
    ch.box(1.9, DF + 1.0, -192.6, 0.32, 0.5, 0.08, M.panelDark, { collide: false, ao: 0 });
    ch.box(1.9, DF + 1.3, -192.55, 0.22, 0.1, 0.02, M.screen, { collide: false, ao: 0, tint: 0xff8866 });
    W.addInteract({ id: 'tideDoor', x: 1.9, y: DF + 1.3, z: -192.3, r: 2.0, label: 'Use the tidal lock' });
    // tide gauge board: a painted scale and a needle that follows the water beyond the lock
    const gt = textTexture([{ text: 'INTAKE LEVEL', size: 34, color: '#f2a65a' }, 'HIGH', ' ', ' ', 'PASSABLE', ' ', 'LOW'], { w: 256, h: 512, size: 30, color: '#d9d2bf', bg: '#1a1f24', lh: 1.6 });
    sign(W, ch, gt, -3.0, DF + 1.8, -192.6, 0.7, 1.4, 0, {});
    const needle = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.03), M.lampRed);
    needle.position.set(-3.0, DF + 1.8, -192.5); ch.mesh(needle); W.tideNeedle = needle;
    // benches, a cart of sample jars, lights
    for (const x of [-4.4, 4.4]) ch.box(x, DF, -187, 0.6, 0.45, 3.2, M.steel, {});
    crate(ch, M, -3.6, DF, -184, 0.8, { mat: M.panelDark });
    ceilingLight(W, ch, 0, DF + 5, -187.5, 0, { cyan: true, len: 2, intensity: 5.0, dist: 12 });
    lightCone(W, ch, 0, DF + 4.8, -187.5, 4.8, 2.2, 0x63f0e2, 0.14);
    sconce(W, ch, -4.85, DF + 2.6, -186, Math.PI / 2, { intensity: 4, dist: 7 }); sconce(W, ch, 4.85, DF + 2.6, -189, -Math.PI / 2, { intensity: 4, dist: 7 });
    pipeRun(ch, M, -4.6, DF + 4.4, -182.5, -4.6, DF + 4.4, -192.5, 0.18, M.copper);
    pipeRun(ch, M, 4.6, DF + 4.2, -182.5, 4.6, DF + 4.2, -192.5, 0.12, M.steel);
    sign(W, ch, textTexture(['THE DEEP', { text: 'tidal intake · low-water laboratory', size: 30 }], { w: 768, h: 160, size: 60, color: '#d9d2bf', bg: '#1b2026' }), 0, DF + 3.6, -192.62, 2.6, 0.55, 0, {});
  }

  // ===================== LOW-WATER RUN =====================
  {
    const ch = W.chunk('run');
    const z0 = -223, z1 = -193;
    // channel floor and grated walkway
    ch.box(0, DF - 2.0, (z0 + z1) / 2, 5.4, 0.4, 30, M.concreteDark, { ao: 0 });
    ch.box(0, DF - 0.12, (z0 + z1) / 2, 2.4, 0.12, 30, M.steel, { ao: 0, tint: 0x9aa0a6 });
    for (let z = z1 - 1.5; z > z0; z -= 3) ch.box(0, DF - 1.6, z, 0.3, 1.5, 0.3, M.steel, { ao: 0 });
    // walls and ceiling
    for (const k of [-1, 1]) ch.box(k * 2.9, DF - 2, (z0 + z1) / 2, 0.6, 7.5, 30, M.concrete, { tint: 0x7f8a8a });
    ch.box(0, DF + 4.5, (z0 + z1) / 2, 6.4, 0.5, 30, M.concrete, { ao: 0 });
    // big intake pipes along both walls
    for (const k of [-1, 1]) {
      pipeRun(ch, M, k * 2.2, DF + 3.2, z1, k * 2.2, DF + 3.2, z0, 0.32, M.copper);
      for (let z = z1 - 2; z > z0; z -= 4) ch.box(k * 2.3, DF + 2.7, z, 0.5, 0.12, 0.25, M.steel, { collide: false, ao: 0 });
    }
    // waterline marks on the walls
    for (let z = z1 - 4; z > z0; z -= 8) {
      const tex = textTexture(['— high water —'], { w: 512, h: 64, size: 34, color: '#b9c9c4' });
      const m = decal(tex, 1.8, 0.22, { opacity: 0.6 }); m.position.set(-2.59, DF + 2.0, z); m.rotation.y = Math.PI / 2; ch.mesh(m);
    }
    for (let z = z1 - 3; z > z0; z -= 7.5) { ceilingLight(W, ch, 0, DF + 4.5, z, 0, { cyan: true, len: 1.4, intensity: 6.5, dist: 11 }); lightCone(W, ch, 0, DF + 4.3, z, 5.8, 1.6, 0x63f0e2, 0.16); }
    // the water itself
    const pool = makePool(5.2, 30, { color: 0x0c2a30, opacity: 0.88 });
    pool.position.set(0, DF + 2.6, (z0 + z1) / 2);
    W.scene.add(pool);
    W.runWater = pool;
    W.runZ = [z0, z1];
  }

  // ===================== LABORATORY =====================
  {
    const ch = W.chunk('lab');
    const x0 = -11, x1 = 11, z0 = -241, z1 = -223, H = 7;
    room(ch, M, x0, z0, x1, z1, DF, H, { wall: M.concrete, floorMat: M.tile, sides: { n: [{ t: 11, w: 4.6, h: 4.4, frame: false }], s: [{ t: 11, w: 4.0, h: 3.6 }] } });
    // ribs on the ceiling
    for (let z = -225; z > -240; z -= 3) ch.box(0, DF + H - 0.5, z, 21.4, 0.5, 0.35, M.steel, { collide: false, ao: 0 });
    for (const [x, z] of [[-6, -228], [6, -228], [-6, -236], [6, -236]]) { ceilingLight(W, ch, x, DF + H - 0.5, z, 0, { cyan: true, len: 2, intensity: 8.6, dist: 14 }); lightCone(W, ch, x, DF + H - 0.7, z, H - 0.7, 2.4, 0x63f0e2, 0.12); }
    // the bypass pump: a big wheel-and-latch on the west wall
    ch.box(-10.3, DF, -232, 1.0, 3.6, 3.2, M.steel, {});
    ch.cyl(-9.75, DF + 2.0, -232, 1.0, 0.18, M.copper, { seg: 24, roll: Math.PI / 2, collide: false });
    for (let i = 0; i < 4; i++) ch.box(-9.65, DF + 2.0, -232, 0.08, 1.8, 0.08, M.steel, { collide: false, ao: 0, pitch: i * Math.PI / 4 });
    const latch = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.0, 0.2), M.hazard);
    latch.geometry.translate(0, 0.45, 0);
    latch.position.set(-9.6, DF + 1.0, -230.3); latch.rotation.x = -0.8; ch.mesh(latch); W.pumpLatch = latch;
    pipeRun(ch, M, -10.6, DF + 3.6, -232, -10.6, DF + H, -232, 0.3, M.copper);
    W.addInteract({ id: 'pump', x: -9.6, y: DF + 1.3, z: -231, r: 2.2, label: 'Work the bypass pump' });
    W.pumpLight = W.light(-9, DF + 3, -232, 0xff5a3c, 4, 7, { chunk: ch });
    // protocol lectern with a laminated card
    ch.box(-4, DF, -239.4, 0.5, 1.05, 0.4, M.steel, {});
    ch.box(-4, DF + 1.05, -239.3, 0.7, 0.05, 0.5, M.paint, { collide: false, ao: 0, pitch: 0.45, tint: 0xe4dcc6 });
    W.addInteract({ id: 'protocol', x: -4, y: DF + 1.2, z: -239.1, r: 2.0, label: 'Read the routing procedure' });
    // the phase bench (a long instrument table with three dead switches: a rehearsal of the real thing)
    table(ch, M, -5.5, DF, -227.2, 3.6, 1.0, { top: M.steel });
    for (let i = 0; i < 3; i++) {
      ch.box(-6.5 + i, DF + 0.78, -227.2, 0.4, 0.12, 0.3, M.panelDark, { collide: false, ao: 0 });
      ch.box(-6.5 + i, DF + 0.9, -227.2, 0.08, 0.2, 0.08, [M.lampCyan, M.lampWarm, M.lampRed][i], { collide: false, ao: 0 });
    }
    // technician's desk and recording
    table(ch, M, 6.5, DF, -239.2, 2.0, 0.8, {});
    ch.box(6.2, DF + 0.78, -239.2, 0.34, 0.14, 0.26, M.steel, { collide: false, ao: 0 });
    ch.cyl(6.2, DF + 0.92, -239.2, 0.06, 0.24, M.brass, { seg: 10, roll: Math.PI / 2, collide: false });
    W.addInteract({ id: 'deepLog', x: 6.2, y: DF + 1.0, z: -239.0, r: 2.0, label: 'Play the technician’s cylinder' });
    shelf(ch, M, 9.6, DF, -239.9, Math.PI, 2.0);
    // warm task lamps over the desk and the lectern, so the lab is not all one colour
    for (const [lx, lz] of [[6.5, -239.2], [-4, -239.4]]) {
      ch.box(lx, DF + 0.78, lz - 0.2, 0.04, 0.5, 0.04, M.steel, { collide: false, ao: 0 });
      ch.box(lx, DF + 1.25, lz - 0.05, 0.2, 0.08, 0.26, M.lampWarm, { collide: false, ao: 0 });
      W.light(lx, DF + 1.6, lz + 0.3, 0xffc890, 4, 6, { chunk: ch });
    }
    // echo recorder: a cabinet with two reels
    ch.box(10.3, DF, -233.5, 1.0, 1.9, 2.0, M.panelDark, {});
    for (const dz of [-0.45, 0.45]) ch.cyl(9.78, DF + 1.45, -233.5 + dz, 0.32, 0.06, M.steel, { seg: 20, roll: Math.PI / 2, collide: false });
    ch.box(9.78, DF + 0.85, -233.5, 0.04, 0.3, 1.2, M.screen, { collide: false, ao: 0 });
    W.reels = [];
    for (const dz of [-0.45, 0.45]) { const r = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.5, 0.06), M.brass); r.position.set(9.74, DF + 1.45, -233.5 + dz); ch.mesh(r); W.reels.push(r); }
    W.addInteract({ id: 'echo', x: 9.6, y: DF + 1.2, z: -233.5, r: 2.0, label: 'Use the echo recorder' });
    // observer lift (north-east corner)
    for (const [a, b] of [[7.9, -223.5], [10.6, -223.5], [7.9, -226.6], [10.6, -226.6]]) ch.box(a, DF, b, 0.14, 3.6, 0.14, M.steel, { ao: 0 });
    ch.box(9.25, DF + 3.6, -225.05, 3.0, 0.2, 3.4, M.steel, { collide: false, ao: 0 });
    ch.box(10.6, DF + 0.1, -225.05, 0.04, 3.4, 3.0, M.steel, { tint: 0x444444, ao: 0 });
    W.liftGateDeep = slidingDoor(W, ch, 7.9, DF, -225.05, 2.8, 2.6, Math.PI / 2, { mat: M.steel, thick: 0.06, speed: 1.0 });
    ch.box(7.5, DF, -227.4, 0.35, 1.15, 0.25, M.panelDark, {});
    W.liftLampDeep = W.light(7.5, DF + 1.5, -227.4, 0xff5a3c, 2, 4, { chunk: ch });
    W.addInteract({ id: 'liftDeep', x: 7.5, y: DF + 1.1, z: -227.1, r: 2.0, label: 'Call the observer lift' });
    // a lab that was worked in: filing cabinets, a shelf of sample boxes, the intake tide pinned up
    for (const z of [-229.3, -230.0]) {
      ch.box(10.45, DF, z, 0.5, 1.32, 0.66, M.panelDark, { tint: 0x8a9aa0 });
      for (let k = 0; k < 3; k++) ch.box(10.19, DF + 0.25 + k * 0.4, z, 0.02, 0.04, 0.2, M.steel, { collide: false, ao: 0 });
    }
    shelf(ch, M, -10.49, DF, -237.8, Math.PI / 2, 2.0, { h: 2.2 });
    poster(W, ch, -6.2, DF + 2.0, -223.3, Math.PI, (g, Wd, Hd, write) => {
      write('INTAKE TIDE', Wd / 2, 34, 46, { color: '#2c4f7c' });
      write('the run, basin time', Wd / 2, 92, 22, { color: '#5a5462' });
      const x0 = 50, x1 = Wd - 40, y0 = 160, y1 = Hd - 120, X = (m) => x0 + (x1 - x0) * m / 22;
      // the dry window, shaded
      g.fillStyle = 'rgba(217,119,46,.22)'; g.fillRect(X(6), y0, X(12) - X(6), y1 - y0);
      g.strokeStyle = '#2a2430'; g.lineWidth = 2; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x0, y1); g.lineTo(x1, y1); g.stroke();
      // water level: high, out between six and twelve, back in after
      g.strokeStyle = '#2f7f86'; g.lineWidth = 5; g.beginPath();
      for (let m = 0; m <= 22; m += 0.1) { const lvl = m < 5 ? 0.85 : m < 6 ? 0.85 - (m - 5) * 0.75 : m < 12 ? 0.1 : m < 13 ? 0.1 + (m - 12) * 0.8 : 0.9; const y = y1 - (y1 - y0) * lvl; if (m === 0) g.moveTo(X(m), y); else g.lineTo(X(m), y); }
      g.stroke();
      for (const m of [0, 6, 12, 22]) write(String(m).padStart(2, '0') + ':00', X(m), y1 + 14, 20, { color: '#2a2430', maxW: 90 });
      write('DRY', (X(6) + X(12)) / 2, y1 - 70, 34, { color: '#c4581e' });
      write('pump at the far end', Wd / 2, Hd - 64, 22, { color: '#5a5462' });
    }, { seed: 41, w: 0.75, h: 0.95, paper: '#e6e2d4' });
    // crates, barrels, cabling
    crate(ch, M, -8.8, DF, -224.6, 0.9, { mat: M.panelDark }); crate(ch, M, -7.8, DF, -224.5, 0.7, { mat: M.panelDark, yaw: 0.3 });
    barrel(ch, M, 4, DF, -224.4); barrel(ch, M, 4.7, DF, -224.6, { tint: 0x88aa99 });
    cable(ch, M, [-9.6, DF + 3.6, -232], [-5.5, DF + 0.8, -227.2], 0.6, 0.04);
    cable(ch, M, [10, DF + 1.9, -233], [6.2, DF + 0.8, -239.2], 0.0, 0.03);
  }

  // ===================== RAMP & BULKHEAD =====================
  {
    const ch = W.chunk('ramp');
    ch.ramp(0, -247, 4.0, 12, CF, DF, 0.5, M.concreteDark, {});
    for (const k of [-1, 1]) ch.box(k * 2.3, CF - 1, -247, 0.6, 9.5, 12.4, M.concrete, { tint: 0x7a7f88 });
    ch.box(0, DF + 3.4, -247, 5.2, 0.5, 12.4, M.concrete, { ao: 0 });
    for (const z of [-243, -247.5, -251.5]) sconce(W, ch, 1.99, (DF + CF) / 2 + 2.5 + (z + 247) * 0.33, z, -Math.PI / 2, { cyan: true, intensity: 6, dist: 8 });
    // bulkhead: a round door in a thick ring
    for (const k of [-1, 1]) ch.box(k * 2.2, CF, -253.4, 1.4, 6, 0.8, M.steel, {});
    ch.box(0, CF + 3.4, -253.4, 3.0, 2.6, 0.8, M.steel, {});
    W.bulkDoor = slidingDoor(W, ch, 0, CF, -253.4, 3.0, 3.4, 0, { mat: M.brass, thick: 0.5, speed: 0.35 });
    // the tester console
    ch.box(1.72, CF + 0.3, -251.6, 0.5, 1.3, 0.7, M.panelDark, {});
    ch.box(1.46, CF + 1.2, -251.6, 0.02, 0.24, 0.45, M.screen, { collide: false, ao: 0 });
    W.addInteract({ id: 'bulkhead', x: 1.3, y: CF + 1.3, z: -251.6, r: 2.0, label: 'Use the bulkhead tester' });
    const cnt = textTexture([{ text: 'REHEARSALS', size: 34 }, { text: '4,812', size: 64, color: '#f2a65a' }], { w: 512, h: 192, color: '#cfd8d4', bg: '#14181c' });
    sign(W, ch, cnt, -1.98, CF + 1.9, -251.4, 0.9, 0.34, Math.PI / 2, {});
  }

  // ===================== THE CORE =====================
  {
    const ch = W.chunk('core');
    const { x: cx, z: cz } = CORE;
    // walkway annulus and the outer wall; the wall rises out of the sea as the vent
    ch.ring(cx, CF - 1.2, cz, 13, 20.2, 1.2, M.concreteDark, {});
    ch.ring(cx, CF, cz, 13.1, 20, 0.02, M.tile, { collide: false });
    ringRailing(ch, M, cx, cz, 13.25, CF, 0.13, Math.PI * 2 - 0.13, { h: 1.05 });
    // north opening for the bulkhead (|x| < 1.6)
    {
      const a = Math.asin(1.7 / 20.4);
      ch.ring(cx, CF, cz, 20.2, 21.2, 20, M.concrete, { a0: Math.PI + a - Math.PI, a1: Math.PI - a + Math.PI, tint: 0x6a6878 });
      ch.ring(cx, CF + 3.5, cz, 20.2, 21.2, 16.5, M.concrete, { a0: -a, a1: a, tint: 0x6a6878 });
    }
    // connector between the bulkhead and the chamber
    ch.box(0, CF - 1.2, -254.7, 3.6, 1.2, 2.6, M.concreteDark, {});
    for (const k of [-1, 1]) ch.box(k * 1.9, CF, -254.7, 0.4, 3.6, 2.6, M.concrete, {});
    ch.box(0, CF + 3.4, -254.7, 4.2, 0.4, 2.6, M.concrete, { collide: false });
    // roof ring at sea level with an open oculus; buttresses outside
    ch.ring(cx, 6.5, cz, 4.5, 21.2, 0.8, M.concreteDark, { collide: false });
    ch.ring(cx, 7.3, cz, 4.3, 5.2, 1.2, M.brass, { collide: false });
    for (let i = 0; i < 12; i++) {
      const a = i * 30 * deg;
      const s = Math.sin(a), c = Math.cos(a);
      ch.box(cx + s * 21.6, -14, cz + c * 21.6, 1.6, 21.5, 2.2, M.concreteDark, { yaw: a, collide: false });
      // interior ribs
      ch.box(cx + s * 19.9, CF, cz + c * 19.9, 0.5, 18.5, 0.9, M.steel, { yaw: a, collide: false, ao: 0 });
    }
    // pit wall and glowing floor far below
    ch.ring(cx, -40, cz, 12.6, 13.0, 26.8, M.concrete, { tint: 0x5a5868, collide: false });
    ch.cyl(cx, -40, cz, 12.6, 0.2, M.lampCyan, { seg: 48, collide: false, tint: 0x1a4a48 });
    // a cylinder collider fills the pit so falls end at the bottom (and reset the player)
    // bridge to the centre platform
    ch.box(0, CF - 0.6, cz + 8.75, 3.0, 0.6, 8.6, M.steel, {});
    railing(ch, M, -1.5, cz + 13.1, -1.5, cz + 4.4, CF, { mat: M.steel });
    railing(ch, M, 1.5, cz + 13.1, 1.5, cz + 4.4, CF, { mat: M.steel });
    // centre platform and the cradle that holds the Core
    ch.cyl(cx, -40, cz, 4.5, 28, M.concreteDark, { seg: 40 });
    ch.cyl(cx, CF - 0.02, cz, 4.4, 0.04, M.tile, { seg: 40, collide: false, tint: 0x7a7f88 });
    ringRailing(ch, M, cx, cz, 4.3, CF, 20 * deg, 340 * deg, { h: 1.05 });
    for (let i = 0; i < 3; i++) {
      const a = i * 120 * deg + 60 * deg;
      const s = Math.sin(a), c = Math.cos(a);
      // tall brass arms from the platform edge up to the cradle ring
      const pts = [new THREE.Vector3(cx + s * 3.6, CF, cz + c * 3.6), new THREE.Vector3(cx + s * 4.2, CF + 4, cz + c * 4.2), new THREE.Vector3(cx + s * 1.95, CF + 8.2, cz + c * 1.95)];
      const g = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 16, 0.28, 8);
      ch.geo(g, M.brass, new THREE.Matrix4(), {}); g.dispose();
      ch.box(cx + s * 3.6, CF, cz + c * 3.6, 0.9, 0.5, 0.9, M.steel, { yaw: a });
    }
    const cradle = new THREE.Mesh(new THREE.TorusGeometry(1.85, 0.24, 10, 64), M.brass);
    cradle.rotation.x = Math.PI / 2; cradle.position.set(cx, CF + 8.2, cz); cradle.castShadow = true; ch.mesh(cradle);
    // the Core sphere, the shell, the beam
    const coreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x63f0e2).multiplyScalar(4), toneMapped: false });
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(2.0, 4), coreMat);
    core.position.set(cx, CF + 9.3, cz); W.scene.add(core);
    const shellMat = new THREE.MeshBasicMaterial({ color: 0x5a3ad0, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(2.8, 3), shellMat);
    shell.position.copy(core.position); W.scene.add(shell);
    const beamMat = new THREE.ShaderMaterial({
      uniforms: { uTime: shared.uTime, amt: { value: 0.5 }, col: { value: new THREE.Color(0x6ff0e6) } },
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      vertexShader: 'varying vec2 vUv; varying vec3 vN; varying vec3 vV; void main(){ vUv = uv; vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }',
      fragmentShader: `uniform float uTime, amt; uniform vec3 col; varying vec2 vUv; varying vec3 vN; varying vec3 vV;
        void main(){ float rim = pow(abs(dot(vN, vV)), 1.5);
          float flow = 0.7 + 0.3 * sin(vUv.y * 120.0 - uTime * 6.0);
          float fade = smoothstep(1.0, 0.25, vUv.y) * smoothstep(0.0, 0.01, vUv.y);
          gl_FragColor = vec4(col * rim * flow * fade * amt * 1.6, 1.0); }`
    });
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 700, 24, 1, true), beamMat);
    beam.geometry.translate(0, 350, 0);
    beam.position.set(cx, CF + 9.3, cz); W.scene.add(beam);
    const glowBeam = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 2.2, 700, 24, 1, true), beamMat.clone());
    glowBeam.material.uniforms = { uTime: shared.uTime, amt: { value: 0.18 }, col: { value: new THREE.Color(0x7a5af0) } };
    glowBeam.geometry.translate(0, 350, 0); glowBeam.position.copy(beam.position); W.scene.add(glowBeam);
    lightCone(W, ch, cx, CF + 9.3, cz, 30, 9, 0x6a5af0, 0.1);
    W.core = { core, coreMat, shell, beam, glowBeam, light: W.light(cx, CF + 10, cz, 0x63f0e2, 70, 70, { key: 'core' }) };
    // release controls: a pedestal at the north edge of the platform, facing the bridge
    ch.box(0, CF, cz + 2.4, 1.6, 1.0, 0.8, M.panelDark, {});
    ch.box(0, CF + 1.0, cz + 2.5, 1.5, 0.08, 0.7, M.steel, { collide: false, ao: 0, pitch: 0.35 });
    for (let i = 0; i < 3; i++) ch.box(-0.45 + i * 0.45, CF + 1.12, cz + 2.55, 0.16, 0.1, 0.16, [M.lampCyan, M.lampWarm, M.lampRed][i], { collide: false, ao: 0 });
    ch.box(0.6, CF + 1.0, cz + 2.2, 0.25, 0.25, 0.25, M.brass, { collide: false, ao: 0 });
    W.addInteract({ id: 'release', x: 0, y: CF + 1.2, z: cz + 2.9, r: 2.2, label: 'Use the release controls' });
    // lights on the walkway
    for (let i = 0; i < 8; i++) {
      const a = i * 45 * deg + 22.5 * deg;
      const s = Math.sin(a), c = Math.cos(a);
      ch.box(cx + s * 19.6, CF, cz + c * 19.6, 0.6, 0.9, 0.6, M.steel, { yaw: a });
      ch.box(cx + s * 19.6, CF + 0.9, cz + c * 19.6, 0.4, 0.1, 0.4, M.lampCyan, { yaw: a, collide: false, ao: 0 });
      W.light(cx + s * 19, CF + 1.4, cz + c * 19, 0x7a6af0, 9, 12, { chunk: ch });
    }
    W.addInteract({ id: 'coreLook', x: 0, y: CF + 1.5, z: cz + 13.4, r: 2.6, label: 'Look at the Core' });
  }
}
