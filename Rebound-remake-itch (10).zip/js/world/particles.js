// Floating motes around the player: dust in the city, cyan sparks in the Deep and the Core.
import * as THREE from '../../vendor/three.module.min.js';

const N = 900;
const R = 16;

export class Motes {
  constructor(scene) {
    const g = new THREE.BufferGeometry();
    const p = new Float32Array(N * 3), seed = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      p[i * 3] = (Math.random() * 2 - 1) * R; p[i * 3 + 1] = (Math.random() * 2 - 1) * R * 0.5; p[i * 3 + 2] = (Math.random() * 2 - 1) * R;
      seed[i] = Math.random();
    }
    g.setAttribute('position', new THREE.BufferAttribute(p, 3));
    g.setAttribute('seed', new THREE.BufferAttribute(seed, 1));
    this.u = {
      uTime: { value: 0 }, center: { value: new THREE.Vector3() }, colA: { value: new THREE.Color(0xffc890) }, colB: { value: new THREE.Color(0x6ff0e6) },
      density: { value: 0.3 }, cyanMix: { value: 0.2 }, size: { value: 34 }, rise: { value: 0.05 }, pull: { value: 0 }
    };
    const m = new THREE.ShaderMaterial({
      uniforms: this.u, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute float seed; uniform float uTime, density, size, rise, pull; uniform vec3 center; varying float vA; varying float vS;
        void main(){
          vec3 p = position;
          p.y += uTime * rise * (0.5 + seed);
          p.x += sin(uTime * 0.3 + seed * 40.0) * 0.6;
          p.z += cos(uTime * 0.25 + seed * 30.0) * 0.6;
          // wrap around the centre so the field follows the camera
          vec3 rel = mod(p - center + vec3(${R.toFixed(1)}, ${(R * 0.5).toFixed(1)}, ${R.toFixed(1)}), vec3(${(R * 2).toFixed(1)}, ${R.toFixed(1)}, ${(R * 2).toFixed(1)})) - vec3(${R.toFixed(1)}, ${(R * 0.5).toFixed(1)}, ${R.toFixed(1)});
          rel *= 1.0 - pull * 0.6;
          vec3 w = center + rel;
          vec4 mv = modelViewMatrix * vec4(w, 1.0);
          gl_Position = projectionMatrix * mv;
          float edge = 1.0 - smoothstep(${(R * 0.6).toFixed(1)}, ${R.toFixed(1)}, length(rel));
          vA = edge * step(seed, density) * (0.5 + 0.5 * sin(uTime * 1.7 + seed * 80.0));
          vS = seed;
          gl_PointSize = size * (0.4 + seed) / max(1.0, -mv.z);
        }`,
      fragmentShader: `
        uniform vec3 colA, colB; uniform float cyanMix; varying float vA; varying float vS;
        void main(){
          vec2 q = gl_PointCoord - 0.5; float d = length(q);
          float a = smoothstep(0.5, 0.0, d); a *= a;
          vec3 c = mix(colA, colB, step(1.0 - cyanMix, fract(vS * 7.31)));
          gl_FragColor = vec4(c * a * vA * 1.6, 1.0);
        }`
    });
    this.points = new THREE.Points(g, m);
    this.points.frustumCulled = false;
    scene.add(this.points);
    this.targets = {
      station: [0.18, 0.25, 0.02], city: [0.3, 0.12, 0.05], deep: [0.55, 0.85, 0.12], core: [0.85, 0.9, 0.3], isle: [0.25, 0.1, 0.04], rise: [0.4, 0.05, 0.05]
    };
  }
  update(dt, t, cam, region) {
    const u = this.u;
    u.uTime.value = t; u.center.value.copy(cam);
    const tg = this.targets[region] || this.targets.city;
    const k = 1 - Math.exp(-dt * 0.8);
    u.density.value += (tg[0] - u.density.value) * k;
    u.cyanMix.value += (tg[1] - u.cyanMix.value) * k;
    u.rise.value += (tg[2] - u.rise.value) * k;
  }
}
