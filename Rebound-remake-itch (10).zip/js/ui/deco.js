// Generates the interface's paper and pen work once at start-up and hands it to the stylesheet as
// CSS variables: paper textures, torn edges, pen-drawn boxes, marker swipes, scribbles, ticks and rings.
import { paperTexture, roughRect, tornPolygon, svgURL, inkWrite } from './hand.js';

const PEN = '#1d2730', PENCIL = '#6e685b', CREAM = '#ebe5d5', RED = '#a33b28';

function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; }

// an outline box, drawn twice over like a quick pen does
function boxSVG(seed, color, { w = 120, h = 44, width = 1.7, dash = '' } = {}) {
  const a = roughRect(w, h, { seed, jitter: 1.8 }), b = roughRect(w, h, { seed: seed + 7, jitter: 2.2 });
  const st = `fill="none" stroke="${color}" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"${dash ? ` stroke-dasharray="${dash}"` : ''}`;
  return svgURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="-2 -2 ${w + 4} ${h + 4}" preserveAspectRatio="none"><path d="${a}" ${st} stroke-width="${width}"/><path d="${b}" ${st} stroke-width="${width * 0.55}" opacity=".55"/></svg>`);
}
// a swipe of highlighter: ragged ends, a little uneven along its length
function markerSVG(seed) {
  const r = rng(seed); const pts = [];
  const n = 14;
  for (let i = 0; i <= n; i++) pts.push([i / n * 200, 6 + r() * 5]);
  for (let i = n; i >= 0; i--) pts.push([i / n * 200, 34 - r() * 5]);
  pts[0][0] = 4 + r() * 6; pts[n + 1][0] = 196 + r() * 4;
  const d = 'M' + pts.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' L') + ' Z';
  return svgURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 40" preserveAspectRatio="none"><path d="${d}" fill="rgba(242,166,90,.58)"/><path d="${d}" fill="rgba(242,166,90,.25)" transform="translate(3 2)"/></svg>`);
}
// a wavy pen line, for underlines and slider tracks
function scribSVG(seed, color, width = 1.6, opacity = 1) {
  const r = rng(seed); let d = 'M2 5';
  for (let x = 20; x <= 400; x += 20) d += ` Q${x - 10} ${(5 + (r() - .5) * 4).toFixed(1)} ${x} ${(5 + (r() - .5) * 2.4).toFixed(1)}`;
  return svgURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 402 10" preserveAspectRatio="none"><path d="${d}" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round" opacity="${opacity}" vector-effect="non-scaling-stroke"/></svg>`);
}
function vruleSVG(seed, color, len = 100) {
  const r = rng(seed); let d = 'M3 0';
  for (let y = 10; y <= len; y += 10) d += ` L${(3 + (r() - .5) * 1.6).toFixed(1)} ${y}`;
  return svgURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 ${len}" preserveAspectRatio="none"><path d="${d}" fill="none" stroke="${color}" stroke-width="1.4" stroke-linecap="round" vector-effect="non-scaling-stroke" opacity=".7"/></svg>`);
}
// a ring drawn round something, overshooting where the pen comes back to the start
function ringSVG(color, width = 1.8) {
  return svgURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 50" preserveAspectRatio="none"><path d="M58 4 C84 3 98 13 97 26 C96 40 76 47 50 47 C22 47 3 39 3 25 C3 12 22 4 46 4 C60 4 74 6 82 10" fill="none" stroke="${color}" stroke-width="${width}" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>`);
}
function tickSVG(color) {
  return svgURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path d="M6 22 C10 25 13 29 15 34 C20 22 27 12 37 4" fill="none" stroke="${color}" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`);
}

export function installDeco() {
  const root = document.documentElement.style;
  const set = (k, v) => root.setProperty(k, v);
  try {
    set('--paper-tex', `url(${paperTexture({ base: '#ddd3b8', seed: 11 })})`);
    set('--paper-aged', `url(${paperTexture({ base: '#d8c9a2', seed: 23, fibers: 1200 })})`);
    set('--paper-ruled', `url(${paperTexture({ base: '#d8c9a2', seed: 31, lines: true })})`);
  } catch (e) { /* no canvas: plain colours */ }
  set('--torn', tornPolygon(5, { amp: 11 }));
  set('--torn-small', tornPolygon(17, { amp: 22 }));
  set('--torn-wide', tornPolygon(29, { amp: 26 }));
  set('--rr1', boxSVG(3, PEN)); set('--rr2', boxSVG(41, PEN)); set('--rr3', boxSVG(77, PEN));
  set('--rr1c', boxSVG(13, 'rgba(235,229,213,.5)')); set('--rr2c', boxSVG(53, CREAM, { width: 1.5 }));
  set('--rr-dash', boxSVG(91, PENCIL, { width: 1.4, dash: '5 6' }));
  set('--marker-tex', markerSVG(9));
  set('--scrib', scribSVG(4, PENCIL)); set('--scribc', scribSVG(8, CREAM, 1.8));
  set('--scrib-faint', scribSVG(12, PENCIL, 1.1, .45));
  set('--vrule', vruleSVG(2, PENCIL, 40)); set('--vrule-long', vruleSVG(6, PENCIL, 400));
  set('--ring', ringSVG(RED)); set('--ringc', ringSVG(CREAM, 2.2));
  set('--tick', tickSVG(RED));
}

// a new tear for each sheet that is opened
let tearSeed = 100;
export function tearSheet(elm, amp = 11) { elm.style.setProperty('--torn', tornPolygon(tearSeed++, { amp })); }

// the title: written out by hand, "Re" in cream and "bound" in amber
export function writeWordmark(h1) {
  const size = 92;
  h1.replaceChildren(
    markSVG(),
    tagWord(inkWrite('Re', { size, color: CREAM, pen: .14, stagger: .17, duration: .55, delay: .35, seed: 5 })),
    tagWord(inkWrite('bound', { size, color: '#f2a65a', pen: .14, stagger: .15, duration: .55, delay: .7, seed: 8 }))
  );
  const sr = document.createElement('span'); sr.className = 'sr'; sr.textContent = 'Rebound'; h1.append(sr);
}
function tagWord(svg) { svg.classList.add('ink-word'); svg.setAttribute('aria-hidden', 'true'); return svg; }
// the loop-and-arrow mark, as one pen stroke
export function markSVG(cls = 'mark') {
  const NS = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(NS, 'svg'); s.setAttribute('viewBox', '0 0 64 64'); s.setAttribute('class', cls); s.setAttribute('aria-hidden', 'true');
  s.innerHTML = '<path d="M47 17 C41 10 31 8 23 12 C13 17 9 29 13 39 C17 50 30 55 41 51 C50 48 55 40 55 31"/><path class="m2" d="M48 7 C48.5 11 48.6 14 47.6 18 C44 17.5 40.5 17.6 37 18.4"/>';
  return s;
}

// ---------- wear: stains and rips for the journal as it ages ----------
const hashStr = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; };
export { hashStr };
function canvasURL(size, draw) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  draw(c.getContext('2d'), size);
  return 'url(' + c.toDataURL('image/png') + ')';
}
// a coffee ring: a mug set down once, darker where it pooled at the rim, broken where it lifted
function coffee(seed) {
  return canvasURL(256, (g, S) => {
    const r = rng(seed), cx = S / 2, cy = S / 2, R = S * (0.3 + r() * 0.08);
    const gap = r() * Math.PI * 2, gapW = 0.6 + r() * 1.4;
    g.fillStyle = 'rgba(132,84,40,.05)'; g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    for (let a = 0; a < Math.PI * 2; a += 0.02) {
      let d = Math.abs(((a - gap + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
      const k = Math.min(1, d / gapW);
      const w = (2 + Math.sin(a * 3 + seed) * 1.2 + r() * 1.5) * k;
      if (w < 0.3) continue;
      const rr = R + Math.sin(a * 5 + seed) * 2.5;
      g.strokeStyle = `rgba(118,70,30,${(0.28 + r() * 0.2) * k})`; g.lineWidth = w;
      g.beginPath(); g.arc(cx, cy, rr, a, a + 0.03); g.stroke();
    }
    // a second, fainter ring where it was set down again
    g.strokeStyle = 'rgba(118,70,30,.12)'; g.lineWidth = 1.5;
    g.beginPath(); g.arc(cx + 14 + r() * 10, cy - 8 - r() * 10, R * 0.97, 0.5, 4.2); g.stroke();
  });
}
// a water mark: an uneven blot, paler inside, with a darker tide line where it dried
function waterMark(seed, tint = '96,104,98') {
  return canvasURL(256, (g, S) => {
    const r = rng(seed), cx = S / 2, cy = S / 2, n = 48, pts = [];
    const ph = [r() * 6, r() * 6, r() * 6];
    for (let i = 0; i < n; i++) {
      const a = i / n * Math.PI * 2;
      const rr = S * 0.32 * (1 + 0.18 * Math.sin(a * 2 + ph[0]) + 0.1 * Math.sin(a * 5 + ph[1]) + 0.05 * Math.sin(a * 11 + ph[2]));
      pts.push([cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.8]);
    }
    const path = () => { g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); };
    g.fillStyle = `rgba(${tint},.07)`; path(); g.fill();
    g.strokeStyle = `rgba(${tint},.42)`; g.lineWidth = 2.4; path(); g.stroke();
    g.strokeStyle = `rgba(${tint},.16)`; g.lineWidth = 6; path(); g.stroke();
  });
}
// a thumb smudge of graphite, dragged a little
function smudge(seed) {
  return canvasURL(256, (g, S) => {
    const r = rng(seed);
    for (let i = 0; i < 9; i++) {
      const x = S * 0.35 + i * 7 + r() * 6, y = S * 0.5 + (r() - 0.5) * 12, rad = 26 + r() * 20;
      const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, 'rgba(40,42,48,.10)'); gr.addColorStop(1, 'rgba(40,42,48,0)');
      g.fillStyle = gr; g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
    }
  });
}
// a fingerprint in ink
function fingerprint(seed) {
  return canvasURL(256, (g, S) => {
    const r = rng(seed), cx = S / 2, cy = S / 2;
    g.lineWidth = 1.6;
    for (let k = 3; k < 15; k++) {
      const rx = k * 4.2, ry = k * 5.6;
      for (let a = 0; a < Math.PI * 2; a += 0.35) {
        if (r() < 0.25) continue;
        g.strokeStyle = `rgba(30,34,44,${0.1 + r() * 0.16})`;
        g.beginPath(); g.ellipse(cx, cy, rx, ry, 0.3, a, a + 0.3); g.stroke();
      }
    }
  });
}
// foxing: little brown age spots
function foxing(seed) {
  return canvasURL(256, (g, S) => {
    const r = rng(seed);
    for (let i = 0; i < 40; i++) {
      const x = r() * S, y = r() * S, rad = 1 + r() * 4;
      g.fillStyle = `rgba(140,96,50,${0.08 + r() * 0.2})`; g.beginPath(); g.arc(x, y, rad, 0, Math.PI * 2); g.fill();
    }
  });
}
// a dried tide line across the bottom of a page, from a cycle that ended underwater
function tideLine(seed) {
  return canvasURL(512, (g, S) => {
    const r = rng(seed); g.beginPath();
    let y0 = S * 0.5;
    g.moveTo(0, y0);
    for (let x = 0; x <= S; x += 8) g.lineTo(x, y0 + Math.sin(x * 0.02 + seed) * 10 + Math.sin(x * 0.07 + seed * 2) * 4 + (r() - 0.5) * 3);
    g.strokeStyle = 'rgba(90,96,86,.38)'; g.lineWidth = 2.2; g.stroke();
    g.lineTo(S, S); g.lineTo(0, S); g.closePath(); g.fillStyle = 'rgba(96,104,92,.07)'; g.fill();
  });
}

let STAINS = null;
export function stains() {
  if (STAINS) return STAINS;
  try {
    STAINS = {
      coffee: [coffee(3), coffee(19), coffee(44)],
      water: [waterMark(5), waterMark(27), waterMark(61, '112,92,62')],
      smudge: [smudge(7), smudge(33)],
      print: [fingerprint(11), fingerprint(52)],
      fox: [foxing(13), foxing(71)],
      tide: [tideLine(2), tideLine(9), tideLine(23), tideLine(37), tideLine(58)]
    };
  } catch (e) { STAINS = { coffee: [], water: [], smudge: [], print: [], fox: [], tide: [] }; }
  return STAINS;
}

// A ripped outline: ragged all round, and with `corner` (1 to 4) set, that corner is torn away.
export function wornPolygon(seed, { amp = 20, corner = 0, cut = 16 } = {}) {
  const r = rng(seed), pts = [];
  const j = (a) => (r() - 0.5) * 2 * a * 0.06;
  const N = 16;
  const edge = (from, to) => { for (let i = 0; i < N; i++) { const t = i / N; pts.push([from[0] + (to[0] - from[0]) * t, from[1] + (to[1] - from[1]) * t]); } };
  edge([0, 0], [100, 0]); edge([100, 0], [100, 100]); edge([100, 100], [0, 100]); edge([0, 100], [0, 0]);
  const C = [[0, 0], [100, 0], [100, 100], [0, 100]][corner - 1];
  const out = [];
  for (const [x, y] of pts) {
    let X = x, Y = y;
    // push each edge point inward by a ragged amount
    if (y === 0) Y = Math.abs(j(amp)) + 0.3; else if (y === 100) Y = 100 - Math.abs(j(amp)) - 0.3;
    if (x === 0) X = Math.abs(j(amp)) + 0.3; else if (x === 100) X = 100 - Math.abs(j(amp)) - 0.3;
    if (C) {
      // inside the torn corner, pull the point onto a jagged diagonal
      const dx = Math.abs(X - C[0]), dy = Math.abs(Y - C[1]);
      if (dx + dy < cut) {
        const k = (cut - (dx + dy)) / 2 + (r() - 0.5) * 2.2;
        X += (C[0] === 0 ? 1 : -1) * Math.max(0, k); Y += (C[1] === 0 ? 1 : -1) * Math.max(0, k);
      }
    }
    out.push(X.toFixed(2) + '% ' + Y.toFixed(2) + '%');
  }
  return 'polygon(' + out.join(',') + ')';
}
