// Hand-lettering and hand-drawn shapes. Every letter is a pen stroke defined here. The same strokes are
// baked into the interface font (tools/build_hand_font.py) and drawn live, with per-letter wobble, ink
// bleed and uneven pressure, for notes, signs and titles.

// advance width, then SVG path data. Baseline is y=10, x-height top is y=4, capitals reach y=0.3, descenders reach 14.
const O = (cx, cy, rx, ry) => 'M' + (cx + rx) + ' ' + cy + ' C' + (cx + rx) + ' ' + (cy - ry * .56) + ' ' + (cx + rx * .56) + ' ' + (cy - ry) + ' ' + cx + ' ' + (cy - ry) +
  ' C' + (cx - rx * .56) + ' ' + (cy - ry) + ' ' + (cx - rx) + ' ' + (cy - ry * .56) + ' ' + (cx - rx) + ' ' + cy +
  ' C' + (cx - rx) + ' ' + (cy + ry * .56) + ' ' + (cx - rx * .56) + ' ' + (cy + ry) + ' ' + cx + ' ' + (cy + ry) +
  ' C' + (cx + rx * .56) + ' ' + (cy + ry) + ' ' + (cx + rx) + ' ' + (cy + ry * .56) + ' ' + (cx + rx) + ' ' + cy;
const GLYPHS = {
  a: [7, O(3.4, 7, 2.7, 2.9) + ' M6.1 4.2 L6.1 10'],
  b: [7.5, 'M1 0 L1 10 ' + O(3.9, 7, 2.9, 2.9)],
  c: [6.5, 'M6 5.2 C5.4 4.5 4.6 4.2 3.6 4.2 C2 4.2 0.9 5.5 0.9 7 C0.9 8.6 2 9.9 3.6 9.9 C4.6 9.9 5.4 9.5 6 8.8'],
  d: [7.5, 'M6.2 0 L6.2 10 ' + O(3.3, 7, 2.9, 2.9)],
  e: [6.8, 'M0.9 7.2 L6 7.2 C6 5.4 4.9 4.2 3.5 4.2 C1.9 4.2 0.9 5.5 0.9 7 C0.9 8.6 2 9.9 3.6 9.9 C4.6 9.9 5.4 9.5 6 8.8'],
  f: [5.5, 'M5.5 0.8 C4 0.3 2.8 1 2.8 2.8 L2.8 10 M0.6 4.4 L5 4.4'],
  g: [7.5, O(3.4, 7, 2.8, 2.9) + ' M6.2 4.2 L6.2 11.5 C6.2 13.5 4.8 14 3.3 14 C2.3 14 1.5 13.7 1 13'],
  h: [7, 'M1 0 L1 10 M1 6.5 C1.8 4.8 3 4.2 4 4.2 C5.4 4.2 6 5.2 6 6.6 L6 10'],
  i: [3, 'M1.5 4.3 L1.5 10 M1.5 1.2 L1.52 1.7'],
  j: [3.6, 'M2.2 4.3 L2.2 12 C2.2 13.4 1.4 14 0.3 14 M2.2 1.2 L2.22 1.7'],
  k: [6.6, 'M1 0 L1 10 M5.8 4.2 L1 7.6 M2.8 6.6 L6 10'],
  l: [3.2, 'M1.6 0 L1.6 9 C1.6 9.7 2.1 10 2.8 10'],
  m: [10.4, 'M1 4.3 L1 10 M1 6 C1.6 4.7 2.6 4.2 3.4 4.2 C4.6 4.2 5 5.2 5 6.4 L5 10 M5 6 C5.6 4.7 6.6 4.2 7.4 4.2 C8.6 4.2 9 5.2 9 6.4 L9 10'],
  n: [7, 'M1 4.3 L1 10 M1 6.2 C1.7 4.8 2.8 4.2 3.8 4.2 C5.2 4.2 5.8 5.2 5.8 6.6 L5.8 10'],
  o: [7, O(3.5, 7, 2.7, 2.9)],
  p: [7.5, 'M1 4.3 L1 14 ' + O(3.9, 7, 2.9, 2.9)],
  q: [7.5, O(3.3, 7, 2.8, 2.9) + ' M6.1 4.3 L6.1 14'],
  r: [5, 'M1 4.3 L1 10 M1 6.8 C1.6 5 2.8 4.2 4.2 4.4'],
  s: [6.5, 'M5.6 5 C5 4.4 4.2 4.2 3.4 4.2 C2.2 4.2 1.4 4.8 1.4 5.7 C1.4 7.6 5.8 6.6 5.8 8.4 C5.8 9.4 4.8 9.9 3.5 9.9 C2.6 9.9 1.6 9.5 1 8.8'],
  t: [5.5, 'M2.6 1.5 L2.6 8.8 C2.6 9.6 3.2 10 4 10 M0.6 4.4 L4.8 4.4'],
  u: [7, 'M1 4.3 L1 8 C1 9.3 2 10 3.2 10 C4.6 10 5.8 9 5.8 7.5 L5.8 4.3 M5.8 7.5 L5.8 10'],
  v: [7, 'M0.8 4.3 L3.5 10 L6.2 4.3'],
  w: [9.6, 'M0.8 4.3 L2.7 10 L4.8 5.5 L6.9 10 L8.8 4.3'],
  x: [7, 'M1 4.3 L6 10 M6 4.3 L1 10'],
  y: [7, 'M1 4.3 L3.5 10 M6 4.3 L3 12 C2.4 13.4 1.6 14 0.6 14'],
  z: [7, 'M1 4.3 L6 4.3 L1 10 L6.2 10'],
  A: [9, 'M0.8 10 L4.5 0.3 L8.2 10 M2.3 6.5 L6.7 6.5'],
  B: [8.6, 'M1 10 L1 0.3 L4.5 0.3 C6.5 0.3 7 1.5 7 2.5 C7 3.8 6 4.8 4.2 4.8 L1 4.8 M4.2 4.8 C6.4 4.8 7.4 5.8 7.4 7.4 C7.4 9 6.2 10 4.5 10 L1 10'],
  C: [8.8, 'M8 2.2 C7 0.9 5.8 0.3 4.6 0.3 C2.4 0.3 1 2.5 1 5 C1 7.6 2.4 9.8 4.6 9.8 C5.8 9.8 7 9.2 8 7.8'],
  D: [9, 'M1 0.3 L1 10 L3.6 10 C6.4 10 8 7.8 8 5.1 C8 2.4 6.4 0.3 3.6 0.3 L1 0.3'],
  E: [8, 'M7.2 0.3 L1 0.3 L1 10 L7.4 10 M1 5.1 L6 5.1'],
  F: [7.5, 'M7.2 0.3 L1 0.3 L1 10 M1 5.1 L6 5.1'],
  G: [9, 'M8 2.4 C7 1 5.8 0.3 4.6 0.3 C2.4 0.3 1 2.5 1 5 C1 7.6 2.4 9.8 4.7 9.8 C6.6 9.8 8 8.4 8 6 L8 5.5 L4.8 5.5'],
  H: [9, 'M1 0.3 L1 10 M8 0.3 L8 10 M1 5.1 L8 5.1'],
  I: [6, 'M1 0.3 L5 0.3 M3 0.3 L3 10 M1 10 L5 10'],
  J: [7, 'M6 0.3 L6 7 C6 9 4.9 10 3.5 10 C2.3 10 1.4 9.4 1 8.3'],
  K: [8.6, 'M1 0.3 L1 10 M7.4 0.3 L1.4 5.7 M3.6 4 L7.8 10'],
  L: [7.5, 'M1 0.3 L1 10 L7 10'],
  M: [10.4, 'M1 10 L1 0.3 L5 7 L9 0.3 L9 10'],
  N: [9, 'M1 10 L1 0.3 L8 10 L8 0.3'],
  O: [9.8, O(4.9, 5.1, 3.9, 4.8)],
  P: [8.4, 'M1 10 L1 0.3 L4.6 0.3 C6.6 0.3 7.4 1.6 7.4 2.9 C7.4 4.3 6.4 5.5 4.4 5.5 L1 5.5'],
  Q: [9.8, O(4.9, 5.1, 3.9, 4.8) + ' M5.6 7.6 L8.8 10.6'],
  R: [8.6, 'M1 10 L1 0.3 L4.6 0.3 C6.6 0.3 7.4 1.6 7.4 2.9 C7.4 4.3 6.4 5.5 4.4 5.5 L1 5.5 M4.3 5.5 L7.8 10'],
  S: [8.6, 'M7.4 1.8 C6.6 0.8 5.5 0.3 4.2 0.3 C2.4 0.3 1.4 1.4 1.4 2.6 C1.4 4.4 3 4.8 4.4 5.2 C6 5.7 7.6 6.2 7.6 7.8 C7.6 9.2 6.2 10 4.4 10 C3 10 1.8 9.4 1 8.3'],
  T: [8.8, 'M0.6 0.3 L8.2 0.3 M4.4 0.3 L4.4 10'],
  U: [9, 'M1 0.3 L1 6.5 C1 8.7 2.4 10 4.5 10 C6.6 10 8 8.7 8 6.5 L8 0.3'],
  V: [9, 'M0.6 0.3 L4.5 10 L8.4 0.3'],
  W: [11.4, 'M0.6 0.3 L3 10 L5.6 2 L8.2 10 L10.6 0.3'],
  X: [9, 'M1 0.3 L8 10 M8 0.3 L1 10'],
  Y: [9.2, 'M0.8 0.3 L4.6 5.3 L8.4 0.3 M4.6 5.3 L4.6 10'],
  Z: [9, 'M1 0.3 L8 0.3 L1 10 L8.2 10'],
  0: [8, O(4, 5.1, 3, 4.8)],
  1: [6, 'M1.5 2.5 L4 0.3 L4 10'],
  2: [8, 'M1.2 2.4 C1.6 1 2.6 0.3 4 0.3 C5.8 0.3 6.8 1.4 6.8 2.8 C6.8 4.4 5.6 5.4 4.4 6.4 L1 10 L7.2 10'],
  3: [8, 'M1.2 1.5 C1.8 0.7 2.8 0.3 4 0.3 C5.6 0.3 6.6 1.2 6.6 2.5 C6.6 3.9 5.4 4.8 3.8 4.8 C5.6 4.8 7 5.6 7 7.4 C7 9 5.6 10 4 10 C2.7 10 1.6 9.5 1 8.5'],
  4: [8, 'M5.6 10 L5.6 0.3 L0.8 7 L7.4 7'],
  5: [8, 'M6.6 0.3 L1.8 0.3 L1.3 4.8 C2 4.4 3 4.1 4 4.1 C5.8 4.1 7 5.4 7 7.1 C7 8.8 5.8 10 4 10 C2.8 10 1.6 9.5 1 8.5'],
  6: [8, 'M6.4 1.4 C5.7 0.7 4.9 0.3 4 0.3 C2.2 0.3 1 2.4 1 5.5 C1 8.3 2.1 10 4 10 C5.7 10 6.9 8.7 6.9 7 C6.9 5.3 5.7 4.2 4 4.2 C2.6 4.2 1.4 5 1 6'],
  7: [8, 'M1 0.3 L7.2 0.3 L3.4 10'],
  8: [8, 'M4 4.8 C2.5 4.8 1.6 3.9 1.6 2.6 C1.6 1.3 2.6 0.3 4 0.3 C5.4 0.3 6.4 1.3 6.4 2.6 C6.4 3.9 5.5 4.8 4 4.8 C2.2 4.8 1 5.8 1 7.4 C1 9 2.3 10 4 10 C5.7 10 7 9 7 7.4 C7 5.8 5.8 4.8 4 4.8'],
  9: [8, 'M6.8 4.6 C6.8 6 5.6 6.8 4 6.8 C2.4 6.8 1.2 5.6 1.2 3.6 C1.2 1.6 2.4 0.3 4 0.3 C5.7 0.3 6.9 1.8 6.9 4.8 C6.9 7.8 5.8 10 4 10 C3 10 2.2 9.6 1.6 8.8'],
  '.': [3, 'M1 9.6 L1.05 9.65'], ',': [3, 'M1.4 9.4 L0.8 11.8'], ':': [3, 'M1 5 L1.05 5.05 M1 9.6 L1.05 9.65'], ';': [3, 'M1 5 L1.05 5.05 M1.4 9.4 L0.8 11.8'],
  '!': [3, 'M1.5 0.3 L1.4 7.2 M1.5 9.6 L1.55 9.65'], '?': [7, 'M1 2.2 C1.3 1 2.4 0.3 3.6 0.3 C5.2 0.3 6 1.4 6 2.6 C6 4.2 3.8 4.6 3.6 6.8 M3.6 9.6 L3.65 9.65'],
  "'": [2.6, 'M1.2 0.5 L0.8 3'], '"': [5, 'M1.2 0.5 L0.8 3 M3.6 0.5 L3.2 3'],
  '-': [5, 'M0.8 6 L4.4 6'], '–': [7, 'M0.6 6 L6.4 6'], '—': [9, 'M0.5 6 L8.2 6'],
  '(': [4, 'M3.6 0.3 C1.4 2.6 1.4 7.8 3.6 10.3'], ')': [4, 'M0.8 0.3 C3 2.6 3 7.8 0.8 10.3'],
  '/': [5.5, 'M0.8 10.3 L5 -0.2'], '·': [3, 'M1 6 L1.05 6.05'], '•': [4, 'M1.6 6 L1.7 6.05'], '+': [7, 'M0.8 5.5 L6.4 5.5 M3.6 2.7 L3.6 8.3'], '=': [7, 'M0.8 3.8 L6.4 3.8 M0.8 7.2 L6.4 7.2'],
  '%': [10, 'M1.6 9.8 L8.2 0.5 ' + O(2.4, 2.6, 1.3, 1.5) + ' ' + O(7.4, 8, 1.3, 1.5)], '°': [4.4, O(2.2, 2.2, 1.3, 1.5)], '&': [9, 'M8 10 L2.6 3.2 C2 2.2 2.2 0.3 3.8 0.3 C5.4 0.3 5.8 2.2 4.8 3.4 L2.4 6.4 C0.8 8.4 1.6 10 3.4 10 C5 10 6.4 8.6 7.2 6.6'],
  '→': [10, 'M0.5 5.5 L9 5.5 M6 2.5 L9.2 5.5 L6 8.5'], '…': [6, 'M1 9.6 L1.05 9.65 M3 9.6 L3.05 9.65 M5 9.6 L5.05 9.65'],
  '[': [4, 'M3.4 0.3 L1 0.3 L1 10.3 L3.4 10.3'], ']': [4, 'M0.6 0.3 L3 0.3 L3 10.3 L0.6 10.3'], '*': [5, 'M2.5 1 L2.5 6 M0.3 2.4 L4.7 4.8 M4.7 2.4 L0.3 4.8'], '_': [7, 'M0 11 L7 11'], '#': [8, 'M2.6 1 L2 9.6 M6 1 L5.4 9.6 M0.8 3.6 L7.4 3.6 M0.6 7 L7.2 7'],
  '<': [6.5, 'M5.6 2.6 L1 6 L5.6 9.4'], '>': [6.5, 'M1 2.6 L5.6 6 L1 9.4'], '|': [3, 'M1.5 -0.2 L1.5 12'],
  '~': [7, 'M0.8 6.4 C1.8 4.8 2.8 4.8 3.6 5.6 C4.4 6.4 5.4 6.4 6.4 4.8'], '×': [6.5, 'M1.2 4.4 L5.4 8.6 M5.4 4.4 L1.2 8.6'],
  '$': [8, 'M7 1.8 C6.4 1 5.4 0.6 4.2 0.6 C2.6 0.6 1.6 1.6 1.6 2.8 C1.6 4.6 3.2 4.9 4.4 5.3 C6 5.8 7.2 6.3 7.2 7.8 C7.2 9 6 9.8 4.2 9.8 C3 9.8 1.8 9.3 1.2 8.4 M4.2 -0.6 L4.2 11'],
  '@': [11.5, O(5.6, 6.2, 1.9, 2.1) + ' M7.5 4.1 L7.5 7.4 C7.5 8.6 8.3 9 9 9 C10 9 10.6 7.6 10.6 6 C10.6 2.8 8.4 0.8 5.6 0.8 C2.8 0.8 0.6 3 0.6 6 C0.6 9 2.8 11 5.8 11 C7 11 8 10.8 8.8 10.2'],
  '^': [6, 'M0.8 3.4 L3 0.6 L5.2 3.4'], '{': [4.6, 'M3.8 0.3 C2.4 0.3 2.2 1 2.2 2.4 L2.2 4 C2.2 4.8 1.6 5.3 0.8 5.3 C1.6 5.3 2.2 5.8 2.2 6.6 L2.2 8.2 C2.2 9.6 2.4 10.3 3.8 10.3'],
  '}': [4.6, 'M0.8 0.3 C2.2 0.3 2.4 1 2.4 2.4 L2.4 4 C2.4 4.8 3 5.3 3.8 5.3 C3 5.3 2.4 5.8 2.4 6.6 L2.4 8.2 C2.4 9.6 2.2 10.3 0.8 10.3'],
  '\\': [5.5, 'M0.8 -0.2 L5 10.3'], '`': [3, 'M0.8 0.6 L1.8 2.4'], '£': [8, 'M6.8 1.6 C6.2 0.8 5.4 0.3 4.4 0.3 C2.8 0.3 2 1.6 2 3.2 L2 10 M0.6 5.4 L5.2 5.4 M0.6 10 L7.4 10'],
  ' ': [4, '']
};
export { GLYPHS };
const ALIAS = { '’': "'", '‘': "'", '“': '"', '”': '"', 'é': 'e', 'É': 'E', 'á': 'a', 'í': 'i', 'ó': 'o', 'ú': 'u', 'ñ': 'n', '\u00a0': ' ', '−': '-' };
const paths = new Map();
const glyph = ch => {
  const key = GLYPHS[ch] ? ch : ALIAS[ch] && GLYPHS[ALIAS[ch]] ? ALIAS[ch] : null;
  if (!key) return GLYPHS[' '];
  return GLYPHS[key];
};
const path2d = d => { if (!paths.has(d)) paths.set(d, new Path2D(d)); return paths.get(d); };

// small deterministic random so a line of writing looks the same every time it is drawn
function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; }
const hash = str => { let h = 2166136261; for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619); return h >>> 0; };

export function measure(text, size, tracking = .9) {
  const s = size / 10;
  let w = 0;
  for (const ch of text) w += glyph(ch)[0] * s + tracking * s;
  return w;
}
export function wrap(text, size, maxWidth, tracking = .9) {
  const lines = [];
  for (const block of String(text).split('\n')) {
    let line = '';
    for (const word of block.split(/ +/)) {
      const test = line ? line + ' ' + word : word;
      if (line && measure(test, size, tracking) > maxWidth) { lines.push(line); line = word; } else line = test;
    }
    lines.push(line);
  }
  return lines;
}

// Draw one line of handwriting. (x, y) is the left end of the line's cap height (the glyph origin is its top).
export function drawLine(ctx, text, x, y, size, { color = '#1d2730', pen = .1, tracking = .9, seed = 1, slant = .06, bleed = true, wobble = 1 } = {}) {
  const r = rng(seed ^ hash(text));
  const s = size / 10;
  ctx.save();
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  let cx = x;
  for (const ch of text) {
    const [adv, d] = glyph(ch);
    if (d) {
      const rot = (r() - .5) * .13 * wobble, dy = (r() - .5) * .42 * s * wobble, sx = 1 + (r() - .5) * .14 * wobble, sy = 1 + (r() - .5) * .12 * wobble, w = pen * 10 * (.8 + r() * .42);
      const p = path2d(d);
      ctx.save();
      ctx.translate(cx, y + dy);
      ctx.rotate(rot);
      ctx.transform(1, 0, -slant, 1, 0, 0);
      ctx.scale(s * sx, s * sy);
      ctx.strokeStyle = color;
      ctx.globalAlpha = .9; ctx.lineWidth = w; ctx.stroke(p);
      if (bleed) {
        // the pen goes over the stroke a second time, a hair off, like quick writing does
        ctx.translate((r() - .5) * .5, (r() - .5) * .4);
        ctx.globalAlpha = .5; ctx.lineWidth = w * .62; ctx.stroke(p);
      }
      ctx.restore();
    }
    cx += (adv * (.94 + r() * .12) + tracking * (.8 + r() * .4)) * s;
  }
  ctx.restore();
  return cx - x;
}

// A canvas of handwriting, wrapped to maxWidth. Returns a <span> that also carries the real text for screen readers.
export function ink(text, { size = 18, color = '#1d2730', width = 560, lineHeight = 1.5, align = 'left', pen = .1, seed = 7, slant = .06, shrink = false, wobble = 1 } = {}) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const lines = wrap(text, size, width);
  const widest = Math.max(...lines.map(l => measure(l, size)));
  const w = shrink ? Math.ceil(widest + size * .5) : Math.ceil(width);
  const lh = size * lineHeight, h = Math.ceil((lines.length - 1) * lh + size * 1.78);
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(w * dpr); canvas.height = Math.ceil(h * dpr);
  canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
  canvas.setAttribute('aria-hidden', 'true');
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  lines.forEach((line, i) => {
    const lw = measure(line, size);
    const x = align === 'center' ? (w - lw) / 2 : align === 'right' ? w - lw : size * .15;
    drawLine(ctx, line, x, size * .16 + i * lh, size, { color, pen, seed: seed + i * 31, slant, wobble });
  });
  const span = document.createElement('span');
  span.className = 'ink';
  const real = document.createElement('span');
  real.className = 'sr'; real.textContent = text;
  span.append(real, canvas);
  return span;
}

// Animated pen: an SVG whose strokes draw themselves one letter at a time.
export function inkWrite(text, { size = 40, color = '#f1ead4', pen = .11, delay = 0, stagger = .09, duration = .45, seed = 3, tracking = .9, slant = .05 } = {}) {
  const NS = 'http://www.w3.org/2000/svg';
  const r = rng(seed ^ hash(text));
  const s = size / 10;
  const svg = document.createElementNS(NS, 'svg');
  const total = measure(text, size, tracking) + size * .3;
  svg.setAttribute('viewBox', '-' + size * .1 + ' -' + size * .1 + ' ' + total + ' ' + size * 1.78);
  svg.setAttribute('width', total); svg.setAttribute('height', size * 1.78);
  svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', text);
  svg.style.overflow = 'visible';
  let cx = 0, i = 0;
  for (const ch of text) {
    const [adv, d] = glyph(ch);
    if (d) {
      const g = document.createElementNS(NS, 'g');
      const rot = (r() - .5) * 5, dy = (r() - .5) * .22 * s;
      g.setAttribute('transform', 'translate(' + cx.toFixed(2) + ' ' + (size * .16 + dy).toFixed(2) + ') rotate(' + rot.toFixed(2) + ') skewX(' + (-slant * 57).toFixed(1) + ') scale(' + s.toFixed(3) + ')');
      const w = pen * 10 * (.85 + r() * .3);
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('d', d); p.setAttribute('pathLength', '1');
      p.setAttribute('fill', 'none'); p.setAttribute('stroke', color);
      p.setAttribute('stroke-width', w.toFixed(2)); p.setAttribute('stroke-linecap', 'round'); p.setAttribute('stroke-linejoin', 'round');
      p.style.strokeDasharray = '1'; p.style.strokeDashoffset = '1';
      p.style.animation = 'inkdraw ' + duration + 's cubic-bezier(.4,.1,.3,1) ' + (delay + i * stagger).toFixed(2) + 's forwards';
      g.append(p); svg.append(g);
    }
    cx += (adv + tracking * (.85 + r() * .3)) * s;
    i++;
  }
  return svg;
}

// ---- hand-drawn shapes ------------------------------------------------------------------------------
// A wobbly rectangle outline as an SVG path string (drawn slightly overshooting, like a pen would).
export function roughRect(w, h, { seed = 1, jitter = 1.6, overshoot = 4 } = {}) {
  const r = rng(seed);
  const j = () => (r() - .5) * jitter * 2;
  const pts = [[2 + j(), 2 + j()], [w - 2 + j(), 2 + j()], [w - 2 + j(), h - 2 + j()], [2 + j(), h - 2 + j()]];
  let d = 'M' + (pts[0][0] - overshoot * .2) + ' ' + pts[0][1];
  for (let i = 0; i < 4; i++) {
    const a = pts[i], b = pts[(i + 1) % 4], m = [(a[0] + b[0]) / 2 + j() * .7, (a[1] + b[1]) / 2 + j() * .7];
    const ext = i === 3 ? overshoot : 0;
    d += ' Q' + m[0].toFixed(1) + ' ' + m[1].toFixed(1) + ' ' + (b[0] + (i === 3 ? 0 : 0)).toFixed(1) + ' ' + (b[1] - ext * 0).toFixed(1);
  }
  d += ' L' + (pts[0][0] + overshoot).toFixed(1) + ' ' + (pts[0][1] + overshoot * .6).toFixed(1);
  return d;
}
export function roughLine(x1, y1, x2, y2, { seed = 1, jitter = 1.5 } = {}) {
  const r = rng(seed);
  const mx = (x1 + x2) / 2 + (r() - .5) * jitter * 2, my = (y1 + y2) / 2 + (r() - .5) * jitter * 2;
  return 'M' + x1.toFixed(1) + ' ' + y1.toFixed(1) + ' Q' + mx.toFixed(1) + ' ' + my.toFixed(1) + ' ' + x2.toFixed(1) + ' ' + y2.toFixed(1);
}
export const svgURL = svg => 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")';

// A jagged torn-paper outline for CSS clip-path.
export function tornPolygon(seed = 1, { amp = 7, step = 26 } = {}) {
  const r = rng(seed);
  const pts = [];
  const edge = (n, f) => { for (let i = 0; i <= n; i++) pts.push(f(i / n, (r() - .5) * 2)); };
  const nx = 18, ny = 14;
  const a = amp;
  edge(nx, (t, j) => [t * 100, Math.max(0, 0.5 + j * a * .09) + '%'].map((v, k) => k ? v : v + '%'));
  edge(ny, (t, j) => [(100 - Math.max(0, .4 + j * a * .06)) + '%', t * 100 + '%']);
  edge(nx, (t, j) => [(100 - t * 100) + '%', (100 - Math.max(0, .5 + j * a * .09)) + '%']);
  edge(ny, (t, j) => [Math.max(0, .4 + j * a * .06) + '%', (100 - t * 100) + '%']);
  return 'polygon(' + pts.map(p => p.join(' ')).join(',') + ')';
}

// A tileable paper texture as a data URL.
export function paperTexture({ base = '#d9cfb4', size = 360, seed = 5, fibers = 900, lines = false } = {}) {
  const r = rng(seed);
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d');
  g.fillStyle = base; g.fillRect(0, 0, size, size);
  for (let i = 0; i < 4500; i++) { const v = Math.floor(r() * 70); g.fillStyle = 'rgba(' + (90 + v) + ',' + (80 + v) + ',' + (60 + v) + ',' + (r() * .08) + ')'; g.fillRect(r() * size, r() * size, 1 + r() * 3, 1 + r() * 2); }
  // fibres and blotches wrap round the edges, so the tile repeats without a seam
  const wrapped = (x, y, reach, draw) => { for (const ox of [-size, 0, size]) for (const oy of [-size, 0, size]) { const X = x + ox, Y = y + oy; if (X + reach < 0 || X - reach > size || Y + reach < 0 || Y - reach > size) continue; draw(X, Y); } };
  for (let i = 0; i < fibers; i++) {
    g.strokeStyle = 'rgba(' + (r() < .5 ? '255,250,235' : '110,95,70') + ',' + (r() * .2) + ')'; g.lineWidth = .5 + r() * .8;
    const x = r() * size, y = r() * size, a = r() * 14 - 7, b = r() * 14 - 7, c2 = r() * 22 - 11, d = r() * 22 - 11;
    wrapped(x, y, 24, (X, Y) => { g.beginPath(); g.moveTo(X, Y); g.quadraticCurveTo(X + a, Y + b, X + c2, Y + d); g.stroke(); });
  }
  for (let i = 0; i < 9; i++) {
    const x = r() * size, y = r() * size, rad = 20 + r() * 60;
    wrapped(x, y, rad, (X, Y) => { const gr = g.createRadialGradient(X, Y, 0, X, Y, rad); gr.addColorStop(0, 'rgba(120,90,50,.10)'); gr.addColorStop(1, 'rgba(120,90,50,0)'); g.fillStyle = gr; g.fillRect(X - rad, Y - rad, rad * 2, rad * 2); });
  }
  if (lines) { g.strokeStyle = 'rgba(70,110,150,.28)'; g.lineWidth = 1; for (let y = 34; y < size; y += 34) { g.beginPath(); g.moveTo(0, y); g.lineTo(size, y); g.stroke(); } }
  return c.toDataURL('image/png');
}
