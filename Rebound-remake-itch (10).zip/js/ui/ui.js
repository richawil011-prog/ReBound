// DOM interface: HUD, toasts, subtitles, panels, dialog, menus, settings, journal.
import { ACTIONS, keyName, DEFAULT_SETTINGS } from '../game/state.js';
import { entries, THREADS, timeline, leads, npcs, LOOP_SECONDS , curiosities } from '../game/story.js';
import { installDeco, tearSheet, writeWordmark, stains, wornPolygon, hashStr } from './deco.js';

const rng = (seed) => { let s = seed >>> 0 || 1; return () => { s = (1664525 * s + 1013904223) >>> 0; return s / 4294967296; }; };

export const $ = (s, r = document) => r.querySelector(s);
export function el(tag, cls, text, parent) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  if (parent) parent.appendChild(e);
  return e;
}
export const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

export class UI {
  constructor(game) {
    this.g = game;
    this.hud = $('#hud');
    this.prompt = $('#prompt');
    this.reticle = $('#reticle');
    this.sub = $('#subtitle');
    this.hint = $('#hint');
    this.toasts = $('#toasts');
    this.place = $('#place');
    this.overlay = $('#overlay');
    this.panel = $('#panel');
    this.dialog = $('#dialog');
    this.journalEl = $('#journal');
    this.subQueue = [];
    this.subTimer = 0;
    this.hintTimer = 0;
    this.placeTimer = 0;
    this.jTab = 'questions';
    this.openEntry = null;
    this.onPanelClose = null;
    installDeco();
    const wm = $('#wordmark'); if (wm) writeWordmark(wm);
  }

  // ---------- HUD ----------
  setPrompt(label) {
    if (label) { this.prompt.lastChild.textContent = label; this.prompt.classList.add('on'); this.reticle.classList.add('on'); }
    else { this.prompt.classList.remove('on'); this.reticle.classList.remove('on'); }
  }
  showPlace(name, sub) {
    this.place.querySelector('.place-name').textContent = name;
    this.place.querySelector('.place-sub').textContent = sub || '';
    this.place.classList.add('show');
    this.placeTimer = 4.5;
  }
  subtitle(text, dur = 5) {
    if (!this.g.settings.subtitles) return;
    this.subQueue.push([text, dur]);
    if (this.subTimer <= 0) this.nextSub();
  }
  nextSub() {
    const n = this.subQueue.shift();
    if (!n) { this.sub.classList.remove('on'); this.subTimer = 0; return; }
    this.sub.textContent = n[0];
    this.sub.classList.add('on');
    this.subTimer = n[1];
  }
  clearSubs() { this.subQueue.length = 0; this.subTimer = 0; this.sub.classList.remove('on'); }
  showHint(html, dur = 7) { this.hint.innerHTML = html; this.hint.classList.add('on'); this.hintTimer = dur; }
  toast(kind, text, amber) {
    const t = el('div', 'toast' + (amber ? ' amber' : ''), null, this.toasts);
    el('div', 't-k', kind, t); el('div', 't-v', text, t);
    setTimeout(() => t.classList.add('out'), 4200);
    setTimeout(() => t.remove(), 4900);
    while (this.toasts.children.length > 4) this.toasts.firstChild.remove();
  }
  tick(dt) {
    if (this.subTimer > 0) { this.subTimer -= dt; if (this.subTimer <= 0) { this.sub.classList.remove('on'); setTimeout(() => { if (this.subTimer <= 0) this.nextSub(); }, 700); this.subTimer = -1; } }
    if (this.hintTimer > 0) { this.hintTimer -= dt; if (this.hintTimer <= 0) this.hint.classList.remove('on'); }
    if (this.placeTimer > 0) { this.placeTimer -= dt; if (this.placeTimer <= 0) this.place.classList.remove('show'); }
  }

  // ---------- panels ----------
  openPanel(build, o = {}) {
    this.panel.innerHTML = '';
    this.panel.className = 'panel sheet' + (o.cls ? ' ' + o.cls : '');
    tearSheet(this.panel);
    // the tape lands a little differently on every sheet
    const tapes = $('#panelWrap').querySelectorAll('.tape'), r = Math.random;
    tapes.forEach((t, i) => { t.style.transform = `rotate(${(i ? 1 : -1) * (2 + r() * 5)}deg)`; t.style[i ? 'right' : 'left'] = (4 + r() * 10) + '%'; t.style.width = (96 + r() * 40) + 'px'; });
    this.overlay.className = 'screen' + (o.overlayCls ? ' ' + o.overlayCls : '');
    this.overlay.hidden = false;
    this.onPanelClose = o.onClose || null;
    this.panel.dataset.simple = '';
    build(this.panel);
    const first = this.panel.querySelector('.btn.primary, .menu button, .btn, button');
    if (first && !o.noFocus) setTimeout(() => first.focus({ preventScroll: true }), 30);
  }
  closePanel() {
    if (this.overlay.hidden) return;
    this.overlay.hidden = true;
    this.panel.innerHTML = '';
    this.keyHandler = null;
    const f = this.onPanelClose; this.onPanelClose = null;
    if (f) f();
    const a = this.afterClose; this.afterClose = null;
    // a handler may close one panel and open the next; only hand control back if nothing reopened
    if (a) setTimeout(() => { if (this.overlay.hidden) a(); else this.afterClose = a; }, 0);
  }
  head(p, kicker, title) { el('p', 'kicker', kicker, p); el('h2', null, title, p); }
  btn(parent, label, fn, cls = '') {
    const b = el('button', 'btn ' + cls, label, parent);
    b.addEventListener('click', (e) => { e.stopPropagation(); this.g.sound.click(); fn(); });
    return b;
  }
  // a document: an entry read in the world
  doc(kicker, title, text, o = {}) {
    this.openPanel(p => {
      this.head(p, kicker, title);
      el('div', 'body', text, p);
      if (o.note) el('p', 'note', o.note, p);
      const row = el('div', 'row', null, p);
      for (const [label, fn, cls] of (o.buttons || [])) this.btn(row, label, fn, cls);
      this.btn(row, o.closeLabel || 'Close', () => this.closePanel(), o.buttons && o.buttons.length ? '' : 'primary');
    }, { cls: (o.paper ? 'doc' : '') + (kicker === 'Letter' ? ' letter' : ''), onClose: o.onClose });
    this.panel.dataset.simple = '1';
  }

  // ---------- dialog ----------
  openDialog(name, role, pages) {
    this.clearSubs();   // a muttered line would sit behind the box, half hidden
    this.dialog.hidden = false;
    $('.dlg-name', this.dialog).textContent = name;
    $('.dlg-role', this.dialog).textContent = role;
    const dots = $('.dlg-pages', this.dialog); dots.innerHTML = '';
    for (let i = 0; i < pages; i++) el('i', null, null, dots);
  }
  dialogPage(i, text) {
    const dots = $('.dlg-pages', this.dialog).children;
    for (let k = 0; k < dots.length; k++) dots[k].classList.toggle('on', k <= i);
    const t = $('.dlg-text', this.dialog);
    t.textContent = '';
    return t;
  }
  closeDialog() { this.dialog.hidden = true; }

  // ---------- menus ----------
  menu(container, items) {
    container.innerHTML = '';
    items.forEach((it, i) => {
      if (it.note) { el('p', 'note', it.note, container); return; }
      const b = el('button', null, null, container);
      el('span', 'n', String(i + 1).padStart(2, '0'), b);
      el('span', null, it.label, b);
      if (it.disabled) b.disabled = true;
      b.addEventListener('mouseenter', () => this.g.sound.hover());
      b.addEventListener('click', (e) => { e.stopPropagation(); this.g.sound.click(); it.fn(); });
    });
  }

  settings(onBack) {
    const s = this.g.settings;
    this.openPanel(p => {
      this.head(p, 'Sound, controls and picture', 'Settings');
      const wrap = el('div', 'settings', null, p);
      const group = (title) => { const g = el('div', 'set-group', null, wrap); el('h3', null, title, g); return g; };
      const slider = (g, label, key, min, max, step, show = v => Math.round(v * 100)) => {
        const r = el('div', 'set-row', null, g);
        const id = 'set-' + key;
        const l = el('label', null, label, r); l.htmlFor = id;
        const i = el('input', null, null, r); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = s[key]; i.id = id;
        const o = el('output', null, show(s[key]), r);
        i.addEventListener('input', () => { s[key] = parseFloat(i.value); o.textContent = show(s[key]); this.g.applySettings(); });
      };
      const seg = (g, label, key, opts) => {
        const r = el('div', 'set-row', null, g); el('label', null, label, r);
        const w = el('div', 'seg', null, r); el('output', null, '', r);
        for (const [v, t] of opts) {
          const b = el('button', s[key] === v ? 'on' : '', t, w);
          b.addEventListener('click', () => { s[key] = v; [...w.children].forEach(c => c.classList.remove('on')); b.classList.add('on'); this.g.sound.click(); this.g.applySettings(); });
        }
      };
      const tog = (g, label, key) => {
        const r = el('div', 'set-row', null, g); el('label', null, label, r);
        const b = el('button', 'toggle' + (s[key] ? ' on' : ''), null, r); b.setAttribute('aria-label', label); b.setAttribute('aria-pressed', !!s[key]);
        el('output', null, '', r);
        b.addEventListener('click', () => { s[key] = !s[key]; b.classList.toggle('on', s[key]); b.setAttribute('aria-pressed', s[key]); this.g.sound.click(); this.g.applySettings(); });
      };
      const a = group('Sound');
      slider(a, 'Master', 'master', 0, 1, 0.01); slider(a, 'Music', 'music', 0, 1, 0.01); slider(a, 'Effects', 'sfx', 0, 1, 0.01);
      slider(a, 'Ambience', 'amb', 0, 1, 0.01); slider(a, 'Voices', 'voice', 0, 1, 0.01);
      const c = group('Controls');
      slider(c, 'Mouse sensitivity', 'sensitivity', 0.2, 3, 0.05, v => v.toFixed(2)); tog(c, 'Invert look', 'invertY');
      slider(c, 'Field of view', 'fov', 55, 100, 1, v => Math.round(v) + '°');
      const d = group('Picture');
      slider(d, 'Brightness', 'brightness', 0.7, 2, 0.05, v => Math.round(v * 100) + '%');
      seg(d, 'Quality', 'quality', [['lowest', 'Lowest'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High']]);
      tog(d, 'Bloom', 'bloom'); tog(d, 'Film grain', 'grain'); tog(d, 'Head bob', 'bob'); tog(d, 'Camera shake', 'shake');
      tog(d, 'Reduce flashing', 'calm');
      const e = group('Interface');
      tog(e, 'Subtitles', 'subtitles');
      seg(e, 'Text size', 'textSize', [[1, 'Normal'], [1.15, 'Large'], [1.3, 'Larger']]);
      seg(e, 'Subtitle size', 'subSize', [[0.85, 'Small'], [1, 'Normal'], [1.25, 'Large'], [1.5, 'Huge']]);
      // keys: click one, press the key you want; a key already in use swaps over
      const kg = group('Keys');
      const kb = [];
      for (const [act, label] of ACTIONS) {
        const r = el('div', 'set-row', null, kg); el('label', null, label, r);
        const b = el('button', 'keybind', keyName(s.keys[act]), r); el('output', null, '', r);
        b.addEventListener('click', () => {
          this.g.sound.click();
          kb.forEach(x => x.b.classList.remove('listening'));
          b.classList.add('listening'); b.textContent = 'Press a key\u2026';
          this.keyHandler = (ev) => {
            ev.preventDefault(); ev.stopPropagation();
            this.keyHandler = null; b.classList.remove('listening');
            if (ev.code !== 'Escape') {
              const other = Object.keys(s.keys).find(a => a !== act && s.keys[a] === ev.code);
              if (other) s.keys[other] = s.keys[act];
              s.keys[act] = ev.code;
              this.g.saveSettings();
            }
            kb.forEach(x => x.b.textContent = keyName(s.keys[x.act]));
          };
          this.keyHandler.rebind = true;
        });
        kb.push({ act, b });
      }
      { const r = el('div', 'set-row', null, kg); el('label', null, '', r);
        const b = el('button', 'keybind', 'Reset keys', r); el('output', null, '', r);
        b.addEventListener('click', () => { this.g.sound.click(); s.keys = { ...DEFAULT_SETTINGS.keys }; kb.forEach(x => x.b.textContent = keyName(s.keys[x.act])); this.g.saveSettings(); }); }
      if (document.fullscreenEnabled) {
        const r = el('div', 'set-row', null, e); el('label', null, 'Fullscreen', r);
        const b = el('button', 'toggle' + (document.fullscreenElement ? ' on' : ''), null, r); b.setAttribute('aria-label', 'Fullscreen'); el('output', null, '', r);
        b.addEventListener('click', () => { this.g.sound.click(); if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => { }); setTimeout(() => b.classList.toggle('on', !!document.fullscreenElement), 300); });
      }
      const row = el('div', 'row', null, p);
      this.btn(row, 'Back', () => { this.g.saveSettings(); onBack(); }, 'primary');
    }, { cls: 'wide', onClose: () => this.g.saveSettings() });
  }

  credits(onBack) {
    this.openPanel(p => {
      this.head(p, 'Credits', 'Rebound');
      const w = el('div', 'credits-roll', null, p);
      const rows = [
        ['Game design and story', 'made by NyxiePlaysGames'], ['World, levels and artwork', 'made by NyxiePlaysGames'],
        ['Music and sound', 'made by NyxiePlaysGames'], ['Writing', 'made by NyxiePlaysGames'],
        ['Programming', 'made by NyxiePlaysGames'], ['Testing', 'made by NyxiePlaysGames'], ['Keanu', 'himself, a very good boy'], ['Milky', 'a cameo, down in the Deep'],
        ['Built with', 'Three.js and the Web Audio API'], ['Lettering', 'drawn by hand for Rebound']
      ];
      for (const [a, b] of rows) { const r = el('div', 'cr', null, w); el('span', null, a, r); el('b', null, b, r); }
      el('p', 'note', 'Thank you for playing.', p);
      const row = el('div', 'row', null, p);
      this.btn(row, 'Back', onBack, 'primary');
    }, { cls: 'wide' });
  }

  // ---------- journal ----------
  openJournal() {
    this.journalEl.hidden = false;
    const jc = this.journalEl.querySelector('.j-close'); if (jc) jc.innerHTML = '<kbd>' + keyName(this.g.settings.keys.journal) + '</kbd> or <kbd>Esc</kbd> to close';
    this.wearPage();
    this.renderJournal();
  }
  closeJournal() { this.journalEl.hidden = true; this.openEntry = null; }
  renderJournal() {
    const st = this.g.st;
    const tabs = $('#jTabs'); tabs.innerHTML = '';
    const openLeads = Object.keys(leads).filter(k => this.g.leadOpen(k)).length;
    const tabList = [
      ['questions', 'Questions', ''], ['notes', 'Notes', String(st.found.size)], ['timeline', 'Timeline', ''],
      ['people', 'People', st.people.size + '/6'], ['map', 'Map', ''], ['curios', 'Curiosities', this.curioCount()]
    ];
    for (const [k, label, n] of tabList) {
      const b = el('button', this.jTab === k ? 'on' : '', null, tabs);
      el('span', null, label, b); if (n) el('i', null, n, b);
      if (k === 'questions' && openLeads) el('i', null, openLeads + ' open', b);
      b.addEventListener('click', () => { this.jTab = k; this.openEntry = null; this.g.sound.page(); this.renderJournal(); });
    }
    $('#jLoop').innerHTML = `Cycle ${st.loop}<br>${this.g.st.ended ? 'After' : fmt(LOOP_SECONDS - st.elapsed) + ' left in this one'}`;
    const body = $('#jBody'); body.innerHTML = '';
    this['j_' + this.jTab](body);
    body.scrollTop = 0;
  }
  entryCard(parent, id) {
    const st = this.g.st;
    const e = entries[id];
    const known = st.found.has(id);
    const c = el('button', 'entry' + (known ? '' : ' unknown') + (this.openEntry === id ? ' open' : ''), null, parent);
    if (!known) { el('div', 'k', 'Unknown', c); el('div', 'h', 'Something you have not found yet', c); c.disabled = true; return; }
    this.wearNote(c, id);
    el('div', 'k' + (st.fresh.has(id) ? ' new' : ''), e[1], c);
    el('div', 'h', e[2], c);
    el('div', 'x', e[3], c);
    c.addEventListener('click', () => { this.openEntry = this.openEntry === id ? null : id; st.fresh.delete(id); this.g.sound.page(); this.renderJournal(); });
  }
  // ---------- wear ----------
  // A note gets older every cycle you carry it through the rebound: yellower, creased, ringed by
  // a mug, thumbed, rained on, and in the end torn at a corner.
  wearNote(c, id) {
    const st = this.g.st, S = stains();
    const age = Math.max(0, st.loop - ((st.foundAt && st.foundAt[id]) ?? st.loop));
    const lvl = Math.min(4, age);
    if (!lvl) return;
    const r = rng(hashStr(id) ^ 0x9e3779b9);
    const pick = (a) => a[Math.floor(r() * a.length)];
    const L = [], P = [], Z = [];
    const add = (img, size) => { if (!img) return; L.push(img); P.push(`${Math.round(r() * 100)}% ${Math.round(r() * 100)}%`); Z.push(size); };
    if (r() < 0.7) add(pick(S.fox), '140px');
    if (lvl >= 2) add(r() < 0.55 ? pick(S.coffee) : pick(S.print), r() < 0.5 ? '150px' : '100px');
    if (lvl >= 3) { add(pick(S.water), '230px'); add(pick(S.smudge), '200px'); }
    if (lvl >= 4) add(pick(S.coffee), '170px');
    if (lvl >= 2) { // a fold, pressed flat again
      const a = Math.round(20 + r() * 140);
      L.push(`linear-gradient(${a}deg, transparent 49.3%, rgba(255,252,240,.45) 49.7%, rgba(70,56,32,.2) 50.1%, transparent 50.6%)`); P.push('0 0'); Z.push('100% 100%');
    }
    c.style.setProperty('--stains', L.join(','));
    c.style.setProperty('--stain-pos', P.join(','));
    c.style.setProperty('--stain-size', Z.join(','));
    c.style.setProperty('--stain-rep', L.map(() => 'no-repeat').join(','));
    c.style.setProperty('--note-c', ['#efe7d0', '#ebdfc0', '#e4d4ab', '#dccb9a', '#d2bf8a'][lvl]);
    c.style.setProperty('--tape-c', ['rgba(240,230,180,.82)', 'rgba(236,222,165,.84)', 'rgba(228,208,140,.86)', 'rgba(214,190,120,.88)', 'rgba(200,172,100,.9)'][lvl]);
    c.style.setProperty('--torn-note', wornPolygon(hashStr(id), { amp: 18 + lvl * 9, corner: lvl >= 3 && r() < 0.65 ? 1 + Math.floor(r() * 4) : 0, cut: 12 + r() * 10 }));
    c.classList.add('worn', 'worn' + lvl);
  }
  // The notebook page itself: a dried tide line for every cycle that ended in the water, more
  // stains as the cycles pile up, and water climbing the page in the last minutes of this one.
  wearPage() {
    const st = this.g.st, S = stains(), page = $('#nbPage');
    if (!page) return;
    const L = [], P = [], Z = [], R = [];
    const add = (img, pos, size, rep = 'no-repeat') => { if (!img) return; L.push(img); P.push(pos); Z.push(size); R.push(rep); };
    const k = st.ended ? 0 : Math.max(0, Math.min(1, (st.elapsed - 1020) / 300));
    const water = $('#nbWater');
    if (water) water.style.height = k > 0 ? (4 + k * 40).toFixed(1) + '%' : '0';
    const past = st.ended ? 0 : Math.min(5, st.loop - 1);
    for (let i = 0; i < past; i++) add(S.tide[i % S.tide.length], '0 100%', `100% ${22 + i * 8}%`);
    const spots = [[S.coffee[0], '6% 88%', '190px'], [S.print[0], '94% 10%', '120px'], [S.water[1], '62% 38%', '300px'], [S.coffee[2], '80% 74%', '160px'], [S.smudge[0], '28% 18%', '240px'], [S.fox[1], '50% 50%', '320px'], [S.water[2], '14% 30%', '260px']];
    for (let i = 0; i < Math.min(spots.length, st.loop - 1); i++) add(...spots[i]);
    add('var(--paper-tex)', '0 0', '360px', 'repeat');
    page.style.backgroundImage = L.join(',');
    page.style.backgroundPosition = P.join(',');
    page.style.backgroundSize = Z.join(',');
    page.style.backgroundRepeat = R.join(',');
    const yel = Math.min(1, (st.loop - 1) / 8);
    page.style.backgroundColor = `rgb(${Math.round(221 - 12 * yel)},${Math.round(211 - 18 * yel)},${Math.round(184 - 34 * yel)})`;
    page.style.setProperty('--torn', wornPolygon(500 + st.loop, { amp: 8 + Math.min(st.loop, 8) * 2.4, corner: st.loop >= 4 ? 3 : 0, cut: 6 }));
  }
  j_questions(b) {
    el('h3', null, 'Questions', b);
    el('p', 'sub', 'Every answer here was in the basin all along.', b);
    const st = this.g.st;
    for (const tk of ['vale', 'engine', 'exodus', 'tarn', 'residents', 'letters']) {
      const T = THREADS[tk];
      const ids = Object.keys(entries).filter(k => entries[k][0] === tk);
      const have = ids.filter(k => st.found.has(k));
      const t = el('section', 'thread', null, b);
      const h = el('div', 'thread-head', null, t);
      el('h3', null, T.title, h);
      const dots = el('div', 'dots', null, h);
      for (const k of ids) el('i', st.found.has(k) ? 'on' : '', null, dots);
      el('p', 'sub', have.length ? `${have.length} of ${ids.length} pieces` : T.hint, t);
      const list = el('div', 'entries', null, t);
      for (const k of have) this.entryCard(list, k);
      if (have.length < ids.length) this.entryCard(list, '__unknown');
    }
    const ls = Object.keys(leads).filter(k => this.g.leadKnown(k));
    if (ls.length) {
      const t = el('section', 'thread', null, b);
      el('h3', null, 'Open leads', t);
      el('p', 'sub', 'Things you meant to come back to.', t);
      const w = el('div', 'leads', null, t);
      for (const k of ls) el('div', 'lead' + (this.g.leadOpen(k) ? '' : ' done'), leads[k][0], w);
    }
  }
  j_notes(b) {
    el('h3', null, 'Notes', b);
    el('p', 'sub', 'Everything you have found, sorted by kind.', b);
    const st = this.g.st;
    const kinds = {};
    for (const id of st.found) { const k = entries[id]?.[1]; if (!k) continue; (kinds[k] ||= []).push(id); }
    const order = ['Place', 'Schedule', 'Observation', 'Recording', 'Radio', 'Machine', 'Procedure', 'Credential', 'Manifest', 'Letter', 'Solution', 'Person'];
    for (const k of order) {
      if (!kinds[k]) continue;
      const t = el('section', 'thread', null, b);
      el('p', 'kicker', k + (kinds[k].length > 1 ? 's' : ''), t);
      const list = el('div', 'entries', null, t);
      for (const id of kinds[k]) this.entryCard(list, id);
    }
    if (!st.found.size) el('p', 'sub', 'Nothing yet. Look around.', b);
  }
  j_timeline(b) {
    el('h3', null, 'The basin’s schedule', b);
    el('p', 'sub', 'The same things happen at the same minute, every cycle.', b);
    const w = el('div', 'tl', null, b);
    const st = this.g.st;
    let nowPlaced = false;
    for (const ev of timeline) {
      const known = !ev.know || st.found.has(ev.know);
      if (!nowPlaced && st.elapsed < ev.t && !st.ended) {
        const r = el('div', 'tl-row now', null, w); el('time', null, fmt(st.elapsed).replace(/^/, ''), r); el('span', null, 'You are here', r);
        nowPlaced = true;
      }
      const r = el('div', 'tl-row ' + (known ? 'known' : 'unknown'), null, w);
      el('time', null, known ? fmt(ev.t) : '--:--', r);
      el('span', null, known ? ev.label : 'Something happens', r);
    }
  }
  j_people(b) {
    el('h3', null, 'People', b);
    el('p', 'sub', 'The ones who stayed.', b);
    const w = el('div', 'people', null, b);
    for (const id of Object.keys(npcs)) this.entryCard(w, id);
  }
  // the small secrets: what you've found, and a nudge towards what you haven't
  curioCount() {
    const s = this.g.st.solved || {}, heard = (s.overheard || []).length, all = this.g.routineLines();
    const n = curiosities.filter(c => c.has(s)).length + (heard >= all && all ? 1 : 0);
    return n ? n + '/' + (curiosities.length + 1) : '';
  }
  j_curios(b) {
    const s = this.g.st.solved || {};
    el('h3', null, 'Curiosities', b);
    el('p', 'sub', 'Small things the basin keeps for people who look.', b);
    const w = el('div', 'curios', null, b);
    const card = (got, title, text) => {
      const c = el('div', 'curio' + (got ? ' got' : ''), null, w);
      el('b', null, got ? title : '?', c);
      el('p', null, got ? text : text, c);
    };
    for (const c of curiosities) card(!!c.has(s), c.title, c.has(s) ? c.found : c.hint);
    const heard = (s.overheard || []).length, all = this.g.routineLines();
    card(heard >= all && all > 0, 'Overheard', heard >= all ? 'Every one of their little rounds, and what they mutter on the way. ' + all + ' of ' + all + '.'
      : 'They each have somewhere to be at certain times of day. Be close by when they get there. ' + heard + ' of ' + all + ' heard.');
  }
  j_map(b) {
    el('h3', null, 'The basin', b);
    el('p', 'sub', 'Drawn from memory. Places you have been are inked in.', b);
    const wrap = el('div', 'map-wrap', null, b);
    wrap.innerHTML = this.g.mapSVG();
  }
}
