// The basin's clock. Everything here is a pure function of elapsed time and of what the player
// has permanently changed (st.solved), so the world can be set to any moment exactly, and the
// same thing always happens at the same minute.
import * as THREE from '../../vendor/three.module.min.js';
import { TIMES, LOOP_SECONDS, lanternAt, witness } from './story.js';
import { skyU } from '../world/sky.js';
import { shared } from '../world/materials.js';
import { DF } from '../world/deep.js';

const sm = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const tmpQ = new THREE.Quaternion(), tmpV = new THREE.Vector3(), axis = new THREE.Vector3();

// where the deep run's water stands at a given moment
export function runWater(e, st) {
  if (st.solved.pump) return DF - 1.6;
  const high = DF + 2.6, low = DF - 1.6;
  if (e < TIMES.drain) return high;
  if (e < TIMES.drain + 25) return high + (low - high) * sm(TIMES.drain, TIMES.drain + 25, e);
  if (e < TIMES.surge) return low;
  if (e < TIMES.surge + 12) return low + (high - low) * sm(TIMES.surge, TIMES.surge + 12, e);
  return high;
}
export const runPassable = (e, st) => runWater(e, st) < DF - 0.5;
export const gridDown = (e) => e >= TIMES.power;
export const relayLive = (e) => e >= TIMES.relay;

// pieces that sink at the end: [chunk name, start time, depth, tilt x, tilt z]
const COLLAPSE = [
  ['tarn', 1262, 14, 0, 0], ['tarnRoofs', 1274, 9, 0.05, -0.06], ['skyline', 1266, 30, 0.05, 0.02],
  ['market', 1284, 9, 0.12, -0.05], ['quay', 1286, 10, -0.08, 0.1], ['isle', 1290, 12, 0.06, 0.04], ['rise', 1289, 9, -0.05, 0.08],
  ['plaza', 1292, 16, 0.07, 0.09], ['apartments', 1294, 22, -0.1, 0.05], ['archive', 1295, 20, 0.08, -0.06],
  ['concourse', 1298, 18, -0.04, 0.07], ['bell', 1299, 20, -0.18, 0.05], ['terrace', 1302, 16, 0.06, -0.05], ['bridge', 1303, 24, 0.1, 0.02],
  ['mast', 1306, 20, 0.03, 0.05], ['station', 1306, 20, 0.03, 0.05]
];

export class Events {
  constructor(game) {
    this.g = game;
    this.fired = new Set();
    this.lastLantern = 0;
  }
  reset() { this.fired.clear(); this.lastLantern = 0; }

  // run once per frame with the current elapsed time
  apply(dt, e, prev, live) {
    const g = this.g, W = g.world, st = g.st, ended = st.ended;
    const f = e / LOOP_SECONDS;
    // during the ending the night lifts slowly: dk runs 0 -> 1
    const dk = ended ? (g.dawnK ?? 1) : 0;

    // ---- sky: the sun sinks through the loop; the Fracture brightens
    const elev = ended ? -0.03 + 0.38 * dk : (0.15 - f * 0.17);
    const az = 245 * Math.PI / 180;
    skyU.sunDir.value.set(Math.sin(az) * Math.cos(elev), Math.sin(elev), Math.cos(az) * Math.cos(elev)).normalize();
    skyU.dusk.value = ended ? 0.6 * (1 - dk) : sm(0, 1, f) * 0.85;
    skyU.dawn.value = ended ? dk : 0;
    skyU.fracture.value = ended ? 1.6 * Math.pow(1 - dk, 2) : 0.18 + 0.6 * Math.pow(f, 1.6) + sm(1262, 1320, e) * 1.2;
    const sunK = ended ? 0.2 + 1.1 * dk : Math.max(0.05, 1 - f * 0.85);
    W.sunBase = sunK;
    // the sun's colour deepens towards red
    skyU.sunCol.value.setRGB(1.0, 0.6 - f * 0.18, 0.35 - f * 0.15);
    W.sun.color.copy(skyU.sunCol.value).lerp(new THREE.Color(1, 0.85, 0.7), 0.4);
    skyU.hor.value.setRGB(0.54 - f * 0.18, 0.37 - f * 0.17, 0.45 - f * 0.12);
    skyU.mid.value.setRGB(0.23 - f * 0.1, 0.17 - f * 0.08, 0.34 - f * 0.12);
    if (ended) { skyU.hor.value.setRGB(0.95, 0.66, 0.5); skyU.mid.value.setRGB(0.5, 0.55, 0.72); skyU.zen.value.setRGB(0.18, 0.3, 0.55); }
    else skyU.zen.value.setRGB(0.04, 0.06, 0.15);
    shared.uPulse.value = sm(1140, 1320, e);

    // ---- the bell tower clock shows the cycle; the bell swings when it tolls
    for (const h of W.clockHands) h.rotation.z = -(ended ? 0 : f) * Math.PI * 2;
    if (W.bell) { W.bell.swing *= Math.exp(-dt * 0.35); W.bell.mesh.rotation.z = Math.sin(g.time * 2.4) * 0.25 * W.bell.swing; }

    // ---- the engine grows restless
    W.engine.wobble = ended ? 0 : sm(1140, 1300, e) * 1.5;
    W.engine.speed = ended ? 0.2 : 1 + sm(1100, 1320, e) * 2.5;

    // ---- lanterns
    const L = ended ? 0 : lanternAt(e);
    W.lanterns.forEach((ln, i) => {
      const on = L === i + 1;
      ln.level += ((on ? 1 : 0) - ln.level) * Math.min(1, dt * (on ? 14 : 4));
      ln.glassMat.color.setRGB(1, 0.82, 0.6).multiplyScalar(0.6 + ln.level * 7);
      ln.light.intensity = 1.5 + ln.level * 22;
      ln.light.color.setRGB(1, 0.72 + ln.level * 0.1, 0.42);
    });
    if (live && L && L !== this.lastLantern) {
      g.sound.lantern(L);
      if (g.region === 'city') g.onLanternSeen(L, e);
    }
    this.lastLantern = L;

    // ---- the gallery sunbeam, 08:00 - 10:00
    const beam = ended ? 0 : sm(TIMES.sunStart - 20, TIMES.sunStart + 15, e) * (1 - sm(TIMES.sunEnd - 15, TIMES.sunEnd + 20, e));
    W.beam.material.opacity = beam * 0.22;
    W.beam.patch.opacity = beam * 0.5;
    W.frames.forEach((fm, i) => { fm.material.opacity = Math.min(1, beam * 1.4 - i * 0.05) * 0.95; });
    W.sunPatch.level = beam; W.sunPatch.intensity = 5;

    // ---- the tide in the run
    const wl = ended ? DF - 1.6 : runWater(e, st);
    W.runWater.position.y = wl;
    shared.uDeepTide.value = wl;
    W.tideNeedle.position.y = DF + 1.8 + Math.max(-0.5, Math.min(0.5, (wl - (DF + 0.5)) / 4.2));

    // ---- doors that remember
    W.hatch.set(!!st.solved.hatch);
    W.vaultDoor.set(!!st.solved.vault);
    W.tideDoor.set(!!st.solved.code);
    W.bulkDoor.set(!!st.solved.bulkhead);
    W.serviceGate.set(ended || e >= TIMES.span);
    W.serviceGate2.set(ended || e >= TIMES.span);
    const liftOK = st.solved.pump && (!gridDown(e) || ended);
    W.liftLampStation.color.setHex(liftOK ? 0x5fe8dc : 0xff5a3c);
    W.liftLampDeep.color.setHex(liftOK ? 0x5fe8dc : 0xff5a3c);
    W.pumpLight.color.setHex(st.solved.pump ? 0x5fe8dc : 0xff5a3c);
    W.pumpLatch.rotation.x = st.solved.pump ? 0.8 : -0.8;
    if (!g.liftRiding) { W.liftGateStation.set(liftOK && g.nearLift === 'station'); W.liftGateDeep.set(liftOK && g.nearLift === 'deep'); }

    // ---- the counter under the tape
    W.counterTape.visible = !st.found.has('imprintsTruth');

    // ---- falling towers
    for (const fl of W.fallers) {
      const t0 = TIMES[fl.time];
      const k = ended ? 0 : sm(t0, t0 + 9, e);
      const ch = fl.chunk;
      const ang = Math.pow(k, 2.2) * 1.45;
      axis.set(fl.dirZ, 0, -fl.dirX).normalize();
      tmpQ.setFromAxisAngle(axis, ang);
      const pivot = tmpV.set(fl.x + fl.dirX * 4, 1.5, fl.z + fl.dirZ * 4);
      const rotated = pivot.clone().applyQuaternion(tmpQ);
      ch.group.quaternion.copy(tmpQ);
      ch.group.position.set(pivot.x - rotated.x, pivot.y - rotated.y - k * 9, pivot.z - rotated.z);
      ch.solid = k < 0.02;
      if (live && prev < t0 && e >= t0) g.distantCrash(fl.x, fl.z, 0.5);
      if (live && prev < t0 + 5.5 && e >= t0 + 5.5) {
        g.distantSplash(fl.x, fl.z);
        for (let i = 0; i < 6; i++) W.fx.splash(fl.x + fl.dirX * (8 + i * 5), 0, fl.z + fl.dirZ * (8 + i * 5), 3.5);
      }
      if (live && k > 0.05 && k < 0.9 && Math.random() < dt * 6) {
        const tip = 1.5 + fl.h * (0.4 + Math.random() * 0.6);
        W.fx.burst(fl.x + fl.dirX * Math.sin(ang) * tip, Math.cos(ang) * tip, fl.z + fl.dirZ * Math.sin(ang) * tip, 3, 6, 4);
      }
    }

    // ---- the span
    {
      const k = ended ? 0 : sm(TIMES.span, TIMES.span + 3.5, e);
      const ch = W.span;
      tmpQ.setFromAxisAngle(axis.set(1, 0, 0), -k * 0.5);
      const pivot = tmpV.set(0, 6, -131);
      const rotated = pivot.clone().applyQuaternion(tmpQ);
      ch.group.quaternion.copy(tmpQ);
      ch.group.position.set(pivot.x - rotated.x, pivot.y - rotated.y - Math.pow(k, 2) * 16, pivot.z - rotated.z);
      ch.offset.y = -Math.pow(k, 2) * 16 - k * 3;
      ch.solid = k < 0.15;
      if (live && prev < TIMES.span && e >= TIMES.span) { g.distantCrash(0, -138, 0.9); g.sound.door(true); W.fx.burst(0, 5, -138, 30, 4, 3); }
      if (live && prev < TIMES.span + 3 && e >= TIMES.span + 3) { g.distantSplash(0, -138); W.fx.splash(0, 0, -136, 4); W.fx.splash(0, 0, -141, 4); }
    }

    // ---- grid failure: lights stutter, station dims to emergency
    const grid = ended ? 1 : (gridDown(e) ? 0.35 + 0.15 * Math.sin(e * 7) * Math.sin(e * 3.1) : 1);
    for (const a of W.pool.anchors) {
      if (a.key === 'engine' || a.key === 'core' || a.key === 'lighthouse' || a.key === 'skiff' || a.key === 'sunPatch') continue;
      a.level = grid;
      a.flickerBoost = gridDown(e) && !ended ? 0.6 : 0;
    }
    if (W.beaconRed) W.beaconRed.level = (Math.sin(e * 2.4) > 0.6 ? 1 : 0.05);

    // ---- the Core and its beam
    const coreK = ended ? 0 : 0.5 + f * 0.8 + sm(1262, 1320, e) * 2;
    W.core.beam.material.uniforms.amt.value = ended ? 6 * Math.pow(1 - dk, 1.5) : 0.35 + f * 0.6 + sm(1262, 1320, e) * 2.2;
    W.core.glowBeam.material.uniforms.amt.value = ended ? 1.5 * Math.pow(1 - dk, 1.5) : 0.12 + f * 0.2 + sm(1262, 1320, e) * 0.6;
    W.core.coreMat.color.setRGB(0.39, 0.94, 0.89).multiplyScalar(ended ? 0.6 : 3 + coreK * (1.5 + Math.sin(g.time * 3) * 0.3));
    W.core.shell.scale.setScalar(1 + 0.05 * Math.sin(g.time * 2.0) + sm(1262, 1320, e) * 0.5);
    W.sea.u.coreAmt.value = ended ? 0 : 0.3 + f * 0.5 + sm(1262, 1320, e) * 1.5;

    if (W.tarnLamp) W.tarnLamp.visible = ended && Math.sin(g.time * 1.3) > -0.6;

    // ---- lighthouse
    const lh = W.lighthouse;
    const lit = (!ended && g.cycle.beacon) || !!g.endingLamp;   // the finale flashes it twice
    lh.lampMat.color.setRGB(1, 0.89, 0.69).multiplyScalar(lit ? 5 : 0.3);
    lh.beamMat.opacity = lit ? 0.08 : 0;
    lh.light.level = lit ? 1 : 0; lh.light.intensity = 30;
    lh.beamPivot.rotation.y = g.time * (Math.PI * 2 / 11);
    W.answerLight.visible = lit && (g.time % 11) < 0.25 && g.cycle.beaconAt && g.time - g.cycle.beaconAt > 6;

    // ---- sea level and the end
    const rise = ended ? 0 : sm(1262, 1320, e) * 7.5;
    W.seaLevel = rise;
    for (const [name, t0, depth, tx, tz] of COLLAPSE) {
      const ch = W.named[name];
      if (!ch) continue;
      const k = ended ? 0 : sm(t0, t0 + 14, e);
      const drop = Math.pow(k, 1.8) * depth;
      const shake = k > 0 && k < 1 ? Math.sin(g.time * 31 + t0) * 0.04 * (1 - k) : 0;
      ch.offset.y = -drop;
      ch.group.position.y = -drop + shake;
      ch.group.rotation.x = tx * k; ch.group.rotation.z = tz * k;
      // crumbling edges and spray where the platforms meet the rising water
      if (live && k > 0 && k < 0.95 && ch.bounds && !ch.bounds.isEmpty()) {
        const B = ch.bounds, cx = (B.min.x + B.max.x) / 2, cz = (B.min.z + B.max.z) / 2;
        if (Math.hypot(cx - g.body.x, cz - g.body.z) < 160) {
          if (Math.random() < dt * 5) {
            const edge = Math.random() < 0.5;
            const px = edge ? (Math.random() < 0.5 ? B.min.x : B.max.x) : B.min.x + Math.random() * (B.max.x - B.min.x);
            const pz = edge ? B.min.z + Math.random() * (B.max.z - B.min.z) : (Math.random() < 0.5 ? B.min.z : B.max.z);
            W.fx.burst(px, Math.min(B.max.y, 26) - drop, pz, 4, 2, 2);
          }
          if (Math.random() < dt * 4) W.fx.splash(B.min.x + Math.random() * (B.max.x - B.min.x), W.seaLevel, Math.random() < 0.5 ? B.min.z : B.max.z, 1.5 + Math.random() * 2);
        }
      }
    }
    // the deep floods in the last minute
    if (!ended && e > 1290) {
      const k = sm(1290, 1318, e);
      W.runWater.position.y = Math.max(W.runWater.position.y, DF - 1.6 + k * 8);
      shared.uDeepTide.value = W.runWater.position.y;
    }

    // ---- one-shot sounds and witness lines
    if (live) {
      for (const w of witness) {
        const key = 'w' + w.t;
        if (prev < w.t && e >= w.t && !this.fired.has(key)) {
          this.fired.add(key);
          if (w.region === -1 || w.region === g.region) {
            g.ui.subtitle(w.text, 5);
            if (w.know) g.observe(w.know);
          }
        }
      }
      const cross = (t) => prev < t && e >= t;
      if (cross(TIMES.lanternA - 1)) g.bellToll(1);
      if (cross(TIMES.drain) && g.region === 'deep') g.sound.noiseBurst(20, { freq: 600, toFreq: 200, gain: 0.12, attack: 2, wet: 0.6 });
      if (cross(TIMES.surge) && g.region === 'deep') g.sound.noiseBurst(12, { freq: 300, toFreq: 1200, gain: 0.25, attack: 1, wet: 0.6 });
      if (cross(TIMES.relay) && g.region === 'station') g.ui.subtitle('In the radio room, the receiver clicks and warms.', 5);
      if (cross(TIMES.warning)) g.sound.siren();
      if (cross(TIMES.power)) g.sound.powerDown();
      if (cross(TIMES.tremor)) { g.bellToll(3); g.sound.rumble(6, 0.3); }
      if (cross(1262)) g.sound.crash(0.25);
      for (const t of [1270, 1278, 1284, 1292, 1298, 1303, 1308]) if (cross(t)) g.sound.crash(0.18 + (t - 1270) * 0.004);
      if (cross(1300)) g.sound.rumble(20, 0.35);
    }
  }
}
