import * as THREE from '../../vendor/three.module.min.js';
import { Renderer } from '../core/render.js';
import { Body, stepBody } from '../core/physics.js';
import { World, REGIONS } from '../world/world.js';
import { skyU } from '../world/sky.js';
import { SPAWN, F } from '../world/station.js';
import { DOCKS } from '../world/isles.js';
import { DF, CF } from '../world/deep.js';
import { entries, npcs, epilogue, reactions, letterReplies, story, leads, endingLines, timeline, LOOP_SECONDS, TIMES, curiosities } from './story.js';
import { Sound } from '../audio/audio.js';
import { Music } from '../audio/music.js';
import { UI, $, el, fmt } from '../ui/ui.js';
import { loadSettings, saveSettings, freshState, loadState, saveState, hasSave, clearSave , keyName } from './state.js';
import { handlers } from './puzzles.js';
import { Events, runWater, gridDown } from './events.js';
import { Finale } from './finale.js';

const sm = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const lerp = (a, b, t) => a + (b - a) * t;
const BIG = new Set(['Solution', 'Machine', 'Recording', 'Radio', 'Credential', 'Procedure']);
const SURFACE = { station: 'metal', mast: 'grate', shaft: 'metal', ante: 'metal', run: 'wet', lab: 'metal', ramp: 'metal', core: 'metal', market: 'wood', rise: 'wood', isle: 'grass', bridge: 'stone', span: 'grate', skyline: 'grate', apartments: 'wood', bell: 'wood', quay: 'stone', tarnRoofs: 'tile', tarn: 'wet', archive: 'tile' };

export class Game {
  constructor() {
    this.settings = loadSettings();
    this.mode = 'boot';
    this.time = 0;
    this.st = freshState();
    this.cycle = {};
    this.body = new Body();
    this.keys = new Set();
    this.look = { dx: 0, dy: 0 };
    this.locked = false;
    this.region = 'station';
    this.place = '';
    this.target = null;
    this.shakeAmt = 0; this.shakeT = 0;
    this.bobPhase = 0; this.stepDist = 0;
    this.cine = null;
    this.nearLift = null;
    this.liftRiding = false;
    this.radioFreq = 96.0;
    this.ambT = 0;
    this.timers = [];
  }
  // timers that run on the game's own clock (browsers throttle setTimeout in background tabs)
  later(sec, fn) { this.timers.push({ left: sec, fn }); }
  runTimers(dt) {
    if (!this.timers.length) return;
    const due = [];
    for (const t of this.timers) { t.left -= dt; if (t.left <= 0) due.push(t); }
    if (!due.length) return;
    this.timers = this.timers.filter(t => t.left > 0);
    for (const t of due) t.fn();
  }

  // ------------------------------------------------------------------ boot
  async boot() {
    const line = $('#bootLine');
    const step = async (text) => { line.textContent = text; await new Promise(r => setTimeout(r, 30)); };
    await step('Waking the renderer');
    this.R = new Renderer($('#view'));
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(this.settings.fov, innerWidth / innerHeight, 0.1, 6000);
    this.camera.rotation.order = 'YXZ';
    await step('Filling the basin');
    // signs and plaques are painted onto canvases, so every face they use must be loaded first
    if (document.fonts && document.fonts.load) {
      await Promise.race([
        Promise.all(['400 64px "Rebound Hand"', '700 64px "Rebound Hand"'].map(f => document.fonts.load(f).catch(() => { }))),
        new Promise(r => setTimeout(r, 4000))
      ]);
    }
    this.world = new World(this.scene, this.R);
    this.events = new Events(this);
    this.sound = new Sound();
    this.world.sound = this.sound;
    // Keanu brings his ball back
    this.world.fetched = () => {
      const s = (this.st.solved ||= {});
      if (!s.keanuFetch) { s.keanuFetch = true; this.save(); }
      if (this.mode === 'play') this.ui.subtitle(s.speakDog ? 'Keanu: \u201cAgain! Again! AGAIN!\u201d' : 'Keanu drops the ball at your feet and looks at you. Again?', 4);
    };
    this.world.say = (t, key) => {
      if (this.mode !== 'play') return;
      this.ui.subtitle(t, 5);
      // remember what you've overheard (for the Curiosities page)
      const s = (this.st.solved ||= {}); s.overheard ||= [];
      if (key && !s.overheard.includes(key)) { s.overheard.push(key); this.save(); }
    };
    this.music = new Music(this.sound);
    this.ui = new UI(this);
    this.applySettings();
    this.bindInput();
    await step('Ready');
    // warm up shaders from a couple of angles so the first frames do not stall
    this.world.update(0.016, 0, this.st, this.camera.position);
    this.R.r.compile(this.scene, this.camera);
    this.titleScreen();
    $('#boot').classList.add('out');
    setTimeout(() => $('#boot').hidden = true, 1100);
    this.last = performance.now();
    const loop = (now) => { requestAnimationFrame(loop); this.frame(Math.min(0.05, (now - this.last) / 1000)); this.last = now; };
    requestAnimationFrame(loop);
    window.addEventListener('pagehide', () => { if (this.mode !== 'title' && this.mode !== 'boot') this.save(); });
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.mode === 'play') this.pause(); });
    this.R.canvas.addEventListener('webglcontextlost', (e) => {
      e.preventDefault(); this.save();
      const l = $('#bootLine'); $('#boot').hidden = false; $('#boot').classList.remove('out');
      if (l) l.textContent = 'The graphics device was reset. Your progress is saved: reload the page to continue.';
    });
    window.addEventListener('resize', () => { this.R.resize(); this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix(); });
  }

  // ------------------------------------------------------------------ input
  bindInput() {
    const canvas = this.R.canvas;
    document.addEventListener('keydown', (e) => {
      this.sound.unlock();
      if (this.ui.keyHandler && !this.ui.overlay.hidden) { const kh = this.ui.keyHandler; kh(e); if (kh.rebind) return; }
      // the finale: Space, Enter or Esc skips ahead to the credits, and a second press ends it
      if (this.cine && this.cine.type === 'ending' && this.cine.canSkip && (e.code === 'Escape' || e.code === 'Space' || e.code === 'Enter')) { this.cine.skip = true; e.preventDefault(); return; }
      if (e.code === 'Escape') { this.onEscape(); e.preventDefault(); return; }
      const K = this.settings.keys;
      if (this.mode === 'play') {
        this.keys.add(e.code);
        if (e.code === K.interact) this.interact();
        if (e.code === K.journal || e.code === 'Tab') { e.preventDefault(); this.openJournal(); }
        if (e.code === K.jump) { this.body.jumpQueued = true; e.preventDefault(); }
        if (e.code === K.wait) this.toggleWait();
        if (e.code === K.hud) { const on = document.body.classList.toggle('nohud'); this.ui.toast('View', on ? 'Interface hidden. Press ' + keyName(K.hud) + ' to bring it back.' : 'Interface shown.'); }
      } else if (this.mode === 'dialog') {
        if (e.code === K.interact || e.code === K.jump || e.code === 'Enter') { e.preventDefault(); this.dialogNext(); }
      } else if (this.mode === 'journal') {
        if (e.code === K.journal || e.code === 'Tab') { e.preventDefault(); this.closeJournal(); }
      } else if (this.mode === 'panel') {
        // the interact key closes a plain document, so reading never needs the mouse
        if ((e.code === K.interact || e.code === 'Enter') && this.ui.panel.dataset.simple === '1' && !this.ui.panel.querySelector('.btn.warn')) { e.preventDefault(); this.ui.closePanel(); }
      }
    });
    document.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());
    document.addEventListener('mousemove', (e) => {
      if (this.mode !== 'play' && !(this.cine && this.cine.look)) return;
      if (this.locked || this.dragging) { this.look.dx += e.movementX || 0; this.look.dy += e.movementY || 0; }
    });
    canvas.addEventListener('mousedown', (e) => {
      this.sound.unlock();
      if (this.mode === 'play' && !this.locked) { this.requestLock(); this.dragging = true; }
      if (this.mode === 'dialog') this.dialogNext();
    });
    document.addEventListener('mouseup', () => { this.dragging = false; });
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === canvas;
      if (!this.locked && this.mode === 'play' && !this.expectUnlock) this.pause();
      this.expectUnlock = false;
    });
    $('#dialog').addEventListener('click', () => this.dialogNext());
    $('#ending').addEventListener('click', () => { if (this.cine && this.cine.type === 'ending' && this.cine.canSkip) this.cine.skip = true; });
  }
  // ---- gamepad: sticks to move and look, A interact, B back, Y journal, Start pause, d-pad in menus
  pollPad(dt) {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const p = pads && [...pads].find(x => x && x.connected);
    if (!p) { this.pad = null; return; }
    const prev = this.padPrev || [];
    const down = (i) => p.buttons[i] && p.buttons[i].pressed;
    const hit = (i) => down(i) && !prev[i];
    const dz = (v) => Math.abs(v) < 0.18 ? 0 : (v - Math.sign(v) * 0.18) / 0.82;
    this.pad = { x: dz(p.axes[0] || 0), z: dz(p.axes[1] || 0), sprint: down(10) || down(6) };
    if (this.mode === 'cine' && this.cine && this.cine.type === 'ending' && this.cine.canSkip && (hit(0) || hit(1) || hit(9))) this.cine.skip = true;
    if (this.mode === 'play') {
      const lx = dz(p.axes[2] || 0), ly = dz(p.axes[3] || 0);
      this.look.dx += lx * Math.abs(lx) * 900 * dt; this.look.dy += ly * Math.abs(ly) * 650 * dt;
      if (hit(0)) this.interact();
      if (hit(1) || hit(3)) this.openJournal();
      if (hit(4) || hit(5)) this.body.jumpQueued = true;
      if (hit(9)) this.pause();
      if (hit(2)) this.toggleWait();
    } else if (this.mode === 'dialog') {
      if (hit(0)) this.dialogNext();
      if (hit(1)) this.endDialog();
    } else if (this.mode !== 'cine' && this.mode !== 'boot') {
      // menus and panels: d-pad moves focus, A presses, B goes back
      const scope = !this.ui.overlay.hidden ? this.ui.panel : !$('#journal').hidden ? $('#journal') : $('#title');
      const items = [...scope.querySelectorAll('button:not([disabled]), input[type=range]')].filter(b => b.offsetParent);
      let i = items.indexOf(document.activeElement);
      const move = (d) => { i = i < 0 ? 0 : (i + d + items.length) % items.length; items[i] && items[i].focus(); this.sound.hover(); };
      if (hit(13) || hit(15)) move(1);
      if (hit(12) || hit(14)) move(-1);
      const ae = document.activeElement;
      if (ae && ae.type === 'range' && (hit(14) || hit(15))) { ae.stepUp ? (hit(15) ? ae.stepUp() : ae.stepDown()) : 0; ae.dispatchEvent(new Event('input')); }
      if (hit(0) && ae && ae.tagName === 'BUTTON') ae.click();
      if (hit(1) || (hit(3) && this.mode === 'journal') || (hit(9) && this.mode === 'pause')) this.onEscape();
    }
    this.padPrev = p.buttons.map(b => b.pressed);
  }

  requestLock() {
    try { const p = this.R.canvas.requestPointerLock({ unadjustedMovement: false }); if (p && p.catch) p.catch(() => { }); } catch (e) { }
  }
  releaseLock() { if (document.pointerLockElement) { this.expectUnlock = true; document.exitPointerLock(); } }
  onEscape() {
    if (this.mode === 'play') this.pause();
    else if (this.mode === 'pause') this.resume();
    else if (this.mode === 'journal') this.closeJournal();
    else if (this.mode === 'dialog') this.endDialog();
    else if (this.mode === 'panel') this.ui.closePanel();
    else if (this.mode === 'settings') this.ui.closePanel();
  }

  // ------------------------------------------------------------------ title
  titleScreen() {
    this.mode = 'title';
    $('#hud').hidden = true; $('#title').hidden = false; $('#journal').hidden = true; $('#ending').hidden = true;
    this.ui.overlay.hidden = true;
    this.music.setMood('menu');
    const saved = hasSave();
    const items = [];
    if (saved) {
      const s = loadState();
      items.push({ label: s && s.ended ? 'Return to the basin' : 'Continue', fn: () => this.start(false) });
    }
    items.push({ label: saved ? 'New journey' : 'Begin', fn: () => saved ? this.confirmNew() : this.start(true) });
    items.push({ label: 'Settings', fn: () => { $('#title').hidden = true; this.mode = 'settings'; this.ui.settings(() => { this.ui.closePanel(); }); this.ui.onPanelClose = () => { this.saveSettings(); this.titleScreen(); }; } });
    items.push({ label: 'Controls', fn: () => { $('#title').hidden = true; this.mode = 'settings'; this.controlsPanel(() => this.ui.closePanel()); this.ui.onPanelClose = () => this.titleScreen(); } });
    items.push({ label: 'Credits', fn: () => { $('#title').hidden = true; this.mode = 'settings'; this.ui.credits(() => this.ui.closePanel()); this.ui.onPanelClose = () => this.titleScreen(); } });
    this.ui.menu($('#titleMenu'), items);
    if (saved) { const s = loadState(); if (s) el('p', 'note', s.ended ? 'The basin after the release. No clock.' : `Cycle ${s.loop} · ${s.found.size} things known`, $('#titleMenu')); }
    this.fadeTo(0, 1.6);
    this.titleT = 0;
  }
  controlsPanel(onBack) {
    this.ui.openPanel(p => {
      this.ui.head(p, 'How to play', 'Controls');
      const w = el('div', 'credits-roll', null, p);
      const K = this.settings.keys, n = keyName;
      for (const [a, b] of [['Move', [K.forward, K.left, K.back, K.right].map(n).join(' ') + ' or arrows \u00b7 left stick'], ['Look', 'Mouse (click to capture) \u00b7 right stick'], ['Run', n(K.sprint) + ' \u00b7 left stick click'], ['Jump', n(K.jump) + ' \u00b7 bumpers'],
        ['Interact, talk', n(K.interact) + ' \u00b7 A'], ['Wait', n(K.wait) + ' \u00b7 X  (time runs fast until the next thing you know about)'], ['Journal', n(K.journal) + ' or Tab \u00b7 Y'], ['Pause', 'Esc \u00b7 Start'], ['Hide the interface', n(K.hud)], ['Change keys', 'Settings \u2192 Keys']]) {
        const r = el('div', 'cr', null, w); el('span', null, a, r); el('b', null, b, r);
      }
      el('p', 'note', 'Every twenty-two minutes the basin rebounds and you wake in your berth. The world forgets. You and your journal do not.', p);
      const row = el('div', 'row', null, p);
      this.ui.btn(row, 'Back', onBack, 'primary');
    }, { cls: 'wide' });
  }

  confirmNew() {
    $('#title').hidden = true; this.mode = 'settings';
    this.ui.openPanel(p => {
      this.ui.head(p, 'New journey', 'Forget everything?');
      el('div', 'body', 'Your journal, the cycles you have lived and everything the relay has kept will be wiped. The basin will not remember you.', p);
      const r = el('div', 'row', null, p);
      this.ui.btn(r, 'Forget and begin', () => { this.ui.onPanelClose = null; this.ui.closePanel(); clearSave(); this.start(true); }, 'warn');
      this.ui.btn(r, 'Keep my journey', () => this.ui.closePanel(), 'primary');
    }, { onClose: () => this.titleScreen() });
  }

  // ------------------------------------------------------------------ start / cycles
  start(fresh) {
    this.sound.unlock();
    this.st = fresh ? freshState() : (loadState() || freshState());
    $('#title').hidden = true;
    this.fadeTo(1, 0.6);
    this.mode = 'cine'; this.cine = { type: 'hold', t: 0, dur: 99 };
    this.later(0.7, () => {
      this.newCycle(false);
      $('#hud').hidden = false;
      this.mode = 'cine';
      const first = fresh || (this.st.loop === 1 && this.st.found.size === 0);
      this.wakeCine(first ? story.opening : null);
    });
    this.requestLock();
  }

  newCycle(advance) {
    if (advance) { this.st.loop++; }
    this.st.elapsed = 0;
    this.cycle = { lanternsSeen: 0, beacon: false, word: null, routing: [], voice: false };
    this.events.reset();
    this.world.fx.clear();
    this.prevElapsed = 0;
    const W = this.world;
    W.skiff.at = 'pier'; W.skiff.moving = null;
    const d = DOCKS.pier; W.skiff.group.position.set(d.boat[0], 0, d.boat[1]); W.skiff.group.rotation.set(0, d.yaw, 0);
    for (const ch of W.chunks) { ch.offset.set(0, 0, 0); ch.group.position.set(0, 0, 0); ch.group.rotation.set(0, 0, 0); ch.solid = true; }
    this.body.place(SPAWN.x, SPAWN.y, SPAWN.z, SPAWN.yaw);
    this.body.pitch = 0;
    for (const p of Object.values(W.people)) p.talking = 0;
    this.events.apply(0.016, 0, 0, false);
    for (const dr of W.doors) { dr.open = dr.target; dr.update(0); }
    this.save();
  }

  wakeCine(lines) {
    // eyes open on the berth ceiling, then you sit up and stand
    this.cine = { type: 'wake', t: 0, dur: lines ? 7.5 : 4.2, lines };
    this.envT = 99;   // the sky has jumped back to dusk: relight at once
    const cc = document.getElementById('cycleCard');
    if (cc && !this.st.ended) {
      cc.querySelector('.cc-n').textContent = this.st.loop;
      this.later(lines ? 9.5 : 1.0, () => cc.classList.add('on'));
      this.later(lines ? 13 : 4.0, () => cc.classList.remove('on'));
    }
    this.ui.clearSubs();
    this.fadeTo(0, lines ? 3.2 : 1.8);
    this.sound.wake();
    if (lines) { lines.forEach((l, i) => this.later(0.6 + i * 4.2, () => this.ui.subtitle(l, 4.2))); }
    else if (this.st.ended) this.ui.subtitle('The berth light comes on. Outside, it is morning, and it stays morning.', 5);
    else this.ui.subtitle(story.wake[(this.st.loop - 2 + story.wake.length) % story.wake.length], 4);
    this.music.setMood('station');
    // on the next bed, Keanu notices you're awake
    if (!this.st.ended) this.later(lines ? 7.2 : 3.4, () => { if (this.cine && this.cine.type !== 'wake' && this.mode !== 'play') return; this.sound.whine(0); this.sound.woof(0.9, 1.15); });
  }

  // a controlled reset, or the real one at 22:00
  rebound(kind = 'loop') {
    if (this.cine && this.cine.type === 'rebound') return;
    if (this.waiting) { this.waiting = null; document.body.classList.remove('waiting'); }
    this.releaseLock();
    this.ui.closePanel(); this.endDialog(true); this.closeJournal(true);
    this.mode = 'cine';
    this.cine = { type: 'rebound', t: 0, dur: kind === 'loop' ? 5.2 : 4.4, kind, e0: this.st.elapsed, cam: this.camera.position.clone() };
    this.sound.rewind();
    this.music.stopAll(1.2);
  }
  rehearse(reason) {
    this.ui.subtitle(reason === 'echo' ? 'You let the reel run out.' : 'You lay your hand on the plinth and let go.', 3);
    this.rebound('rehearse');
  }
  groundFirst() {
    this.sound.flash();
    this.fadeColor('#f4fbff');
    this.fadeTo(1, 0.15);
    this.shake(1.5, 1.5);
    this.mode = 'cine';
    this.cine = { type: 'white', t: 0, dur: 3.2 };
    this.ui.subtitle('Ground before listen. The chamber goes white.', 4);
  }

  // ------------------------------------------------------------------ main loop
  frame(dt) {
    if (window.__rbFreeze) return;   // tests can stop the clock and the renderer
    this.time += dt;
    this.runTimers(dt);
    this.pollPad(dt);
    const W = this.world, st = this.st;
    if (this.mode === 'title') this.titleFrame(dt);
    else if (this.mode === 'play') this.playFrame(dt);
    else if (this.mode === 'cine') this.cineFrame(dt);
    else if (this.mode === 'dialog' || this.mode === 'panel' || this.mode === 'journal' || this.mode === 'pause') {
      if (this.mode === 'dialog' && this.dlg) this.frameSpeaker(dt);
      this.updateCamera(dt, false);
      if (this.mode === 'journal') { this.jWearT = (this.jWearT || 0) + dt; if (this.jWearT > 0.5) { this.jWearT = 0; this.ui.wearPage(); } }
      // the basin doesn't wait while you read or talk: only the pause menu stops the clock
      if (this.mode !== 'pause' && !st.ended) {
        st.elapsed += dt; st.playTime += dt;
        if (st.elapsed >= LOOP_SECONDS) this.rebound('loop');
      }
    }
    if (this.mode !== 'play') { const lh = document.getElementById('lookHint'); if (lh) lh.classList.remove('on'); }
    // the world is drawn at the current elapsed time in every mode
    if (this.mode !== 'title') {
      this.events.apply(dt, st.elapsed, this.prevElapsed ?? st.elapsed, this.mode === 'play' || this.mode === 'panel' || this.mode === 'dialog' || this.mode === 'journal' || (this.mode === 'cine' && this.cine && this.cine.live));
      this.prevElapsed = st.elapsed;
    }
    W.regionKey = this.region;
    W.update(dt, this.time, st, this.camera.position);
    this.environment(dt);
    this.ambience(dt);
    this.music.update(this.mode === 'title' || st.ended ? 0 : sm(1100, 1320, st.elapsed));
    this.ui.tick(dt);
    if (!window.__rbNoRender) this.R.render(this.scene, this.camera, this.time);
  }

  titleFrame(dt) {
    this.titleT += dt;
    const t = Math.sin(this.titleT * 0.02) * 0.5;
    this.camera.position.set(-98 + t * 8, 26 + Math.sin(this.titleT * 0.05) * 1.0, 40 + t * 5);
    this.camera.lookAt(-6 + t * 4, 10, -80);
    this.st.elapsed = 520;
    this.events.apply(dt, 520, 520, false);
    this.region = 'city';
  }

  // if the first stretch of play runs slowly, step the picture quality down once
  watchPerformance(dt) {
    if (this.perfDone || window.__rbNoRender) return;
    const p = this.perf || (this.perf = { t: 0, n: 0, skip: 2 });
    if (p.skip > 0) { p.skip -= dt; return; }
    p.t += dt; p.n++;
    if (p.t < 8) return;
    const fps = p.n / p.t;
    this.perfDone = true;
    const s = this.settings;
    if (fps < 28 && s.quality !== 'lowest') {
      s.quality = s.quality === 'high' ? 'medium' : s.quality === 'medium' ? 'low' : 'lowest';
      this.applySettings(); this.saveSettings();
      this.ui.toast('Picture', 'Quality lowered to ' + s.quality + ' for smoother play. You can change it in Settings.', true);
      this.perfDone = false; this.perf = null;   // check once more at the new setting
    }
  }

  playFrame(dt) {
    const st = this.st, b = this.body;
    this.watchPerformance(dt);
    if (!st.ended) st.elapsed += dt * (this.waiting ? 12 : 1);
    st.playTime += dt;
    if (this.waiting) {
      const k = this.keys;
      if (st.elapsed >= this.waiting.until || ['forward', 'back', 'left', 'right'].some(a => k.has(this.settings.keys[a])) || (this.pad && (this.pad.x || this.pad.z))) this.toggleWait(false);
    }
    // input
    const k = this.keys, K = this.settings.keys;
    const input = {
      x: (k.has(K.right) || k.has('ArrowRight') ? 1 : 0) - (k.has(K.left) || k.has('ArrowLeft') ? 1 : 0),
      z: (k.has(K.back) || k.has('ArrowDown') ? 1 : 0) - (k.has(K.forward) || k.has('ArrowUp') ? 1 : 0),
      sprint: k.has(K.sprint) || (K.sprint === 'ShiftLeft' && k.has('ShiftRight')),
      jump: !!b.jumpQueued
    };
    b.jumpQueued = false;
    if (this.pad && (this.pad.x || this.pad.z)) { input.x = this.pad.x; input.z = this.pad.z; input.sprint = input.sprint || this.pad.sprint; }
    this.applyLook();
    const wasGrounded = b.grounded;
    stepBody(this.world.phys, b, input, dt, { unsafe: (bb) => !bb.groundC || bb.groundC.chunk.name === 'span' || bb.groundC.chunk.offset.y < -0.5 });
    if (input.jump && wasGrounded && !b.grounded) this.sound.jump();
    if (b.landed) { this.sound.land(b.landed, this.surface()); if (b.landed > 9) this.shake(0.3, 0.3); b.landed = 0; }
    // footsteps
    const sp = Math.hypot(b.vx, b.vz);
    if (b.grounded && sp > 0.5) {
      this.stepDist += sp * dt;
      this.bobPhase += sp * dt * 1.9;
      const stride = input.sprint ? 2.1 : 1.6;
      if (this.stepDist > stride) { this.stepDist = 0; this.sound.step(this.surface(), input.sprint); }
    }
    this.updateSkiff(dt);
    this.recover(dt);
    this.updateRegion();
    this.updateCamera(dt, true);
    this.updateTarget();
    this.updateHud();
    if (!st.ended && st.elapsed >= LOOP_SECONDS) this.rebound('loop');
    // the lift gates open when you stand near them
    const p = b;
    this.nearLift = Math.hypot(p.x - 7.1, p.z - (-12.3)) < 4 && p.y > 20 ? 'station' : Math.hypot(p.x - 8.5, p.z + 225.5) < 4 && p.y < -5 ? 'deep' : null;
    // autosave every 20 s
    this.saveT = (this.saveT || 0) + dt;
    if (this.saveT > 20) { this.saveT = 0; this.save(); }
  }

  // ---- waiting: let the basin's clock run fast until something you know about is due
  toggleWait(force) {
    if (this.st.ended) return;
    if (this.waiting || force === false) {
      if (!this.waiting) return;
      this.waiting = null;
      document.body.classList.remove('waiting');
      this.ui.toast('Waiting', 'You stop waiting at ' + fmt(this.st.elapsed) + '.');
      return;
    }
    if (!this.body.grounded || this.region === 'deep' && runWater(this.st.elapsed, this.st) > DF) return;
    const known = timeline.filter(ev => ev.t > this.st.elapsed + 12 && (!ev.know || this.st.found.has(ev.know)));
    const next = known.length ? known[0] : null;
    // stop shortly before the next thing you know about, and never wait more than three minutes at a time
    const cap = this.st.elapsed + 180;
    const until = Math.min(next ? next.t - 8 : Infinity, cap, LOOP_SECONDS - 2);
    this.waiting = { until };
    document.body.classList.add('waiting');
    this.ui.toast('Waiting', next && next.t - 8 <= cap ? 'Until ' + fmt(next.t) + ' \u00b7 ' + next.label + '. Press T or move to stop.' : 'Three minutes pass quickly. Press T or move to stop.');
  }

  applyLook() {
    const s = this.settings, b = this.body;
    const k = 0.0022 * s.sensitivity;
    b.yaw -= this.look.dx * k;
    b.pitch -= this.look.dy * k * (s.invertY ? -1 : 1);
    b.pitch = Math.max(-1.45, Math.min(1.45, b.pitch));
    this.look.dx = this.look.dy = 0;
  }

  surface() {
    const g = this.body.groundC;
    if (this.body.y < this.world.seaLevel + 0.2 && this.region !== 'deep' && this.region !== 'core') return 'water';
    if (!g) return 'stone';
    const s = SURFACE[g.chunk.name] || 'stone';
    // everything down in the Deep is wet underfoot
    return this.region === 'deep' && (s === 'metal' || s === 'stone') ? 'wet' : s;
  }
  // which music goes with where you are: each region has its own, and a few places in the city too
  moodFor(r, name) {
    if (r !== 'city') return r;
    if (name === 'Market Pier') return 'market';
    if (name === 'The Sky Bridge' || name === 'Upper Terrace' || name === 'The Bell Tower') return 'sky';
    return 'city';
  }

  updateCamera(dt, moving) {
    const b = this.body, cam = this.camera, s = this.settings;
    let bob = 0, roll = 0;
    if (moving && s.bob && b.grounded) {
      const sp = Math.min(1, Math.hypot(b.vx, b.vz) / 6);
      bob = Math.sin(this.bobPhase * 2) * 0.04 * sp;
      roll = Math.sin(this.bobPhase) * 0.004 * sp;
    }
    cam.position.set(b.x, b.y + b.eye + b.eyeOffset + bob, b.z);
    let sx = 0, sy = 0;
    const tremor = this.st.ended ? 0 : sm(TIMES.tremor, 1320, this.st.elapsed) * 0.5 + (this.st.elapsed > TIMES.warning ? 0.04 : 0);
    const shake = (this.shakeT > 0 ? this.shakeAmt : 0) + (this.mode === 'play' || this.mode === 'cine' ? tremor : 0);
    if (shake > 0 && s.shake) {
      sx = (Math.sin(this.time * 37) + Math.sin(this.time * 23.1)) * 0.006 * shake;
      sy = (Math.sin(this.time * 31.7) + Math.sin(this.time * 19.3)) * 0.006 * shake;
    }
    this.shakeT -= dt;
    cam.rotation.set(b.pitch + sy, b.yaw + sx, roll);
    if (cam.fov !== s.fov) { cam.fov = s.fov; cam.updateProjectionMatrix(); }
  }
  shake(amount, dur) { this.shakeAmt = amount; this.shakeT = dur; }
  // during a conversation the view settles on the speaker's face, a little above the dialogue box
  frameSpeaker(dt) {
    const P = this.world.people[this.dlg.id]; if (!P || !P.head) return;
    const b = this.body, h = (this._hv ||= new THREE.Vector3());
    P.head.getWorldPosition(h);
    const ex = b.x, ey = b.y + b.eye, ez = b.z;
    const dx = h.x - ex, dz = h.z - ez, dist = Math.max(0.6, Math.hypot(dx, dz));
    const yaw = Math.atan2(-dx, -dz);
    const pitch = Math.atan2(h.y - ey, dist) - Math.atan2(0.32, dist);
    const k = Math.min(1, dt * 3.2);
    b.yaw += (((yaw - b.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI) * k;
    b.pitch += (pitch - b.pitch) * k;
  }

  // getting out of the sea, the pit, or the flooded run
  recover(dt) {
    const b = this.body, W = this.world, st = this.st;
    if (this.recovering) return;
    const late = !st.ended && st.elapsed > 1262;
    const inRun = b.z < -192.5 && b.z > -223 && Math.abs(b.x) < 3 && b.y < DF + 1;
    const runLevel = runWater(st.elapsed, st);
    let why = null, to = null;
    if (inRun && runLevel > b.y + 1.3 && !late) { why = 'The current drags you back to the lock.'; to = { x: 0, y: DF, z: -187, yaw: 0 }; }
    else if (b.y < -42) { why = 'You fall a long way, and then you are somewhere you have been before.'; }
    else if (b.y + 1.2 < W.seaLevel && !late && this.region !== 'deep' && this.region !== 'core') { why = 'The water is colder than it looks. You haul yourself out.'; }
    const cam = this.camera.position;
    $('#vignetteHurt').classList.toggle('under', (cam.y < W.seaLevel && this.region !== 'deep' && this.region !== 'core') || (inRun && runLevel > cam.y));
    if (!why) return;
    this.recovering = true;
    this.sound.splash(0.3);
    this.fadeTo(1, 0.35);
    st.deaths++;
    this.later(0.6, () => {
      let p = to || b.lastSafe;
      if (!to && p.y + 1.2 < W.seaLevel && p.y > -5) p = SPAWN;  // never 'recover' into the water
      b.place(p.x, p.y + 0.05, p.z, p.yaw ?? b.yaw);
      this.fadeTo(0, 0.8);
      this.ui.subtitle(why, 4);
      st.elapsed = Math.min(LOOP_SECONDS - 1, st.elapsed + 10);
      this.recovering = false;
    });
  }

  updateRegion() {
    const b = this.body, W = this.world;
    const r = W.regionAt(b.x, b.y, b.z);
    const name = W.placeName(b.x, b.y, b.z);
    if (r !== this.region) {
      this.region = r;
      this.mood = this.moodFor(r, name); this.music.setMood(this.mood);
      const placeEntry = { deep: 'deep', core: 'core', isle: 'isle', rise: 'rise', tarn: 'tarnRoofs' }[r];
      if (placeEntry) this.observe(placeEntry);
    }
    if (name !== this.place) {
      this.place = name;
      const mood = this.moodFor(r, name);
      if (mood !== this.mood) { this.mood = mood; this.music.setMood(mood); }
      const lastShown = this.shownAt?.[name] ?? -99;
      if (this.time - lastShown > 20) {
        (this.shownAt ||= {})[name] = this.time;
        const subs = { 'Halcyon Station': 'research habitat', 'The Sky Bridge': 'to the Hollow City', 'Upper Terrace': 'the Hollow City', 'The Hollow City': 'the Concourse', 'Market Pier': 'the Hollow City', 'The Service Walk': 'older than the city', 'South Plaza': 'the Hollow City', 'The Deep': 'tidal intake', 'The Core': 'pressure ring', 'Lantern Isle': 'the keeper’s rock', 'Verdant Rise': 'the glasshouse', 'Civic Archive': 'the Hollow City', 'Vale Court': 'apartments', 'The Bell Tower': 'the Hollow City', 'The Shelter': 'the Service Walk', 'Tarn Rooftops': 'what the water left' };
        this.ui.showPlace(name, subs[name]);
      } else {
        this.ui.place.classList.remove('show');   // never leave a stale name on screen
      }
      if (name === 'Upper Terrace' || name === 'The Hollow City') this.observe('city');
      if (name === 'The Service Walk' || name === 'The Shelter') this.observe('serviceWalk');
    }
  }

  updateTarget() {
    const cam = this.camera, W = this.world;
    const dir = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion);
    let best = null, bestScore = -1;
    for (const it of W.interact) {
      const dx = it.x - cam.position.x, dy = it.y - cam.position.y, dz = it.z - cam.position.z;
      const d = Math.hypot(dx, dy, dz);
      if (d > it.r + 0.4) continue;
      const dot = (dx * dir.x + dy * dir.y + dz * dir.z) / Math.max(d, 0.001);
      const need = d < 1.2 ? 0.55 : d < 2 ? 0.8 : 0.9;
      if (dot < need) continue;
      const score = dot * 2 - d * 0.15;
      if (score <= bestScore) continue;
      // occlusion
      const hit = W.phys.ray(cam.position.x, cam.position.y, cam.position.z, dx / d, dy / d, dz / d, d, c => c.npc || c.rail);
      if (hit < d - 0.45) continue;
      best = it; bestScore = score;
    }
    this.target = best;
    this.ui.setPrompt(best ? this.labelFor(best) : null);
  }
  labelFor(it) {
    const id = it.id, st = this.st;
    if (id.startsWith('skiff_')) { const here = id.slice(6); return this.world.skiff.moving ? 'The skiff is on its way' : this.world.skiff.at === here ? 'Board the skiff' : 'Call the skiff'; }
    if (id === 'engine' && st.found.has('imprints') && !st.found.has('imprintsTruth')) return 'Peel back the tape';
    if (id === 'cylinder' && st.solved.cylinder) return 'Look at the empty cradle';
    const c = this.cycle || {};
    if (!st.ended && id === 'npcJuniper' && c.tomato && !c.gaveTomato) return 'Give Skye the tomato';
    if (!st.ended && id === 'npcSef' && c.pebble && !c.gavePebble) return 'Give Charley the pebble';
    if (!st.ended && id === 'npcKeeper' && c.tea && !c.gaveTea) return 'Give Aiden the tea';
    if (id === 'gallery' && st.elapsed >= TIMES.sunStart - 5 && st.elapsed <= TIMES.sunEnd + 5) return 'Look at the light on the floor';
    return it.label;
  }

  interact() {
    const it = this.target;
    if (!it || this.mode !== 'play') return;
    this.toggleWait(false);
    const h = handlers[it.id];
    if (!h) return;
    this.sound.click();
    if (it.id.startsWith('npc')) { h(this); return; }
    this.openPanelMode();
    h(this);
    if (this.ui.overlay.hidden && this.mode === 'panel') this.closePanelMode();
  }
  openPanelMode() {
    this.mode = 'panel';
    this.keys.clear();
    this.releaseLock();
    this.ui.afterClose = () => this.closePanelMode();
  }
  closePanelMode() {
    if (this.mode !== 'panel') return;
    this.mode = 'play';
    this.ui.setPrompt(null);
    this.requestLock();
  }

  updateHud() {
    const st = this.st;
    // a small secret found: a quiet note about it, once
    const now = performance.now();
    if (st && now > (this._curioCheck || 0)) {
      this._curioCheck = now + 700;
      const s = st.solved || {}, got = curiosities.filter(c => c.has(s));
      if (!this._curioSeen || this._curioSt !== st) { this._curioSt = st; this._curioSeen = new Set(got.map(c => c.title)); }
      const fresh = got.filter(c => !this._curioSeen.has(c.title));
      if (fresh.length) {
        for (const c of fresh) this._curioSeen.add(c.title);
        const last = fresh[0];
        this.later(this.mode === 'dialog' ? 0.2 : 1.2, () => { this.ui.toast('Curiosity \u00b7 ' + this.ui.curioCount().replace('/', ' of '), last.title); this.sound.curio(); });
      }
    }
    const lh = document.getElementById('lookHint');
    if (lh) lh.classList.toggle('on', !this.locked && !this.dragging && !this.pad && !this.target);
    const jn = document.getElementById('jNew'), n = st.fresh.size;
    if (jn) { jn.hidden = n === 0; if (n) jn.lastChild.textContent = n === 1 ? '1 new note' : n + ' new notes'; }
  }

  // ------------------------------------------------------------------ knowledge
  learn(id, o = {}) {
    const st = this.st;
    if (!entries[id] || st.found.has(id)) return false;
    st.found.add(id);
    (st.foundAt ||= {})[id] = st.loop;
    st.fresh.add(id);
    const e = entries[id];
    if (!o.quiet && !st.hints.journal && e[1] !== 'Place') {
      st.hints.journal = true;
      this.later(5, () => this.ui.showHint('Everything you find is kept in your journal: <kbd>J</kbd>. It survives the rebound.', 8));
    }
    if (!o.quiet) {
      this.ui.toast(e[1] === 'Person' ? 'Journal · people' : e[1] === 'Place' ? 'Journal · new place' : 'Journal · new entry', e[2], e[1] === 'Solution');
      if (BIG.has(e[1])) this.sound.discover(e[1] === 'Solution' || id === 'carrier' || id === 'imprintsTruth'); else this.sound.journal();
    }
    // connections between pieces
    if (st.found.has('lanterns')) this.markLead('vault');
    if (id === 'tide' || id === 'unlocked') this.markLead('pump');
    if (id === 'echo') this.markLead('bulkhead');
    if (id === 'evac') this.markLead('radio');
    if (/^letter[A-Z]/.test(id)) this.markLead('letters');
    this.save();
    return true;
  }
  observe(id) { return this.learn(id); }
  markLead(k) { if (!this.st.hints['lead_' + k]) { this.st.hints['lead_' + k] = true; this.save(); } }
  leadKnown(k) { return !!this.st.hints['lead_' + k]; }
  leadOpen(k) { return this.leadKnown(k) && !leads[k][1](this.st); }
  onLanternSeen(n) {
    this.cycle.lanternsSeen++;
    if (this.cycle.lanternsSeen >= 4 && this.body.z < -60) { this.learn('lanterns'); this.markLead('vault'); }
  }
  save() { saveState(this.st); }

  // ------------------------------------------------------------------ dialog
  talk(id) {
    if (id === 'npcKeanu') return this.talkKeanu();
    let n = npcs[id];
    if (this.st.ended && epilogue[id]) n = { ...n, lines: [epilogue[id]] };
    else if (id === 'npcSef' && this.cycle.pebble && !this.cycle.gavePebble) {
      this.cycle.gavePebble = true;
      n = { ...n, lines: ['Eh? What is that. For me?', 'A pebble. From the isle, by the smell of it. Lamp oil.', 'So the isle is still there. Good. Good. I will keep it in my pocket.', 'Thank you. Nobody brings old Charley anything.'] };
      this.later(0.5, () => this.learn('pebble'));
    }
    else if (id === 'npcKeeper' && this.cycle.tea && !this.cycle.gaveTea && !this.st.ended) {
      this.cycle.gaveTea = true;
      const s = (this.st.solved ||= {}); if (!s.teaGiven) { s.teaGiven = true; this.save(); }
      n = { ...n, lines: ['Is that tea? For me?', 'It\u2019s stone cold. You carried it across the water.', '\u2026It is the best cup I have had in four hundred days. Don\u2019t tell the others. It was my turn on the rota.'] };
    }
    else if (id === 'npcJuniper' && this.cycle.tomato && !this.cycle.gaveTomato && !this.st.ended) {
      this.cycle.gaveTomato = true;
      const s = (this.st.solved ||= {}); if (!s.tomatoGiven) { s.tomatoGiven = true; this.save(); }
      if (this.world.stallTomato) this.later(1.0, () => { this.world.stallTomato.visible = true; });
      n = { ...n, lines: ['Is that\u2026 a tomato? From the Rise?', 'Christian grows them. I have only ever had apples. The same apples.', 'I\u2019ll put it out on the counter. First new thing on this stall in four hundred days.', 'Don\u2019t tell anyone it\u2019s not for sale.'] };
    }
    else if (id === 'npcJuniper' && this.cycle.awning && !this.cycle.awningThanked && !this.st.ended) {
      this.cycle.awningThanked = true;
      const s = (this.st.solved ||= {}); if (!s.skyeThanked) { s.skyeThanked = true; this.save(); }
      n = { ...n, lines: ['Oh. The awning. That was you?', 'It was you last cycle as well, wasn\u2019t it. And the one before that. I knew it was somebody.', 'Thank you. Here, have an apple. It\u2019s the same apple as yesterday, but it\u2019s the thought.', ...n.lines.slice(3)] };
    }
    else if (id === 'npcPilot' && this.st.solved && this.st.solved.speakRobot && !this.cycle.robotTalk) {
      this.cycle.robotTalk = true;
      if (!this.st.solved.robotHeard) { this.st.solved.robotHeard = true; this.save(); }
      n = { ...n, lines: ['BEEP. \u2026Beep. Operator, you are parsing my status tones. Nobody has done that since the yard.', 'You asked about the count. I said it is large. It is forty-one thousand, two hundred and six. Every trip begins at the pier and ends at the pier.', 'I said six on the manifest and zero departed was not a problem. I was told to say that. I will say it again if you need me to.', 'I am not unhappy. I am rated for ferrying, and you always come back. That is a good route.', 'Hold on to nothing in particular. BEEP.'] };
    }
    else if (reactions[id] && this.st.found.has(reactions[id][0]) && !(this.cycle.reacted ||= new Set()).has(id)) {
      this.cycle.reacted.add(id);
      n = { ...n, lines: [reactions[id][1], ...n.lines] };
    }
    // a letter you found for them: they answer it once, and it stays answered
    const lr = letterReplies[id], given = (this.st.solved.letters ||= {});
    if (!this.st.ended && lr && this.st.found.has(lr[0]) && !given[id]) {
      given[id] = true;
      n = { ...n, lines: [lr[1], ...n.lines] };
      this.ui.toast('Letter', 'Delivered \u00b7 ' + Object.keys(given).length + ' of 6');
      if (Object.keys(given).length >= 6) this.later(1.0, () => this.learn('letters'));
      this.save();
    }
    this.mode = 'dialog';
    this.keys.clear();
    this.dlg = { id, n, page: 0 };
    const P = this.world.people[id]; if (P) P.talking = 1;
    this.ui.openDialog(n.name, n.role, n.lines.length);
    this.ui.setPrompt(null);
    const first = !this.st.people.has(id);
    this.st.people.add(id);
    this.learn(id, { quiet: !first });
    if (first) this.markLead('imprints');
    this.dialogPage();
  }
  // Keanu isn't one of the residents and doesn't go in the journal. The first time each cycle he
  // gets a belly rub and then follows you about; once you've read the book on the radio desk you
  // understand him, and after the first thing he has to say he starts pointing you places.
  talkKeanu() {
    const P = this.world.people.npcKeanu;
    const s = (this.st.solved ||= {});
    const fluent = !!s.speakDog;
    if (P && P.ball && P.ball.state === 'held') {
      // throw it: along where you're looking, as far as the room allows
      const cam = this.camera, dir = new THREE.Vector3(0, 0, -1).applyQuaternion(cam.quaternion), h = Math.hypot(dir.x, dir.z) || 1;
      P.throwBall(cam.position.x, cam.position.y, cam.position.z, dir.x / h, dir.z / h);
      P.called = true; P.petted = true;
      this.sound.woof(0.15, 1.25);
      return;
    }
    let lines;
    if (!fluent) lines = ['Rufff, ruf, rrrrr....'];
    else if (!s.keanuThanked) { s.keanuThanked = true; this.save(); lines = ['Finally You Understand Me']; }
    else lines = [this.keanuHint()];
    const n = fluent ? { name: 'Keanu', role: 'Good boy', voice: 150, wave: 'triangle', lines } : { name: 'Keanu', role: 'Good boy', dog: true, lines };
    if (P && P.mode === 'bed' && !P.petted) { P.petted = true; P.mode = 'pet'; P.petT = 0; this.sound.whine(0.1); if (!s.keanuPet) { s.keanuPet = true; this.save(); } }
    else if (P && P.mode === 'bed') { P.mode = 'hop'; P.hop = 0; }
    if (P) P.called = true;
    this.mode = 'dialog';
    this.keys.clear();
    this.dlg = { id: 'npcKeanu', n, page: 0 };
    if (P) P.talking = 1;
    this.ui.openDialog('Keanu', 'Good boy', lines.length);
    this.ui.setPrompt(null);
    if (fluent) this.sound.woof(0.02, 1.1); else { this.sound.woof(0.05, 1); this.sound.woof(0.42, 1.12); this.sound.growl(0.85, 1.2); }
    this.dialogPage();
  }
  // a short conversation with something that isn't a resident (the water, say): no journal, no count
  talkThing(id, name, role, lines, voice = 200, wave = 'sine') {
    this.mode = 'dialog';
    this.keys.clear();
    this.dlg = { id, n: { name, role, voice, wave, lines }, page: 0 };
    this.ui.openDialog(name, role, lines.length);
    this.ui.setPrompt(null);
    this.dialogPage();
  }
  // how many muttered lines there are to overhear across everyone's day
  routineLines() { let n = 0; for (const id in this.world.people) n += (this.world.people[id].route || []).length; return n; }
  // a nudge towards whatever you're stuck on, the way a dog would put it
  keanuHint() {
    const H = {
      hatch: 'The gallery floor. Be there when the sun is low, at eight. The light writes on it. I like sunny spots.',
      vault: 'The lanterns on the arches light up at three. Count them from the descent. The vault wants that order.',
      door: 'The tidal lock wants a civic override. Somebody wrote all of those down in a ledger. In a shelter. Somewhere wet.',
      gate: 'The iron gate opens when the span falls, at fifteen. Don\u2019t stand on the span. I mean it.',
      pump: 'Past the lock the run is only dry from six until twelve. Get to the pump at the far end before the water comes back.',
      bulkhead: 'The Core bulkhead compares one moment across two cycles. Do the same thing at the same time. Twice.',
      radio: 'The bell keeper left a recording in the city. It says which band, and when. *ears up*',
      beacon: 'The lighthouse has two switches. Aiden keeps the lamp. Ask him. He smells like lamp oil.',
      imprints: 'The engine in the middle of the station has a counter with tape over it. Look under the tape.',
      letters: 'Letters. One for each of them, left where they would walk past. Mailboxes. Take them to who they are for.',
      tarn: 'Show Luka the map. The boat will go to Tarn Quarter. I am not allowed on the boat.',
      release: 'Your voice. A word from the sky. The routing, in the right order. You can do it. Good human.'
    };
    const open = Object.keys(H).filter(k => leads[k] && this.leadOpen(k));
    if (open.length) return H[open[(this.st.loop + (this.cycle.keanuN = (this.cycle.keanuN || 0) + 1)) % open.length]];
    const unknown = Object.keys(H).find(k => leads[k] && !this.leadKnown(k));
    if (unknown) return '*sniff sniff* Go out. Walk. Talk to the others. Then come back and I will tell you where to dig.';
    // all the big things done: he knows where the little ones are too
    const C = {
      'Fetch': 'Ball. My ball. By the desk. You pick it up, you throw it, I bring it back. It is the best game.',
      'A small favour': 'Skye\u2019s roof flaps. Flap flap flap. Somebody should tie it. It frightens the gulls. I like the gulls.',
      'Something new': 'The garden man has too many red balls that are not balls. The apple lady has never had one.',
      'A fellow explorer': 'Milky. Fluffy. At the bottom of the long stairs. Smells like paper and string. Good tail. Not as good as mine.',
      'Cold tea': 'The kettle on the desk. The lamp man on the island is on the list and nobody makes him any.',
      'How to Speak Robot': 'The boat robot beeps in words. There is a book about it. On a crate, by the water.',
      'How to Speak Fish': 'The apple lady has a fish book. Fish are boring. But Charley would like it.'
    };
    const s = this.st.solved || {}, missing = curiosities.filter(c => !c.has(s) && C[c.title]);
    if (missing.length) return C[missing[(this.cycle.keanuN = (this.cycle.keanuN || 0) + 1) % missing.length].title];
    return 'Nothing left to sniff out. Sit with me a while.';
  }
  dialogPage() {
    const d = this.dlg; if (!d) return;
    clearInterval(this.typing);
    const text = d.n.lines[d.page];
    const t = this.ui.dialogPage(d.page, text);
    let i = 0;
    d.typing = true;
    this.typing = setInterval(() => {
      i += 1;
      t.textContent = text.slice(0, i);
      if (!d.n.dog && i % 2 === 0 && /[a-z0-9]/i.test(text[i - 1] || '')) this.sound.talk(d.n.voice, d.n.wave, text.endsWith('?') ? 1 : 0);
      if (i >= text.length) { clearInterval(this.typing); d.typing = false; }
    }, 26);
  }
  dialogNext() {
    const d = this.dlg; if (!d || this.mode !== 'dialog') return;
    if (d.typing) { clearInterval(this.typing); d.typing = false; this.ui.dialog.querySelector('.dlg-text').textContent = d.n.lines[d.page]; return; }
    d.page++;
    if (d.page >= d.n.lines.length) return this.endDialog();
    this.sound.click();
    this.dialogPage();
  }
  endDialog(silent) {
    if (!this.dlg) return;
    clearInterval(this.typing);
    const P = this.world.people[this.dlg.id]; if (P) P.talking = 0;
    this.dlg = null;
    this.ui.closeDialog();
    if (this.st.people.size >= 3 && this.learn('imprints')) this.markLead('imprints');
    if (!silent && this.mode === 'dialog') this.mode = 'play';
  }

  // ------------------------------------------------------------------ journal / pause
  openJournal() {
    if (this.mode !== 'play') return;
    this.toggleWait(false);
    this.mode = 'journal'; this.keys.clear(); this.releaseLock();
    this.sound.page();
    this.ui.openJournal();
  }
  closeJournal(silent) {
    if (this.mode !== 'journal' && !silent) return;
    if (this.mode === 'journal') this.st.fresh.clear();   // you've seen them now
    this.ui.closeJournal();
    if (this.mode === 'journal') { this.mode = 'play'; this.requestLock(); this.sound.page(); }
  }
  pause() {
    if (this.mode !== 'play') return;
    this.toggleWait(false);
    this.mode = 'pause'; this.keys.clear(); this.releaseLock();
    this.save();
    const st = this.st;
    this.ui.openPanel(p => {
      el('p', 'kicker', st.ended ? 'After' : 'Cycle ' + st.loop, p);
      el('h2', null, 'Paused', p);
      const meta = el('div', 'pause-meta', null, p);
      meta.innerHTML = `<span>${this.place || ''}</span>` + (st.ended ? '' : `<span>Basin time <b>${fmt(st.elapsed)}</b></span><span><b>${fmt(LOOP_SECONDS - st.elapsed)}</b> left</span>`) + `<span><b>${st.found.size}</b> known</span>`;
      // what you're carrying this cycle, if anything
      const c = this.cycle || {}, K = this.world.people.npcKeanu, pocket = [];
      if (c.pebble && !c.gavePebble) pocket.push('a pebble'); if (c.tomato && !c.gaveTomato) pocket.push('a tomato'); if (c.tea && !c.gaveTea) pocket.push('a cup of tea');
      if (K && K.ball && K.ball.state === 'held') pocket.push('Keanu\u2019s ball');
      if (pocket.length && !st.ended) meta.innerHTML += `<span>Carrying <b>${pocket.join(', ')}</b></span>`;
      const m = el('nav', 'menu', null, p);
      this.ui.menu(m, [
        { label: 'Resume', fn: () => this.resume() },
        { label: 'Journal', fn: () => { this.ui.onPanelClose = null; this.ui.closePanel(); this.mode = 'play'; this.openJournal(); } },
        { label: 'Settings', fn: () => { this.ui.onPanelClose = null; this.ui.settings(() => { this.ui.onPanelClose = null; this.ui.closePanel(); this.mode = 'play'; this.pause(); }); this.ui.onPanelClose = () => { this.mode = 'play'; this.pause(); }; } },
        { label: 'Controls', fn: () => { this.ui.onPanelClose = null; this.controlsPanel(() => { this.ui.onPanelClose = null; this.ui.closePanel(); this.mode = 'play'; this.pause(); }); this.ui.onPanelClose = () => { this.mode = 'play'; this.pause(); }; } },
        { label: 'Quit to title', fn: () => { this.ui.onPanelClose = null; this.ui.closePanel(); this.save(); this.fadeTo(1, 0.6); this.later(0.65, () => this.titleScreen()); } }
      ]);
    }, { overlayCls: 'pause', onClose: () => { if (this.mode === 'pause') { this.mode = 'play'; this.requestLock(); } } });
  }
  resume() { if (this.mode === 'pause') { this.ui.closePanel(); } }

  // ------------------------------------------------------------------ travel
  callSkiff(here) {
    const sk = this.world.skiff;
    this.ui.closePanel();
    if (sk.moving) return;
    this.ui.subtitle('Somewhere across the water, a motor coughs and starts.', 4);
    this.sound.motor(6);
    this.moveSkiff(sk.at, here, Math.max(9, Math.min(30, this.skiffPath(sk.at, here).getLength() / 10)), () => { this.ui.toast('The skiff', 'Luka is waiting at the landing.'); });
  }
  skiffPath(from, to) {
    // legs between docks, with the bends that keep the boat clear of rocks and towers
    const LEGS = {
      'pier-isle': [[-110, -100]], 'pier-rise': [[-100, -160]], 'isle-rise': [[-118, -120]],
      'pier-tarn': [[-70, -150], [-55, -195], [10, -200], [45, -190], [72, -170], [74, -130]]
    };
    const leg = (a, b) => { const k = a + '-' + b; if (LEGS[k]) return LEGS[k]; const r = LEGS[b + '-' + a]; return r ? [...r].reverse() : null; };
    let mids;
    if (leg(from, to)) mids = leg(from, to);
    else mids = [...leg(from, 'pier'), DOCKS.pier.boat, ...leg('pier', to)];
    const pts = [DOCKS[from].boat, ...mids, DOCKS[to].boat].map(p => new THREE.Vector3(p[0], 0, p[1]));
    return new THREE.CatmullRomCurve3(pts);
  }
  moveSkiff(from, to, dur, done) {
    const sk = this.world.skiff;
    sk.moving = { curve: this.skiffPath(from, to), t: 0, dur, to, done };
  }
  updateSkiff(dt) {
    const sk = this.world.skiff, W = this.world;
    const m = sk.moving;
    sk.wake.material.uniforms.time.value = this.time;
    if (m) {
      m.t += dt / m.dur;
      const k = Math.min(1, m.t), e = k * k * (3 - 2 * k);
      const p = m.curve.getPointAt(e), p2 = m.curve.getPointAt(Math.min(1, e + 0.01));
      sk.group.position.set(p.x, W.seaLevel, p.z);
      if (k < 0.98) sk.group.rotation.y = Math.atan2(p2.x - p.x, p2.z - p.z);
      sk.wake.material.uniforms.amt.value = Math.min(1, Math.sin(k * Math.PI) * 2.2) * 0.55;
      if (k >= 1) { sk.at = m.to; sk.moving = null; sk.group.rotation.y = DOCKS[m.to].yaw; if (m.done) m.done(); }
    } else {
      sk.wake.material.uniforms.amt.value *= Math.exp(-dt * 0.8);
      sk.group.position.y = W.seaLevel + Math.sin(this.time * 1.3) * 0.05;
      sk.group.rotation.z = Math.sin(this.time * 0.9) * 0.02;
    }
    W.skiff.light.x = sk.group.position.x; W.skiff.light.y = sk.group.position.y + 2.8; W.skiff.light.z = sk.group.position.z;
  }
  rideSkiff(from, to) {
    this.mode = 'cine';
    const dur = Math.max(14, Math.min(40, this.skiffPath(from, to).getLength() / 9));
    this.cine = { type: 'skiff', t: 0, dur, from, to, live: true, look: true, yaw0: this.body.yaw };
    this.moveSkiff(from, to, dur, null);
    this.sound.motor(dur);
    if (to === 'tarn' && !this.st.hints.tarnRide) { this.st.hints.tarnRide = true; this.later(4, () => this.ui.subtitle('Luka: \u201cTarn Quarter is closed to traffic. You have the map. That is irregular. Hold on.\u201d', 5)); }
    this.requestLock();
    this.ui.subtitle('Luka: “Hold on to nothing in particular.”', 3.5);
  }
  rideLift(where) {
    this.mode = 'cine';
    this.liftRiding = true;
    this.cine = { type: 'lift', t: 0, dur: 6.5, where, live: true };
    this.fadeTo(1, 1.2);
    this.sound.lift(6);
  }

  // ------------------------------------------------------------------ cinematics
  cineFrame(dt) {
    const c = this.cine, b = this.body, st = this.st;
    if (!c) { this.mode = 'play'; return; }
    c.t += dt;
    if (c.live && !st.ended) st.elapsed += dt;
    if (c.type !== 'skiff') this.updateSkiff(c.live ? dt : 0);
    if (c.type === 'wake') {
      const k = Math.min(1, c.t / c.dur);
      // lie still, then sit up and look ahead
      const lie = 1 - sm(0.25, 0.85, k);
      b.pitch = lerp(0, 1.25, lie);
      this.updateCamera(dt, false);
      this.camera.position.y -= lie * 0.9;
      this.camera.position.z += lie * 0.8;
      if (k >= 1) {
        this.mode = 'play'; this.cine = null;
        if (this.st.loop === 1 && !this.st.hints.controls) {
          this.st.hints.controls = true;
          { const K = this.settings.keys, b = (c) => '<kbd>' + keyName(c) + '</kbd>';
            this.ui.showHint(b(K.forward) + b(K.left) + b(K.back) + b(K.right) + ' move &nbsp; ' + b(K.sprint) + ' run &nbsp; ' + b(K.jump) + ' jump &nbsp; ' + b(K.interact) + ' interact &nbsp; ' + b(K.wait) + ' wait &nbsp; ' + b(K.journal) + ' journal &nbsp; <kbd>Esc</kbd> pause', 12); }
        } else if (this.st.loop === 2 && !this.st.hints.loop2) {
          this.st.hints.loop2 = true;
          this.ui.showHint('Everything you learned is still in your journal. <kbd>J</kbd>', 8);
        }
        this.later(2.5, () => this.observe('station'));
      }
    } else if (c.type === 'rebound') {
      const k = Math.min(1, c.t / c.dur);
      // the world runs backwards: platforms rise out of the sea, towers stand, the sun climbs
      const back = sm(0.12, 0.8, k);
      st.elapsed = c.e0 * (1 - back * back * (3 - 2 * back));
      this.prevElapsed = st.elapsed;
      this.R.comp.u.warp.value = this.settings.calm ? 0 : Math.sin(k * Math.PI) * 2.2 + sm(0.8, 1, k) * 2;
      this.fadeColor('#dff8f5');
      $('#fade').style.transition = 'none';
      $('#fade').style.opacity = sm(0.08, 0.2, k) * 0.25 + sm(0.78, 0.97, k);
      // drift up and back to take it in
      this.updateCamera(dt, false);
      // rise straight up first, then drift back from the city, so the camera clears roofs and the dome
      const up = sm(0.04, 0.42, k), away = sm(0.3, 0.85, k);
      const ax = c.cam.x - 0, az = c.cam.z + 110, al = Math.hypot(ax, az) || 1;
      this.camera.position.set(c.cam.x + ax / al * 28 * away, Math.max(c.cam.y + 34 * up, c.cam.y), c.cam.z + az / al * 28 * away);
      const look = new THREE.Vector3(0, 4, -100);
      const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
      this.camera.lookAt(this.camera.position.clone().add(fwd.lerp(look.sub(this.camera.position).normalize(), Math.min(1, dt * 2.5))));
      if (k >= 1) {
        this.R.comp.u.warp.value = 0;
        $('#fade').style.background = '#000';
        $('#fade').style.opacity = 1;
        $('#fade').style.transition = '';
        this.newCycle(true);
        this.mode = 'cine';
        this.later(0.4, () => this.wakeCine(null));
        this.cine = { type: 'hold', t: 0, dur: 99 };
      }
    } else if (c.type === 'white') {
      this.updateCamera(dt, false);
      if (c.t >= c.dur) { this.cine = null; this.rebound('rehearse'); }
    } else if (c.type === 'hold') {
      this.updateCamera(dt, false);
    } else if (c.type === 'skiff') {
      this.applyLook();
      const sk = this.world.skiff;
      this.updateSkiff(dt);
      const g = sk.group;
      const seat = new THREE.Vector3(0, 0.95, -1.3).applyEuler(g.rotation).add(g.position);
      b.x = seat.x; b.y = seat.y - 0.2; b.z = seat.z;
      this.updateCamera(dt, false);
      if (!sk.moving) {
        const L = DOCKS[c.to].land;
        b.place(L[0], L[1], L[2], DOCKS[c.to].face);
        this.mode = 'play'; this.cine = null;
        this.updateRegion();
      }
    } else if (c.type === 'lift') {
      this.updateCamera(dt, false);
      this.shake(0.15, 0.1);
      if (c.t > 3 && !c.moved) {
        c.moved = true;
        if (c.where === 'station') b.place(9.25, DF + 0.05, -225.05, -Math.PI / 2); else b.place(Math.sin(120 * Math.PI / 180) * 12.6, F + 0.05, Math.cos(120 * Math.PI / 180) * 12.6, 120 * Math.PI / 180 + Math.PI);
        st.elapsed = Math.min(LOOP_SECONDS - 1, st.elapsed + 20);
        this.updateRegion();
      }
      if (c.t > 4.5 && !c.faded) { c.faded = true; this.fadeTo(0, 1.2); }
      if (c.t >= c.dur) { this.mode = 'play'; this.cine = null; this.liftRiding = false; this.requestLock(); }
    } else if (c.type === 'ending') {
      this.endingFrame(dt);
    }
  }

  // ------------------------------------------------------------------ the ending
  ending() {
    const st = this.st;
    this.mode = 'cine';
    this.releaseLock();
    this.cine = { type: 'ending', t: 0, stage: 0 };
    this.sound.flash();
    this.shake(1.2, 4);
    this.music.stopAll(2);
    this.fadeColor('#f6fbff');
    this.fadeTo(1, 3.5);
    this.world.core.beam.material.uniforms.amt.value = 6;
  }
  endingFrame(dt) {
    const c = this.cine, st = this.st;
    if (c.stage === 0 && c.t > 4) {
      c.stage = 1;
      st.ended = true;
      this.save();
      this.dawnK = 0;
      $('#hud').hidden = true;
      this.music.setMood('ending');
      this.fadeTo(0, 3);
      $('#ending').hidden = false;
      c.finale = new Finale(this);
      c.canSkip = true;
    }
    if (c.stage === 1) {
      // a click skips to the title and credits; a second click ends it
      if (c.skip) { c.skip = false; if (c.t < 88) c.t = 88; else c.t = Math.max(c.t, 104); }
      this.dawnK = sm(5.5, 20, c.t);
      c.finale.update(c.t, dt);
      if (c.t > 104 && !c.out) {
        c.out = true;
        this.fadeColor('#000'); this.fadeTo(1, 2.5);
        this.later(2.7, () => { c.finale.finish(); $('#ending').hidden = true; this.cine = null; this.dawnK = 1; this.titleScreen(); });
      }
    }
  }

  // ------------------------------------------------------------------ world audio-visual helpers
  distantCrash(x, z, k = 0.5) {
    const d = Math.hypot(this.body.x - x, this.body.z - z);
    const v = Math.max(0.05, 1 - d / 260) * k;
    this.sound.crash(0.35 * v);
    this.shake(Math.max(0, 1 - d / 120) * 0.8, 2.5);
  }
  distantSplash(x, z) {
    const d = Math.hypot(this.body.x - x, this.body.z - z);
    this.sound.splash(Math.max(0.04, 0.35 * (1 - d / 260)));
  }
  bellToll(n) {
    const d = Math.hypot(this.body.x + 10.5, this.body.z + 70.5, (this.body.y - 30) * 0.5);
    const v = Math.max(0, 1 - d / 220);
    if (v <= 0.02) return;
    for (let i = 0; i < n; i++) this.later(i * 2.6, () => this.sound.towerBell(0.16 * v));
    if (this.world.bell) this.world.bell.swing = 1;
  }

  environment(dt) {
    const W = this.world, R = this.R, st = this.st;
    const reg = REGIONS[this.region] || REGIONS.city;
    const k = 1 - Math.exp(-dt * 1.2);
    const fog = this.scene.fog;
    const f = st.ended ? 0 : st.elapsed / LOOP_SECONDS;
    const dawn = st.ended && this.region !== 'deep' && this.region !== 'core';
    const tgtFog = new THREE.Color(dawn ? 0x8a7a8a : reg.fog);
    if (!dawn && (this.region === 'city' || this.region === 'isle' || this.region === 'rise' || this.region === 'station')) tgtFog.lerp(new THREE.Color(0x1c1a2a), f * 0.6);
    fog.color.lerp(tgtFog, k);
    fog.density = lerp(fog.density, reg.den * (dawn ? 0.6 : 1) * (1 + sm(1262, 1320, st.elapsed) * 0.6), k);
    skyU.fogCol.value.copy(fog.color);
    W.sea.u.fogDen.value = fog.density;
    W.hemi.color.lerp(new THREE.Color(reg.hemiSky), k);
    W.hemi.groundColor.lerp(new THREE.Color(reg.hemiGround), k);
    W.hemi.intensity = lerp(W.hemi.intensity, reg.hemi * (dawn ? 1.3 : 1 - f * 0.35), k);
    W.sun.intensity = lerp(W.sun.intensity, reg.sun * (W.sunBase ?? 1), k);
    this.envT = (this.envT ?? 99) + dt;
    if (this.envT > (st.ended || st.elapsed > 1250 ? 2 : 8)) { this.envT = 0; W.updateEnv(); }
    this.scene.environmentIntensity = lerp(this.scene.environmentIntensity ?? 0, (reg.env ?? 0.3) * (dawn ? 1.2 : 1), k);
    const g = reg.grade, G = R.grade;
    G.lift.lerp(new THREE.Vector3(...g.lift), k); G.gamma.lerp(new THREE.Vector3(...g.gamma), k); G.gain.lerp(new THREE.Vector3(...g.gain), k);
    G.sat = lerp(G.sat, g.sat * (1 - sm(1290, 1320, st.elapsed) * 0.4), k);
    G.contrast = lerp(G.contrast, g.contrast, k);
    G.exposure = lerp(G.exposure, g.exposure * (dawn ? 1.1 : 1), k);
    G.bloom = lerp(G.bloom, g.bloom, k);
    R.comp.u.grain.value = this.settings.grain && this.settings.quality !== 'lowest' ? 0.03 : 0;
    R.comp.u.aberr.value = this.settings.calm ? 0 : 0.2 + sm(1262, 1320, st.elapsed) * 1.2;
    if (!(this.cine && this.cine.type === 'rebound')) R.comp.u.warp.value = st.ended || this.settings.calm ? 0 : sm(1290, 1320, st.elapsed) * 0.8;
  }

  ambience(dt) {
    const s = this.sound; if (!s.ready) return;
    const r = this.region, st = this.st;
    s.setSpace(this.mode === 'title' ? 'city' : r);
    const title = this.mode === 'title';
    const L = { wind: 0, sea: 0, hum: 0, deep: 0, core: 0, water: 0, dread: 0 };
    if (title) { L.wind = 0.35; L.sea = 0.4; }
    else if (r === 'station') {
      // the Engine is louder the closer you stand to it
      const d = Math.hypot(this.body.x, this.body.z);
      L.hum = (gridDown(st.elapsed) && !st.ended ? 0.15 : 0.3) + 0.45 * Math.max(0, 1 - d / 14);
      L.wind = d > 15 ? 0.35 : 0.12; L.sea = d > 15 ? 0.25 : 0.08;
    }
    else if (r === 'city') { L.wind = 0.45; L.sea = this.body.y < 4 ? 0.65 : 0.35; }
    else if (r === 'isle' || r === 'rise' || r === 'tarn') { L.wind = 0.5; L.sea = 0.75; }
    else if (r === 'deep') { L.deep = 0.6; L.water = runWater(st.elapsed, st) > DF ? 0.5 : 0.1; }
    else if (r === 'core') { const d = Math.hypot(this.body.x, this.body.z + 275); L.core = 0.4 + 0.5 * Math.max(0, 1 - d / 20); L.deep = 0.2; }
    if (!st.ended && !title) L.dread = sm(1140, 1320, st.elapsed) * 0.6;
    for (const k in L) s.setLayer(k, L[k]);
    // occasional one-shots
    this.ambT -= dt;
    if (this.ambT <= 0 && !title) {
      this.ambT = 3 + Math.random() * 6;
      if (r === 'deep' || r === 'core') s.drip();
      else if ((r === 'isle' || r === 'rise' || r === 'tarn' || (r === 'city' && this.body.y < 4)) && Math.random() < 0.5) s.gull();
      else if (r === 'station' && Math.random() < 0.3) s.creak();
    }
  }

  fadeTo(v, sec) { const f = $('#fade'); f.style.transition = `opacity ${sec}s ease`; f.style.opacity = v; }
  fadeColor(c) { $('#fade').style.background = this.settings.calm && c !== '#000' ? '#0b0d14' : c; }

  // ------------------------------------------------------------------ settings
  applySettings() {
    const s = this.settings;
    document.documentElement.style.fontSize = (16 * (s.textSize || 1)) + 'px';
    document.documentElement.style.setProperty('--sub-scale', s.subSize || 1);
    // the keys printed on screen follow your bindings
    const pk = document.querySelector('#prompt kbd'), jk = document.querySelector('#jNew kbd');
    if (pk && s.keys) pk.textContent = keyName(s.keys.interact);
    if (jk && s.keys) jk.textContent = keyName(s.keys.journal);
    this.sound.setVolumes({ master: s.master, music: s.music, sfx: s.sfx, amb: s.amb, voice: s.voice });
    if (this.R) {
      if (this.R.quality !== s.quality) this.R.setQuality(s.quality);
      this.R.bloomOn = s.bloom;
      this.R.brightness = s.brightness ?? 1.2;
      const lean = s.quality === 'low' || s.quality === 'lowest';
      if (s.quality === 'lowest') { this.R.bloomOn = false; }
      this.world && (this.world.sun.castShadow = !lean);
      if (this.world) this.world.sun.shadow.mapSize.set(s.quality === 'high' ? 2048 : 1024, s.quality === 'high' ? 2048 : 1024);
    }
    if (this.camera) { this.camera.fov = s.fov; this.camera.updateProjectionMatrix(); }
  }
  saveSettings() { saveSettings(this.settings); }

  // ------------------------------------------------------------------ the map
  mapSVG() {
    const st = this.st, seen = (id) => st.found.has(id);
    const X = (x) => (x + 175) * 2.6, Y = (z) => (25 - z) * 2.6;
    const R = (x0, z0, x1, z1, on, label, lx, lz) => `<rect x="${X(x0)}" y="${Y(z1)}" width="${(x1 - x0) * 2.6}" height="${(z1 - z0) * 2.6}" class="${on ? 'm-on' : 'm-off'}"/>` + (on && label ? `<text x="${X(lx ?? (x0 + x1) / 2)}" y="${Y(lz ?? (z0 + z1) / 2)}">${label}</text>` : '');
    const Cc = (x, z, r, on, label, dash) => `<circle cx="${X(x)}" cy="${Y(z)}" r="${r * 2.6}" class="${on ? 'm-on' : 'm-off'}${dash ? ' m-dash' : ''}"/>` + (on && label ? `<text x="${X(x)}" y="${Y(z) + r * 2.6 + 26}">${label}</text>` : '');
    const city = seen('city');
    // ink on paper: every line goes through a little turbulence so it wobbles like a pen line
    let s = `<svg viewBox="0 0 ${X(130)} ${Y(-300)}" xmlns="http://www.w3.org/2000/svg"><defs>
      <filter id="wob" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="4"/><feDisplacementMap in="SourceGraphic" scale="4"/></filter>
      <filter id="wash"><feTurbulence type="fractalNoise" baseFrequency="0.012" numOctaves="3" seed="9"/><feColorMatrix values="0 0 0 0 0.35  0 0 0 0 0.52  0 0 0 0 0.62  0 0 0 0.55 -0.12"/><feComposite in2="SourceGraphic" operator="in"/></filter>
      <radialGradient id="washFade" cx="50%" cy="50%" r="62%"><stop offset="55%" stop-color="#fff"/><stop offset="100%" stop-color="#000"/></radialGradient>
      <mask id="washMask"><rect x="0" y="0" width="${X(130)}" height="${Y(-300)}" fill="url(#washFade)"/></mask></defs><style>
      .m-on{fill:rgba(29,39,48,.07);stroke:#1d2730;stroke-width:3;stroke-linejoin:round}.m-off{fill:none;stroke:rgba(110,104,91,.6);stroke-width:2;stroke-dasharray:6 7}
      .m-dash{stroke-dasharray:6 5}.m-line{stroke:#1d2730;stroke-width:2.6;fill:none}.m-water{fill:#7fa6b3}
      text{font:400 27px "Rebound Hand",sans-serif;fill:#1d2730;text-anchor:middle}.m-you{fill:#a33b28}.m-core{fill:#2c4f7c;opacity:.6}</style>`;
    s += `<rect x="8" y="8" width="${X(130) - 16}" height="${Y(-300) - 16}" class="m-water" filter="url(#wash)" opacity=".5" mask="url(#washMask)"/>`;
    s += `<g filter="url(#wob)">`;
    s += `<g transform="translate(${X(110)} ${Y(5)})"><path d="M0 -18 L7 5 L0 1 L-7 5 Z" fill="none" stroke="#1d2730" stroke-width="1.6" stroke-linejoin="round"/><text y="24" style="font-weight:700">N</text></g>`;
    if (seen('skiff')) {
      const D = DOCKS;
      s += `<path d="M${X(D.pier.boat[0])} ${Y(D.pier.boat[1])} Q ${X(-110)} ${Y(-100)} ${X(D.isle.boat[0])} ${Y(D.isle.boat[1])} M${X(D.pier.boat[0])} ${Y(D.pier.boat[1])} Q ${X(-100)} ${Y(-160)} ${X(D.rise.boat[0])} ${Y(D.rise.boat[1])}" fill="none" stroke="#2c4f7c" stroke-width="1.4" stroke-dasharray="2 6" stroke-linecap="round"/>`;
      if (seen('tarnRoofs')) s += `<polyline points="${[D.pier.boat, [-70, -150], [-55, -195], [10, -200], [45, -190], [72, -170], [74, -130], D.tarn.boat].map(p => X(p[0]) + ',' + Y(p[1])).join(' ')}" fill="none" stroke="#2c4f7c" stroke-width="1.4" stroke-dasharray="2 6" stroke-linecap="round"/>`;
    }
    s += Cc(0, 0, 16.3, true, 'Halcyon Station');
    s += `<line x1="${X(0)}" y1="${Y(-21)}" x2="${X(0)}" y2="${Y(-60)}" class="m-line"/>`;
    s += R(-16, -80, 16, -58, city, 'Upper Terrace', 0, -66);
    s += R(-24, -131, 24, -80, city, 'Concourse', 0, -110);
    s += R(12, -116, 24, -96, city, '');
    s += R(-23.5, -110, -12, -91, city, '');
    s += R(-50, -130, -30, -110, city && st.found.has('npcJuniper') || seen('pierBoard'), 'Market Pier', -40, -137);
    s += R(-72, -122, -50, -118, city && seen('pierBoard'), '');
    s += R(24, -136, 35, -108, seen('serviceWalk'), 'Service Walk', 30, -100);
    s += R(-16, -174, 24, -145, city, 'South Plaza', 4, -160);
    s += R(-2.1, -145, 2.1, -131, city, '');
    s += R(-5, -241, 11, -182, seen('deep'), 'The Deep', 18, -212);
    s += Cc(0, -275, 20.5, seen('core'), 'The Core', true);
    s += `<circle cx="${X(0)}" cy="${Y(-275)}" r="5" class="m-core"/>`;
    s += Cc(-150, -58, 11, seen('isle'), 'Lantern Isle');
    s += R(-133, -212, -111, -192, seen('rise'), 'Verdant Rise', -122, -219);
    s += R(60, -180, 128, -40, seen('tarnMap') || seen('tarnStone'), 'Tarn Quarter (drowned)', 94, -60);
    s += R(80, -122, 104, -98, seen('tarnRoofs'), 'Tarn Rooftops', 92, -130);
    const b = this.body;
    if (!st.ended || true) s += `<g transform="translate(${X(b.x)} ${Y(b.z)}) rotate(${-b.yaw * 180 / Math.PI + 180})"><path d="M0 -9 L6 6 L0 3 L-6 6 Z" class="m-you"/></g>`;
    s += `</g></svg>`;
    return s;
  }
}
