// Saved progress (knowledge survives the loop) and settings. Both live in localStorage and
// both survive any storage failure: the game still runs, it just forgets on reload.
const SAVE_KEY = 'rebound.v3.save';
const SET_KEY = 'rebound.v3.settings';

export const DEFAULT_SETTINGS = {
  master: 0.8, music: 0.6, sfx: 0.8, amb: 0.7, voice: 0.7,
  sensitivity: 1.0, invertY: false, fov: 66,
  quality: 'high', brightness: 1.2, bloom: true, bob: true, grain: true, shake: true,
  subtitles: true, textSize: 1, subSize: 1, calm: false,
  // every action can be moved to another key (the arrow keys always move too)
  keys: { forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD', sprint: 'ShiftLeft', jump: 'Space', interact: 'KeyE', journal: 'KeyJ', wait: 'KeyT', hud: 'KeyH' }
};
export const ACTIONS = [['forward', 'Move forward'], ['back', 'Move back'], ['left', 'Step left'], ['right', 'Step right'], ['sprint', 'Run'], ['jump', 'Jump'], ['interact', 'Interact, talk'], ['journal', 'Journal'], ['wait', 'Wait'], ['hud', 'Hide the interface']];
// a key's name the way it's printed on the key
export function keyName(code) {
  if (!code) return '?';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  const n = { Space: 'Space', ShiftLeft: 'Shift', ShiftRight: 'Right Shift', ControlLeft: 'Ctrl', ControlRight: 'Right Ctrl', AltLeft: 'Alt', AltRight: 'Right Alt', Tab: 'Tab', Enter: 'Enter', Backspace: 'Backspace', CapsLock: 'Caps Lock',
    ArrowUp: '\u2191', ArrowDown: '\u2193', ArrowLeft: '\u2190', ArrowRight: '\u2192', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backslash: '\\', BracketLeft: '[', BracketRight: ']', Minus: '-', Equal: '=', Backquote: '`' }[code];
  return n || code.replace(/^Numpad/, 'Num ');
}

function read(key) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch { return null; } }
function write(key, v) { try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch { return false; } }

export function loadSettings() { const saved = read(SET_KEY) || {}; return { ...DEFAULT_SETTINGS, ...saved, keys: { ...DEFAULT_SETTINGS.keys, ...(saved.keys || {}) } }; }
export function saveSettings(s) { write(SET_KEY, s); }

export function freshState() {
  return {
    version: 3,
    loop: 1,
    elapsed: 0,
    found: new Set(),
    foundAt: {},             // the cycle each note was found in: older notes are more worn
    fresh: new Set(),        // entries not yet opened in the journal
    solved: {},              // persistent puzzle state (knowledge and relay-retained mechanisms)
    people: new Set(),
    ended: false,
    hints: {},
    playTime: 0,
    deaths: 0
  };
}

export function hasSave() { const s = read(SAVE_KEY); return !!(s && s.version === 3 && (s.loop > 1 || (s.found && s.found.length))); }

export function loadState() {
  const s = read(SAVE_KEY);
  if (!s || s.version !== 3) return null;
  const st = freshState();
  st.loop = s.loop | 0 || 1;
  st.found = new Set(s.found || []);
  st.foundAt = s.foundAt || {};
  st.fresh = new Set(s.fresh || []);
  st.solved = s.solved || {};
  st.people = new Set(s.people || []);
  st.ended = !!s.ended;
  st.hints = s.hints || {};
  st.playTime = s.playTime || 0;
  return st;
}

export function saveState(st) {
  return write(SAVE_KEY, {
    version: 3, loop: st.loop, found: [...st.found], foundAt: st.foundAt, fresh: [...st.fresh], solved: st.solved,
    people: [...st.people], ended: st.ended, hints: st.hints, playTime: Math.round(st.playTime)
  });
}

export function clearSave() { try { localStorage.removeItem(SAVE_KEY); } catch { } }
