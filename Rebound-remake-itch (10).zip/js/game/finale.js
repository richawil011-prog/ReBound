// The finale. After the beam goes up, a short film:
//   A  dawn over the basin from the Upper Terrace, the beam still climbing
//   B  up to the Sister, as the carrier answers: "We see the sunrise."
//   C  the Market Pier at sunrise: the residents at the rail, Luka bringing the skiff in
//   D  everyone aboard, two by two, Keanu last and into the bow
//   E  out across the basin past Lantern Isle: the lamp flashes, and the skiff flashes back
//   F  from the stern, the city going small behind you
//   G  the boat heading into the sun, and the title
// Every moving thing is worked out from the clock T alone, so skipping ahead lands everything
// exactly where it should be.
import * as THREE from '../../vendor/three.module.min.js';
import { endingLines, story } from './story.js';
import { $, el } from '../ui/ui.js';

const sm = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const V = (x, y, z) => new THREE.Vector3(x, y, z);

// the skiff: in from the sunrise to the pier, and back out again into it
const DOCK = V(-75.5, 0, -124.5), DOCK_YAW = Math.PI / 2;
const ARRIVE = new THREE.CatmullRomCurve3([V(-185, 0, -196), V(-128, 0, -176), V(-100, 0, -158), V(-84, 0, -132), DOCK]);
const DEPART = new THREE.CatmullRomCurve3([DOCK, V(-73.5, 0, -129.5), V(-82, 0, -138.5), V(-100, 0, -160), V(-150, 0, -185), V(-260, 0, -236), V(-390, 0, -296)]);
const T_ARRIVE = [23, 39], T_DEPART = [56, 112];
const LIGHTHOUSE = V(-156, 20.5, -52);

// who stands where on the pier, the order they go aboard, and where they stand on deck (x across,
// z along the boat, bow +z)
const ORDER = ['npcPell', 'npcJuniper', 'npcGardener', 'npcSef', 'npcKeeper', 'npcKeanu'];
const PIER = { npcPell: [-70.6, -120.5], npcJuniper: [-69.5, -120.3], npcGardener: [-68.3, -120.6], npcSef: [-67.1, -120.4], npcKeeper: [-65.9, -120.6], npcKeanu: [-64.8, -120.9] };
const SEAT = { npcPell: [-0.5, 0.95], npcJuniper: [0.5, 0.95], npcGardener: [-0.5, -0.6], npcSef: [0.5, -0.6], npcKeeper: [0, -2.7], npcKeanu: [0, 2.8] };
const EDGE = V(-70.0, 2.0, -121.7), STEP = V(-70.15, 1.6, -123.05), PIER_Y = 2.0, DECK = 0.55;

// the lines of the story, and when each one comes up
function lineTimes(n) { return [6, 10.5, 16.5, 24.5, 32, 45, 56].slice(0, n); }

export class Finale {
  constructor(g) {
    this.g = g;
    const box = $('#ending .end-text'); box.innerHTML = ''; box.classList.add('film');
    this.lines = endingLines(g.st).map(t => el('p', null, t, box));
    this.msg = el('p', 'msg', story.message, box);
    this.times = lineTimes(this.lines.length);
    this.skipHint = el('div', 'skip-hint', 'Space to skip', $('#ending'));
    setTimeout(() => this.skipHint.classList.add('on'), 6000);
    setTimeout(() => this.skipHint.classList.remove('on'), 12000);
    this.shown = -1;
    this.cut = -1;
    this.flags = {};
    this.boatYaw = DOCK_YAW;
    const W = g.world;
    W.cutscene = true;
    // the world as it is on the morning after: nothing sunk, nothing falling
    for (const ch of W.chunks) { ch.offset.set(0, 0, 0); ch.group.position.set(0, 0, 0); ch.group.rotation.set(0, 0, 0); ch.solid = true; }
    const sk = W.skiff; sk.moving = null;
    for (const id in W.people) { const p = W.people[id]; if (p.line) p.line.visible = false; if (!p.robot) p.group.visible = true; }
    const K = W.people.npcKeanu;
    if (K) { K.dogs.lie.group.visible = false; K.dogs.stand.group.visible = true; }
  }

  // ---------------------------------------------------------------- the boat
  boat(T) {
    const W = this.g.world, sk = W.skiff, P = sk.group.position;
    let p, yaw, speed = 0;
    if (T < T_ARRIVE[1]) {
      const t = clamp01((T - T_ARRIVE[0]) / (T_ARRIVE[1] - T_ARRIVE[0])), e = 1 - Math.pow(1 - t, 2.2);
      p = ARRIVE.getPointAt(e); const q = ARRIVE.getPointAt(Math.min(1, e + 0.005));
      yaw = Math.atan2(q.x - p.x, q.z - p.z);
      yaw = lerpAngle(yaw, DOCK_YAW, sm(0.82, 1, e));
      speed = t < 1 ? (1 - t) * 9 : 0;
    } else if (T < T_DEPART[0]) {
      p = DOCK; yaw = DOCK_YAW;
    } else {
      const t = clamp01((T - T_DEPART[0]) / (T_DEPART[1] - T_DEPART[0])), e = Math.pow(t, 1.45);
      p = DEPART.getPointAt(e); const q = DEPART.getPointAt(Math.min(1, e + 0.004));
      yaw = lerpAngle(DOCK_YAW, Math.atan2(q.x - p.x, q.z - p.z), sm(0, 0.02, e));
      speed = Math.min(1, t * 6) * 7;
    }
    P.x = p.x; P.z = p.z;
    sk.group.rotation.y = yaw;
    sk.wake.material.uniforms.amt.value = Math.min(0.55, speed * 0.08);
    sk.light.x = P.x; sk.light.z = P.z;
    sk.group.updateMatrixWorld(true);
    return sk.group;
  }
  onDeck(boat, id) { const [x, z] = SEAT[id]; return boat.localToWorld(V(x, DECK, z)); }

  // ---------------------------------------------------------------- the people
  people(T, boat, dt) {
    const W = this.g.world;
    ORDER.forEach((id, i) => {
      const p = W.people[id]; if (!p) return;
      const dog = !!p.dog, G = p.group;
      const [sx, sz] = PIER[id], S = V(sx, PIER_Y, sz);
      const t0 = 42 + i * 1.5, dW = S.distanceTo(EDGE) / (dog ? 2.2 : 1.2);
      const t1 = t0 + dW, t2 = t1 + (dog ? 0 : 0.45), t3 = t2 + (dog ? 0.75 : 0.6);
      let pos, yaw, walking = false;
      if (T < t0) {
        // at the rail, watching the boat come in
        pos = S; const B = boat.position; yaw = Math.atan2(B.x - S.x, B.z - S.z);
      } else if (T < t1) {
        const k = (T - t0) / dW; pos = S.clone().lerp(EDGE, k); yaw = Math.atan2(EDGE.x - S.x, EDGE.z - S.z); walking = true;
      } else if (T < t2) {
        const k = (T - t1) / (t2 - t1); pos = EDGE.clone().lerp(STEP, k); pos.y += Math.sin(k * Math.PI) * 0.15; yaw = Math.atan2(STEP.x - EDGE.x, STEP.z - EDGE.z);
      } else if (T < t3) {
        const from = dog ? EDGE : STEP, to = this.onDeck(boat, id), k = (T - t2) / (t3 - t2);
        pos = from.clone().lerp(to, k); pos.y += Math.sin(k * Math.PI) * (dog ? 0.6 : 0.35); yaw = Math.atan2(to.x - from.x, to.z - from.z);
        if (dog && !this.flags.woof) { this.flags.woof = true; this.g.sound.woof(0, 1.05); }
      } else {
        // aboard: facing the bow, riding with the boat
        pos = this.onDeck(boat, id); yaw = boat.rotation.y;
      }
      G.position.copy(pos);
      G.rotation.y = yaw;
      G.visible = true;
      // legs: a walk for people, a trot for Keanu
      p.stride = (p.stride || 0) + dt * (walking ? (dog ? 12 : 7.5) : 0);
      const sw = walking ? Math.sin(p.stride) : 0;
      if (dog) {
        const L = p.dogs.stand.legs;
        L[0].rotation.x = sw * 0.5; L[3].rotation.x = sw * 0.5; L[1].rotation.x = -sw * 0.5; L[2].rotation.x = -sw * 0.5;
        p.dogs.stand.tail.rotation.y = Math.sin(this.g.time * 12) * 0.5;
        p.head = p.dogs.stand.head;
        // if you ever played fetch with him, he brings his ball
        const sol = this.g.st.solved || {};
        if (p.ball && sol.keanuFetch) {
          const hp = this._hp || (this._hp = new THREE.Vector3()), q = this._hq || (this._hq = new THREE.Quaternion()), f = this._hf || (this._hf = new THREE.Vector3());
          p.dogs.stand.head.getWorldPosition(hp); p.dogs.stand.group.getWorldQuaternion(q); f.set(0, 0, 1).applyQuaternion(q); f.y = 0; f.normalize();
          p.ball.mesh.visible = true; p.ball.mesh.position.set(hp.x + f.x * 0.2, hp.y - 0.07, hp.z + f.z * 0.2); p.ball.it.y = -999;
        } else if (p.ball) p.ball.mesh.visible = false;
      } else {
        if (p.legs) { p.legs[0].rotation.x = sw * 0.42; p.legs[1].rotation.x = -sw * 0.42; }
        p.arms[0].rotation.x = -sw * 0.25; p.arms[1].rotation.x = sw * 0.25;
        p.body.position.y = walking ? Math.abs(Math.cos(p.stride)) * 0.025 : 0;
        p.head.rotation.set(0, 0, 0);
      }
    });
  }

  // ---------------------------------------------------------------- the camera, shot by shot
  shot(T, boat) {
    const B = boat.position, fwd = V(Math.sin(boat.rotation.y), 0, Math.cos(boat.rotation.y));
    if (T < 15) {           // A: dawn from the terrace, the beam still climbing
      const k = (T - 4) / 11;
      return { pos: V(Math.sin(k * 0.8) * 2, 17.6 + k * 1.8, -82 - k * 5), at: V(0, 14 + k * 18, -260), id: 0 };
    }
    if (T < 23) {           // B: up to the Sister
      const k = (T - 15) / 8, pos = V(3, 19.5, -87);
      const moon = pos.clone().addScaledVector(V(0.55, 0.32, 0.62).normalize(), 100);
      return { pos, at: V(0, 18, -40).lerp(moon, sm(0, 0.7, k)), id: 1 };
    }
    if (T < 41) {           // C: behind the residents on the pier, the skiff coming in out of the sunrise
      const k = (T - 23) / 18;
      const at = V(-82, 1.4, -133).lerp(B.clone().setY(1.2), 0.35 + 0.3 * k);
      return { pos: V(-59.6 - k * 1.2, 4.7 - k * 0.5, -116.6 - k * 0.6), at, id: 2 };
    }
    if (T < 55.5) {         // D: aboard, looking down over the pier end onto the deck
      const k = (T - 41) / 14.5;
      return { pos: V(-64.6 + k * 0.6, 5.5 - k * 0.3, -117.4), at: V(-73.6, 0.8, -124.6), id: 3 };
    }
    if (T < 66) {           // E1: following them out
      const pos = B.clone().addScaledVector(fwd, -11).add(V(0, 4.8, 0)).add(V(fwd.z, 0, -fwd.x).multiplyScalar(3));
      return { pos, at: B.clone().addScaledVector(fwd, 8).add(V(0, 1.2, 0)), id: 4 };
    }
    if (T < 75) {           // E2: abeam of the boat, Lantern Isle behind: the lamp, and the answer
      const toIsle = LIGHTHOUSE.clone().sub(B).setY(0).normalize();
      const pos = B.clone().addScaledVector(toIsle, -12).add(V(0, 3.2, 0)).addScaledVector(fwd, 2);
      return { pos, at: B.clone().lerp(LIGHTHOUSE, 0.08).add(V(0, 1.5, 0)), id: 5 };
    }
    if (T < 88) {           // F: from the stern, the city going small behind
      const pos = boat.localToWorld(V(0, 2.1, -3.6));
      return { pos, at: boat.localToWorld(V(0, 3.4, -60)), id: 6 };
    }
    // G: the boat heading into the sun
    if (!this.final) { this.final = B.clone().addScaledVector(fwd, -26).add(V(0, 5.5, 0)); }
    return { pos: this.final, at: B.clone().add(V(0, 2.5, 0)).addScaledVector(fwd, 30), id: 7 };
  }

  // ---------------------------------------------------------------- the words
  words(T) {
    let want = -1;
    this.times.forEach((t, i) => { if (T >= t) want = i; });
    // each line stays up until the next one, or for seven seconds
    if (want >= 0 && T > this.times[want] + 7) want = -1;
    if (want !== this.shown) {
      this.lines.forEach((l, i) => l.classList.toggle('on', i === want));
      this.shown = want;
    }
    const box = $('#ending .end-text');
    this.msg.classList.toggle('on', T > 77 && T < 86.5);
    if (T > 89 && !this.credits) {
      box.classList.remove('film');
      this.lines.forEach(l => l.remove()); this.msg.remove();
      const cr = this.credits = el('div', 'credits', null, box);
      cr.innerHTML = '<h4>Rebound</h4>Game design and story · <b>made by NyxiePlaysGames</b><br>World, levels and artwork · <b>made by NyxiePlaysGames</b><br>Music and sound · <b>made by NyxiePlaysGames</b><br>Writing · <b>made by NyxiePlaysGames</b><br>Programming · <b>made by NyxiePlaysGames</b><br>Keanu · <b>himself, a very good boy</b><br>Milky · <b>a cameo, down in the Deep</b><br><br>Built with Three.js and the Web Audio API<br>Thank you for playing.';
      setTimeout(() => cr.classList.add('on'), 60);
    }
  }

  // ---------------------------------------------------------------- the lamps, and the sounds
  moments(T) {
    const g = this.g, W = g.world, f = this.flags, sk = W.skiff;
    // the lighthouse flashes twice; the skiff's lamp answers each time
    const pulse = (a) => T > a && T < a + 0.55;
    g.endingLamp = pulse(66.8) || pulse(68.8);
    const ans = pulse(67.7) || pulse(69.7);
    sk.light.intensity = ans ? 22 : 3;
    if (W.skiffLamp) W.skiffLamp.color.setRGB(0.39, 0.94, 0.89).multiplyScalar(ans ? 6 : 1.4);
    const once = (k, t, fn) => { if (T > t && !f[k]) { f[k] = true; fn(); } };
    once('radio', 15.4, () => g.sound.recording());
    once('beep', 39.3, () => { g.sound.talk(440, 'square'); setTimeout(() => g.sound.talk(520, 'square'), 160); });
    once('flash1', 66.8, () => g.sound.click());
    once('flash2', 68.8, () => g.sound.click());
  }

  update(T, dt) {
    const g = this.g, boat = this.boat(T);
    this.people(T, boat, dt);
    this.moments(T);
    this.words(T);
    const s = this.shot(T, boat);
    // a quick dip to black between shots
    if (s.id !== this.cut) {
      if (this.cut >= 0) {
        const fd = $('#fade'); fd.style.transition = 'none'; fd.style.background = '#000'; fd.style.opacity = 1;
        void fd.offsetWidth; fd.style.transition = 'opacity 0.7s ease'; fd.style.opacity = 0;
      }
      this.cut = s.id;
    }
    g.camera.position.copy(s.pos);
    g.camera.lookAt(s.at);
    g.camera.updateMatrixWorld();
    // shadows and the light pool follow what the camera is looking at
    const b = g.body; b.x = s.at.x * 0.2 + s.pos.x * 0.8; b.y = s.pos.y; b.z = s.at.z * 0.2 + s.pos.z * 0.8;
  }

  // the world goes back to how it is any other morning
  finish() {
    const W = this.g.world;
    W.cutscene = false;
    this.g.endingLamp = false;
    for (const id in W.people) {
      const p = W.people[id]; if (p.robot) continue;
      if (p.dog) { p.loop = -1; p.dogs.stand.group.visible = false; p.dogs.lie.group.visible = true; continue; }
      p.group.position.set(p.x, p.y, p.z); p.group.rotation.y = p.baseYaw;
      p.px = p.x; p.pz = p.z; p.queue = []; p.seg = null; p.loopSeen = -1;
      if (p.line) p.line.visible = true;
    }
    const sk = W.skiff; sk.at = 'pier'; sk.moving = null;
    sk.group.position.set(DOCK.x, 0, DOCK.z); sk.group.rotation.set(0, DOCK_YAW, 0);
    sk.light.intensity = 3; sk.wake.material.uniforms.amt.value = 0;
    const box = $('#ending .end-text'); box.classList.remove('film'); box.innerHTML = '';
    if (this.skipHint) this.skipHint.remove();
  }
}

function lerpAngle(a, b, t) { const d = ((b - a + Math.PI * 3) % (Math.PI * 2)) - Math.PI; return a + d * t; }
