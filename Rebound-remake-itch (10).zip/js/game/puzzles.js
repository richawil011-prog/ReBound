// What happens when you press E on something. Each handler gets the game.
import { entries, npcs, CIVIC_CODE, HATCH_CODE, LANTERN_ORDER, RELEASE_WORD, CARRIER, EVAC, TIMES } from './story.js';
import { el } from '../ui/ui.js';
import { relayLive, gridDown, runPassable } from './events.js';
import { DOCKS } from '../world/isles.js';

const KIND_LABEL = { Recording: 'Recording · cylinder', Radio: 'Receiver', Machine: 'Machine', Procedure: 'Procedure', Schedule: 'Notice', Manifest: 'Manifest', Credential: 'Ledger', Observation: 'Observation', Person: 'Person', Place: 'Place', Solution: 'Solved', Letter: 'Letter' };

// read an entry in the world: learn it and show it
export function read(g, id, o = {}) {
  const e = entries[id];
  g.learn(id);
  let voice = null;
  if (e[1] === 'Letter') g.sound.page();
  if (e[1] === 'Recording') {
    g.sound.recording();
    // your own voice is a little lower and steadier than the others'
    const own = /Your (own )?voice/.test(e[3]);
    voice = g.sound.murmur(e[3].length * 0.055, { pitch: own ? 0.95 : 0.85 + Math.random() * 0.3 });
  }
  g.ui.doc(o.kicker || KIND_LABEL[e[1]] || e[1], e[2], e[3], { paper: o.paper, note: o.note, buttons: o.buttons, onClose: voice ? () => voice.stop() : null });
}

function keypad(g, kicker, title, text, answer, onOK) {
  let entry = '';
  g.ui.openPanel(p => {
    g.ui.head(p, kicker, title);
    const wrap = el('div', 'keypad', null, p);
    const left = el('div', null, null, wrap);
    el('div', 'body', text, left);
    const ro = el('div', 'readout', null, left);
    const cells = [0, 1, 2, 3].map(() => el('span', null, '·', ro));
    const keys = el('div', 'keys', null, wrap);
    const draw = () => cells.forEach((c, i) => c.textContent = entry[i] ?? '·');
    const press = (k) => {
      if (k === 'clr') { entry = ''; ro.className = 'readout'; draw(); g.sound.back(); return; }
      if (entry.length >= 4) return;
      entry += k; g.sound.key(+k); draw();
      if (entry.length === 4) {
        if (entry === answer) { ro.className = 'readout ok'; g.sound.accept(); setTimeout(() => { g.ui.closePanel(); onOK(); }, 650); }
        else { ro.className = 'readout bad'; g.sound.deny(); setTimeout(() => { entry = ''; ro.className = 'readout'; draw(); }, 700); }
      }
    };
    for (const k of ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clr', '0', 'esc']) {
      const b = el('button', k.length > 1 ? 'fn' : '', k === 'clr' ? 'CLEAR' : k === 'esc' ? 'LEAVE' : k, keys);
      b.addEventListener('click', (ev) => { ev.stopPropagation(); if (k === 'esc') g.ui.closePanel(); else press(k); });
    }
    g.ui.keyHandler = (ev) => {
      if (/^[0-9]$/.test(ev.key)) press(ev.key);
      else if (ev.key === 'Backspace') press('clr');
    };
  }, { onClose: () => { g.ui.keyHandler = null; } });
}

export const handlers = {
  // ---------------- station ----------------
  identity: g => read(g, 'identity', { paper: true }),
  directory: g => {
    g.observe('station');
    g.ui.doc('Directory', 'Halcyon Station', 'Engine Hall, centre.\nBerths, north. Radio, north-east. Observer lift, south-east.\nAirlock and Sky Bridge, south. Gallery, south-west.\nArchive, north-west. (Sealed by order of the operator.)', { paper: true });
  },
  schedule: g => { g.learn('tide', { quiet: true }); g.learn('span', { quiet: true }); read(g, 'schedule', { paper: true }); },
  tally: g => read(g, 'tally'),
  cellA: g => read(g, 'cellA'),
  cellB: g => read(g, 'cellB'),
  gallery: g => {
    const e = g.st.elapsed;
    if (e >= TIMES.sunStart - 5 && e <= TIMES.sunEnd + 5) {
      g.learn('sun');
      g.ui.doc('Observation', 'Light on the gallery floor', 'The low sun reaches through the slit and lays a bar of light across the floor. Inside the four stencilled frames, digits appear where the light falls: 5 9 0 2.');
    } else {
      g.markLead('hatch');
      g.ui.doc('Observation', 'Four empty frames', 'Four square frames are stencilled on the floor in a line, pointing at the narrow slit in the wall. They are empty. They look like they are waiting for something to be put in them.' + (g.st.found.has('schedule') || g.st.loop > 1 ? '' : ''), { note: e < TIMES.sunStart ? 'The slit faces the setting sun.' : 'The sun has moved on.' });
    }
  },
  hatch: g => {
    if (g.st.solved.hatch) return g.ui.doc('Archive hatch', 'The hatch stands open', 'The relay keeps it unlocked now.');
    g.markLead('hatch');
    keypad(g, 'Archive hatch', 'Four digits', 'A keypad beside the hatch. The display reads: OPERATOR CODE.', HATCH_CODE, () => {
      g.st.solved.hatch = true; g.sound.door(false); g.learn('hatch'); g.save();
    });
  },
  engine: g => {
    const st = g.st;
    const peel = st.found.has('imprints') && !st.found.has('imprintsTruth');
    if (peel) {
      g.learn('imprintsTruth');
      g.sound.discover(true);
      g.ui.doc('The Rebound Engine', 'Under the tape', entries.imprintsTruth[3], { buttons: [] });
      return;
    }
    const first = !st.found.has('engine');
    g.learn('engine');
    const buttons = [];
    if (!first && !st.ended) buttons.push(['Rehearse: end this cycle now', () => { g.ui.closePanel(); g.rehearse('engine'); }, 'warn']);
    g.ui.doc('Machine', 'The Rebound Engine', entries.engine[3] + (st.found.has('imprintsTruth') ? '\n\nThe dial under the tape still reads six.' : ''), { buttons, note: first ? 'You could rehearse here: end the cycle early and wake again. The Engine will let you, next time you ask.' : '' });
  },
  radio: g => radioPanel(g),
  liftStation: g => lift(g, 'station'),
  liftDeep: g => lift(g, 'deep'),

  // ---------------- city ----------------
  memorial: g => read(g, 'memorial'),
  cityLog: g => { g.learn('relay', { quiet: true }); g.markLead('vault'); g.markLead('radio'); read(g, 'cityLog'); },
  tarnMap: g => { g.markLead('tarn'); read(g, 'tarnMap', { paper: true }); },
  tags: g => read(g, 'tags'),
  vault: g => lanternLock(g),
  cylinder: g => {
    if (g.st.solved.cylinder) return g.ui.doc('Vault', 'An empty cradle', 'You already carry the operator cylinder. The relay keeps it with you, cycle after cycle.');
    g.st.solved.cylinder = true;
    g.markLead('release');
    read(g, 'vault', { kicker: 'Recording · operator cylinder' });
    g.save();
  },
  serviceGate: g => {
    if (g.st.elapsed >= TIMES.span || g.st.ended) { g.observe('serviceWalk'); return g.ui.doc('Service gate', 'The gate is open', 'Stone steps lead down to the old quay.'); }
    g.markLead('gate');
    g.sound.deny();
    g.ui.doc('Service gate', 'Chained', 'An iron gate in a stone frame, chained shut. The plate on the chain reads: RELEASES WITH THE SPAN.');
  },
  code: g => { g.markLead('door'); read(g, 'code', { paper: true }); },
  serviceGate2: g => handlers.serviceGate(g),
  tarnStone: g => read(g, 'tarnStone'),
  pierBoard: g => { g.markLead('imprints'); read(g, 'pierBoard', { paper: true }); },

  // ---------------- isles ----------------
  keeperLog: g => { g.markLead('beacon'); read(g, 'keeperLog'); },
  beacon: g => beaconPanel(g),
  gardenLog: g => read(g, 'gardenLog'),
  telescope: g => {
    g.learn('sister');
    g.ui.doc('Gallery telescope', 'Beside the Sister', 'You find the crescent moon, then the bright point beside it. Held still in the eyepiece, it is not a point at all but a ring of tiny lights, turning very slowly. Ships. Holding position, as if waiting for something below to finish.');
  },
  pebble: g => {
    if (g.cycle.pebble) return g.ui.doc('Lantern Isle', 'A pebble', 'You already have one in your pocket. It is smooth and still warm from the lamp.');
    g.cycle.pebble = true;
    g.sound.click();
    g.ui.doc('Lantern Isle', 'A pebble', 'You pick a smooth grey pebble from the cairn and put it in your pocket. It smells faintly of lamp oil.', { note: 'Things you carry do not survive the rebound.' });
  },
  seedbed: g => read(g, 'seedbed'),

  // ---------------- deep ----------------
  tideDoor: g => {
    if (g.st.solved.code) return g.ui.doc('Tidal lock', 'Override accepted', 'The lock is open. Beyond it, the run is ' + (runPassable(g.st.elapsed, g.st) ? 'dry enough to cross.' : 'full of water.'));
    g.markLead('door');
    keypad(g, 'Tidal lock', 'Civic override', 'A heavy keypad under a hinged cover. The display reads: CIVIC OVERRIDE REQUIRED.', CIVIC_CODE, () => {
      g.st.solved.code = true; g.sound.door(true); g.learn('unlocked'); g.learn('tide', { quiet: true }); g.save();
    });
  },
  pump: g => {
    if (g.st.solved.pump) return g.ui.doc('Bypass pump', 'Latched', 'The latch is down and the relay will keep it down. The run stays dry and the lift will run.');
    g.st.solved.pump = true;
    g.sound.door(true);
    g.shake(0.6, 1.2);
    g.learn('pump');
    g.save();
    g.ui.doc('Bypass pump', 'You throw the latch', 'The wheel turns, then the latch drops into place with a sound you feel in your teeth. Far behind you, the run begins to empty and does not refill. A lamp by the lift turns from red to green.');
  },
  protocol: g => { g.markLead('release'); read(g, 'protocol', { paper: true }); },
  deepLog: g => read(g, 'deepLog'),
  echo: g => {
    const st = g.st, s = st.solved;
    const buttons = [];
    let text;
    if (s.echoLoop == null) {
      s.echoLoop = st.loop;
      g.learn('echo');
      g.markLead('bulkhead');
      g.save();
      g.sound.tone(440, 1.5, { type: 'sine', gain: 0.05, wet: 0.6 });
      text = 'You press RECORD. The reels turn once and stop. A label prints itself: REFERENCE · CYCLE ' + st.loop + '.\n\nThe bulkhead will want to hear this moment again, from the other side of a rebound.';
    } else if (s.echoLoop === st.loop) {
      text = 'The reel holds a reference from this cycle. The bulkhead needs the same moment from a different one.';
    } else {
      text = 'The reel holds a reference from cycle ' + s.echoLoop + '. The bulkhead can compare it now.';
    }
    if (!st.ended) buttons.push(['Rehearse: end this cycle now', () => { g.ui.closePanel(); g.rehearse('echo'); }, 'warn']);
    g.ui.doc('Echo recorder', 'Reference tape', text, { buttons });
  },
  bulkhead: g => {
    const s = g.st.solved;
    if (s.bulkhead) return g.ui.doc('Bulkhead', 'Open', 'The bulkhead stands open. The counter still says 4,812.');
    g.markLead('bulkhead');
    if (s.echoLoop != null && g.st.loop > s.echoLoop) {
      s.bulkhead = true;
      g.sound.accept(); g.sound.door(true); g.shake(0.4, 2);
      g.learn('bulkhead');
      g.save();
      g.ui.doc('Bulkhead tester', 'Match', 'REFERENCE CYCLE ' + s.echoLoop + ' · PRESENT CYCLE ' + g.st.loop + '\nEVENT MATCH: 100%\n\nThe two moments line up exactly, and the bulkhead rolls aside.');
    } else if (s.echoLoop === g.st.loop) {
      g.sound.deny();
      g.ui.doc('Bulkhead tester', 'Same cycle', 'REFERENCE CYCLE ' + s.echoLoop + ' · PRESENT CYCLE ' + g.st.loop + '\n\nThe tester cannot compare a moment with itself. It needs the reference from a cycle that has already ended.');
    } else {
      g.sound.deny();
      g.ui.doc('Bulkhead tester', 'No reference', 'COMPARE: NO REFERENCE ON REEL\n\nThe tester wants an echo, recorded in an earlier cycle, to compare with this one.');
    }
  },
  coreLook: g => { g.learn('coreLook'); read(g, 'revelation', { kicker: 'Recording · wired into the rail' }); },
  release: g => releasePanel(g),

  // ---------------- the skiff ----------------
  skiff_pier: g => skiffPanel(g, 'pier'),
  skiff_isle: g => skiffPanel(g, 'isle'),
  skiff_rise: g => skiffPanel(g, 'rise'),
  skiff_tarn: g => skiffPanel(g, 'tarn'),
  wrenTag: g => read(g, 'wrenTag'),
  wrenNote: g => read(g, 'wrenNote'),
  lastHand: g => read(g, 'lastHand'),
  tarnClock: g => read(g, 'tarnClock'),
  letterPell: g => read(g, 'letterPell', { paper: true }),
  letterJuniper: g => read(g, 'letterJuniper', { paper: true }),
  letterSef: g => read(g, 'letterSef', { paper: true }),
  letterKeeper: g => read(g, 'letterKeeper', { paper: true }),
  letterGardener: g => read(g, 'letterGardener', { paper: true }),
  letterPilot: g => read(g, 'letterPilot', { paper: true })
};
for (const id of Object.keys(npcs)) handlers[id] = g => g.talk(id);
handlers.npcKeanu = g => g.talk('npcKeanu');
// two more little books, for two more ways of talking
const learnBook = (g, key, title, body, toast) => {
  g.ui.doc('Book', title, body, { paper: true });
  const s = (g.st.solved ||= {});
  if (!s[key]) { s[key] = true; g.save(); g.ui.toast(title, toast); }
};
handlers.robotBook = g => learnBook(g, 'speakRobot', 'How to Speak Robot', 'A slim manual from the skiff yard, with somebody\u2019s notes in the margins.\n\nOne beep: yes. Two beeps: no. A long beep: I have been waiting.\nA count read aloud is never only a count.\nIf a pilot unit says something is not a problem, ask it twice.\n\nOn the inside cover: \u201cLuka (LK-4) talks more than it lets on. Be patient.\u201d', 'You can understand Luka properly now');
handlers.fishBook = g => learnBook(g, 'speakFish', 'How to Speak Fish', 'A waterlogged pamphlet. Most of the words are vowels.\n\n\u201cBlub\u201d \u2014 hello.\n\u201cBlub blub\u201d \u2014 go away.\n\u201cBlub\u2026\u201d \u2014 there is something I have been meaning to tell you.\n\nPencilled at the bottom: \u201cFor Dad \u2014 for Charley. Since you never listen to me, maybe you\u2019ll listen to them.\u201d', 'You can understand the fish now');
handlers.npcFishWater = g => { const s = (g.st.solved ||= {}); if (s.speakFish && !s.fishHeard) { s.fishHeard = true; g.save(); } return g.talkThing('npcFishWater', 'The water', 'Off the end of the pier', s.speakFish
  ? ['Blub\u2026', 'Tell Charley there is no fish in this channel with a score to settle. There never was.', 'He can stop waiting. He can go home. We will keep the water.']
  : ['Blub.'], 90, 'sine'); };
// Skye's awning: tie the loose strip down (it comes loose again every cycle)
handlers.awning = g => {
  if (!g.world.awning || g.world.awning.fixed) return;
  g.world.awning.fixed = true; g.cycle.awning = true;
  g.sound.click();
  g.ui.subtitle('You pull the loose corner of the awning tight and knot the cord round the post.', 4);
};
// one of Christian's tomatoes, for somebody who might want it
handlers.tomato = g => {
  if (g.cycle.tomato) return g.ui.doc('Verdant Rise', 'A tomato', 'You already have one. He really does have too many, though.');
  g.cycle.tomato = true;
  g.ui.doc('Verdant Rise', 'A tomato', 'You pick a ripe tomato from the back row. Christian won\u2019t miss it; there are hundreds.', { note: 'Things you carry do not survive the rebound.' });
};
// the kettle on the berths desk: a cup of tea for whoever is on the rota
handlers.kettle = g => {
  if (g.cycle.tea) return g.ui.doc('Berths', 'A cup of tea', 'You already have one. It is getting colder.');
  g.cycle.tea = true;
  g.ui.doc('Berths', 'A cup of tea', 'You boil the kettle and make a cup of tea in the spare mug. Strong, no sugar. Somebody on the rota hasn\u2019t had one in a very long time.', { note: 'Things you carry do not survive the rebound.' });
};
// Milky, the explorer at the bottom of the Deep stairs: a proper hello once a cycle, then whatever's on their mind
handlers.npcExplorer = g => {
  const s = (g.st.solved ||= {}), c = g.cycle;
  let lines;
  if (!c.explorer) {
    c.explorer = 1;
    lines = s.metExplorer
      ? ['Oh! Hello. I\u2019m Milky. Have we met? My map says we haven\u2019t. My map\u2019s never wrong.', '\u2026Is it?', 'Mind the string. It\u2019s how I find my way back up.']
      : ['Oh! Hello. Mind the string, it\u2019s how I find my way back up.', 'I\u2019m Milky. I\u2019m an explorer.', 'I\u2019m mapping everything under the plaza. Every turn, every step. The string is for when the map runs out.', 'That door won\u2019t open for me. It wants some kind of override. I\u2019ve drawn it four times now.', 'If you get through, come back and tell me what\u2019s on the other side. I\u2019ll put it on the map.'];
  } else {
    const more = [
      ['Forty-one steps down from the plaza. I counted twice. Then I counted my tail, by accident.'],
      ['The gauge says the water\u2019s low between six and twelve. I keep meaning to go then. Then I keep drawing the gauge instead.'],
      ['Can you hear that? Like the whole basin breathing in.', '\u2026No? Just my ears, then. They hear everything.'],
      ['I\u2019ve run out of string twice. I tie the new ball to the old one. It\u2019s a very long map.'],
      g.st.found.has('deepLog') || g.st.found.has('protocol') ? ['You got through! What\u2019s down there?', '\u2026A laboratory? Under the sea? I need a bigger notebook.'] : ['Still here. Still drawing the door.']
    ];
    lines = more[(c.explorer++ - 1) % more.length];
  }
  if (!s.metExplorer) { s.metExplorer = true; g.save(); }
  return g.talkThing('npcExplorer', 'Milky', 'Explorer, mapping the Deep', lines, 360, 'triangle');
};
// Keanu's ball: pick it up, and his label turns into a throw
handlers.keanuBall = g => {
  const K = g.world.people.npcKeanu, b = K && K.ball;
  if (!b || (b.state !== 'floor' && b.state !== 'landed')) return;
  b.state = 'held'; b.mesh.visible = false;
  if (!g.st.hints.ball) { g.st.hints.ball = true; g.save(); g.ui.toast('Keanu\u2019s ball', 'Chewed, a bit damp. He\u2019d like you to throw it'); }
};
// a pocket guide left on the radio desk; reading it once is enough, every cycle after
handlers.dogBook = g => {
  g.ui.doc('Book', 'How to Speak Dog', 'A pocket guide, much thumbed. Someone has underlined nearly all of it.\n\n\u201cRuff\u201d \u2014 hello.\n\u201cRuf\u201d \u2014 hello again, in case you missed the first one.\n\u201cRrrrr\u2026\u201d \u2014 a long story. Sit down for it.\n\nOn the last page, in pencil: \u201cHe has been trying to tell you something this whole time.\u201d', { paper: true });
  const s = (g.st.solved ||= {});
  if (!s.speakDog) { s.speakDog = true; g.save(); g.ui.toast('How to Speak Dog', 'You can understand Keanu now'); }
};

// ---------------------------------------------------------------- panels

function lanternLock(g) {
  if (g.st.solved.vault) return g.ui.doc('Lantern lock', 'The vault stands open', 'The four lanterns are dark. You already answered them.');
  g.markLead('vault');
  let seq = [];
  g.ui.openPanel(p => {
    g.ui.head(p, 'Civic Archive · vault', 'Four lanterns');
    el('div', 'body', 'A brass plate with four little lanterns set into it, numbered like the arches. Press them in order.', p);
    const row = el('div', 'lanterns', null, p);
    const msg = el('div', 'seq', '', p);
    const buttons = [];
    for (let i = 1; i <= 4; i++) {
      const b = el('button', null, null, row);
      el('i', null, null, b); el('span', null, ['I', 'II', 'III', 'IV'][i - 1], b);
      buttons.push(b);
      b.addEventListener('click', (ev) => {
        ev.stopPropagation();
        if (seq.length >= 4) return;
        seq.push(i); b.classList.add('lit'); g.sound.lantern(i);
        msg.textContent = seq.map(n => ['I', 'II', 'III', 'IV'][n - 1]).join('  ·  ');
        if (seq.length === 4) {
          if (seq.join() === LANTERN_ORDER.join()) {
            setTimeout(() => {
              g.sound.accept(); g.st.solved.vault = true; g.sound.door(true); g.save();
              g.ui.closePanel(); g.ui.toast('Vault', 'The vault door rolls aside.');
            }, 700);
          } else {
            setTimeout(() => { g.sound.deny(); seq = []; buttons.forEach(x => x.classList.remove('lit')); msg.textContent = 'The lanterns go dark.'; }, 600);
          }
        }
      });
    }
    const r = el('div', 'row', null, p);
    g.ui.btn(r, 'Leave', () => g.ui.closePanel());
  });
}

function radioPanel(g) {
  g.observe('station');
  let freq = g.radioFreq || 96.0;
  let raf = 0, typing = 0, voice = null;
  const e = g.st.elapsed;
  g.ui.openPanel(p => {
    g.ui.head(p, 'Radio room', 'Field receiver');
    const face = el('div', 'radio-face', null, p);
    const fr = el('div', 'radio-freq', null, face);
    const scale = el('div', 'radio-scale', null, face);
    const needle = el('div', 'radio-needle', null, scale);
    const labels = el('div', 'radio-labels', null, face);
    for (const n of [88, 92, 96, 100, 104, 108]) el('span', null, n, labels);
    const slider = el('input', null, null, face);
    Object.assign(slider, { type: 'range', min: 88, max: 108, step: 0.1, value: freq });
    slider.setAttribute('aria-label', 'Tuning');
    const cv = el('canvas', 'radio-wave', null, face); cv.width = 520; cv.height = 56;
    const txt = el('div', 'radio-text', '', face);
    el('p', 'note', 'Drag the dial or use the arrow keys. Some stations only speak at certain times.', p);
    const row = el('div', 'row', null, p);
    g.ui.btn(row, 'Leave', () => g.ui.closePanel());
    let current = null;
    const station = () => {
      if (Math.abs(freq - EVAC) < 0.15) return 'evac';
      if (Math.abs(freq - CARRIER) < 0.15) return relayLive(e) || g.st.ended ? 'carrier' : 'quiet';
      return null;
    };
    const say = (text) => {
      clearInterval(typing); txt.textContent = ''; let i = 0;
      typing = setInterval(() => { i += 2; txt.textContent = text.slice(0, i); if (i >= text.length) clearInterval(typing); }, 28);
    };
    const update = () => {
      fr.innerHTML = freq.toFixed(1) + '<small>MHz</small>';
      needle.style.left = ((freq - 88) / 20 * 100) + '%';
      const s = station();
      if (s !== current) {
        current = s;
        if (voice) { voice.stop(); voice = null; }
        if (s === 'evac') { g.learn('evac'); g.markLead('radio'); say(entries.evac[3]); voice = g.sound.murmur(9, { radio: true, pitch: 0.9, gain: 0.55 }); }
        else if (s === 'carrier') { g.learn('relay', { quiet: true }); g.learn('carrier'); g.sound.discover(true); say(entries.carrier[3]); voice = g.sound.murmur(12, { radio: true, pitch: 1.1, gain: 0.55 }); }
        else if (s === 'quiet') { g.learn('relay', { quiet: true }); say('Nothing on 107.3. Not static: silence, like somebody holding their breath. ' + (g.st.found.has('cityLog') ? 'Half past eighteen, the keeper said.' : '')); }
        else { clearInterval(typing); txt.textContent = ''; }
      }
      g.sound.tuneTick(s ? 1 : 0);
    };
    slider.addEventListener('input', () => { freq = parseFloat(slider.value); g.radioFreq = freq; update(); });
    update();
    g.sound.setLayer('static', 0.5, 0.2);
    const ctx = cv.getContext('2d');
    const draw = () => {
      raf = requestAnimationFrame(draw);
      ctx.clearRect(0, 0, cv.width, cv.height);
      ctx.strokeStyle = current ? '#7fe3da' : 'rgba(235,229,213,.5)'; ctx.lineWidth = 1.5; ctx.beginPath();
      const t = performance.now() / 1000;
      for (let x = 0; x < cv.width; x += 3) {
        const n = current === 'quiet' ? 0.02 : current ? Math.sin(x * 0.05 + t * 8) * 0.5 * Math.sin(x * 0.011 + t) : (Math.random() - 0.5) * 0.8;
        const y = cv.height / 2 + n * cv.height * 0.8;
        x ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.stroke();
    };
    draw();
    g.ui.keyHandler = (ev) => {
      if (ev.key === 'ArrowLeft' || ev.key === 'ArrowDown') { freq = Math.max(88, +(freq - 0.1).toFixed(1)); slider.value = freq; update(); }
      if (ev.key === 'ArrowRight' || ev.key === 'ArrowUp') { freq = Math.min(108, +(freq + 0.1).toFixed(1)); slider.value = freq; update(); }
    };
  }, { onClose: () => { cancelAnimationFrame(raf); clearInterval(typing); if (voice) voice.stop(); g.ui.keyHandler = null; g.sound.setLayer('static', 0, 0.2); } });
}

function beaconPanel(g) {
  g.ui.openPanel(p => {
    g.ui.head(p, 'Lantern Isle · lamp room base', 'Two switches');
    el('div', 'body', 'Two brass switches under a cracked enamel plate. The plate’s labels have worn off.' + (g.cycle.beacon ? '\n\nThe lamp is lit. Its beam turns above you.' : ''), p);
    const row = el('div', 'row', null, p);
    g.ui.btn(row, 'Left switch', () => {
      g.ui.closePanel();
      if (g.cycle.beacon) return;
      g.cycle.beacon = true; g.cycle.beaconAt = g.time;
      g.sound.door(false); g.sound.tone(110, 3, { type: 'sawtooth', filter: 400, gain: 0.05, attack: 1, wet: 0.5 });
      g.ui.subtitle('High above, the great lamp catches. Its beam starts to turn.', 5);
      g.later(7, () => { if (g.cycle.beacon) { g.ui.subtitle('Far out to the west, something blinks back. Once.', 6); g.learn('beacon'); } });
    });
    g.ui.btn(row, 'Right switch', () => {
      g.ui.closePanel(); g.sound.deny();
      g.ui.subtitle('A red warning lamp blinks in the lamp room. Nothing else happens.', 4);
    });
    g.ui.btn(row, 'Leave', () => g.ui.closePanel());
  });
}

function releasePanel(g) {
  const st = g.st;
  if (st.ended) return g.ui.doc('Release controls', 'Released', 'The controls are dark. There is nothing left to let go of.');
  g.markLead('release');
  const word = (g.cycle.word || 'AAAAA').split('');
  const seq = g.cycle.routing || (g.cycle.routing = []);
  g.ui.openPanel(p => {
    g.ui.head(p, 'The Core', 'Release controls');
    const w = el('div', 'release', null, p);
    // voiceprint
    const v = el('div', 'rel-row' + (g.cycle.voice ? ' ok' : ''), null, w);
    const vl = el('div', null, null, v); el('div', 'lbl', 'Voiceprint', vl);
    el('div', 'val', g.cycle.voice ? 'Operator: Iona Vale' : st.solved.cylinder ? 'Cylinder slot is empty' : 'The slot wants a recording cylinder', vl);
    if (!g.cycle.voice && st.solved.cylinder) g.ui.btn(v, 'Insert cylinder', () => { g.cycle.voice = true; g.sound.accept(); g.ui.closePanel(); releasePanel(g); }, 'primary');
    // word
    const r2 = el('div', 'rel-row' + (word.join('') === RELEASE_WORD ? ' ok' : ''), null, w);
    const wl = el('div', null, null, r2); el('div', 'lbl', 'Release word', wl);
    el('div', 'val', st.found.has('carrier') ? 'Heard on 107.3' : 'Carried on the live band', wl);
    const wd = el('div', 'word', null, r2);
    word.forEach((ch, i) => {
      const s = el('div', 'slot', null, wd);
      const up = el('button', null, '▲', s); const sp = el('span', null, ch, s); const dn = el('button', null, '▼', s);
      const set = (d) => { word[i] = String.fromCharCode((word[i].charCodeAt(0) - 65 + d + 26) % 26 + 65); sp.textContent = word[i]; g.cycle.word = word.join(''); g.sound.key(i); r2.classList.toggle('ok', word.join('') === RELEASE_WORD); };
      up.addEventListener('click', (e) => { e.stopPropagation(); set(1); });
      dn.addEventListener('click', (e) => { e.stopPropagation(); set(-1); });
    });
    // routing
    const r3 = el('div', 'rel-row', null, w);
    const rl = el('div', null, null, r3); el('div', 'lbl', 'Routing', rl);
    const rv = el('div', 'val', seq.length ? seq.join(' → ') : 'Three switches', rl);
    const sw = el('div', 'switches', null, r3);
    for (const name of ['Listen', 'Ground', 'Open']) {
      const b = el('button', seq.includes(name) ? 'done' : '', name, sw);
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        if (seq.includes(name)) return;
        if (name === 'Ground' && !seq.includes('Listen')) { g.ui.closePanel(); g.groundFirst(); return; }
        if (name === 'Open' && !(seq.includes('Listen') && seq.includes('Ground'))) { g.sound.deny(); rv.textContent = 'OPEN refuses: nothing is routed yet.'; return; }
        seq.push(name); b.classList.add('done'); g.sound.key(seq.length); rv.textContent = seq.join(' → ');
        if (seq.length === 3) tryRelease();
      });
    }
    const note = el('p', 'note', '', p);
    const tryRelease = () => {
      if (!g.cycle.voice) { note.textContent = 'The routing holds, but nothing answers without the operator’s voiceprint.'; g.sound.deny(); seq.length = 0; return setTimeout(() => { g.ui.closePanel(); releasePanel(g); }, 1400); }
      if (word.join('') !== RELEASE_WORD) { note.textContent = 'The routing holds, waiting for a word.'; g.sound.deny(); seq.length = 0; return setTimeout(() => { g.ui.closePanel(); releasePanel(g); }, 1400); }
      g.learn('phase');
      setTimeout(() => { g.ui.closePanel(); g.ending(); }, 900);
    };
    const row = el('div', 'row', null, p);
    g.ui.btn(row, 'Step back', () => g.ui.closePanel());
  }, { cls: 'wide' });
}

function skiffPanel(g, here) {
  const W = g.world, sk = W.skiff;
  if (sk.moving) return g.ui.doc('The skiff', 'On its way', 'The skiff is crossing the basin. It will be here soon.');
  if (sk.at !== here) {
    g.callSkiff(here);
    return;
  }
  g.learn('skiff');
  g.ui.openPanel(p => {
    g.ui.head(p, 'The skiff', 'Where to?');
    el('div', 'body', 'Luka’s plate glows: FERRY SERVICE SUSPENDED. OPERATOR VALE EXEMPT.', p);
    const c = el('div', 'choices', null, p);
    const tarnOK = g.st.found.has('tarnMap') || here === 'tarn';
    for (const k of ['pier', 'isle', 'rise', 'tarn']) {
      // Tarn is always on the list, so you know it's there; Luka only goes once you have the map
      const closed = k === 'tarn' && !tarnOK && !g.st.found.has('tarnRoofs');
      const b = el('button', 'choice', null, c);
      el('b', null, DOCKS[k].name, b);
      el('small', null, closed ? 'Closed to traffic \u00b7 Luka needs the basin map' : k === here ? 'You are here' : k === 'tarn' || here === 'tarn' ? 'The long way round' : 'About a minute', b);
      if (k === here || closed) b.disabled = true;
      b.addEventListener('click', (e) => { e.stopPropagation(); g.sound.click(); g.ui.closePanel(); g.rideSkiff(here, k); });
    }
    const row = el('div', 'row', null, p);
    g.ui.btn(row, 'Stay here', () => g.ui.closePanel());
  });
}

function lift(g, where) {
  const st = g.st;
  if (!st.solved.pump) { g.sound.deny(); return g.ui.doc('Observer lift', 'Isolated', 'The call button is dead. A tag hangs on the gate: LINE ISOLATED · BYPASS PUMP NOT LATCHED.'); }
  if (gridDown(st.elapsed) && !st.ended) { g.sound.deny(); return g.ui.doc('Observer lift', 'No power', 'The grid is down. The lift will not run again this cycle.'); }
  g.ui.openPanel(p => {
    g.ui.head(p, 'Observer lift', where === 'station' ? 'Down to the Deep' : 'Up to Halcyon Station');
    el('div', 'body', 'The cage is waiting. The ride is long, but shorter than the walk.', p);
    const row = el('div', 'row', null, p);
    g.ui.btn(row, 'Ride the lift', () => { g.ui.closePanel(); g.rideLift(where); }, 'primary');
    g.ui.btn(row, 'Stay', () => g.ui.closePanel());
  });
}
