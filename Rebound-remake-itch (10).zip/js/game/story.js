// Everything the player can learn. Lore carried over from the earlier builds, re-set in the new
// world and grouped into the five questions the game is built around.

export const LOOP_SECONDS = 22 * 60;

// elapsed-time schedule in seconds
export const TIMES = {
  lanternA: 180,   // 03:00 civic lanterns flare
  lanternB: 200,   // 03:20 and again
  drain: 360,      // 06:00 intake drains
  sunStart: 480,   // 08:00 light reaches the gallery floor
  sunEnd: 600,     // 10:00
  surge: 720,      // 12:00 intake surges
  towerA: 810,     // 13:30 west tower falls
  span: 900,       // 15:00 transit span fails, service gate releases
  towerB: 990,     // 16:30 east tower falls
  relay: 1110,     // 18:30 orbital relay powers
  warning: 1140,   // 19:00 pressure warning
  power: 1200,     // 20:00 station grid fails
  tremor: 1260,    // 21:00 final tremors
  collapse: 1280   // 21:20 the basin begins to go
};

export const CIVIC_CODE = '0417';
export const HATCH_CODE = '5902';
export const LANTERN_ORDER = [3, 1, 4, 2];
export const RELEASE_WORD = 'STILL';
export const CARRIER = 107.3;
export const EVAC = 91.8;

export function lanternAt(elapsed) {
  for (const start of [TIMES.lanternA, TIMES.lanternB]) {
    const t = elapsed - start;
    if (t < 0 || t >= LANTERN_ORDER.length * 2.6) continue;
    const slot = Math.floor(t / 2.6);
    if (t - slot * 2.6 < 1.9) return LANTERN_ORDER[slot];
  }
  return 0;
}

export const THREADS = {
  vale: { title: 'Who is Iona Vale?', hint: 'The berth says the name is yours.' },
  engine: { title: 'What is the Rebound Engine?', hint: 'It breathes behind the wall of the station.' },
  exodus: { title: 'Where did everyone go?', hint: 'The city is empty, but not abandoned in a hurry.' },
  tarn: { title: 'What happened to Tarn Quarter?', hint: 'A district the maps still draw, under the water.' },
  residents: { title: 'Why are some people still here?', hint: 'Six people never got on the boats.' },
  world: { title: 'The basin’s schedule', hint: 'Everything happens at the same minute, every time.' },
  letters: { title: 'Who wrote to the ones who stayed?', hint: 'The six who stayed knew they would forget. Not all of them left it at that.' },
  places: { title: 'Places', hint: '' }
};

const nth = ['first', 'second', 'third', 'fourth'];

// id: [thread, kind, title, text]
export const entries = {
  // ---- places
  station: ['places', 'Place', 'Halcyon Station', 'A round habitat on a mast above the basin. Berths to the north, the radio room, an observer lift, the airlock to the Sky Bridge, a gallery facing the sunset, and an archive that has been sealed from the inside. The Rebound Engine turns in the domed hall at the centre.'],
  city: ['places', 'Place', 'The Hollow City', 'The Sky Bridge lands on the Upper Terrace beside a bell tower whose clock has twenty-two hours. Below it the Concourse runs south under four transit arches to the span and South Plaza. The Civic Archive stands on the east side, Vale Court on the west, and stairs lead down to the Market Pier.'],
  deep: ['places', 'Place', 'The Deep', 'The tidal intake under South Plaza. An antechamber, a lock, a low-water run that floods with the tide, and a laboratory at the far end with an observer lift back to the station.'],
  core: ['places', 'Place', 'The Core', 'A pressure ring under the sea. The light that stands over the basin comes from here: a sphere held in a brass cradle above a pit, and a set of release controls facing it.'],
  isle: ['places', 'Place', 'Lantern Isle', 'A keeper’s rock west of the Market Pier, reached by the skiff. A lighthouse, a hut, three garden beds.'],
  rise: ['places', 'Place', 'Verdant Rise', 'A glasshouse on piles south-west of the city. Whoever tended it left the grow lights on.'],
  tarnRoofs: ['places', 'Place', 'The Tarn Rooftops', 'What is left of Tarn Quarter above the water: three roofs joined by planks somebody laid and relaid, a hut of scavenged boards, and the district\u2019s bell tower leaning out of the sea.'],
  serviceWalk: ['places', 'Place', 'The Service Walk', 'Behind the iron gate on the Concourse, old stone steps lead down to a quay older than the city, a shelter cut into the cliff, and a low footbridge across the channel.'],

  // ---- Iona Vale
  identity: ['vale', 'Manifest', 'Berth 01', 'Operator Iona Vale. Intake note: “Autobiographical recall may lag behind procedural recall. Leave the name on the berth where I can see it.” The entry is in your handwriting. Beneath it, in a different pen: “Don’t trust the count.”'],
  tally: ['vale', 'Observation', 'The marks on the archive wall', 'Thousands of tally marks in groups of five, wall to wall, the early ones neat, the late ones barely lines. Under them, in red: “don’t trust the count.” You know the handwriting before you know why.'],
  cellA: ['vale', 'Recording', 'Rehearsal log · early', '“Rehearsal six. The engine works exactly as specified. It restores the basin to the snapshot and leaves me alone with what I remember. Tarn Quarter is already under the water in the snapshot. I can fix that. I only need more tries.”'],
  cellB: ['vale', 'Recording', 'Rehearsal log · late', '“I stopped counting somewhere past a thousand. I started naming the lanterns instead; it is easier to be a person who names lanterns. I have set the relay to forget me when the old count fills, so I can try again without knowing how many times I failed.”'],
  vault: ['vale', 'Recording', 'Operator cylinder', 'Your own voice, younger and steadier: “This cylinder holds my voiceprint. The release controls will only answer to it. If I ever hand the release to someone who isn’t me, I want it to be on purpose.” You take the cylinder with you. The relay will remember that you did.'],
  wrenTag: ['vale', 'Observation', 'A tag on a nail', 'An evacuation tag, the same kind as the ones in Vale Court: W. VALE \u00b7 TARN QUARTER \u00b7 AGE 9. Stamped across it in red: NOT COLLECTED.'],
  wrenNote: ['vale', 'Observation', 'Chalk on the hut wall', 'A child\u2019s drawing: a lighthouse, the sea, a tall woman holding a lamp and a small boy holding her other hand. Underneath, in careful capitals: IONA SAYS STAY ON THE ROOF. IONA COMES BACK.'],
  lastHand: ['vale', 'Recording', 'The hand in the dark', 'Your voice, very tired: \u201cWren. I had his hand on this roof and the water came up under it. I built the Engine to take us back to the minute before. It has never once gone back far enough. The snapshot starts when the berth light comes on, and by then he is already gone. I keep coming back here anyway. I keep the lamp ready, in case.\u201d'],
  revelation: ['vale', 'Recording', 'Last field recording', 'Your own voice, at the Core: “The basin had already lost its lowest districts when I stored the snapshot. I thought if I kept trying, I could remember them out of the water. Instead I kept everyone else from leaving. If I forget again: let the damaged world be the one that continues.”'],

  // ---- the Engine
  engine: ['engine', 'Machine', 'The Rebound Engine', 'At failure the apparatus restores a saved physical state of the basin. The observer’s memory is kept outside that state. A controlled rehearsal can trigger the same reset early. A counter on the plinth has been taped over: DO NOT READ.'],
  power: ['engine', 'Observation', 'Grid failure', 'At 20:00 the station grid fails. The observer lift stops, and every light in the basin stutters.'],
  final: ['engine', 'Observation', 'Final tremors', 'From 21:00 the structure never stops shaking. A little after, the basin starts to come apart, and at 22:00 the Engine lets go.'],
  deepLog: ['engine', 'Recording', 'Intake technician', '“They told us the Engine would only pause the basin. By the fourth rehearsal we noticed the pump logs matched to the digit. Nobody says it, but the ones who left are the lucky ones. If you ever work the release, listen before you ground. I watched a man ground first. The lab was white for a week.”'],
  protocol: ['engine', 'Procedure', 'Release routing · Listen, Ground, Open', 'Listen to establish reference. Ground the echo across both snapshots. Open the discharge into the unoccupied upper atmosphere. Never ground before you listen. The release controls answer only to the operator’s voiceprint and a release word carried on the live band.'],
  echo: ['engine', 'Machine', 'First reference saved', 'The echo recorder keeps one moment on tape across a reset. The bulkhead to the Core compares that tape against the same moment in a later cycle. Come back after the next rebound.'],
  bulkhead: ['engine', 'Solution', 'Core route released', 'Two snapshots now resolve to a single event, and the bulkhead lets go. A counter beside it reads 4,812 rehearsals. Your journal says you have lived through very few of them.'],
  coreLook: ['engine', 'Observation', 'The Core', 'The light in the cradle is warm on your face and makes no sound at all. Every surface in the chamber faces it. The beam it throws goes straight up through the sea and into the crack in the sky.'],

  // ---- the evacuation
  evac: ['exodus', 'Radio', '91.8 MHz · Authority loop', 'A recorded voice, patient and tired: “Level three. Tarn Quarter is closed to traffic. Remaining personnel, proceed to the lift. The Authority thanks you for your service.” It repeats exactly, down to the breath.'],
  relay: ['exodus', 'Schedule', 'Relay window', 'The remote transmitter on 107.3 powers at 18:30. Before then the band is quiet. Something is listening.'],
  carrier: ['exodus', 'Radio', '107.3 MHz · the release word', '“Iona? The evacuation reached orbit before the basin failed. Your instrument keeps putting us back in the same twenty-two minutes. If you hear this, release on STILL. We’ll be listening on the other side.”'],
  memorial: ['exodus', 'Observation', 'The Reaching', 'Two bronze hands that do not quite meet. The plaque: “To those who went ahead, and to those who stayed to see them off.” The last thing you remember is reaching for a hand in the dark.'],
  keeperLog: ['exodus', 'Recording', 'Aiden, the lamp keeper', '“Aiden here. Day four hundred and something. I light the lamp when the basin is quiet and put it out when it is not. If you are Iona: it is the left switch. It was always the left switch. Somebody out there answers it.”'],
  beacon: ['exodus', 'Observation', 'Somebody answers', 'The great lamp answers to the left switch. Its beam sweeps the basin once every eleven seconds. Far out to the west, low over the water, something blinks back, once, as if surprised.'],
  skiff: ['exodus', 'Machine', 'The skiff', 'A lift-hulled ferry between the Market Pier, Lantern Isle and Verdant Rise. The pilot plate reads: “Ferry service suspended by order of the Authority. Operator Vale exempt.” It runs off the same relay as everything else, so it still comes when called.'],
  sister: ['exodus', 'Observation', 'Beside the Sister', 'Through the gallery telescope, the bright point beside the crescent moon is moving against the stars, very slowly. It is not a star. It is a ring of ships, holding position above the basin.'],
  pierBoard: ['exodus', 'Schedule', 'Harbour notices', 'A board of pinned notes. “Skiff runs whenever it is called.” “Lantern Isle keeper wanted, quiet work.” “Please stop feeding the relay.” One is in your handwriting: “Ask what the rehearsal counter is really counting.”'],

  // ---- Tarn Quarter
  tarnMap: ['tarn', 'Observation', 'The basin map', 'A survey map of the basin under glass. The eastern third is a district called Tarn Quarter, drawn in full: streets, a bell tower of its own, a school. Someone has shaded it blue in pencil, very carefully, and written a date beside it that is the same as today’s. A route for the skiff is pencilled in, south around the city and up to a roof marked with a small cross.'],
  tarnClock: ['tarn', 'Observation', 'The drowned clock', 'The Tarn bell tower leans out of the water, its clock face cracked but readable. Like the one on the Upper Terrace it has twenty-two hours. It stopped at 21:58, two minutes before the end.'],
  tarnStone: ['tarn', 'Observation', 'Tarn Quarter stone', 'A memorial on the old quay: TARN QUARTER, 1,214 souls, the water took them first. The stone is newer than the quay. Fresh flowers lie on it, still wet, as they will every cycle.'],
  code: ['tarn', 'Credential', 'Civic override · ' + CIVIC_CODE, 'The shelter ledger lists emergency overrides for the basin. The tidal lock in the Deep takes ' + CIVIC_CODE + '. Overrides are “mechanical, and retained by the observer relay”: once used, they stay used. The page is worn at the entry for Tarn Quarter.'],
  cityLog: ['tarn', 'Recording', 'The bell keeper', '“Iona, if you can hear this cylinder, I’m sorry for the mess. The lanterns flare at three minutes, in an order the archive vault answers to; count from the descent. Our carrier is on 107.3, but there’s no power to send until half past eighteen. And when the span goes, take the service walk. It was here before the city.”'],

  // ---- the residents
  npcPell: ['residents', 'Person', 'Absol, berth warden', 'Keeps the berths. Says good morning to an empty bed most cycles. Has stopped minding the count.'],
  npcJuniper: ['residents', 'Person', 'Skye, stallholder', 'Runs the stall on the Market Pier. Is paid in favours and cannot remember who did them.'],
  npcSef: ['residents', 'Person', 'Charley, fisherman', 'Fishes off the end of the Market Pier. Four hundred days, no catch. Gets seasick.'],
  npcPilot: ['residents', 'Person', 'Luka, skiff pilot', 'The skiff’s pilot unit. Has counted every trip and would rather not say how many.'],
  npcKeeper: ['residents', 'Person', 'Aiden, lamp keeper', 'Keeps the lamp on Lantern Isle. Lights it when the basin is quiet. Somebody answers it.'],
  npcGardener: ['residents', 'Person', 'Christian, gardener', 'Tends the glasshouse on Verdant Rise. Far too many tomatoes.'],
  tags: ['residents', 'Observation', 'The tag board', 'Every resident of Vale Court took a tag from this board on the way to the boats. Three hundred and twelve hooks. Six tags are still hanging.'],
  imprints: ['residents', 'Observation', 'Nobody remembers leaving', 'Everyone you have spoken to talks about the evacuation boats as something that happened to other people. None of them remembers deciding to stay. None of them remembers yesterday at all.'],
  imprintsTruth: ['residents', 'Machine', 'Residents retained', 'Under the tape, the counter on the Rebound Engine is not counting rehearsals. Its plate reads RESIDENTS RETAINED, and the dial stands at six. A line is scratched beside it in your hand: “They asked to stay with me. The engine keeps them the way it keeps the water. When I let go, so does it.”'],
  pebble: ['residents', 'Person', 'A pebble for Charley', 'You brought Charley a pebble from Lantern Isle. He turned it over for a long time. \u201cSmells of lamp oil. So the isle is still there. Good. Good.\u201d He put it in his pocket, where it will not stay.'],
  gardenLog: ['residents', 'Recording', 'The botanist', '“Sixty seedlings survived the second reset. None survived the third. The plants do not remember, which is why I trust them. Leave the bed by the door alone. It is for the next person who forgets.”'],
  seedbed: ['residents', 'Observation', 'The seed bed', 'In the bed by the door a single shoot has grown to your knee: far taller than anything should grow in twenty-two minutes. A tag in your handwriting: “Planted this cycle, or the last? Ask the plant.”'],

  // ---- letters left on the night of the boats, one for each of the six
  letterPell: ['letters', 'Letter', 'For Absol, from Skye', '\u201cAbsol. It\u2019s Skye, from the stall. You won\u2019t remember this, and neither will I by morning, so I\u2019m writing it down. You stayed because somebody had to keep the beds. I stayed because you looked like you needed somebody to haggle with. Every morning you will make a bed for nobody, and every morning I will try to sell you an apple you don\u2019t want. Come down and buy one anyway. The mask suits you. \u2014 Skye, Market Pier\u201d'],
  letterJuniper: ['letters', 'Letter', 'For Skye, from Absol', '\u201cSkye. Absol here, from the berths. Tonight you gave your whole stall away to people getting on the boats, then stayed behind with an empty counter. I don\u2019t think I\u2019ll remember saying this, so here it is in ink: thank you. If you forget everything else, the arch song goes slow in the middle, where you always rush it. I\u2019ll keep a bed made for you up at the station. Just in case. \u2014 Absol, Halcyon berths\u201d'],
  letterSef: ['letters', 'Letter', 'For Charley, from Christian', '\u201cCharley. It\u2019s Christian, from the glasshouse. You told me tonight you\u2019re staying to settle things with a fish, and I told you I\u2019m staying for the seedlings. I think we are both fibbing a little. There\u2019s no fish in the channel, Charley, and there won\u2019t be new seedlings, and that\u2019s all right. I\u2019ve left a bag of tomatoes by your bucket. Eat one. Don\u2019t throw it at the gulls. And when you look up, the bright one beside the Sister is the boats. \u2014 Christian\u201d'],
  letterKeeper: ['letters', 'Letter', 'For Aiden, from Luka', '\u201cTo Aiden, keeper, Lantern Isle. From Luka, pilot unit LK-4. BEEP. Every night I run the skiff home past your rock, and your beam comes round every eleven seconds. I count them. Somebody far out to the west blinks back at you. It is not me. I wanted you to know that someone is counting from this side too. If you forget this, I will not. I do not forget. \u2014 Luka\u201d'],
  letterGardener: ['letters', 'Letter', 'For Christian, from Charley', '\u201cChristian. Charley here, the old fool on the end of the pier. Ilse left you a note about the bed by the door. I watched you read it, and then I watched you water the bed anyway. Good lad. The plants don\u2019t remember, she says, but they keep going. So do we. The tides are on the back, not that you need them up there. Save me a tomato. \u2014 Charley\u201d'],
  letterPilot: ['letters', 'Letter', 'For Luka, from Aiden', '\u201cLuka. It\u2019s Aiden, from the lamp. They cleared your route table tonight and you kept running it anyway. Good. Somebody has to bring the operator across when she comes, and she will come; she always does. I asked the yard to leave you exempt for her. Wipe your plate now and then. And when you pass my rock, flash your lamp. I will flash back. \u2014 Aiden, keeper\u201d'],
  letters: ['letters', 'Observation', 'Six letters, delivered', 'Every one was written by one of the six, to another of the six, on the night they chose to stay: Skye and Absol to each other, Christian and Charley, Aiden and Luka. They knew they would forget, so they wrote it down. None of them remembers writing theirs. All of them kept the one they were given.'],

  // ---- schedule
  schedule: ['world', 'Schedule', 'Basin operations', 'The operations board by the airlock: the intake drains at 06:00 and surges at 12:00. The transit span is rated to fail at 15:00, and the service gate on the Concourse releases with it. Every other line has been scratched out.'],
  lanterns: ['world', 'Observation', 'Civic lanterns', 'At 03:00 the lanterns on the transit arches flare one after another, and again at 03:20. Counting from the descent: ' + LANTERN_ORDER.map(n => nth[n - 1]).join(', ') + '. The arches carry numerals, I to IV.'],
  tide: ['world', 'Schedule', 'Low water', 'Beyond the tidal lock the run is passable only between 06:00 and 12:00, while the intake is drained. A bypass pump at the far end could keep it dry for good.'],
  sun: ['world', 'Observation', 'Light on the gallery floor', 'At 08:00 the low sun reaches through the slit in the gallery wall and fills four stencilled frames on the floor with digits: 5 9 0 2. The hatch to the archive is beside them.'],
  span: ['world', 'Schedule', 'Transit span', 'The span between the Concourse and South Plaza fails at 15:00. The iron gate to the service walk unlocks at the same moment. Do not be standing on the span.'],
  towers: ['world', 'Observation', 'Failing towers', 'The tower on the rock west of the Market Pier comes down at 13:30. The one east of the quay follows at 16:30.'],

  // ---- solutions (journal only)
  hatch: ['vale', 'Solution', 'Archive hatch open', 'The hatch accepts 5902. The relay will keep it unlocked.'],
  unlocked: ['tarn', 'Solution', 'Tidal lock released', 'The civic override is accepted and will stay accepted. The run beyond floods outside low water.'],
  pump: ['engine', 'Solution', 'Bypass latched', 'The observer relay now reapplies the bypass latch at the start of every cycle. The Deep stays dry, and the observer lift will run between the station and the laboratory.'],
  phase: ['engine', 'Solution', 'Release armed', 'Voiceprint accepted, word accepted. Listen, Ground, Open. The stored energy goes up the beam and does not come back down.']
};

export const timeline = [
  { t: TIMES.lanternA, label: 'Civic lanterns flare', know: 'lanterns' },
  { t: TIMES.drain, label: 'Intake drains', know: 'tide' },
  { t: TIMES.sunStart, label: 'Light crosses the gallery floor', know: 'sun' },
  { t: TIMES.surge, label: 'Intake surges', know: 'tide' },
  { t: TIMES.towerA, label: 'West tower falls', know: 'towers' },
  { t: TIMES.span, label: 'Span fails, service gate opens', know: 'span' },
  { t: TIMES.towerB, label: 'East tower falls', know: 'towers' },
  { t: TIMES.relay, label: 'Relay powers on 107.3', know: 'relay' },
  { t: TIMES.power, label: 'Station grid fails', know: 'power' },
  { t: TIMES.tremor, label: 'Final tremors', know: 'final' },
  { t: LOOP_SECONDS, label: 'The rebound', know: null }
];

// events announced by a line of text when you are there to see them (region -1 = anywhere)
export const witness = [
  { t: TIMES.lanternA - 2, region: 'city', know: null, text: 'Up on the arches, the lanterns stir.' },
  { t: TIMES.drain, region: 'deep', know: 'tide', text: 'Beyond the lock, the water begins to drain.' },
  { t: TIMES.surge, region: 'deep', know: 'tide', text: 'Water roars back into the run.' },
  { t: TIMES.towerA, region: 'city', know: 'towers', text: 'A tower west of the pier gives way.' },
  { t: TIMES.span, region: 'city', know: 'span', text: 'The span lets go. Somewhere east, an iron gate unlatches.' },
  { t: TIMES.towerB, region: 'city', know: 'towers', text: 'The tower beyond the quay leans, and keeps leaning.' },
  { t: TIMES.warning, region: -1, know: null, text: 'A pressure warning sounds across the basin.' },
  { t: TIMES.power, region: -1, know: 'power', text: 'The grid fails. Every light stutters.' },
  { t: TIMES.tremor, region: -1, know: 'final', text: 'The ground will not stop shaking.' },
  { t: 1292, region: -1, know: null, text: 'The water is taking the city.' }
];

// open questions; cleared when `done(state)` is true
export const leads = {
  hatch: ['A keypad beside a hatch in the gallery wall. Four empty frames are stencilled on the floor.', s => s.solved.hatch],
  vault: ['The vault in the Civic Archive wants four lanterns, in the right order.', s => s.solved.vault],
  door: ['The tidal lock in the Deep wants a four-digit civic override.', s => s.solved.code],
  gate: ['The iron gates to the service walk are chained. Their plates say they release with the span.', s => s.found.has('serviceWalk')],
  pump: ['The bypass pump at the far end of the Deep could keep the run dry for good.', s => s.solved.pump],
  bulkhead: ['The Core bulkhead compares one moment across two cycles.', s => s.solved.bulkhead],
  radio: ['The receiver hears an old loop on 91.8. Another band should come alive later.', s => s.found.has('carrier')],
  release: ['The release controls need the operator’s voiceprint, a word from the sky, and the routing done in the right order.', s => s.ended],
  beacon: ['The lighthouse on Lantern Isle has two switches. Aiden, the keeper, would know which.', s => s.found.has('beacon')],
  imprints: ['The people still in the basin do not remember the evacuation. Something in the station might know why.', s => s.found.has('imprintsTruth')],
  letters: ['Somebody left a letter for one of the residents on the night of the boats. There may be one for each of them, and whoever wrote them may be closer than you think.', s => s.found.has('letters')],
  tarn: ['Tarn Quarter is closed to traffic, but the skiff answers to you. With the map, Luka might take you there.', s => s.found.has('tarnRoofs')]
};

export const story = {
  opening: [
    'The last thing you remember is reaching for a hand in the dark.',
    'A berth light comes on. Behind the wall, something immense takes its first breath.'
  ],
  wake: [
    'The berth light comes on.',
    'You wake with the taste of salt water.',
    'The first breath is always the same.',
    'Somewhere below, the pumps start their count.',
    'You were dreaming of a bell.',
    'Your hand is still reaching for something.',
    'The engine turns over. So do you.'
  ],
  ending: [
    'The beam goes up and does not come back.',
    'For the first time, the carrier says something you have never heard before.',
    '“Iona? We see the sunrise.”',
    'Below the station, the drowned streets stay drowned. On a rooftop in Tarn Quarter, a single white light answers another.',
    'On the Market Pier the residents stand at the rail, blinking at the light as if they have just remembered something, and Luka is bringing the boat in.'
  ],
  message: 'You can’t change what happened. But you can change what happens next.'
};

// the ending changes a little depending on what you found
export function endingLines(st) {
  const lines = [...story.ending];
  if (st.found.has('lastHand')) lines[3] = 'Below the station, the drowned streets stay drowned. On a roof in Tarn Quarter the lamp you kept ready for Wren is burning, and far out on the water a single white light answers it.';
  if (st.found.has('imprintsTruth')) lines[4] = 'On the Market Pier the residents stand at the rail, blinking at the light as if they have just remembered something. They are not held any more. Luka is bringing the boat in.';
  if (st.found.has('letters')) lines.push('Six letters go aboard in six pockets, each one beside the person who wrote it.');
  // the small kindnesses, remembered
  const s = st.solved || {}, small = [];
  if (s.tomatoGiven) small.push('Skye has a tomato in her coat pocket.');
  if (s.teaGiven) small.push('Aiden has filled a flask for the crossing.');
  if (s.keanuFetch) small.push('Keanu has his ball.');
  if (small.length) lines.push(small.join(' '));
  return lines;
}

// the people: voice pitch for the 8-bit chatter, and what they say, one page at a time
// what each of them says once the beam has gone up
export const epilogue = {
  npcPell: 'I made the bed this morning. First time in, oh, ever. It stayed made.',
  npcJuniper: 'There is a boat coming! A real one. I am going to sell them everything.',
  npcSef: 'Felt a bite. Lost it. Best day in four hundred years.',
  npcPilot: 'BEEP. New manifest received. Residents departing: six. That is a problem I am glad to have.',
  npcKeeper: 'I can put the lamp out now. Somebody is coming who knows the way.',
  npcGardener: 'The seedlings came up different today. New leaves. I cried a bit, do not tell anyone.'
};

// what each of them says the first time you bring up the letter that was left for them
export const letterReplies = {
  npcPell: ['letterPell', 'Skye wrote this? Skye from the stall? I walk past her every morning. She always tries to sell me an apple. \u2026I think I\u2019m going to buy one.'],
  npcJuniper: ['letterJuniper', 'Absol? The one in the fox mask, up at the berths? He wrote to me? \u2026He kept a bed made for me. All this time. Don\u2019t you dare tell him I cried.'],
  npcSef: ['letterSef', 'Christian. The lad with the tomatoes. \u201cThere\u2019s no fish.\u201d Cheeky. \u2026He\u2019s right, isn\u2019t he. Four hundred days I have been looking at the water.'],
  npcKeeper: ['letterKeeper', '\u201cSomeone is counting from this side too.\u201d The skiff. Every night, that little blue light going home. I thought it was only going home.'],
  npcGardener: ['letterGardener', 'Charley wrote this? Charley doesn\u2019t write anything. \u201cGood lad.\u201d \u2026I am saving him the best tomato. I am saving him all of them.'],
  npcPilot: ['letterPilot', 'BEEP. Message from Aiden received. \u201cOperator exempt.\u201d I had that filed as policy. It was a kindness. Updating classification. Also: I will flash the lamp.']
};

// a line each resident has once you know a particular thing (shown first, once per cycle)
export const reactions = {
  npcPell: ['imprintsTruth', 'You looked under the tape, didn\u2019t you. Six. I always thought it was counting beds.'],
  npcJuniper: ['lanterns', 'You saw them! The little song on the arches. Three, one, four, two. My mother used to hum it.'],
  npcSef: ['beacon', 'Someone lit the lamp on the isle. I saw it from here. Felt like being remembered.'],
  npcPilot: ['tarnRoofs', 'Trip to Tarn Quarter logged. Passengers out: one. Passengers back: one. I hoped it would say two.'],
  npcKeeper: ['lastHand', 'The boy on the roof in Tarn. Wren. He waved at my lamp every night. Then one night he didn\u2019t, and you started coming here instead.'],
  npcGardener: ['seedbed', 'You found the tall one. I don\u2019t water it. It grows anyway, like it knows something we don\u2019t.']
};

// The basin's small secrets, for the Curiosities page of the journal. `has` reads the save.
export const curiosities = [
  { title: 'How to Speak Dog', found: 'A pocket guide from the radio desk. Every bark makes sense now.', hint: 'A book someone left in the station, much thumbed.', has: (s) => s.speakDog },
  { title: 'A belly rub', found: 'Keanu, berth 03. He rolled straight over.', hint: 'Somebody on the bed next to yours would like some attention.', has: (s) => s.keanuPet },
  { title: 'Finally', found: 'Keanu told you what he has been trying to say all along.', hint: 'Talk to him once you can understand him.', has: (s) => s.keanuThanked },
  { title: 'Fetch', found: 'Keanu\u2019s ball, from beside the writing desk. He brought it back every time.', hint: 'Something chewed and round is lying about in the berths.', has: (s) => s.keanuFetch },
  { title: 'A small favour', found: 'You tied down Skye\u2019s awning, and she finally found out who keeps doing it.', hint: 'Skye would like to thank whoever keeps fixing her awning.', has: (s) => s.skyeThanked },
  { title: 'Something new', found: 'You carried one of Christian\u2019s tomatoes all the way to Skye\u2019s stall. The first new thing on it in four hundred days.', hint: 'Christian has far too many tomatoes. Somebody else might like one.', has: (s) => s.tomatoGiven },
  { title: 'Cold tea', found: 'You carried a cup of tea from the station all the way to Lantern Isle. Stone cold. Aiden drank every drop.', hint: 'Somebody on the kettle rota hasn\u2019t had a cup in a very long time.', has: (s) => s.teaGiven },
  { title: 'A fellow explorer', found: 'Milky, a white-furred explorer at the bottom of the long stairs, mapping the tunnels with a notebook and a ball of string.', hint: 'Somebody has been unrolling string at the bottom of the long stairs.', has: (s) => s.metExplorer },
  { title: 'How to Speak Robot', found: 'A manual from the skiff yard, with notes in the margins.', hint: 'A slim manual, left on a crate where the boats don\u2019t go.', has: (s) => s.speakRobot },
  { title: 'Forty-one thousand', found: 'Luka told you the real trip count, and what he was told to say.', hint: 'Ask the pilot again, once you can parse the beeps.', has: (s) => s.robotHeard },
  { title: 'How to Speak Fish', found: 'A waterlogged pamphlet. Mostly vowels.', hint: 'Somebody is selling more than apples on the Market Pier.', has: (s) => s.speakFish },
  { title: 'The channel', found: 'The water had a message for Charley. There never was a fish.', hint: 'Listen at the end of the pier, once you know the words.', has: (s) => s.fishHeard }
];

export const npcs = {
  npcPell: { name: 'Absol', role: 'Berth warden', voice: 190, wave: 'square', lines: [
    'Oh! You are up. Good. Most mornings you are not, and I am left talking to a bed.',
    'Nobody says it, but we all keep a count. Twenty-two minutes, then the whole basin lets go and we all start again. I have stopped minding.',
    'The notes you keep are the only thing the loop does not take back. Read them. You wrote some of them for yourself.',
    'Funny thing. Everyone talks about the evacuation boats. I must have slept through them. I always seem to.',
    'The bridge is out the south door. Mind the gallery at eight; the light does something there.'] },
  npcJuniper: { name: 'Skye', role: 'Stallholder', voice: 330, wave: 'square', lines: [
    'Fresh! Well. Fresh-ish. Everything on this stall is from this morning, and so is everything else, if you think about it.',
    'People pay me in little favours now. Last cycle somebody fixed my awning and I do not know who. I would like to thank them.',
    'At three minutes the lanterns on the arches go off like a little song. Count them from the stairs. It matters more than it sounds.',
    'Everyone else went on the boats. I meant to. I had my coat on and everything. Then it was morning again.',
    'Go on, look around. Just do not lean on the rail at the end. It has opinions.'] },
  npcSef: { name: 'Charley', role: 'Fisherman', voice: 130, wave: 'triangle', lines: [
    'Hnh. Quiet out here. I like it quiet.',
    'Caught nothing in four hundred days. Keep the line wet anyway. You never know.',
    'The skiff comes when you ask it. Lantern Isle to the west, a green place down south. I get seasick.',
    'Bring me back something if you go. Anything. A pebble.',
    'If you see the boats that left, tell them old Charley is still here. They will know what that means. I am not sure I do.'] },
  npcPilot: { name: 'Luka', role: 'Skiff pilot', voice: 440, wave: 'square', robot: true, lines: [
    'BEEP. Hello, Operator. Ferry service is suspended by order of the Authority. You are exempt. You are always exempt.',
    'Three stops. Market Pier. Lantern Isle. Verdant Rise. I do not choose. You choose.',
    'Passengers are asked to hold on to nothing in particular. The skiff will do the holding.',
    'I have counted every trip. Do you want the number? No? Good. It is large.',
    'Residents on manifest: six. Residents departed: zero. That is not a problem. I was told it is not a problem.'] },
  npcKeeper: { name: 'Aiden', role: 'Lamp keeper', voice: 150, wave: 'triangle', lines: [
    'You came by boat. Nobody comes by boat. Sit, sit.',
    'I keep the lamp. When the basin is quiet I light it, when it is not I put it out. That is the whole job and I am very good at it.',
    'The switches are inside the tower. The left one. It was always the left one.',
    'Somebody out there answers it. I have never found out who. Maybe you will.',
    'You have a kind face. I feel like I have told you all of this before.'] },
  npcGardener: { name: 'Christian', role: 'Gardener', voice: 280, wave: 'square', lines: [
    'Shh! Mind the seedlings. They have only just woken up.',
    'Everything grows here, loop or no loop. The roots do not read the clock.',
    'The bed by the door is the oldest. Somebody left it a note. Too tidy to be mine.',
    'The seedlings come up the same way every morning. Exactly the same leaves. I counted. I wonder if I come up the same way too.',
    'If you find a use for tomatoes in a time loop, tell me. I have far too many.'] }
};
