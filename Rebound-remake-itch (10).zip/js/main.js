// Rebound · made by NyxiePlaysGames
import { Game } from './game/game.js';
import { handlers } from './game/puzzles.js';
import { stepBody } from './core/physics.js';

const game = new Game();
if (matchMedia('(pointer: coarse)').matches && !matchMedia('(pointer: fine)').matches) document.getElementById('bootNote').hidden = false;
game.boot().catch((err) => {
  console.error(err);
  const l = document.getElementById('bootLine');
  if (l) l.textContent = 'Rebound could not start: ' + (err && err.message ? err.message : err) + '. Try a desktop browser with WebGL 2.';
});

// A small handle for automated tests and curious players. Nothing here is needed to play.
window.__rb = {
  game, handlers, stepBody,
  tp(x, y, z, yaw = 0, pitch = 0) { game.body.place(x, y, z, yaw); game.body.pitch = pitch; game.updateRegion(); },
  setElapsed(e) { game.st.elapsed = e; game.prevElapsed = e; },
  use(id) { const h = handlers[id]; if (!h) return false; if (id.startsWith('npc')) { h(game); return true; } game.openPanelMode(); h(game); if (game.ui.overlay.hidden && game.mode === 'panel') game.closePanelMode(); return true; },
  closePanels() { game.ui.closePanel(); game.endDialog(); if (game.mode !== 'cine') game.mode = 'play'; },
  // skip the title and the wake-up: straight into cycle 1, standing in the berths
  quickStart() {
    game.sound.unlock(); game.st = (game.st && game.st.loop) ? game.st : null;
    game.start(true); game.timers = []; game.newCycle(false);
    document.getElementById('hud').hidden = false; document.getElementById('title').hidden = true;
    game.mode = 'play'; game.cine = null; game.fadeTo(0, 0.01);
  },
  // advance game time quickly without drawing (headless browsers barely fire animation frames)
  run(sec, dt = 0.05) { const f = window.__rbFreeze, r = window.__rbNoRender; window.__rbFreeze = false; window.__rbNoRender = true; for (let t = 0; t < sec; t += dt) game.frame(dt); window.__rbFreeze = f; window.__rbNoRender = r; },
  // run a few frames even while frozen (for screenshots)
  shot(n = 3, dt = 0.02) { const f = window.__rbFreeze, r = window.__rbNoRender; window.__rbFreeze = false; for (let i = 0; i < n; i++) { window.__rbNoRender = i < n - 1; game.frame(dt); } window.__rbFreeze = f; window.__rbNoRender = r; },
  // walk the body towards (tx, tz) with real collision, as if holding W; returns where it ended up
  walkTo(tx, tz, o = {}) {
    const b = game.body, dt = 1 / 60;
    let steps = 0, stuck = 0, lx = b.x, lz = b.z;
    while (steps++ < (o.max || 6000)) {
      const dx = tx - b.x, dz = tz - b.z, d = Math.hypot(dx, dz);
      if (d < (o.tol || 0.4)) break;
      b.yaw = Math.atan2(-dx, -dz);
      stepBody(game.world.phys, b, { x: 0, z: -1, sprint: o.sprint !== false, jump: false }, dt, {});
      if (steps % 60 === 0) { if (Math.hypot(b.x - lx, b.z - lz) < 0.2) { if (++stuck > 2) break; } else stuck = 0; lx = b.x; lz = b.z; }
      if (b.y < -60) break;
    }
    return { x: +b.x.toFixed(2), y: +b.y.toFixed(2), z: +b.z.toFixed(2), ok: Math.hypot(tx - b.x, tz - b.z) < (o.tol || 0.4) + 0.2, steps };
  }
};
