// All sound is synthesised with the Web Audio API: no samples, nothing to load.
// Buses: master <- music, sfx, ambience, voice. A shared convolution reverb gives spaces depth.

const A4 = 440;
export const hz = (n) => A4 * Math.pow(2, (n - 69) / 12);

export class Sound {
  constructor() {
    this.ctx = null;
    this.vol = { master: 0.8, music: 0.6, sfx: 0.8, amb: 0.7, voice: 0.7 };
    this.ready = false;
    this.layers = {};
    this.reverbMix = 0.3;
  }

  unlock() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = this.ctx = new AC();
    this.master = ctx.createGain();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 12; comp.ratio.value = 3; comp.attack.value = 0.01; comp.release.value = 0.3;
    this.master.connect(comp); comp.connect(ctx.destination);
    this.bus = {};
    for (const k of ['music', 'sfx', 'amb', 'voice']) { this.bus[k] = ctx.createGain(); this.bus[k].connect(this.master); }
    // reverb
    this.verb = ctx.createConvolver();
    this.verb.buffer = this.impulse(3.2, 2.6);
    this.verbIn = ctx.createGain(); this.verbIn.gain.value = 1;
    this.verbOut = ctx.createGain(); this.verbOut.gain.value = 0.5;
    this.verbIn.connect(this.verb); this.verb.connect(this.verbOut); this.verbOut.connect(this.master);
    // a soft delay for bells and voices
    this.delay = ctx.createDelay(2); this.delay.delayTime.value = 0.42;
    this.fb = ctx.createGain(); this.fb.gain.value = 0.32;
    const dl = ctx.createBiquadFilter(); dl.type = 'lowpass'; dl.frequency.value = 2600;
    this.delay.connect(dl); dl.connect(this.fb); this.fb.connect(this.delay);
    this.delayOut = ctx.createGain(); this.delayOut.gain.value = 0.35;
    dl.connect(this.delayOut); this.delayOut.connect(this.bus.music);
    this.noise = this.noiseBuffer(4);
    this.applyVolumes();
    this.ready = true;
    this.startAmbience();
  }

  setVolumes(v) { Object.assign(this.vol, v); this.applyVolumes(); }
  // how big the space sounds: more reverb in the Deep and the Core, very little out on the water
  setSpace(region) {
    if (!this.ctx) return;
    const k = { station: 0.55, city: 0.3, deep: 0.95, core: 1.1, isle: 0.2, rise: 0.25, tarn: 0.25 }[region] ?? 0.4;
    if (this.space === k) return;
    this.space = k;
    this.verbOut.gain.setTargetAtTime(k, this.ctx.currentTime, 1.0);
  }
  // music steps back while someone is speaking
  duck(on) {
    if (!this.ctx) return;
    this.ducked = on;
    this.bus.music.gain.setTargetAtTime(this.vol.music * 0.9 * (on ? 0.35 : 1), this.ctx.currentTime, on ? 0.2 : 0.8);
  }
  applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.vol.master, t, 0.05);
    this.bus.music.gain.setTargetAtTime(this.vol.music * 0.9, t, 0.05);
    this.bus.sfx.gain.setTargetAtTime(this.vol.sfx, t, 0.05);
    this.bus.amb.gain.setTargetAtTime(this.vol.amb, t, 0.05);
    this.bus.voice.gain.setTargetAtTime(this.vol.voice, t, 0.05);
  }

  impulse(sec, decay) {
    const ctx = this.ctx, len = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = b.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay) * (i < 200 ? i / 200 : 1);
    }
    return b;
  }
  noiseBuffer(sec) {
    const ctx = this.ctx, len = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(1, len, ctx.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = w * 0.6 + last * 3; }
    return b;
  }

  // ---------- primitives ----------
  out(bus = 'sfx', wet = 0.2) {
    const g = this.ctx.createGain();
    g.connect(this.bus[bus]);
    if (wet > 0) { const s = this.ctx.createGain(); s.gain.value = wet; g.connect(s); s.connect(this.verbIn); }
    return g;
  }
  tone(freq, dur, o = {}) {
    if (!this.ready) return;
    const ctx = this.ctx, t = ctx.currentTime + (o.at || 0);
    const osc = ctx.createOscillator(); osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(freq, t);
    if (o.to) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.to), t + dur);
    if (o.detune) osc.detune.value = o.detune;
    const g = ctx.createGain();
    const a = o.attack ?? 0.005, peak = o.gain ?? 0.2;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let node = osc;
    if (o.filter) { const f = ctx.createBiquadFilter(); f.type = o.filterType || 'lowpass'; f.frequency.value = o.filter; f.Q.value = o.q || 0.7; osc.connect(f); node = f; }
    node.connect(g);
    const dest = this.out(o.bus || 'sfx', o.wet ?? 0.15);
    g.connect(dest);
    if (o.delay) { const d = ctx.createGain(); d.gain.value = o.delay; g.connect(d); d.connect(this.delay); }
    osc.start(t); osc.stop(t + dur + 0.05);
    return osc;
  }
  noiseBurst(dur, o = {}) {
    if (!this.ready) return;
    const ctx = this.ctx, t = ctx.currentTime + (o.at || 0);
    const src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
    src.playbackRate.value = o.rate || 1;
    const f = ctx.createBiquadFilter(); f.type = o.type || 'lowpass'; f.frequency.setValueAtTime(o.freq || 1200, t); f.Q.value = o.q || 0.8;
    if (o.toFreq) f.frequency.exponentialRampToValueAtTime(o.toFreq, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(o.gain ?? 0.2, t + (o.attack ?? 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.out(o.bus || 'sfx', o.wet ?? 0.2));
    src.start(t, Math.random() * 3); src.stop(t + dur + 0.05);
  }
  // FM bell
  bell(freq, dur = 3, gain = 0.12, o = {}) {
    if (!this.ready) return;
    const ctx = this.ctx, t = ctx.currentTime + (o.at || 0);
    const car = ctx.createOscillator(), mod = ctx.createOscillator(), mg = ctx.createGain();
    car.frequency.value = freq; mod.frequency.value = freq * (o.ratio || 3.5);
    mg.gain.setValueAtTime(freq * (o.index || 2.2), t); mg.gain.exponentialRampToValueAtTime(freq * 0.05, t + dur);
    mod.connect(mg); mg.connect(car.frequency);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(gain, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    car.connect(g);
    g.connect(this.out(o.bus || 'sfx', o.wet ?? 0.35));
    if (o.delay) { const d = ctx.createGain(); d.gain.value = o.delay; g.connect(d); d.connect(this.delay); }
    car.start(t); mod.start(t); car.stop(t + dur + 0.1); mod.stop(t + dur + 0.1);
  }

  // ---------- effects ----------
  step(surface, sprint) {
    if (!this.ready) return;
    const v = (sprint ? 1.2 : 0.9) * 3;
    const r = 0.9 + Math.random() * 0.2;
    if (surface === 'metal') { this.noiseBurst(0.09, { freq: 3200 * r, type: 'bandpass', q: 3, gain: 0.07 * v, wet: 0.25 }); this.tone(180 * r, 0.08, { type: 'triangle', gain: 0.03 * v, wet: 0.2 }); }
    else if (surface === 'wood') { this.noiseBurst(0.08, { freq: 900 * r, type: 'bandpass', q: 2, gain: 0.08 * v }); this.tone(120 * r, 0.1, { type: 'sine', gain: 0.05 * v }); }
    else if (surface === 'water') { this.noiseBurst(0.22, { freq: 1600 * r, toFreq: 500, type: 'bandpass', q: 1, gain: 0.1 * v }); }
    else if (surface === 'grate') { this.noiseBurst(0.07, { freq: 2600 * r, type: 'bandpass', q: 4, gain: 0.06 * v, wet: 0.3 }); this.tone(310 * r, 0.22, { type: 'triangle', gain: 0.02 * v, wet: 0.35 }); this.tone(467 * r, 0.16, { type: 'sine', gain: 0.012 * v, wet: 0.35 }); }
    else if (surface === 'wet') { this.noiseBurst(0.07, { freq: 1300 * r, type: 'bandpass', q: 1.2, gain: 0.06 * v, wet: 0.35 }); this.noiseBurst(0.16, { freq: 2200 * r, toFreq: 900, type: 'bandpass', q: 1.4, gain: 0.045 * v, wet: 0.35, at: 0.02 }); }
    else if (surface === 'tile') { this.noiseBurst(0.05, { freq: 2900 * r, type: 'bandpass', q: 2.5, gain: 0.06 * v, wet: 0.3 }); this.tone(260 * r, 0.05, { type: 'triangle', gain: 0.025 * v, wet: 0.2 }); }
    else if (surface === 'grass') { this.noiseBurst(0.12, { freq: 2400 * r, type: 'highpass', q: 0.5, gain: 0.035 * v }); }
    else { this.noiseBurst(0.07, { freq: 1400 * r, type: 'bandpass', q: 1.2, gain: 0.07 * v, wet: 0.2 }); this.tone(90 * r, 0.06, { gain: 0.03 * v }); }
  }
  land(speed, surface) {
    this.noiseBurst(0.18, { freq: 700, gain: Math.min(0.35, 0.08 * speed), wet: 0.2 }); this.tone(70, 0.2, { gain: Math.min(0.3, 0.06 * speed) });
    if (!this.ready) return;
    // what you landed on answers back: a ring off metal, a splash in the wet, a creak of planks
    const k = Math.min(1, speed / 6);
    if (surface === 'metal' || surface === 'grate') this.tone(196, 0.5, { type: 'triangle', gain: 0.04 * k, wet: 0.5 });
    else if (surface === 'wet' || surface === 'water') this.noiseBurst(0.35, { freq: 1800, toFreq: 500, type: 'bandpass', q: 1, gain: 0.12 * k, wet: 0.4 });
    else if (surface === 'wood') this.tone(95, 0.25, { type: 'sine', gain: 0.06 * k, to: 80 });
  }
  jump() { this.noiseBurst(0.08, { freq: 900, gain: 0.03 }); }
  hover() { this.tone(1600, 0.04, { type: 'sine', gain: 0.02, wet: 0, bus: 'sfx' }); }
  click() { this.tone(900, 0.05, { type: 'triangle', gain: 0.05, wet: 0.05 }); this.tone(1800, 0.03, { gain: 0.02, wet: 0, at: 0.01 }); }
  back() { this.tone(600, 0.06, { type: 'triangle', gain: 0.04, to: 420, wet: 0.05 }); }
  key(i = 0) { this.tone(700 + i * 60, 0.07, { type: 'square', gain: 0.025, filter: 2500, wet: 0.05 }); }
  accept() { this.tone(660, 0.12, { type: 'triangle', gain: 0.06 }); this.tone(990, 0.25, { type: 'triangle', gain: 0.06, at: 0.1 }); }
  deny() { this.tone(220, 0.18, { type: 'square', gain: 0.04, filter: 900 }); this.tone(180, 0.25, { type: 'square', gain: 0.04, filter: 900, at: 0.14 }); }
  door(heavy) {
    this.noiseBurst(heavy ? 2.2 : 1.0, { freq: heavy ? 300 : 700, toFreq: heavy ? 120 : 300, gain: heavy ? 0.16 : 0.08, attack: 0.15, wet: 0.4 });
    this.tone(heavy ? 55 : 110, heavy ? 2.0 : 0.8, { type: 'sawtooth', filter: 300, gain: heavy ? 0.08 : 0.03, to: heavy ? 48 : 90, wet: 0.3 });
    this.tone(heavy ? 70 : 160, 0.4, { gain: 0.1, at: heavy ? 2.0 : 0.9, wet: 0.5 });
  }
  page() { this.noiseBurst(0.25, { freq: 4000, toFreq: 1500, type: 'bandpass', q: 0.6, gain: 0.04, wet: 0.05 }); }
  // the discovery chime: two notes and a soft high shimmer
  discover(big) {
    const n = big ? [62, 69, 74, 78] : [69, 76];
    n.forEach((m, i) => this.bell(hz(m), 2.8, big ? 0.07 : 0.06, { at: i * 0.12, bus: 'sfx', ratio: 2.0, index: 1.2, delay: 0.3, wet: 0.5 }));
  }
  journal() { this.tone(523, 0.3, { type: 'sine', gain: 0.04, wet: 0.3 }); this.tone(784, 0.4, { type: 'sine', gain: 0.03, at: 0.08, wet: 0.3 }); }
  // a small secret found: three little bells going up, softer than a discovery
  curio() { [[72, 0], [76, 0.11], [83, 0.22]].forEach(([n, at]) => this.bell(hz(n), 1.6, 0.045, { bus: 'sfx', ratio: 3.0, index: 1.1, wet: 0.55, at })); }
  lantern(n) { this.bell(hz([0, 74, 69, 77, 72][n]), 2.4, 0.1, { bus: 'sfx', ratio: 1.5, index: 1.6, wet: 0.6, delay: 0.4 }); }
  towerBell(gain = 0.16) { this.bell(hz(45), 6, gain, { ratio: 2.76, index: 3.0, wet: 0.7, delay: 0.2 }); this.bell(hz(57), 5, gain * 0.4, { ratio: 2.76, index: 2.0, wet: 0.7 }); }
  rumble(dur = 4, gain = 0.3) {
    this.noiseBurst(dur, { freq: 160, toFreq: 60, gain, attack: 0.4, wet: 0.5, rate: 0.5 });
    this.tone(38, dur, { type: 'sine', gain: gain * 0.8, attack: 0.3, wet: 0.2 });
  }
  crash(gain = 0.35) {
    this.noiseBurst(3.5, { freq: 900, toFreq: 120, gain, attack: 0.02, wet: 0.6 });
    for (let i = 0; i < 6; i++) this.noiseBurst(0.3, { freq: 1500 + Math.random() * 2000, type: 'bandpass', q: 2, gain: gain * 0.25, at: 0.2 + Math.random() * 1.8, wet: 0.5 });
    this.rumble(4, gain * 0.7);
  }
  splash(gain = 0.25) { this.noiseBurst(1.6, { freq: 2600, toFreq: 300, gain, attack: 0.02, wet: 0.4 }); this.tone(90, 0.5, { gain: gain * 0.5, to: 50 }); }
  siren() {
    for (let i = 0; i < 3; i++) {
      this.tone(420, 1.4, { type: 'sawtooth', filter: 1400, gain: 0.14, to: 640, at: i * 1.6, attack: 0.3, wet: 0.7 });
    }
  }
  powerDown() { this.tone(220, 2.5, { type: 'sawtooth', filter: 800, gain: 0.08, to: 30, wet: 0.5 }); this.noiseBurst(0.4, { freq: 5000, type: 'highpass', gain: 0.08 }); }
  lift(dur) { this.tone(70, dur, { type: 'sawtooth', filter: 260, gain: 0.07, attack: 1.0, wet: 0.4 }); this.noiseBurst(dur, { freq: 400, gain: 0.05, attack: 1.0, wet: 0.3 }); }
  motor(dur) { this.tone(48, dur, { type: 'sawtooth', filter: 200, gain: 0.08, attack: 1.2, wet: 0.2 }); this.noiseBurst(dur, { freq: 600, gain: 0.05, attack: 1.0, wet: 0.2 }); }
  flash() { this.noiseBurst(2.5, { freq: 8000, toFreq: 200, gain: 0.25, attack: 0.01, wet: 0.8 }); this.tone(1200, 2, { gain: 0.08, to: 60, wet: 0.8 }); }
  // the rebound: everything pulled backwards, then the first breath
  rewind() {
    if (!this.ready) return;
    this.noiseBurst(2.6, { freq: 200, toFreq: 6000, gain: 0.22, attack: 2.2, wet: 0.7, type: 'bandpass', q: 0.8 });
    this.tone(55, 2.6, { type: 'sawtooth', filter: 600, gain: 0.12, to: 880, attack: 2.0, wet: 0.6 });
    this.tone(110, 2.6, { type: 'sawtooth', filter: 900, gain: 0.06, to: 1760, attack: 2.0, wet: 0.6, detune: 8 });
  }
  wake() {
    [50, 57, 62, 69].forEach((m, i) => this.bell(hz(m), 5, 0.06, { at: i * 0.05, ratio: 2, index: 0.6, wet: 0.8, bus: 'music' }));
    this.noiseBurst(1.5, { freq: 500, toFreq: 2000, gain: 0.05, attack: 0.6, wet: 0.6 });
  }
  // 8-bit chatter: one blip per syllable on a pentatonic ladder
  talk(voice, wave = 'square', mood = 0) {
    if (!this.ready) return;
    const steps = [0, 2, 4, 7, 9, 12];
    const s = steps[Math.floor(Math.random() * steps.length)] + (mood > 0 ? 2 : 0);
    const f = voice * Math.pow(2, s / 12);
    this.tone(f, 0.07, { type: wave, gain: 0.11, filter: 3200, wet: 0.06, bus: 'voice', attack: 0.003 });
    if (Math.random() < 0.15) this.tone(f * 2, 0.04, { type: wave, gain: 0.05, filter: 4000, wet: 0.05, bus: 'voice', at: 0.035 });
  }
  // Keanu: a woof is a square-wave bark that drops in pitch with a breath of noise on it; a
  // growl is a low rumble that rolls in little pulses
  woof(at = 0, big = 1) {
    if (!this.ready) return;
    this.tone(330 * big, 0.16, { type: 'square', gain: 0.12, filter: 1800, to: 150 * big, attack: 0.008, wet: 0.08, bus: 'voice', at });
    this.tone(165 * big, 0.14, { type: 'sawtooth', gain: 0.07, filter: 900, to: 90 * big, attack: 0.008, wet: 0.08, bus: 'voice', at });
    this.noiseBurst(0.12, { freq: 900, type: 'bandpass', q: 1.2, gain: 0.06, attack: 0.005, wet: 0.05, bus: 'voice', at });
  }
  // a gull somewhere over the water: two or three falling cries, far off
  gull() {
    if (!this.ready) return;
    const n = 2 + (Math.random() < 0.5 ? 1 : 0), base = 1250 + Math.random() * 300;
    for (let i = 0; i < n; i++) {
      const at = i * (0.32 + Math.random() * 0.08), f = base * (1 - i * 0.06);
      this.tone(f, 0.22, { type: 'sawtooth', gain: 0.018, filter: 2600, to: f * 0.68, attack: 0.02, wet: 0.65, bus: 'amb', at });
      this.tone(f * 1.5, 0.18, { type: 'triangle', gain: 0.008, to: f * 1.0, attack: 0.02, wet: 0.65, bus: 'amb', at });
    }
  }
  // a fish going back in: a small wet plip
  plip() {
    if (!this.ready) return;
    this.noiseBurst(0.09, { freq: 1600, toFreq: 700, type: 'bandpass', q: 3, gain: 0.05, wet: 0.3 });
    this.tone(880, 0.08, { type: 'sine', gain: 0.02, to: 520, wet: 0.3 });
  }
  // loose canvas catching the wind
  flap(v = 1) {
    if (!this.ready) return;
    this.noiseBurst(0.07, { freq: 700, toFreq: 380, type: 'bandpass', q: 1.2, gain: 0.04 * v, wet: 0.3, bus: 'amb' });
    this.noiseBurst(0.05, { freq: 520, type: 'bandpass', q: 1.5, gain: 0.025 * v, wet: 0.3, bus: 'amb', at: 0.09 });
  }
  // a bird taking off: a quick run of soft wingbeats
  flutter() {
    if (!this.ready) return;
    for (let i = 0; i < 7; i++) this.noiseBurst(0.06, { freq: 900 - i * 40, type: 'bandpass', q: 0.7, gain: 0.05 * (1 - i / 9), wet: 0.25, bus: 'amb', at: i * 0.075 });
  }
  // a tennis ball landing: two soft thuds, the second smaller
  bounce() {
    if (!this.ready) return;
    for (const [at, g] of [[0, 0.07], [0.22, 0.035], [0.36, 0.015]]) {
      this.noiseBurst(0.05, { freq: 420, toFreq: 180, type: 'lowpass', q: 1, gain: g, wet: 0.2, at });
      this.tone(150, 0.06, { type: 'sine', gain: g * 0.6, to: 90, wet: 0.2, at });
    }
  }
  whine(at = 0) {
    if (!this.ready) return;
    this.tone(620, 0.45, { type: 'triangle', gain: 0.06, to: 880, attack: 0.05, wet: 0.15, bus: 'voice', at });
    this.tone(860, 0.4, { type: 'triangle', gain: 0.05, to: 700, attack: 0.04, wet: 0.15, bus: 'voice', at: at + 0.5 });
  }
  howl(at = 0) {
    if (!this.ready) return;
    this.tone(420, 1.2, { type: 'triangle', gain: 0.08, to: 700, attack: 0.25, wet: 0.5, bus: 'voice', at });
    this.tone(700, 1.6, { type: 'triangle', gain: 0.08, to: 520, attack: 0.05, wet: 0.6, bus: 'voice', at: at + 1.15 });
    this.tone(210, 2.6, { type: 'sine', gain: 0.03, to: 260, attack: 0.4, wet: 0.6, bus: 'voice', at });
  }
  growl(at = 0, dur = 1.1) {
    if (!this.ready) return;
    for (let t = 0; t < dur; t += 0.055) this.tone(68 + Math.random() * 10, 0.05, { type: 'sawtooth', gain: 0.07 * (1 - t / dur * 0.6), filter: 500, attack: 0.006, wet: 0.05, bus: 'voice', at: at + t });
  }
  // a wax cylinder starting up: a click, a hiss and a little wow
  recording() {
    if (!this.ready) return;
    this.tone(1200, 0.03, { type: 'square', gain: 0.03, wet: 0.05 });
    this.noiseBurst(2.4, { freq: 3800, type: 'bandpass', q: 0.5, gain: 0.05, attack: 0.2, wet: 0.1 });
    this.tone(220, 1.4, { type: 'sine', gain: 0.02, to: 196, attack: 0.3, wet: 0.4 });
  }
  // a muffled voice under a recording or a broadcast: band-limited noise shaped into syllables.
  // Returns a handle with stop(). pitch shifts the formants (lower for older voices).
  murmur(seconds, o = {}) {
    if (!this.ready) return { stop() { } };
    const ctx = this.ctx, t0 = ctx.currentTime + 0.25;
    const src = ctx.createBufferSource(); src.buffer = this.noise; src.loop = true;
    const p = o.pitch || 1;
    const f1 = ctx.createBiquadFilter(); f1.type = 'bandpass'; f1.frequency.value = 620 * p; f1.Q.value = 4;
    const f2 = ctx.createBiquadFilter(); f2.type = 'bandpass'; f2.frequency.value = 1500 * p; f2.Q.value = 5;
    const voiced = ctx.createOscillator(); voiced.type = 'sawtooth'; voiced.frequency.value = 118 * p;
    const vg = ctx.createGain(); vg.gain.value = 0.35;
    const env = ctx.createGain(); env.gain.value = 0;
    const band = ctx.createBiquadFilter(); band.type = 'highpass'; band.frequency.value = o.radio ? 380 : 220;
    const top = ctx.createBiquadFilter(); top.type = 'lowpass'; top.frequency.value = o.radio ? 2600 : 3400;
    src.connect(f1); src.connect(f2); voiced.connect(vg); vg.connect(f1); vg.connect(f2);
    f1.connect(env); f2.connect(env); env.connect(band); band.connect(top);
    const out = this.out('voice', 0.25); top.connect(out);
    // syllables: quick swells with small pauses, and longer gaps between phrases
    let t = t0; const end = t0 + Math.min(seconds, 14);
    while (t < end) {
      const words = 3 + Math.floor(Math.random() * 6);
      for (let w = 0; w < words && t < end; w++) {
        const syl = 1 + Math.floor(Math.random() * 3);
        for (let s = 0; s < syl; s++) {
          const d = 0.08 + Math.random() * 0.1, peak = (o.gain || 0.7) * (0.6 + Math.random() * 0.4);
          env.gain.setValueAtTime(0.0001, t); env.gain.linearRampToValueAtTime(peak, t + d * 0.3); env.gain.linearRampToValueAtTime(0.0001, t + d);
          f1.frequency.setValueAtTime(520 * p + Math.random() * 260 * p, t);
          f2.frequency.setValueAtTime(1200 * p + Math.random() * 700 * p, t);
          voiced.frequency.setValueAtTime((105 + Math.random() * 30) * p, t);
          t += d + 0.02;
        }
        t += 0.08 + Math.random() * 0.08;
      }
      t += 0.35 + Math.random() * 0.4;
    }
    src.start(t0); voiced.start(t0); src.stop(end + 0.5); voiced.stop(end + 0.5);
    if (o.radio) this.noiseBurst(Math.min(seconds, 14) + 0.5, { freq: 3200, type: 'bandpass', q: 0.4, gain: 0.025, attack: 0.3, wet: 0.05, bus: 'voice' });
    this.duck(true);
    const undo = setTimeout(() => this.duck(false), (end - ctx.currentTime + 0.4) * 1000);
    return { stop: () => { clearTimeout(undo); this.duck(false); try { const n = ctx.currentTime; env.gain.cancelScheduledValues(n); env.gain.setTargetAtTime(0.0001, n, 0.05); src.stop(n + 0.3); voiced.stop(n + 0.3); } catch (e) { } } };
  }
  // radio static burst while tuning
  tuneTick(strength) { this.noiseBurst(0.06, { freq: 2500 + strength * 2000, type: 'bandpass', q: 0.7, gain: 0.03 + strength * 0.03, wet: 0.05 }); }

  // ---------- ambience ----------
  startAmbience() {
    const ctx = this.ctx;
    const layer = (name, build) => {
      const g = ctx.createGain(); g.gain.value = 0; g.connect(this.bus.amb);
      build(g);
      this.layers[name] = { g, level: 0 };
    };
    const loopNoise = (dest, type, freq, q, gain, rate = 1) => {
      const s = ctx.createBufferSource(); s.buffer = this.noise; s.loop = true; s.playbackRate.value = rate;
      const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
      const g = ctx.createGain(); g.gain.value = gain;
      s.connect(f); f.connect(g); g.connect(dest); s.start(0, Math.random() * 3);
      return { s, f, g };
    };
    const lfo = (param, rate, depth, offset) => {
      const o = ctx.createOscillator(); o.frequency.value = rate;
      const d = ctx.createGain(); d.gain.value = depth;
      o.connect(d); d.connect(param); o.start();
      if (offset !== undefined) param.value = offset;
    };
    // wind: two bands of noise with slow gusts
    layer('wind', (g) => {
      const a = loopNoise(g, 'bandpass', 420, 0.6, 0.35, 0.6); lfo(a.f.frequency, 0.07, 180, 420); lfo(a.g.gain, 0.11, 0.18, 0.3);
      const b = loopNoise(g, 'bandpass', 1200, 1.2, 0.08, 0.8); lfo(b.f.frequency, 0.05, 400, 1200);
    });
    // sea: low surf with swells
    layer('sea', (g) => {
      const a = loopNoise(g, 'lowpass', 500, 0.5, 0.5, 0.5); lfo(a.g.gain, 0.13, 0.3, 0.45);
      const b = loopNoise(g, 'bandpass', 2200, 0.8, 0.05, 1); lfo(b.g.gain, 0.21, 0.04, 0.05);
    });
    // station hum: mains and the engine's breathing
    layer('hum', (g) => {
      for (const [f, a] of [[55, 0.12], [110, 0.05], [165, 0.02], [220, 0.012]]) {
        const o = ctx.createOscillator(); o.frequency.value = f; o.type = 'sine';
        const og = ctx.createGain(); og.gain.value = a; o.connect(og); og.connect(g); o.start();
      }
      const breath = loopNoise(g, 'lowpass', 300, 0.7, 0.12, 0.4); lfo(breath.g.gain, 0.09, 0.1, 0.1);
    });
    // the deep: a cold drone, drips handled separately
    layer('deep', (g) => {
      for (const [f, a, d] of [[41.2, 0.14, 0], [61.7, 0.06, 6], [82.4, 0.04, -5]]) {
        const o = ctx.createOscillator(); o.frequency.value = f; o.type = 'triangle'; o.detune.value = d;
        const og = ctx.createGain(); og.gain.value = a; o.connect(og); og.connect(g); o.start();
      }
      const w = loopNoise(g, 'lowpass', 220, 1.0, 0.25, 0.3); lfo(w.g.gain, 0.05, 0.12, 0.2);
    });
    // the core: shimmering cluster
    layer('core', (g) => {
      for (const [f, a] of [[146.8, 0.04], [220, 0.035], [329.6, 0.02], [415.3, 0.012], [73.4, 0.1]]) {
        const o = ctx.createOscillator(); o.frequency.value = f; o.type = 'sine';
        const og = ctx.createGain(); og.gain.value = a; lfo(og.gain, 0.1 + Math.random() * 0.2, a * 0.6, a);
        o.connect(og); og.connect(g); o.start();
      }
    });
    // electrical interference near radios and relays
    layer('static', (g) => {
      const a = loopNoise(g, 'highpass', 3000, 0.5, 0.15, 1.3); lfo(a.g.gain, 7, 0.1, 0.1);
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 50; const og = ctx.createGain(); og.gain.value = 0.02;
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 800; o.connect(f); f.connect(og); og.connect(g); o.start();
    });
    // flowing water (the run, rain off ledges)
    layer('water', (g) => { const a = loopNoise(g, 'bandpass', 900, 0.4, 0.3, 1.1); lfo(a.g.gain, 0.4, 0.08, 0.3); });
    // end-of-loop tension: a beating low cluster that rises
    layer('dread', (g) => {
      for (const [f, d] of [[55, 0], [58.3, 0], [82.4, 7]]) {
        const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.detune.value = d;
        const fl = ctx.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 240;
        const og = ctx.createGain(); og.gain.value = 0.06; o.connect(fl); fl.connect(og); og.connect(g); o.start();
      }
      this.dreadNoise = loopNoise(g, 'lowpass', 120, 1, 0.4, 0.4);
    });
  }
  setLayer(name, level, rate = 1.5) {
    const l = this.layers[name]; if (!l || !this.ctx) return;
    if (Math.abs(l.level - level) < 0.005) return;
    l.level = level;
    l.g.gain.setTargetAtTime(level, this.ctx.currentTime, rate);
  }
  drip() { if (!this.ready) return; this.tone(1800 + Math.random() * 1600, 0.12, { gain: 0.03, to: 900 + Math.random() * 400, wet: 0.9 }); }
  creak() { if (!this.ready) return; this.tone(80 + Math.random() * 60, 1.2, { type: 'sawtooth', filter: 400, q: 6, gain: 0.03, to: 60 + Math.random() * 40, attack: 0.3, wet: 0.7 }); }
  gull() { if (!this.ready) return; const f = 1200 + Math.random() * 400; this.tone(f, 0.35, { type: 'triangle', gain: 0.015, to: f * 0.7, wet: 0.6, filter: 3000 }); this.tone(f * 0.9, 0.3, { type: 'triangle', gain: 0.012, to: f * 0.6, at: 0.4, wet: 0.6, filter: 3000 }); }
}
