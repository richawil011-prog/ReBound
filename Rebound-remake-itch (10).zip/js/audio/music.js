// A generative score. Each place has a mood: a chord progression, a register and how often the
// bells speak. Phrases are four bars long and are sometimes followed by a bar of silence.
// Late in the loop a slow pulse and a rising cluster take over.
import { hz } from './audio.js';

const C = (...n) => n;
const MOODS = {
  menu:    { bar: 8.5, chords: [C(50, 57, 60, 64, 69), C(46, 53, 57, 62, 65), C(53, 57, 60, 64, 67), C(48, 55, 59, 62, 67)], bells: 0.55, theme: true, cut: 1400 },
  station: { bar: 9.0, chords: [C(50, 57, 60, 64, 65), C(43, 50, 53, 58, 62), C(46, 53, 57, 60, 62), C(45, 52, 55, 61, 64)], bells: 0.35, cut: 1000 },
  city:    { bar: 8.0, chords: [C(41, 52, 57, 60, 64), C(40, 48, 55, 60, 64), C(38, 50, 53, 57, 60), C(46, 50, 57, 60, 65)], bells: 0.45, cut: 1300 },
  deep:    { bar: 11.0, chords: [C(38, 45, 52, 57, 59), C(38, 45, 50, 57, 64), C(36, 45, 52, 55, 59)], bells: 0.18, cut: 600, dark: true },
  core:    { bar: 10.0, chords: [C(39, 46, 55, 58, 62, 69), C(36, 46, 51, 55, 58, 62)], bells: 0.4, cut: 1600, shimmer: true },
  tarn:    { bar: 10.0, chords: [C(40, 47, 52, 55, 59), C(36, 43, 52, 55, 60), C(38, 45, 50, 53, 57)], bells: 0.28, cut: 800, dark: true },
  isle:    { bar: 8.0, chords: [C(43, 54, 59, 62, 66), C(40, 52, 55, 59, 66), C(36, 52, 55, 59, 64), C(38, 54, 57, 62, 64)], bells: 0.5, cut: 1500 },
  rise:    { bar: 7.5, chords: [C(41, 53, 57, 60, 64), C(46, 53, 58, 62, 65), C(43, 55, 58, 62, 67), C(48, 55, 60, 64, 67)], bells: 0.5, cut: 1700 },
  market:  { bar: 7.0, chords: [C(43, 50, 59, 62, 65), C(41, 48, 57, 60, 65), C(43, 50, 55, 62, 67), C(38, 50, 57, 60, 65)], bells: 0.4, cut: 1500 },
  sky:     { bar: 9.5, chords: [C(45, 52, 59, 64, 71), C(41, 52, 57, 60, 67), C(43, 50, 57, 62, 69)], bells: 0.6, cut: 2000, shimmer: true },
  ending:  { bar: 7.0, chords: [C(50, 57, 61, 64, 69), C(47, 54, 57, 62, 66), C(43, 54, 59, 62, 66), C(45, 52, 57, 61, 64)], bells: 0.7, theme: true, cut: 2200 }
};
// Each place also has a short figure of its own, played now and then over the chords so that
// you can tell where you are with your eyes shut. Steps are chord tones counted down from the
// top (0 = highest), then [start, length] in eighths of a bar.
const LINES = {
  station: [[0, 0, 1.5], [1, 1.5, 1], [2, 2.5, 2.5], [1, 5.5, 2]],
  city:    [[3, 0, 1], [2, 1, 1], [1, 2, 1.5], [0, 3.5, 3]],
  deep:    [[2, 0, 3], [3, 3.5, 4]],
  core:    [[1, 0, 2], [0, 2, 2], [2, 4, 3.5]],
  tarn:    [[1, 0, 2.5], [2, 2.5, 1.5], [3, 4, 3.5]],
  isle:    [[2, 0, 1], [1, 1, 1], [0, 2, 1], [1, 3, 1], [2, 4, 3]],
  rise:    [[0, 0, 1], [2, 1, 1], [1, 2, 1], [0, 3, 1], [3, 4, 2], [2, 6, 1.5]],
  market:  [[1, 0, 1], [0, 1, 0.5], [1, 1.5, 0.5], [2, 2, 1.5], [3, 4, 1], [2, 5, 2.5]],
  sky:     [[0, 0, 3], [1, 3, 1], [0, 4, 3.5]]
};
const THEME = [[74, 0, 1.2], [72, 1.2, 0.6], [69, 1.8, 0.9], [67, 2.7, 0.6], [69, 3.3, 2.0], [64, 5.6, 0.8], [65, 6.4, 1.6]];

export class Music {
  constructor(sound) {
    this.s = sound;
    this.mood = 'menu';
    this.nextBar = 0;
    this.barIndex = 0;
    this.intensity = 0;
    this.enabled = true;
    this.silent = false;
    this.pad = [];
  }
  setMood(m) {
    if (m === this.mood) return;
    this.mood = m;
    // let the current bar ring out, then start the new mood promptly
    if (this.s.ctx) this.nextBar = Math.min(this.nextBar, this.s.ctx.currentTime + 1.5);
    this.barIndex = 0;
  }
  stopAll(fade = 1.5) {
    if (!this.s.ctx) return;
    const t = this.s.ctx.currentTime;
    for (const v of this.pad) { try { v.g.gain.cancelScheduledValues(t); v.g.gain.setTargetAtTime(0.0001, t, fade / 3); v.o.forEach(o => o.stop(t + fade + 0.5)); } catch (e) { } }
    this.pad = [];
    this.nextBar = t + fade + 0.5;
  }
  update(intensity = 0) {
    const s = this.s;
    if (!s.ready || !this.enabled) return;
    this.intensity = intensity;
    const ctx = s.ctx, now = ctx.currentTime;
    if (now < this.nextBar - 0.2) return;
    const M = MOODS[this.mood] || MOODS.station;
    const t0 = Math.max(now + 0.05, this.nextBar);
    const bar = M.bar * (1 - intensity * 0.25);
    // a bar of silence after every four, unless things are getting urgent
    const rest = this.barIndex > 0 && this.barIndex % 5 === 4 && intensity < 0.3 && this.mood !== 'menu' && this.mood !== 'ending';
    if (!rest) {
      const chord = M.chords[Math.floor(this.barIndex - Math.floor(this.barIndex / 5)) % M.chords.length];
      this.padChord(chord, t0, bar, M);
      // bells: a few notes from the chord, high up, unevenly placed
      const n = Math.random() < M.bells ? 1 + Math.floor(Math.random() * 3) : 0;
      for (let i = 0; i < n; i++) {
        const note = chord[1 + Math.floor(Math.random() * (chord.length - 1))] + 12 + (Math.random() < 0.3 ? 12 : 0);
        s.bell(hz(note), 4, 0.07, { at: t0 - now + 0.6 + Math.random() * (bar - 1.5), bus: 'music', ratio: 3.01, index: 1.1, delay: 0.5, wet: 0.6 });
      }
      if (M.theme && this.barIndex % 4 === 0) {
        for (const [note, at, len] of THEME) s.bell(hz(note), len + 2.5, 0.08, { at: t0 - now + at * (bar / 8.5), bus: 'music', ratio: 2.0, index: 0.9, delay: 0.45, wet: 0.5 });
      }
      const line = LINES[this.mood];
      if (line && this.barIndex % 5 === 2 && Math.random() < 0.8) {
        const top = chord.slice(1).sort((a, b) => b - a);
        const lift = top[0] < 62 ? 12 : 0;
        for (const [step, at, len] of line) {
          const n = top[Math.min(step, top.length - 1)] + lift;
          s.tone(hz(n), len * bar / 8 + 1.2, { at: t0 - now + 0.4 + at * bar / 8, gain: M.dark ? 0.03 : 0.036, type: 'triangle', attack: 0.08, bus: 'music', wet: 0.55, filter: 1800 });
          s.tone(hz(n + 12), len * bar / 8 * 0.6 + 0.6, { at: t0 - now + 0.42 + at * bar / 8, gain: 0.008, attack: 0.05, bus: 'music', wet: 0.7 });
        }
      }
      if (M.shimmer) for (let i = 0; i < 6; i++) s.tone(hz(chord[chord.length - 1] + 24 + [0, 2, 7][i % 3]), 1.2, { at: t0 - now + i * bar / 6, gain: 0.024, bus: 'music', wet: 0.8, attack: 0.4 });
    }
    // the pulse: a soft low heartbeat that quickens near the end
    if (intensity > 0.05) {
      const beat = 1.0 - intensity * 0.45;
      for (let t = 0; t < bar; t += beat) {
        s.tone(hz(26), 0.5, { at: t0 - now + t, gain: 0.22 * intensity, bus: 'music', wet: 0.1, attack: 0.01, to: hz(22) });
        if (intensity > 0.6) s.tone(hz(38), 0.3, { at: t0 - now + t + beat * 0.32, gain: 0.09 * intensity, bus: 'music', wet: 0.1, attack: 0.01 });
      }
    }
    this.nextBar = t0 + bar;
    this.barIndex++;
  }
  padChord(notes, t0, bar, M) {
    const s = this.s, ctx = s.ctx;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    const peak = M.dark ? 0.1 : 0.085;
    g.gain.exponentialRampToValueAtTime(peak, t0 + Math.min(3, bar * 0.35));
    g.gain.setValueAtTime(peak, t0 + bar - 0.5);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + bar + 3.5);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass';
    f.frequency.setValueAtTime(M.cut * (1 + this.intensity * 0.8), t0); f.Q.value = 0.5;
    f.frequency.linearRampToValueAtTime(M.cut * 0.7, t0 + bar + 3);
    g.connect(f);
    const out = s.out('music', 0.45); f.connect(out);
    const oscs = [];
    notes.forEach((n, i) => {
      for (const d of i === 0 ? [0] : [-7, 6]) {
        const o = ctx.createOscillator(); o.type = i === 0 ? 'triangle' : 'sawtooth';
        o.frequency.value = hz(n); o.detune.value = d;
        const og = ctx.createGain(); og.gain.value = i === 0 ? 0.9 : 0.22;
        o.connect(og); og.connect(g);
        o.start(t0); o.stop(t0 + bar + 4);
        oscs.push(o);
      }
    });
    const v = { g, o: oscs };
    this.pad.push(v);
    setTimeout(() => { this.pad = this.pad.filter(x => x !== v); }, (bar + 5) * 1000);
  }
}
