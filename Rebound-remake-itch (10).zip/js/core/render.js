// Renderer and post-processing: HDR scene target -> bloom mip chain -> composite
// (exposure, filmic curve, per-area grade, vignette, grain, collapse distortion, fade).
import * as THREE from '../../vendor/three.module.min.js';

const quadGeo = new THREE.BufferGeometry();
quadGeo.setAttribute('position', new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
const vert = `varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

function pass(frag, uniforms) {
  const m = new THREE.ShaderMaterial({ vertexShader: vert, fragmentShader: frag, uniforms, depthTest: false, depthWrite: false });
  const mesh = new THREE.Mesh(quadGeo, m); mesh.frustumCulled = false;
  const scene = new THREE.Scene(); scene.add(mesh);
  return { m, scene, u: uniforms };
}

const brightFrag = `
uniform sampler2D tSrc; uniform vec2 texel; uniform float threshold; varying vec2 vUv;
void main(){
  vec3 c = vec3(0.0);
  c += texture2D(tSrc, vUv + texel * vec2(-1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2(-1.0, 1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0, 1.0)).rgb;
  c *= 0.25;
  float l = max(c.r, max(c.g, c.b));
  float k = smoothstep(threshold, threshold * 2.2, l);
  gl_FragColor = vec4(min(c * k, vec3(40.0)), 1.0);
}`;
const downFrag = `
uniform sampler2D tSrc; uniform vec2 texel; varying vec2 vUv;
void main(){
  vec3 c = texture2D(tSrc, vUv).rgb * 4.0;
  c += texture2D(tSrc, vUv + texel * vec2(-1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2(-1.0, 1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0, 1.0)).rgb;
  gl_FragColor = vec4(c / 8.0, 1.0);
}`;
const upFrag = `
uniform sampler2D tSrc; uniform sampler2D tBase; uniform vec2 texel; uniform float mixAmt; varying vec2 vUv;
void main(){
  vec3 c = vec3(0.0);
  c += texture2D(tSrc, vUv + texel * vec2(-1.0, 0.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0, 0.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + texel * vec2( 0.0,-1.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + texel * vec2( 0.0, 1.0)).rgb * 2.0;
  c += texture2D(tSrc, vUv + texel * vec2(-1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2(-1.0, 1.0)).rgb;
  c += texture2D(tSrc, vUv + texel * vec2( 1.0, 1.0)).rgb;
  gl_FragColor = vec4(c / 12.0 + texture2D(tBase, vUv).rgb * mixAmt, 1.0);
}`;
const compFrag = `
uniform sampler2D tScene; uniform sampler2D tBloom;
uniform float bloom, exposure, time, grain, vignette, warp, aberr, fadeAmt, sat, contrast, bright;
uniform vec3 lift, gamma, gain, fadeCol;
uniform vec2 res;
varying vec2 vUv;
vec3 aces(vec3 x){ const float a=2.51,b=0.03,c=2.43,d=0.59,e=0.14; return clamp((x*(a*x+b))/(x*(c*x+d)+e),0.0,1.0); }
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453); }
void main(){
  vec2 uv = vUv;
  vec2 cc = uv - 0.5;
  float r2 = dot(cc, cc);
  // collapse distortion: a slow radial wave + pull towards the centre
  if (warp > 0.0) {
    float w = sin(r2 * 40.0 - time * 6.0) * 0.006 * warp;
    uv += cc * w - cc * warp * 0.05 * r2;
  }
  float ab = aberr * (0.4 + r2 * 2.5);
  vec3 col;
  col.r = texture2D(tScene, uv + cc * ab * 0.012).r;
  col.g = texture2D(tScene, uv).g;
  col.b = texture2D(tScene, uv - cc * ab * 0.012).b;
  col += texture2D(tBloom, uv).rgb * bloom;
  col *= exposure;
  col *= mix(1.0, bright, 0.35);
  col = aces(col);
  // brightness setting: lifts the shadows most, leaves highlights where they are
  col = pow(max(col, 0.0), vec3(1.0 / bright));
  // grade
  col = pow(max(col * gain + lift * (1.0 - col), 0.0), 1.0 / gamma);
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = mix(vec3(l), col, sat);
  col = (col - 0.5) * contrast + 0.5;
  // vignette
  col *= 1.0 - vignette * smoothstep(0.12, 0.85, r2 * 1.6);
  // grain (applied in perceptual space)
  col += (hash(uv * res + fract(time * 13.1)) - 0.5) * grain;
  col = mix(col, fadeCol, fadeAmt);
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}`;

export class Renderer {
  constructor(container) {
    this.r = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', stencil: false });
    this.r.setPixelRatio(1);
    this.r.outputColorSpace = THREE.LinearSRGBColorSpace;
    this.r.toneMapping = THREE.NoToneMapping;
    this.r.shadowMap.enabled = true;
    this.r.shadowMap.type = THREE.PCFSoftShadowMap;
    this.r.shadowMap.autoUpdate = true;
    container.appendChild(this.r.domElement);
    this.canvas = this.r.domElement;
    this.scale = 1;
    this.quality = 'high';
    this.bloomOn = true;
    const hf = { type: THREE.HalfFloatType, depthBuffer: false };
    this.sceneRT = new THREE.WebGLRenderTarget(4, 4, { type: THREE.HalfFloatType, samples: 4 });
    this.mips = [];
    for (let i = 0; i < 6; i++) this.mips.push(new THREE.WebGLRenderTarget(4, 4, hf));
    this.ups = [];
    for (let i = 0; i < 5; i++) this.ups.push(new THREE.WebGLRenderTarget(4, 4, hf));
    this.bright = pass(brightFrag, { tSrc: { value: null }, texel: { value: new THREE.Vector2() }, threshold: { value: 1.0 } });
    this.down = pass(downFrag, { tSrc: { value: null }, texel: { value: new THREE.Vector2() } });
    this.up = pass(upFrag, { tSrc: { value: null }, tBase: { value: null }, texel: { value: new THREE.Vector2() }, mixAmt: { value: 1 } });
    this.comp = pass(compFrag, {
      tScene: { value: null }, tBloom: { value: null }, bloom: { value: 0.6 }, exposure: { value: 1 }, bright: { value: 1 }, time: { value: 0 },
      grain: { value: 0.035 }, vignette: { value: 0.55 }, warp: { value: 0 }, aberr: { value: 0.25 }, fadeAmt: { value: 0 },
      fadeCol: { value: new THREE.Color(0, 0, 0) }, sat: { value: 1 }, contrast: { value: 1 },
      lift: { value: new THREE.Vector3(0, 0, 0) }, gamma: { value: new THREE.Vector3(1, 1, 1) }, gain: { value: new THREE.Vector3(1, 1, 1) },
      res: { value: new THREE.Vector2(1, 1) }
    });
    this.orthoCam = new THREE.Camera();
    this.grade = { lift: new THREE.Vector3(), gamma: new THREE.Vector3(1, 1, 1), gain: new THREE.Vector3(1, 1, 1), sat: 1, contrast: 1, exposure: 1, bloom: 0.6 };
    this.resize();
  }

  setQuality(q) {
    this.quality = q;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    // lowest is for old laptops: half the pixels, no shadows, no multisampling (and no bloom or grain, set by the game)
    this.scale = q === 'lowest' ? Math.min(dpr, 1) * 0.5 : q === 'low' ? Math.min(dpr, 1) * 0.75 : q === 'medium' ? Math.min(dpr, 1.25) : Math.min(dpr, 1.6);
    this.r.shadowMap.enabled = q !== 'low' && q !== 'lowest';
    this.sceneRT.samples = q === 'low' || q === 'lowest' ? 0 : 4;
    this.resize();
  }

  resize() {
    const w = Math.max(2, window.innerWidth), h = Math.max(2, window.innerHeight);
    this.r.setPixelRatio(this.scale);
    this.r.setSize(w, h, true);
    const W = Math.max(2, Math.floor(w * this.scale)), H = Math.max(2, Math.floor(h * this.scale));
    this.W = W; this.H = H;
    this.sceneRT.setSize(W, H);
    let mw = Math.max(1, W >> 1), mh = Math.max(1, H >> 1);
    for (let i = 0; i < this.mips.length; i++) {
      this.mips[i].setSize(mw, mh);
      if (i < this.ups.length) this.ups[i].setSize(mw, mh);
      mw = Math.max(1, mw >> 1); mh = Math.max(1, mh >> 1);
    }
    this.comp.u.res.value.set(W, H);
  }

  render(scene, camera, t) {
    const r = this.r;
    r.setRenderTarget(this.sceneRT);
    r.render(scene, camera);
    const g = this.grade, u = this.comp.u;
    let bloomTex = null;
    if (this.bloomOn) {
      // bright pass into mip 0
      this.bright.u.tSrc.value = this.sceneRT.texture;
      this.bright.u.texel.value.set(1 / this.W, 1 / this.H);
      r.setRenderTarget(this.mips[0]); r.render(this.bright.scene, this.orthoCam);
      for (let i = 1; i < this.mips.length; i++) {
        const src = this.mips[i - 1];
        this.down.u.tSrc.value = src.texture;
        this.down.u.texel.value.set(1 / src.width, 1 / src.height);
        r.setRenderTarget(this.mips[i]); r.render(this.down.scene, this.orthoCam);
      }
      // upsample: ups[i] = up(mips[i+1] or ups[i+1]) + mips[i]
      let src = this.mips[this.mips.length - 1];
      for (let i = this.ups.length - 1; i >= 0; i--) {
        this.up.u.tSrc.value = src.texture;
        this.up.u.tBase.value = this.mips[i].texture;
        this.up.u.texel.value.set(1 / src.width, 1 / src.height);
        this.up.u.mixAmt.value = 1;
        r.setRenderTarget(this.ups[i]); r.render(this.up.scene, this.orthoCam);
        src = this.ups[i];
      }
      bloomTex = this.ups[0].texture;
    }
    u.tScene.value = this.sceneRT.texture;
    u.tBloom.value = bloomTex || this.mips[this.mips.length - 1].texture;
    u.bloom.value = this.bloomOn ? g.bloom * 0.22 : 0;
    u.exposure.value = g.exposure;
    u.bright.value = this.brightness ?? 1;
    u.lift.value.copy(g.lift); u.gamma.value.copy(g.gamma); u.gain.value.copy(g.gain);
    u.sat.value = g.sat; u.contrast.value = g.contrast;
    u.time.value = t;
    r.setRenderTarget(null);
    r.render(this.comp.scene, this.orthoCam);
  }
}
