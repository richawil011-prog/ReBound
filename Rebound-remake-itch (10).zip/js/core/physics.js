// Collision world and first-person body.
// Colliders: oriented boxes (yaw only), walkable ramps and vertical cylinders.
// A chunk's offset moves all of its colliders (used by falling structures).

const CELL = 8;

export class Physics {
  constructor() {
    this.cells = new Map();
    this.dynamic = [];
    this.all = [];
  }
  addChunk(chunk) {
    for (const c of chunk.colliders) {
      this.all.push(c);
      if (chunk.dynamic) { this.dynamic.push(c); continue; }
      const x0 = Math.floor((c.x - c.br) / CELL), x1 = Math.floor((c.x + c.br) / CELL);
      const z0 = Math.floor((c.z - c.br) / CELL), z1 = Math.floor((c.z + c.br) / CELL);
      for (let i = x0; i <= x1; i++) for (let k = z0; k <= z1; k++) {
        const key = i * 4096 + k;
        let list = this.cells.get(key);
        if (!list) this.cells.set(key, list = []);
        list.push(c);
      }
    }
  }
  near(x, z, r, out = []) {
    out.length = 0;
    const x0 = Math.floor((x - r) / CELL), x1 = Math.floor((x + r) / CELL);
    const z0 = Math.floor((z - r) / CELL), z1 = Math.floor((z + r) / CELL);
    const stamp = ++this._stamp || (this._stamp = 1);
    for (let i = x0; i <= x1; i++) for (let k = z0; k <= z1; k++) {
      const list = this.cells.get(i * 4096 + k);
      if (!list) continue;
      for (const c of list) { if (c._s === stamp) continue; c._s = stamp; if (live(c)) out.push(c); }
    }
    for (const c of this.dynamic) if (live(c)) out.push(c);
    return out;
  }

  // highest walkable surface at (x,z) for a circle of radius r whose top is at or below maxY
  groundAt(x, z, r, maxY, list) {
    let best = -Infinity, bestC = null;
    for (const c of list) {
      const oy = c.chunk.offset.y, ox = c.chunk.offset.x, oz = c.chunk.offset.z;
      let top;
      if (c.type === 'cyl') {
        if (Math.hypot(x - c.x - ox, z - c.z - oz) > c.r + r * 0.6) continue;
        top = c.y1 + oy;
      } else {
        const dx = x - c.x - ox, dz = z - c.z - oz;
        const lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
        const m = r * 0.6;
        if (Math.abs(lx) > c.hx + m || Math.abs(lz) > c.hz + m) continue;
        if (c.type === 'box') top = c.y + c.hy + oy;
        else {
          const t = Math.max(0, Math.min(1, (lz + c.hz) / (2 * c.hz)));
          top = c.y0 + (c.y1 - c.y0) * t + oy;
        }
      }
      if (top <= maxY && top > best) { best = top; bestC = c; }
    }
    return [best, bestC];
  }

  // lowest ceiling above y
  ceilingAt(x, z, r, y, list) {
    let best = Infinity;
    for (const c of list) {
      if (c.type === 'ramp') continue;
      const oy = c.chunk.offset.y;
      let bottom;
      if (c.type === 'cyl') {
        if (Math.hypot(x - c.x - c.chunk.offset.x, z - c.z - c.chunk.offset.z) > c.r + r * 0.5) continue;
        bottom = c.y0 + oy;
      } else {
        const dx = x - c.x - c.chunk.offset.x, dz = z - c.z - c.chunk.offset.z;
        const lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
        if (Math.abs(lx) > c.hx + r * 0.5 || Math.abs(lz) > c.hz + r * 0.5) continue;
        bottom = c.y - c.hy + oy;
      }
      if (bottom >= y && bottom < best) best = bottom;
    }
    return best;
  }

  // push a vertical capsule (circle radius r between feet and head) out of solids
  resolve(body, list, step) {
    const r = body.radius;
    for (let pass = 0; pass < 3; pass++) {
      let moved = false;
      for (const c of list) {
        const oy = c.chunk.offset.y, ox = c.chunk.offset.x, oz = c.chunk.offset.z;
        let top, bottom;
        if (c.type === 'cyl') { top = c.y1 + oy; bottom = c.y0 + oy; }
        else if (c.type === 'box') { top = c.y + c.hy + oy; bottom = c.y - c.hy + oy; }
        else continue; // ramps are floors only
        if (top <= body.y + step || bottom >= body.y + body.height) continue;
        if (c.type === 'cyl') {
          const dx = body.x - c.x - ox, dz = body.z - c.z - oz, d = Math.hypot(dx, dz);
          const min = c.r + r;
          if (d < min) {
            const nx = d > 1e-5 ? dx / d : 1, nz = d > 1e-5 ? dz / d : 0;
            body.x += nx * (min - d); body.z += nz * (min - d); moved = true;
          }
        } else {
          const dx = body.x - c.x - ox, dz = body.z - c.z - oz;
          const lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
          const qx = Math.max(-c.hx, Math.min(c.hx, lx)), qz = Math.max(-c.hz, Math.min(c.hz, lz));
          let ex = lx - qx, ez = lz - qz, d = Math.hypot(ex, ez);
          if (d >= r) continue;
          let px, pz;
          if (d > 1e-5) { px = ex / d * (r - d); pz = ez / d * (r - d); }
          else { // centre inside the box: push out along the shallowest axis
            const ox2 = c.hx - Math.abs(lx), oz2 = c.hz - Math.abs(lz);
            if (ox2 < oz2) { px = Math.sign(lx || 1) * (ox2 + r); pz = 0; } else { px = 0; pz = Math.sign(lz || 1) * (oz2 + r); }
          }
          // back to world
          body.x += px * c.c + pz * c.s; body.z += -px * c.s + pz * c.c; moved = true;
        }
      }
      if (!moved) break;
    }
  }

  // ray against colliders, returns distance or Infinity. Used to stop interaction through walls.
  ray(ox, oy, oz, dx, dy, dz, maxD, ignore) {
    let best = maxD;
    const list = this.near(ox + dx * maxD / 2, oz + dz * maxD / 2, maxD / 2 + 1, []);
    for (const c of list) {
      if (ignore && ignore(c)) continue;
      const cy = c.chunk.offset.y;
      let t;
      if (c.type === 'cyl') t = rayCyl(ox - c.x, oy - cy, oz - c.z, dx, dy, dz, c.r, c.y0, c.y1);
      else if (c.type === 'box') {
        const px = ox - c.x, pz = oz - c.z;
        const lx = px * c.c - pz * c.s, lz = px * c.s + pz * c.c;
        const ldx = dx * c.c - dz * c.s, ldz = dx * c.s + dz * c.c;
        t = rayBox(lx, oy - c.y - cy, lz, ldx, dy, ldz, c.hx, c.hy, c.hz);
      } else continue;
      if (t >= 0 && t < best) best = t;
    }
    return best;
  }
}

function live(c) { return c.chunk.solid && c.enabled !== false; }

function rayBox(ox, oy, oz, dx, dy, dz, hx, hy, hz) {
  let tmin = -Infinity, tmax = Infinity;
  for (const [o, d, h] of [[ox, dx, hx], [oy, dy, hy], [oz, dz, hz]]) {
    if (Math.abs(d) < 1e-8) { if (o < -h || o > h) return -1; continue; }
    let t1 = (-h - o) / d, t2 = (h - o) / d;
    if (t1 > t2) [t1, t2] = [t2, t1];
    tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
    if (tmin > tmax) return -1;
  }
  return tmin >= 0 ? tmin : (tmax >= 0 ? 0 : -1);
}
function rayCyl(ox, oy, oz, dx, dy, dz, r, y0, y1) {
  const a = dx * dx + dz * dz, b = 2 * (ox * dx + oz * dz), cc = ox * ox + oz * oz - r * r;
  if (cc <= 0 && oy >= y0 && oy <= y1) return 0;
  if (a < 1e-9) return -1;
  const disc = b * b - 4 * a * cc;
  if (disc < 0) return -1;
  const t = (-b - Math.sqrt(disc)) / (2 * a);
  if (t < 0) return -1;
  const y = oy + dy * t;
  return y >= y0 && y <= y1 ? t : -1;
}

// ---------------------------------------------------------------------------------------
// First-person body

export class Body {
  constructor() {
    this.x = 0; this.y = 0; this.z = 0;
    this.vx = 0; this.vy = 0; this.vz = 0;
    this.yaw = 0; this.pitch = 0;
    this.radius = 0.32; this.height = 1.75; this.eye = 1.62;
    this.grounded = false; this.groundC = null;
    this.eyeOffset = 0;     // smooths step-ups
    this.airTime = 0;
    this.lastSafe = { x: 0, y: 0, z: 0, yaw: 0 };
    this.safeTimer = 0;
    this.noclip = false;
    this.landed = 0;        // impact speed of the last landing, consumed by audio
  }
  place(x, y, z, yaw = this.yaw) {
    this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.vx = this.vz = this.vy = 0;
    this.lastSafe = { x, y, z, yaw }; this.eyeOffset = 0;
  }
}

const scratch = [];
export function stepBody(phys, body, input, dt, opt = {}) {
  const STEP = 0.52;
  const speed = input.sprint ? 6.6 : 3.9;
  const accel = body.grounded ? 14 : 3;
  // desired velocity in world space
  const s = Math.sin(body.yaw), c = Math.cos(body.yaw);
  let mx = input.x, mz = input.z;
  const ml = Math.hypot(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
  const wx = (mx * c + mz * s) * speed, wz = (-mx * s + mz * c) * speed;
  const k = 1 - Math.exp(-accel * dt);
  body.vx += (wx - body.vx) * k; body.vz += (wz - body.vz) * k;

  if (body.noclip) {
    body.x += body.vx * dt * 2; body.z += body.vz * dt * 2;
    body.y += (input.up ? 6 : 0) * dt - (input.down ? 6 : 0) * dt;
    body.vy = 0; body.grounded = false; return;
  }

  // jump
  if (input.jump && body.grounded) { body.vy = 5.0; body.grounded = false; input.jump = false; }
  body.vy -= 15.5 * dt;
  if (body.vy < -40) body.vy = -40;

  // horizontal move in sub-steps
  const dist = Math.hypot(body.vx, body.vz) * dt;
  const n = Math.max(1, Math.ceil(dist / 0.18));
  const list = phys.near(body.x, body.z, 3 + dist, scratch);
  for (let i = 0; i < n; i++) {
    const px = body.x, pz = body.z;
    body.x += body.vx * dt / n; body.z += body.vz * dt / n;
    phys.resolve(body, list, body.grounded ? STEP : 0.12);
    // don't walk off ledges into the void while not moving intentionally? (no: allow falling)
    if (!isFinite(body.x)) { body.x = px; body.z = pz; }
  }

  // vertical
  const wasGrounded = body.grounded;
  const prevY = body.y;
  body.y += body.vy * dt;
  const [gy, gc] = phys.groundAt(body.x, body.z, body.radius, Math.max(prevY, body.y) + STEP, list);
  const snap = wasGrounded && body.vy <= 0 ? STEP : 0.02;
  if (gy > -Infinity && body.y <= gy + snap && body.vy <= 0.01) {
    if (!wasGrounded && body.vy < -3) body.landed = -body.vy;
    if (gy > body.y + 0.05) body.eyeOffset -= (gy - body.y);  // stepped up: let the eye catch up
    else if (wasGrounded && gy < body.y - 0.05) body.eyeOffset += (body.y - gy) * 0.6; // stepping down
    body.y = gy; body.vy = 0; body.grounded = true; body.groundC = gc;
    // ride moving platforms
    if (gc && gc.chunk.dynamic && gc.chunk._dy) body.y += gc.chunk._dy;
  } else {
    body.grounded = false; body.groundC = null;
  }
  // ceiling
  if (body.vy > 0) {
    const ceil = phys.ceilingAt(body.x, body.z, body.radius, prevY + body.height - 0.05, list);
    if (body.y + body.height > ceil) { body.y = ceil - body.height; body.vy = 0; }
  }
  body.eyeOffset *= Math.exp(-dt * 12);
  if (Math.abs(body.eyeOffset) < 1e-3) body.eyeOffset = 0;
  body.airTime = body.grounded ? 0 : body.airTime + dt;

  // remember the last good standing place, for recovering from falls into the sea
  body.safeTimer -= dt;
  if (body.grounded && body.safeTimer <= 0 && (!opt.unsafe || !opt.unsafe(body))) {
    body.safeTimer = 0.4;
    // only accept places with ground under a slightly larger circle (not ledge tips)
    body.lastSafe = { x: body.x, y: body.y, z: body.z, yaw: body.yaw };
  }
}
