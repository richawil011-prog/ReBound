// Geometry batching. Every piece of architecture is added to a Chunk, which merges
// everything that shares a material into one mesh and keeps its own colliders.
// Chunks can be moved as a whole (falling towers, the span, the end-of-loop collapse).
import * as THREE from '../../vendor/three.module.min.js';

const tmpV = new THREE.Vector3();
const tmpN = new THREE.Vector3();
const tmpC = new THREE.Color();
const nMat = new THREE.Matrix3();
const WHITE = new THREE.Color(1, 1, 1);

export class Chunk {
  constructor(name, opts = {}) {
    this.name = name;
    this.group = new THREE.Group();
    this.group.name = name;
    this.parts = new Map();
    this.colliders = [];
    this.offset = new THREE.Vector3();
    this.dynamic = !!opts.dynamic;
    this.shadows = opts.shadows !== false;
    this.solid = true;          // colliders active
    this.extra = [];            // un-merged meshes that belong to the chunk
  }

  // ----- geometry -----
  // Adds any THREE geometry, transformed by matrix. tint multiplies the vertex colour,
  // ao darkens the bottom `ao` metres of the piece (contact shadow), aoMin is the darkest value.
  geo(geometry, material, matrix, o = {}) {
    let g = geometry.index ? geometry.toNonIndexed() : geometry;
    const pos = g.attributes.position, nor = g.attributes.normal, uv = g.attributes.uv;
    let part = this.parts.get(material);
    if (!part) { part = { pos: [], nor: [], uv: [], col: [] }; this.parts.set(material, part); }
    nMat.getNormalMatrix(matrix);
    const tint = o.tint ? tmpC.set(o.tint) : WHITE;
    const tr = tint.r, tg = tint.g, tb = tint.b;
    const ao = o.ao ?? 0, aoMin = o.aoMin ?? 0.45, top = o.topLight ?? 0;
    // world-space min/max y of this piece for AO
    let minY = Infinity, maxY = -Infinity;
    const world = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      tmpV.fromBufferAttribute(pos, i).applyMatrix4(matrix);
      world[i * 3] = tmpV.x; world[i * 3 + 1] = tmpV.y; world[i * 3 + 2] = tmpV.z;
      if (tmpV.y < minY) minY = tmpV.y; if (tmpV.y > maxY) maxY = tmpV.y;
    }
    // for the floating-object check in the tests: every piece's bounds, recorded only when asked for
    if (typeof window !== 'undefined' && window.__rbParts) {
      const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
      for (let i = 0; i < world.length; i += 3) for (let a = 0; a < 3; a++) { const v = world[i + a]; if (v < lo[a]) lo[a] = v; if (v > hi[a]) hi[a] = v; }
      const where = (new Error().stack || '').split('\n').find(l => /\/world\/(?!.*build\.js)/.test(l) && !/build\.js/.test(l)) || '';
      window.__rbParts.push({ c: this.name, m: material.name || material.type, lo, hi, at: (where.match(/world\/([\w.]+:\d+)/) || [])[1] });
    }
    for (let i = 0; i < pos.count; i++) {
      const x = world[i * 3], y = world[i * 3 + 1], z = world[i * 3 + 2];
      part.pos.push(x, y, z);
      tmpN.fromBufferAttribute(nor, i).applyMatrix3(nMat).normalize();
      part.nor.push(tmpN.x, tmpN.y, tmpN.z);
      if (uv) part.uv.push(uv.getX(i), uv.getY(i)); else part.uv.push(0, 0);
      let k = 1;
      if (ao > 0) { const t = Math.min(1, Math.max(0, (y - minY) / ao)); k = aoMin + (1 - aoMin) * (t * t * (3 - 2 * t)); }
      if (top > 0) k *= 1 + top * Math.max(0, (y - minY) / Math.max(0.001, maxY - minY) - 0.5);
      if (tmpN.y < -0.5) k *= o.under ?? 0.7; // undersides read darker
      part.col.push(tr * k, tg * k, tb * k);
    }
    if (g !== geometry) g.dispose();
    return this;
  }

  // Box occupying x±w/2, y..y+h, z±d/2 (base convention), rotated by yaw around its centre.
  box(x, y, z, w, h, d, material, o = {}) {
    const yaw = o.yaw || 0;
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(x, y + h / 2, z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(o.pitch || 0, yaw, o.roll || 0, 'YXZ')),
      new THREE.Vector3(w, h, d));
    this.geo(boxGeo(w, h, d), material, m, { ao: o.ao ?? Math.min(h, 1.4), aoMin: o.aoMin, tint: o.tint, under: o.under });
    if (o.collide !== false && !o.pitch && !o.roll) this.collider({ type: 'box', x, y: y + h / 2, z, hx: w / 2, hy: h / 2, hz: d / 2, yaw, tag: o.tag });
    return this;
  }

  // vertical cylinder, base at y
  cyl(x, y, z, r, h, material, o = {}) {
    const seg = o.seg || Math.max(10, Math.min(48, Math.round(r * 10)));
    const g = new THREE.CylinderGeometry(o.rTop ?? r, r, h, seg, 1, !!o.open);
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x, y + h / 2, z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(o.pitch || 0, o.yaw || 0, o.roll || 0)), new THREE.Vector3(1, 1, 1));
    this.geo(g, material, m, { ao: o.ao ?? Math.min(h, 1.2), aoMin: o.aoMin, tint: o.tint });
    g.dispose();
    if (o.collide !== false && !o.pitch && !o.roll) this.collider({ type: 'cyl', x, z, r: Math.max(r, o.rTop ?? r), y0: y, y1: y + h, tag: o.tag });
    return this;
  }

  // a ring wall / annulus slab between r0 and r1, from angle a0 to a1 (radians, 0 = +z, clockwise towards +x)
  ring(x, y, z, r0, r1, h, material, o = {}) {
    const a0 = o.a0 ?? 0, a1 = o.a1 ?? Math.PI * 2;
    const seg = o.seg || Math.max(8, Math.round((a1 - a0) * (r1 + r0) * 0.9));
    const shape = new THREE.Shape();
    // build annulus sector in XZ (shape in XY then rotate)
    const pt = (r, a) => new THREE.Vector2(Math.sin(a) * r, -Math.cos(a) * r);
    const outer = [], inner = [];
    for (let i = 0; i <= seg; i++) { const a = a0 + (a1 - a0) * i / seg; outer.push(pt(r1, a)); inner.push(pt(r0, a)); }
    const full = (a1 - a0) >= Math.PI * 2 - 1e-4;
    let g;
    if (full) {
      shape.setFromPoints(outer.slice(0, -1));
      const hole = new THREE.Path(); hole.setFromPoints(inner.slice(0, -1).reverse()); shape.holes.push(hole);
    } else {
      shape.setFromPoints([...outer, ...inner.reverse()]);
    }
    g = new THREE.ExtrudeGeometry(shape, { depth: h, bevelEnabled: false, curveSegments: 1 });
    // shape XY -> world XZ: rotate so shape Y maps to +z and extrusion goes up
    // shape (sx, sy) with extrusion ez  ->  world (x + sx, y + ez, z - sy)
    const m = new THREE.Matrix4().set(1, 0, 0, x, 0, 0, 1, y, 0, -1, 0, z, 0, 0, 0, 1);
    this.geo(g, material, m, { ao: o.ao ?? Math.min(h, 1.2), aoMin: o.aoMin, tint: o.tint, under: o.under });
    g.dispose();
    if (o.collide !== false) {
      // approximate with rotated boxes along the arc
      const n = o.colSeg || Math.max(6, Math.round((a1 - a0) * r1 / 1.6));
      const rm = (r0 + r1) / 2, thick = r1 - r0;
      for (let i = 0; i < n; i++) {
        const a = a0 + (a1 - a0) * (i + 0.5) / n;
        const len = 2 * rm * Math.sin((a1 - a0) / n / 2) + 0.08 + (thick > 2 ? 0 : 0.0);
        if (thick > 2.5) {
          // wide annulus (a floor): use several radial boxes
          const steps = Math.ceil(thick / 2);
          for (let k = 0; k < steps; k++) {
            const rr = r0 + thick * (k + 0.5) / steps, l2 = 2 * rr * Math.sin((a1 - a0) / n / 2) + 0.3;
            this.collider({ type: 'box', x: x + Math.sin(a) * rr, y: y + h / 2, z: z + Math.cos(a) * rr, hx: l2 / 2, hy: h / 2, hz: thick / steps / 2 + 0.05, yaw: a, tag: o.tag });
          }
        } else {
          this.collider({ type: 'box', x: x + Math.sin(a) * rm, y: y + h / 2, z: z + Math.cos(a) * rm, hx: len / 2, hy: h / 2, hz: thick / 2, yaw: a, tag: o.tag });
        }
      }
    }
    return this;
  }

  // Walkable slope. Runs along local z from (y0 at z-d/2) to (y1 at z+d/2), rotated by yaw.
  ramp(x, z, w, d, y0, y1, thick, material, o = {}) {
    const yaw = o.yaw || 0;
    const len = Math.hypot(d, y1 - y0), pitch = Math.atan2(y1 - y0, d);
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x, (y0 + y1) / 2 - thick / 2, z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(-pitch, yaw, 0, 'YXZ')), new THREE.Vector3(w, thick, len));
    this.geo(boxGeo(w, thick, len), material, m, { ao: 0, tint: o.tint });
    this.collider({ type: 'ramp', x, z, hx: w / 2, hz: d / 2, yaw, y0, y1, thick, tag: o.tag });
    return this;
  }

  // straight flight of steps from (x,z) going along yaw direction; each riser rh, tread td
  stairs(x, y, z, w, steps, rh, td, material, o = {}) {
    const yaw = o.yaw || 0, s = Math.sin(yaw), c = Math.cos(yaw);
    for (let i = 0; i < steps; i++) {
      const along = td * (i + 0.5);
      const h = rh * (i + 1);
      // solid steps down to base y (so no floating stairs)
      const bx = x - s * along, bz = z - c * along;
      this.box(bx, o.solidBase ? y : y + h - (o.thick ?? 0.35), bz, w, o.solidBase ? h : (o.thick ?? 0.35), td + 0.02, material, { yaw, ao: 0, tint: o.tint, tag: o.tag });
    }
    return this;
  }

  collider(c) {
    c.chunk = this;
    if (c.type === 'box' || c.type === 'ramp') { c.c = Math.cos(c.yaw || 0); c.s = Math.sin(c.yaw || 0); }
    // bounding radius for broadphase
    c.br = c.type === 'cyl' ? c.r : Math.hypot(c.hx, c.hz);
    this.colliders.push(c);
    return c;
  }

  mesh(object) { this.extra.push(object); this.group.add(object); return object; }

  finalize() {
    // world-space bounds of everything in the chunk (used for effects)
    this.bounds = new THREE.Box3();
    for (const [, p] of this.parts) for (let i = 0; i < p.pos.length; i += 3) this.bounds.expandByPoint(tmpV.set(p.pos[i], p.pos[i + 1], p.pos[i + 2]));
    for (const [mat, p] of this.parts) {
      if (!p.pos.length) continue;
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(p.pos, 3));
      g.setAttribute('normal', new THREE.Float32BufferAttribute(p.nor, 3));
      g.setAttribute('uv', new THREE.Float32BufferAttribute(p.uv, 2));
      g.setAttribute('color', new THREE.Float32BufferAttribute(p.col, 3));
      g.computeBoundingSphere(); g.computeBoundingBox();
      const mesh = new THREE.Mesh(g, mat);
      mesh.castShadow = this.shadows && !mat.userData.noShadow;
      mesh.receiveShadow = !mat.userData.noReceive;
      mesh.matrixAutoUpdate = false;
      mesh.updateMatrix();
      this.group.add(mesh);
    }
    this.parts.clear();
    return this;
  }
}

const boxCache = new Map();
function boxGeo(w, h, d) {
  // unit box with uvs scaled by real size so textures keep metric scale
  const key = [w, h, d].map(v => v.toFixed(2)).join(',');
  let g = boxCache.get(key);
  if (!g) {
    g = new THREE.BoxGeometry(1, 1, 1).toNonIndexed();
    const uv = g.attributes.uv, n = g.attributes.normal;
    for (let i = 0; i < uv.count; i++) {
      const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i));
      const su = ax > .5 ? d : w, sv = ay > .5 ? d : h;
      uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv);
    }
    if (boxCache.size < 4000) boxCache.set(key, g);
  }
  return g;
}

// Small helper for lights that should glow: a set of anchors that the renderer assigns a
// fixed pool of point lights to, nearest first.
export class LightPool {
  constructor(scene, count = 8) {
    this.anchors = [];
    this.lights = [];
    for (let i = 0; i < count; i++) {
      const l = new THREE.PointLight(0xffffff, 0, 10, 1.25);
      l.castShadow = false;
      scene.add(l);
      this.lights.push(l);
    }
  }
  add(x, y, z, color, intensity, distance, o = {}) {
    const a = { x, y, z, color: new THREE.Color(color), intensity, distance, on: true, flicker: o.flicker || 0, chunk: o.chunk || null, level: 1, key: o.key };
    this.anchors.push(a);
    return a;
  }
  update(cam, time) {
    const px = cam.x, py = cam.y, pz = cam.z;
    const list = [];
    for (const a of this.anchors) {
      if (!a.on || a.level <= 0.01) continue;
      const oy = a.chunk ? a.chunk.offset.y : 0;
      const d = Math.hypot(a.x - px, (a.y + oy - py) * 1.5, a.z - pz) - a.distance * 0.5;
      list.push([d, a]);
    }
    list.sort((p, q) => p[0] - q[0]);
    for (let i = 0; i < this.lights.length; i++) {
      const l = this.lights[i], e = list[i];
      if (!e) { l.intensity = 0; continue; }
      const a = e[1];
      const oy = a.chunk ? a.chunk.offset.y : 0;
      l.position.set(a.x, a.y + oy, a.z);
      l.color.copy(a.color);
      l.distance = a.distance;
      let f = 1;
      const fl = a.flicker + (a.flickerBoost || 0);
      if (fl) f = 1 - Math.min(1, fl) * (0.5 + 0.5 * Math.sin(time * 23 + a.x * 3)) * (Math.sin(time * 7.3 + a.z) > 0.6 ? 1 : 0.15);
      // fade lights in as they enter the pool so swaps never pop
      const fade = Math.max(0, Math.min(1, 1 - (e[0] - 18) / 10));
      l.intensity = a.intensity * a.level * f * fade * 3.2;
    }
  }
}
